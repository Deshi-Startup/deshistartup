---
source: "Startup Bangladesh reports"
tier: 2
category: "Ecosystem report"
url: "https://www.startupbangladesh.vc/media/gallery/"
title: "Startup Bangladesh Limited - GalleryStartup Bangladesh Limited - Gallery"
scraped_at: "2026-07-02"
---

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/) 

[Apply Now](http://www.startupbangladesh.vc/contact/apply-for-investment/)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg) 

#### about

#### Fund of Funds

#### Portfolio

#### Partners

#### NRB Connect

#### media

#### career

#### contact

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/des-close.svg)

#### Bangladesh National Parliament House

Jatiya Sangsad Bhaban or National Parliament House, is the house of the Parliament of Bangladesh, located at Sher-e-Bangla Nagar in the Bangladeshi capital of Dhaka.

[Learn more](javascript:)

Photo by Unknown

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/)  

[Apply Now](https://www.startupbangladesh.vc/contact/apply-for-investment/)

-   -   [About](javascript:)
        
    -   [Fund of Funds](javascript:)
        
    -   [Portfolio](javascript:)
        
    -   [Partners](javascript:)
        
    -   [NRB Connect](javascript:)
        
    -   [media](javascript:)
        
    -   [career](javascript:)
        
    -   [contact](javascript:)
        

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

-   [](https://www.startupbangladesh.vc/media/news)
-   [](https://www.startupbangladesh.vc/media/media-videos)

Gallery ![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/caret.svg) 

-   [Photos](https://www.startupbangladesh.vc/media/media-photo/)
-   [Videos](https://www.startupbangladesh.vc/media/media-videos/)

## Gallery

[](https://www.startupbangladesh.vc/photos/bangladesh-startup-summit-2023/)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Bangladesh Startup Summit 2023

© 2025 Startup Bangladesh Limited