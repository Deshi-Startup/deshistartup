---
source: "Startup Bangladesh reports"
tier: 2
category: "Ecosystem report"
url: "https://www.startupbangladesh.vc/sbl-young-ambassadors/"
title: "Startup Bangladesh Limited - SBL Young AmbassadorsStartup Bangladesh Limited - SBL Young Ambassadors"
scraped_at: "2026-07-02"
---

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/) 

[Apply Now](http://www.startupbangladesh.vc/contact/apply-for-investment/)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg) 

#### about

#### Fund of Funds

#### Portfolio

#### Partners

#### NRB Connect

#### media

#### career

#### contact

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/des-close.svg)

#### Bangladesh National Parliament House

Jatiya Sangsad Bhaban or National Parliament House, is the house of the Parliament of Bangladesh, located at Sher-e-Bangla Nagar in the Bangladeshi capital of Dhaka.

[Learn more](javascript:)

Photo by Unknown

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/)  

[Apply Now](https://www.startupbangladesh.vc/contact/apply-for-investment/)

-   -   [About](javascript:)
        
    -   [Fund of Funds](javascript:)
        
    -   [Portfolio](javascript:)
        
    -   [Partners](javascript:)
        
    -   [NRB Connect](javascript:)
        
    -   [media](javascript:)
        
    -   [career](javascript:)
        
    -   [contact](javascript:)
        

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

-   [](https://www.startupbangladesh.vc/sbl-young-ambassador-program/)
-   [](https://www.startupbangladesh.vc/nrb-contact/)

SBL Young Ambassadors ![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/caret.svg) 

-   [SBL NRB Connect](https://www.startupbangladesh.vc/sbl-nrb-connect/)
-   [NRB–Startup Bridge](https://www.startupbangladesh.vc/nrb-reconnect-and-rebuild/)
-   [NRB Desk Services](https://www.startupbangladesh.vc/nrb-connect-services/)
-   [SBL Young Ambassador Program](https://www.startupbangladesh.vc/sbl-young-ambassador-program/)
-   [SBL Young Ambassadors](https://www.startupbangladesh.vc/sbl-young-ambassadors/)
-   [NRB Program Contact](https://www.startupbangladesh.vc/nrb-contact/)

## SBL Young Ambassadors

**North American Representatives:**

![Anisa Adiba](https://www.startupbangladesh.vc/wp-content/uploads/2026/01/Anisa-Adiba2.jpeg)

#### Anisa Adiba

[LinkedIn](https://www.linkedin.com/in/anisa43870?utm_source=share_via&utm_content=profile&utm_medium=member_ios)

![Akib Zaman](https://www.startupbangladesh.vc/wp-content/uploads/2026/01/akib.jpeg)

#### Akib Zaman

[LinkedIn](https://www.linkedin.com/in/akib-zaman-081ab9184/)

**European Representatives:**

![Fuad Alam](https://www.startupbangladesh.vc/wp-content/uploads/2026/01/fuad.jpeg)

#### Fuad Alam

[LinkedIn](https://www.linkedin.com/in/alam-fuad/)

![Ruzlin Akter](https://www.startupbangladesh.vc/wp-content/uploads/2026/01/Ruzlin.jpeg)

#### Ruzlin Akter

[LinkedIn](https://www.linkedin.com/in/ruzlin-a-02109b229/)

**Bangladeshi Representatives:**

![A H M Rafsan Uddin Khandaker](https://www.startupbangladesh.vc/wp-content/uploads/2025/12/Rafsan-Uddin-Khandaker.png)

#### A H M Rafsan Uddin Khandaker

[LinkedIn](https://www.linkedin.com/in/ahmrafsanuddinkhondokar?utm_source=share_via&utm_content=profile&utm_medium=member_ios)

![Mahirul Islam](https://www.startupbangladesh.vc/wp-content/uploads/2025/12/Mahirul-Islam.jpeg)

#### Mahirul Islam

[LinkedIn](https://www.linkedin.com/in/mahirul-10-islam?utm_source=share_via&utm_content=profile&utm_medium=member_ios)

![Md. Rafidul Islam](https://www.startupbangladesh.vc/wp-content/uploads/2026/01/rafidul.jpeg)

#### Md. Rafidul Islam

[LinkedIn](https://bd.linkedin.com/in/rafidul-islam-44b092172)

![Jubair Mahamud Apon](https://www.startupbangladesh.vc/wp-content/uploads/2026/01/Apon-.jpeg)

#### Jubair Mahamud Apon

[LinkedIn](https://www.linkedin.com/in/jubairmahamudapon/)

![Faridul Hasan Shuvo](https://www.startupbangladesh.vc/wp-content/uploads/2026/01/Faridul-Hasan-Shuvo.jpeg)

#### Faridul Hasan Shuvo

[LinkedIn](https://www.linkedin.com/in/faridulhasanshuvo/)

![Anonna Dev Nipa](https://www.startupbangladesh.vc/wp-content/uploads/2026/02/Anonna-Dev-Nipa.jpeg)

#### Anonna Dev Nipa

[LinkedIn](https://www.linkedin.com/in/anonna-dev-nipa-756a1b228)

© 2025 Startup Bangladesh Limited

\-->