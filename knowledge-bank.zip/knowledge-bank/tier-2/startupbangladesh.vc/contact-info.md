---
source: "Startup Bangladesh reports"
tier: 2
category: "Ecosystem report"
url: "https://www.startupbangladesh.vc/contact/contact-info/"
title: "Startup Bangladesh Limited - InformationStartup Bangladesh Limited - Information"
scraped_at: "2026-07-02"
---

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/) 

[Apply Now](http://www.startupbangladesh.vc/contact/apply-for-investment/)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg) 

#### about

#### Fund of Funds

#### Portfolio

#### Partners

#### NRB Connect

#### media

#### career

#### contact

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/des-close.svg)

#### Bangladesh National Parliament House

Jatiya Sangsad Bhaban or National Parliament House, is the house of the Parliament of Bangladesh, located at Sher-e-Bangla Nagar in the Bangladeshi capital of Dhaka.

[Learn more](javascript:)

Photo by Unknown

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/)  

[Apply Now](https://www.startupbangladesh.vc/contact/apply-for-investment/)

-   -   [About](javascript:)
        
    -   [Fund of Funds](javascript:)
        
    -   [Portfolio](javascript:)
        
    -   [Partners](javascript:)
        
    -   [NRB Connect](javascript:)
        
    -   [media](javascript:)
        
    -   [career](javascript:)
        
    -   [contact](javascript:)
        

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

-   [](https://www.startupbangladesh.vc/contact/apply-for-investment/)
-   [](https://startupbangladesh.vc/contact/contact-enquiries/)

Information ![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/caret.svg) 

-   [Application for Investment](https://www.startupbangladesh.vc/contact/apply-for-investment/)
-   [Information](https://www.startupbangladesh.vc/contact/contact-info/)
-   [Enquiries](https://www.startupbangladesh.vc/contact/contact-enquiries/)
-   [FAQ](https://www.startupbangladesh.vc/contact/faqs/)

## Information

**Startup Bangladesh Limited.**

**Address:** ICT Tower (Level-14), Plot: E-14/X, Agargaon, Dhaka-1207.

**Email:**

For general enquiry: info@startupbangladesh.gov.bd  
For investment enquiry: investment@startupbangladesh.gov.bd

**Cell** (Calls Only, Sunday – Thursday: 9:00 AM – 5:00 PM)**:**

**For general enquiry:** +880255006433

**RTI Officer:**  
Designated Officer Name: Nazmul Huda  
Designation: Assistant Vice President – Compliance and HR  
Email: nazmul@startupbangladesh.gov.bd

Alternative Designated Officer Name: Mehedi Hasan  
Designation: Executive – Compliance and HR  
Email: mehedi@startupbangladesh.gov.bd

Appellate Authority:  
Secretary  
Office: Information and Communication Technology Division  
Ministry of Posts, Telecommunication and Information Technology  
Phone (Office) +88-02-41024031  
Email: secretary@ictd.gov.bd

© 2025 Startup Bangladesh Limited