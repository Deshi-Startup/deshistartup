---
source: "Startup Bangladesh reports"
tier: 2
category: "Ecosystem report"
url: "https://www.startupbangladesh.vc/fund-of-funds-overview/"
title: "Startup Bangladesh Limited - Fund of Funds OverviewStartup Bangladesh Limited - Fund of Funds Overview"
scraped_at: "2026-07-02"
---

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/) 

[Apply Now](http://www.startupbangladesh.vc/contact/apply-for-investment/)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg) 

#### about

#### Fund of Funds

#### Portfolio

#### Partners

#### NRB Connect

#### media

#### career

#### contact

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/des-close.svg)

#### Bangladesh National Parliament House

Jatiya Sangsad Bhaban or National Parliament House, is the house of the Parliament of Bangladesh, located at Sher-e-Bangla Nagar in the Bangladeshi capital of Dhaka.

[Learn more](javascript:)

Photo by Unknown

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/)  

[Apply Now](https://www.startupbangladesh.vc/contact/apply-for-investment/)

-   -   [About](javascript:)
        
    -   [Fund of Funds](javascript:)
        
    -   [Portfolio](javascript:)
        
    -   [Partners](javascript:)
        
    -   [NRB Connect](javascript:)
        
    -   [media](javascript:)
        
    -   [career](javascript:)
        
    -   [contact](javascript:)
        

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

-   [](https://www.startupbangladesh.vc/apply-for-fund-of-funds/)
-   [](https://www.startupbangladesh.vc/eligibility-criteria-for-fund-managers)

Fund of Funds Overview ![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/caret.svg) 

-   [Fund of Funds Overview](https://www.startupbangladesh.vc/fund-of-funds-overview/)
-   [Eligibility Criteria for Fund Managers](https://www.startupbangladesh.vc/eligibility-criteria-for-fund-managers/)
-   [Apply for Fund of Funds](https://www.startupbangladesh.vc/apply-for-fund-of-funds/)

## Fund of Funds Overview

Our initial Fund of Funds (FoF) size is USD 33 million, with the flexibility to scale further. We will deploy these funds for direct investments in partnership funds established in collaboration with local and global Venture Capital Fund Managers with the mandate to invest in Bangladesh. Additionally, a portion of the total fund will be allocated for strengthening the startup ecosystem, including investments in government-approved incubators, accelerators, and challenger funds. The life of the FoF will be 30 years, after which a decision will be made on whether to transition it into an evergreen fund.

**Objectives of the Fund of Funds**

The Fund of Funds holds a three-pronged objective –

-   1\. Enhance mobilization of foreign capital and promote foreign market access
-   2\. Stimulate local funding to advance the local VCs and attract funding from local LPs
-   3\. Drive sustainable development by contributing towards impact goals aligning with national priorities

  
  
**

## Investment Strategy

**

Our mandate is to catalyze Bangladesh’s venture capital ecosystem by investing in high-potential international, regional, and local funds that drive innovation, economic growth, and impact. Beyond capital deployment, we provide strategic guidance, facilitate co-investments, and support ecosystem development.

Our investment strategy focuses on value creation, diversification, and risk management. We rigorously evaluate fund managers based on track record, investment thesis, and return potential to ensure both strong financial performance and long-term impact.

We maintain a sector- and stage-agnostic approach while prioritizing high-growth sectors such as financial services, e-commerce, logistics, healthcare, education, and agriculture.

Additionally, we integrate ESG principles to ensure sustainable, long-term value creation for investors and the broader economy.

  
  

**For More Information:**  
Email: rashel@startupbangladeshvc.gov.bd  

© 2025 Startup Bangladesh Limited

\-->