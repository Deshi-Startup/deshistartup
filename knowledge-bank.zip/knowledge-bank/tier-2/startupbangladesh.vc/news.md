---
source: "Startup Bangladesh reports"
tier: 2
category: "Ecosystem report"
url: "https://www.startupbangladesh.vc/media/news/"
title: "Startup Bangladesh Limited - NewsStartup Bangladesh Limited - News"
scraped_at: "2026-07-02"
---

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/) 

[Apply Now](http://www.startupbangladesh.vc/contact/apply-for-investment/)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg) 

#### about

#### Fund of Funds

#### Portfolio

#### Partners

#### NRB Connect

#### media

#### career

#### contact

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/des-close.svg)

#### Bangladesh National Parliament House

Jatiya Sangsad Bhaban or National Parliament House, is the house of the Parliament of Bangladesh, located at Sher-e-Bangla Nagar in the Bangladeshi capital of Dhaka.

[Learn more](javascript:)

Photo by Unknown

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/)  

[Apply Now](https://www.startupbangladesh.vc/contact/apply-for-investment/)

-   -   [About](javascript:)
        
    -   [Fund of Funds](javascript:)
        
    -   [Portfolio](javascript:)
        
    -   [Partners](javascript:)
        
    -   [NRB Connect](javascript:)
        
    -   [media](javascript:)
        
    -   [career](javascript:)
        
    -   [contact](javascript:)
        

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

-   [](https://www.startupbangladesh.vc/media/latest-reports/)
-   [](https://www.startupbangladesh.vc/media/media-photo/)

Newsroom ![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/caret.svg) 

-   [Newsroom](https://www.startupbangladesh.vc/media/news/)
-   [Gallery](https://www.startupbangladesh.vc/media/gallery/)
-   [Events](https://www.startupbangladesh.vc/media/media_events/)
-   [Notice](https://www.startupbangladesh.vc/media/notice/)
-   [Newsletter](https://www.startupbangladesh.vc/media/media_resources/)
-   [Latest Reports](https://www.startupbangladesh.vc/media/latest-reports/)

## Newsroom

[](<

                                https://www.startupbangladesh.vc/driving-bangladeshs-sustainable-finance-and-innovation-agenda/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Driving Bangladesh’s Sustainable Finance and Innovation Agenda

[](<

                                https://www.startupbangladesh.vc/startup-bangladesh-participates-in-yess-program-to-inspire-young-entrepreneurs-in-khulna/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Startup Bangladesh Participates in YESS Program to Inspire Young Entrepreneurs in Khulna

[](<

                                https://www.startupbangladesh.vc/startup-bangladesh-and-lightcastle-partners-alliance/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Startup Bangladesh and LightCastle Partners Form Strategic Alliance to Accelerate Bangladesh’s Startup Ecosystem

[](<

                                https://www.startupbangladesh.vc/device-innovation-expo-2026/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Bangladesh Charts a Sustainable Path for ICT Startups at Digital Device & Innovation Expo 2026

[](<

                                https://www.startupbangladesh.vc/sbl-portfolio-night-2026/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### SBL Portfolio Night 2026

[](<

                                https://www.startupbangladesh.vc/portfolio_ifarmer_folon/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### iFarmer’s Folon: Empowering Farmers, Fueling Smart Agriculture in Bangladesh

[](<

                                https://www.startupbangladesh.vc/sbl-welcomes-mr-nurul-hai/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Startup Bangladesh Appoints Mr. Nurul Hai as New Managing Director

[](<

                                https://www.startupbangladesh.vc/empowering-the-next-generation-a-seminar-that-amplifies-the-voice-of-young-innovators-in-bangladesh/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Empowering the Next Generation: A Seminar that Amplifies the Voice of Young Innovators in Bangladesh

[](<

                                https://www.startupbangladesh.vc/startup-bangladesh-shares-roadmap-to-strengthen-innovation-and-startup-landscape/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Startup Bangladesh Shares Roadmap to Strengthen Innovation and Startup Landscape

[](<

                                https://www.startupbangladesh.vc/markopolo-ai-raises-usd-2-million/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Markopolo.ai Raises USD 2 Million to Accelerate Growth in Saudi Arabia

[](<

                                https://www.startupbangladesh.vc/startup-bangladesh-shikho/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Startup Bangladesh Announces Strategic Investment in Shikho to Accelerate AI-Powered Learning in Bangladesh

[](<

                                https://www.startupbangladesh.vc/northrim-labs-wins-the-youth-innovation-challenge-2025-in-the-dhaka-and-mymensingh-segment-in-the-youth-startup-summit/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Northrim Labs wins the Youth Innovation Challenge 2025 in the Dhaka and Mymensingh segment in the Youth Startup Summit

[](<

                                https://www.startupbangladesh.vc/uniapp-wins-the-youth-innovation-challenge-2025-in-the-chittagong-segment-in-the-youth-startup-summit/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### UniApp wins the Youth Innovation Challenge 2025 in the Chittagong segment in the Youth Startup Summit

[](<

                                https://www.startupbangladesh.vc/eco-sentinels-wins-the-youth-innovation-challenge-2025-in-the-khulna-and-barisal-segment-in-the-youth-startup-summit/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Eco Sentinels wins the Youth Innovation Challenge 2025 in the Khulna and Barisal segment in the Youth Startup Summit

[](<

                                https://www.startupbangladesh.vc/sign-talk-wins-in-the-yss-sylhet/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Sign Talk wins the Youth Innovation Challenge 2025 in the Sylhet segment in the Youth Startup Summit

[](<

                                https://www.startupbangladesh.vc/anondopath-wins-the-youth-innovation-challenge/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Anondopath wins the Youth Innovation Challenge 2025 in the Rajshahi & Rangpur segment in the Youth Startup Summit

[](<

                                https://www.startupbangladesh.vc/startup-bangladesh-invests-bdt-11-10-cr-in-local-startups/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Startup Bangladesh invests BDT 11.10 cr in local startups

[](<

                                https://www.startupbangladesh.vc/%e0%a6%9b%e0%a6%af%e0%a6%bc-%e0%a6%ae%e0%a6%be%e0%a6%b8%e0%a7%87-%e0%a7%af-%e0%a6%95%e0%a7%8b%e0%a6%9f%e0%a6%bf-%e0%a6%9f%e0%a6%be%e0%a6%95%e0%a6%be-%e0%a6%ac%e0%a6%bf%e0%a6%a8%e0%a6%bf%e0%a6%af/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### ছয় মাসে ৯ কোটি টাকা বিনিয়োগ করেছে স্টার্টআপ বাংলাদেশ

[](<

                                https://www.startupbangladesh.vc/startup-bangladeshs-strategic-investments-continue-to-accelerate-growth-across-key-sectors/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Startup Bangladesh’s Strategic Investments Continue to Accelerate Growth Across Key Sectors

[](<

                                https://www.startupbangladesh.vc/bangladeshs-startup-ecosystem-showcased-at-expand-north-star-2024-in-dubai/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Bangladesh’s startup ecosystem showcased at Expand North Star 2024 in Dubai

[](<

                                https://www.startupbangladesh.vc/pathao-raises-12-million-in-foreign-funds/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Pathao raises $12 million in foreign funds

[](<

                                https://www.startupbangladesh.vc/%e0%a6%85%e0%a6%a8%e0%a7%81%e0%a6%b7%e0%a7%8d%e0%a6%a0%e0%a6%bf%e0%a6%a4-%e0%a6%b9%e0%a6%b2%e0%a7%8b-%e0%a6%b8%e0%a7%8d%e0%a6%9f%e0%a6%be%e0%a6%b0%e0%a7%8d%e0%a6%9f%e0%a6%86%e0%a6%aa/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### অনুষ্ঠিত হলো ‘স্টার্টআপ ফাউন্ডারস মিট’

[](<

                                https://www.startupbangladesh.vc/exciting-opportunity-for-women-tech-entrepreneurs/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Exciting Opportunity for Women Tech Entrepreneurs

[](<

                                https://www.startupbangladesh.vc/sbl-monerbondhu-partnership/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Startup Bangladesh Limited (SBL) signs a new partnership with Moner Bondhu offering mental health care and wellbeing services to all SBL portfolio startups

[](<

                                https://www.startupbangladesh.vc/bangladesh-startup-summit-partnership-signing/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Startup Bangladesh signed up to collaborate with Asiatic Mindshare Ltd. and Windmill Advertising Ltd. for the upcoming Bangladesh Startup Summit.

[](<

                                https://www.startupbangladesh.vc/%e0%a6%a6%e0%a7%81%e0%a6%b0%e0%a7%8d%e0%a6%a6%e0%a6%be%e0%a6%a8%e0%a7%8d%e0%a6%a4-%e0%a6%b8%e0%a6%ac-%e0%a6%89%e0%a6%a6%e0%a7%8d%e0%a6%af%e0%a7%8b%e0%a6%95%e0%a7%8d%e0%a6%a4%e0%a6%be%e0%a6%b0%e0%a6%be/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### দুর্দান্ত সব উদ্যোক্তারা আসছেন ‘Shark Tank Bangladesh Season 1’-এর ২য় পর্বে। দেখতে চোখ রাখুন আজ রাত ঠিক ১০ টায় Bongo ও দীপ্ত টিভি-তে।

[](<

                                https://www.startupbangladesh.vc/%e0%a6%a6%e0%a7%81%e0%a6%b0%e0%a7%8d%e0%a6%a6%e0%a6%be%e0%a6%a8%e0%a7%8d%e0%a6%a4-%e0%a6%b8%e0%a6%ac-%e0%a6%b8%e0%a6%ae%e0%a7%8d%e0%a6%ad%e0%a6%be%e0%a6%ac%e0%a6%a8%e0%a6%be%e0%a6%ae%e0%a6%af%e0%a6%bc/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### দুর্দান্ত সব সম্ভাবনাময় উদ্যোক্তাদের নিয়ে শুরু হচ্ছে দেশের সবচেয়ে বড় বিজনেস রিয়ালিটি শো ‘Shark Tank Bangladesh’। দেখুন আজ ১ম পর্ব ঠিক রাত ১০টায় Bongo ও দীপ্ত টিভি-তে।

[](<

                                https://www.startupbangladesh.vc/startup-bangladesh-limited-announces-bdt-1-crore-investment-in-pulse-tech/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Startup Bangladesh Limited Announces BDT 1 Crore Investment in Pulse Tech Ltd. to Enhance Retail Pharma Operation in Bangladesh

[](<

                                https://www.startupbangladesh.vc/shark-tank-bangladesh-makes-waves/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Shark Tank Bangladesh Makes Waves: Premiere Set for April 26th

[](<

                                https://www.startupbangladesh.vc/the-most-awaited-shark-tank-bangladesh-is-scheduled-to-be-aired-from-26th-april-2024-in-dipto-tv-bongo/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### The most awaited “Shark Tank Bangladesh” is scheduled to be aired from 26th April 2024 in Dipto TV & Bongo.

[](<

                                https://www.startupbangladesh.vc/mr-sami-ahmed-managing-director-ceo-of-startup-bangladesh-is-going-to-appear-as-a-shark-at-the-shark-tank-bangladesh-tv-show/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Mr. Sami Ahmed, Managing Director & CEO of Startup Bangladesh is going to appear as a Shark at the Shark Tank Bangladesh TV Show

[](<

                                https://www.startupbangladesh.vc/shark-tank-bangladesh-meet-the-sharks/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Shark Tank Bangladesh: Meet the Sharks

[](<

                                https://www.startupbangladesh.vc/startup-bangladesh-invests-in-apan-impact-driven-fintech-startup/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Startup Bangladesh Invests in Apan – impact driven Fintech Startup

[](<

                                https://www.startupbangladesh.vc/startup-bangladesh-invests-in-hishab-telephony-driven-generative-ai/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Startup Bangladesh Invests in Hishab – Telephony-driven Generative AI

[](<

                                https://www.startupbangladesh.vc/startup-bangladesh-invests-in-alice-labs-global-saas/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Startup Bangladesh Invests in Alice Labs – Global SaaS

[](<

                                https://www.startupbangladesh.vc/kalerantho-sami-ahmed/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### উদ্যোক্তাদের উদ্ভাবনী চিন্তা করতে হবে – সামি আহমেদ, ম্যানেজিং ডিরেক্টর, স্টার্টআপ বাংলাদেশ লিমিটেড

[](<

                                https://www.startupbangladesh.vc/shebas-comeback-story-a-demonstration-of-resilience/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Sheba’s comeback story: A demonstration of resilience

[](<

                                https://www.startupbangladesh.vc/startup-bangladesh-limiteds-board-of-directors-explores-the-innovative-strides-of-our-investee-company-10-minute-school/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Startup Bangladesh Limited’s Board of Directors explores the innovative strides of our investee company, 10 Minute School

[](<

                                https://www.startupbangladesh.vc/the-internationally-acclaimed-business-reality-show-shark-tank-has-officially-opened-the-doors-to-its-bangladeshi-adaptation/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### The internationally acclaimed business reality show, Shark Tank, has officially opened the doors to its Bangladeshi adaptation.

[](<

                                https://www.startupbangladesh.vc/startup-bangladeshs-portfolio-health-tech-startup-arogga-%e0%a6%86%e0%a6%b0%e0%a7%8b%e0%a6%97%e0%a7%8d%e0%a6%af-has-raised-a-total-of-5-5-million-in-its-seed-funding-round/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Startup Bangladesh’s portfolio health-tech startup Arogga – আরোগ্য has raised a total of $5.5 million in its seed funding round

[](<

                                https://www.startupbangladesh.vc/shark-tank-comes-to-bangladesh/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Shark Tank comes to Bangladesh

[](<

                                https://www.startupbangladesh.vc/startup-bangladesh-collaborates-in-sdg-localization-consultation-and-field-engagement/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Startup Bangladesh Collaborates in SDG Localization Consultation and Field Engagement

[](<

                                https://www.startupbangladesh.vc/startup-bangladesh-invests-5cr-in-bongo-to-grow-digital-entertainment-consumption-in-bangladesh/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Startup Bangladesh invests 5cr in Bongo to grow Digital Entertainment consumption in Bangladesh

[](<

                                https://www.startupbangladesh.vc/startup-bangladesh-invests-in-online-pharmacy-medeasy/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Startup Bangladesh Invests in Online Pharmacy MedEasy

[](<

                                https://www.startupbangladesh.vc/%e0%a6%86%e0%a6%87%e0%a6%a1%e0%a6%bf%e0%a6%af%e0%a6%bc%e0%a6%be-%e0%a6%93-%e0%a6%b8%e0%a7%8d%e0%a6%9f%e0%a6%be%e0%a6%b0%e0%a7%8d%e0%a6%9f%e0%a6%86%e0%a6%aa-%e0%a6%ac%e0%a6%be%e0%a6%82%e0%a6%b2/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### আইডিয়া ও স্টার্টআপ বাংলাদেশ’র মধ্যে সমঝোতা স্মারক স্বাক্ষর

[](<

                                https://www.startupbangladesh.vc/startup-bangladesh-invests-in-markopolo-ai/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Startup Bangladesh invests in Markopolo Ai

[](<

                                https://www.startupbangladesh.vc/%e0%a6%a6%e0%a7%87%e0%a6%b6%e0%a7%87%e0%a6%b0-%e0%a6%b6%e0%a6%bf%e0%a6%95%e0%a7%8d%e0%a6%b7%e0%a6%bf%e0%a6%a4-%e0%a6%af%e0%a7%81%e0%a6%ac%e0%a6%95%e0%a6%a6%e0%a7%87%e0%a6%b0-%e0%a6%b8%e0%a7%83/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### দেশের শিক্ষিত যুবকদের সৃজনশীল ও উদ্ভাবনী স্টার্টআপ বা নতুন উদ্যোগে যৌথভাবে কাজ করবে এসএমই ফাউন্ডেশন ও স্টার্টআপ বাংলাদেশ।

[](<

                                https://www.startupbangladesh.vc/1st-sankalp-dhaka-summit-initiative-announced-to-raise-250m-for-1000-impact-enterprises/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### 1st Sankalp Dhaka Summit: Initiative announced to raise $250m for 1,000 impact enterprises

[](<

                                https://www.startupbangladesh.vc/startup-bangladesh-invests-in-openrefactory/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Startup Bangladesh invests in OpenRefactory

[](<

                                https://www.startupbangladesh.vc/startup-bangladesh-invests-in-countrys-first-diagnostic-marketplace-amarlab/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Startup Bangladesh invests in country’s first diagnostic marketplace AmarLab

[](<

                                https://www.startupbangladesh.vc/farewell-to-mr-zeaul-alam-paa-the-founding-chairman-of-startup-bangladesh-and-sr-secretary-of-the-ict-division/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Farewell to Mr. Zeaul Alam PAA, the Founding Chairman of Startup Bangladesh and Sr. Secretary of the ICT Division

[](<

                                https://www.startupbangladesh.vc/startup-bangladesh-invests-in-pickaboo/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Startup Bangladesh invests in Pickaboo

[](<

                                https://www.startupbangladesh.vc/startup-bangladesh-invests-in-bimafy/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Startup Bangladesh invests in Bimafy

[](<

                                https://www.startupbangladesh.vc/startup-bangladesh-invests-in-swap/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Startup Bangladesh invests in SWAP

[](<

                                https://www.startupbangladesh.vc/%e0%a6%b8%e0%a7%8d%e0%a6%9f%e0%a6%be%e0%a6%b0%e0%a7%8d%e0%a6%9f%e0%a6%86%e0%a6%aa-%e0%a6%ac%e0%a6%be%e0%a6%82%e0%a6%b2%e0%a6%be%e0%a6%a6%e0%a7%87%e0%a6%b6%e0%a7%87%e0%a6%b0-%e0%a6%ac%e0%a6%bf%e0%a6%a8/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### স্টার্টআপ বাংলাদেশের বিনিয়োগ পেলো ভ্রুম

[](<

                                https://www.startupbangladesh.vc/undp-moner-bondhu-provide-mental-health-support-for-climate-change-victims/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### UNDP, Moner Bondhu provide mental health support for climate change victims

[](<

                                https://www.startupbangladesh.vc/20-startups-in-huawei-ict-incubator-final-round/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### 20 startups in Huawei ICT Incubator final round

[](<

                                https://www.startupbangladesh.vc/world-tourism-day-2022-sharetrip-revolutionising-travel-in-bangladesh/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### World Tourism Day 2022: ShareTrip – Revolutionising travel in Bangladesh

[](<

                                https://www.startupbangladesh.vc/moner-bondhu-a-portfolio-startup-of-startup-bangladesh-limited-won-asias-first-award-for-sustainability-women-empowerment-ggef-women-eco-game-changer-awards/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Moner Bondhu , a portfolio startup of Startup Bangladesh Limited won Asia’s first Award for Sustainability & Women empowerment GGEF Women Eco Game Changer Awards

[](<

                                https://www.startupbangladesh.vc/financial-planning-for-the-down-market-jointly-organized-by-startup-bangladesh-limited-and-idlc-venture-capital-fund-i/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Financial planning for the down market, jointly organized by Startup Bangladesh Limited and IDLC Venture Capital Fund I

[](<

                                https://www.startupbangladesh.vc/chaldal-raises-5c-follow-on-investment-from-startup-bangladesh/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Chaldal raises 5C follow-on investment from Startup Bangladesh

[](<

                                https://www.startupbangladesh.vc/%e0%a6%b8%e0%a7%8d%e0%a6%9f%e0%a6%be%e0%a6%b0%e0%a7%8d%e0%a6%9f%e0%a6%86%e0%a6%aa-%e0%a6%ac%e0%a6%be%e0%a6%82%e0%a6%b2%e0%a6%be%e0%a6%a6%e0%a7%87%e0%a6%b6-%e0%a6%a5%e0%a7%87%e0%a6%95%e0%a7%87/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### স্টার্টআপ বাংলাদেশ থেকে ৫ কোটি টাকা বিনিয়োগ পেলো শেয়ারট্রিপ

[](<

                                https://www.startupbangladesh.vc/%e0%a6%ac%e0%a6%bf%e0%a6%a6%e0%a7%8d%e0%a6%af%e0%a7%81%e0%a7%8e-%e0%a6%b8%e0%a6%be%e0%a6%b6%e0%a7%8d%e0%a6%b0%e0%a7%9f%e0%a7%87-%e0%a6%b8%e0%a7%8d%e0%a6%9f%e0%a6%be%e0%a6%b0%e0%a7%8d%e0%a6%9f%e0%a6%86/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### বিদ্যুৎ সাশ্রয়ে স্টার্টআপ বাংলাদেশ ।

[](<

                                https://www.startupbangladesh.vc/2857-2/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Join the biggest mobile application hackathon and win prize money worth 𝟱 𝗟𝗮𝗸𝗵𝘀

[](<

                                https://www.startupbangladesh.vc/banglalink-holds-seminar-on-startup-ecosystem-in-collaboration-with-startup-bangladesh/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Banglalink holds seminar on startup ecosystem in collaboration with Startup Bangladesh

[](<

                                https://www.startupbangladesh.vc/road-to-new-digital-ecosystem-developing-tech-entrepreneurs/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Road to New Digital Ecosystem-Developing Tech Entrepreneurs

[](<

                                https://www.startupbangladesh.vc/moner-bondhu-has-won-the-championship-as-the-global-winner-jointly-under-the-category-of-digital-health-solutions-to-fight-covid-19/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### “Moner Bondhu” has won the championship as the Global Winner’ ( jointly) under the category of Digital health solutions to fight Covid-19

[](<

                                https://www.startupbangladesh.vc/deep-dive-session-on-red-flags-for-investors-which-founders-should-be-aware-of/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Deep Dive Session on “Red Flags For investors which founders should be aware of”

[](<

                                https://www.startupbangladesh.vc/startup-bangladesh-limited-and-idlc-venture-capital-fund-i-hosted-a-session-on-investment-structures/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

####  Startup Bangladesh Limited and IDLC Venture Capital Fund I hosted a session on Investment Structures

[](<

                                https://www.startupbangladesh.vc/seven-bangladeshi-youths-on-forbes-30-under-30-2022-asia-list/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Seven Bangladeshi youths on Forbes 30 Under 30 2022 Asia list

[](<

                                https://www.startupbangladesh.vc/investment-structure-an-event-jointly-organized-by-startup-bangladesh-limited-and-idlc-venture-capital-fund-i/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### “Investment Structure” – An event jointly organized by Startup Bangladesh Limited and IDLC Venture Capital Fund I

[](<

                                https://www.startupbangladesh.vc/mr-sami-ahmed-managing-director-of-startup-bangladesh-ltd-speaks-on-the-rise-of-the-edtech-startups-in-bangladesh/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Mr. Sami Ahmed, Managing Director of Startup Bangladesh Ltd. speaks on the rise of the EdTech Startups in Bangladesh.

[](<

                                https://www.startupbangladesh.vc/startup-bangladesh-limited-has-been-nominated-as-a-finalist-under-the-best-vc-for-the-global-startup-awardss-saarc-region/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Startup Bangladesh Limited has been nominated as a finalist under the Best VC for the Global Startup Awards‘s SAARC Region

[](<

                                https://www.startupbangladesh.vc/3-bangladeshi-startups-receive-funding-from-accelerating-asia/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### 3 Bangladeshi startups receive funding from Accelerating Asia

[](<

                                https://www.startupbangladesh.vc/eduhive-to-offer-intl-courses-for-bd-students/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### EduHive to offer int’l courses for BD students

[](<

                                https://www.startupbangladesh.vc/discussion-on-future-opportunities-with-the-delegation-from-the-embassy-of-the-netherlands/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Discussion on future opportunities with the delegation from the Embassy of the Netherlands

[](<

                                https://www.startupbangladesh.vc/intelligent-machines-intelligent-by-design-humane-by-choice/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Intelligent Machines: Intelligent by design, humane by choice

[](<

                                https://www.startupbangladesh.vc/wavemaker-leads-4m-round-of-bangladeshi-edtech-startup/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Wavemaker leads $4m round of Bangladeshi edtech startup

[](<

                                https://www.startupbangladesh.vc/startup-bangladesh-limited-made-its-vintage-ii-investments-in-8-startups/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Startup Bangladesh Limited made its Vintage II investments in 8 startups

[](<

                                https://www.startupbangladesh.vc/sami-ahmed-joins-as-the-newest-md-of-startup-bangladesh/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Sami Ahmed joins as the newest MD of Startup Bangladesh

[](<

                                https://www.startupbangladesh.vc/mr-sami-ahmed-joins-as-the-managing-director-of-startup-bangladesh-limited/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Mr. Sami Ahmed joins as the Managing Director of Startup Bangladesh Limited.

[](<

                                https://www.startupbangladesh.vc/team-meeting-with-respected-chairman-of-board-of-directors-of-startup-bangladesh-limited-launching-of-grp-module-at-startup-bangladesh-limited/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Team Meeting with respected Chairman of Board of Directors of Startup Bangladesh Limited & launching of GRP module at Startup Bangladesh Limited

[](<

                                https://www.startupbangladesh.vc/state-of-the-ecosystem-for-youth-entrepreneurship-in-bangladesh/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### State of the Ecosystem for Youth Entrepreneurship in Bangladesh

[](<

                                https://www.startupbangladesh.vc/22-asia-pacific-firms-recognized-in-un-women-2021-asia-pacific-weps-awards/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### 22 Asia-Pacific firms recognized in UN Women 2021 Asia-Pacific WEPs Awards

[](<

                                https://www.startupbangladesh.vc/healthcare-startup-dhaka-cast-organized-special-event-on-world-diabetes-day/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Healthcare Startup Dhaka Cast Organized Special Event on World Diabetes Day

[](<

                                https://www.startupbangladesh.vc/bangladeshi-recommerce-swap-raises-1-25-million-in-seed-round/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Bangladeshi recommerce SWAP raises $1.25 million in seed round

[](<

                                https://www.startupbangladesh.vc/startup-ecosystem-in-bangladesh-current-status-and-future-outlook/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Startup ecosystem in Bangladesh: Current status and future outlook

[](<

                                https://www.startupbangladesh.vc/go-zayaan-receives-tk22-crore-foreign-investment/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Go Zayaan receives Tk22 crore foreign investment

[](<

                                https://www.startupbangladesh.vc/bangladesh-is-the-proud-host-of-the-25th-world-congress-on-information-technology-wcit-2021/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Bangladesh is the proud host of the 25th World Congress on Information Technology (WCIT) 2021

[](<

                                https://www.startupbangladesh.vc/the-remarkable-story-of-bangladeshs-development-journey/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### The Remarkable Story of Bangladesh’s Development Journey

[](<

                                https://www.startupbangladesh.vc/doctor-networking-app-frontliners-raises-new-investment/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Doctor Networking App Frontliners Raises New Investment

[](<

                                https://www.startupbangladesh.vc/the-state-of-startup-funding-in-bangladesh-till-september-2021/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### The State of Startup Funding In Bangladesh till September 2021.

[](<

                                https://www.startupbangladesh.vc/our-portfolio-startup-chaldal-bangladeshs-largest-grocery-delivery-platform-raises-10m-series-c/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Our Portfolio Startup Chaldal, Bangladesh’s largest grocery delivery platform, raises $10M Series C.

[](<

                                https://www.startupbangladesh.vc/the-1st-annual-general-meeting-of-startup-bangladesh-limited-successfully-closed-on-september-11-2021/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### The 1st Annual General Meeting of Startup Bangladesh Limited successfully closed on September 11, 2021.

[](<

                                https://www.startupbangladesh.vc/she-loves-tech-bangladesh-top-3-startups-will-be-recognized/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### She Loves Tech: Bangladesh top 3 Startups will be recognized.

[](<

                                https://www.startupbangladesh.vc/commerce-platform-shopup-raises-75-million-led-by-valar-in-bangladeshs-largest-funding/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Commerce platform ShopUp raises $75 million led by Valar in Bangladesh’s largest funding

[](<

                                https://www.startupbangladesh.vc/the-dhaka-based-edtech-company-harnesses-technology-to-make-learning-more-accessible-affordable-and-fun/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### The Dhaka-based edtech company harnesses technology to make learning more accessible, affordable, and fun.

[](<

                                https://www.startupbangladesh.vc/they-said-i-was-crazy-leaving-silicon-valley-for-bangladesh/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### ‘They said I was crazy leaving Silicon Valley for Bangladesh’

[](<

                                https://www.startupbangladesh.vc/usa-bangladesh-tech-investment-summit-held-in-silicon-valley/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### USA-Bangladesh Tech Investment Summit held in Silicon Valley

[](<

                                https://www.startupbangladesh.vc/%e0%a6%b6%e0%a6%bf%e0%a6%95%e0%a7%8d%e0%a6%b7%e0%a6%be%e0%a6%aa%e0%a7%8d%e0%a6%b0%e0%a6%af%e0%a7%81%e0%a6%95%e0%a7%8d%e0%a6%a4%e0%a6%bf%e0%a6%b0-%e0%a6%89%e0%a6%a8%e0%a7%8d%e0%a6%a8%e0%a7%9f%e0%a6%a8/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### শিক্ষাপ্রযুক্তির উন্নয়নে ১৩ লাখ ডলারের বিনিয়োগ পেয়েছে বাংলাদেশি স্টার্টআপ ‘শিখো’।

[](<

                                https://www.startupbangladesh.vc/10-entrepreneurs-share-their-top-tips-for-applying-to-startup-accelerators/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### 10 Entrepreneurs Share Their Top Tips For Applying To Startup Accelerators

[](<

                                https://www.startupbangladesh.vc/%e0%a6%a6%e0%a7%87%e0%a6%b6%e0%a7%80%e0%a7%9f-%e0%a6%b8%e0%a7%8d%e0%a6%9f%e0%a6%be%e0%a6%b0%e0%a7%8d%e0%a6%9f%e0%a6%86%e0%a6%aa%e0%a6%97%e0%a7%81%e0%a6%b2%e0%a7%8b-%e0%a6%aa%e0%a6%be%e0%a6%9a%e0%a7%8d/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### দেশীয় স্টার্টআপগুলো পাচ্ছে বিদেশি বিনিয়োগ

[](<

                                https://www.startupbangladesh.vc/bangladeshi-startup-arogga-raises-usd-200k/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Bangladeshi startup Arogga raises USD 200K

[](<

                                https://www.startupbangladesh.vc/shuttle-a-bangladesh-based-mass-transit-startup-raised-us750000-in-its-seed-round-led-by-accelerating-asia/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Shuttle, a Bangladesh-based mass-transit startup raised US$750,000 in its seed round led by Accelerating Asia

[](<

                                https://www.startupbangladesh.vc/driving-change/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Driving Change

[](<

                                https://www.startupbangladesh.vc/sdg-impact-accelerator-is-excited-to-present-10-startups-selected-for-digitalagriculture-and-financialinclusion-acceleration-programs/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### SDG Impact Accelerator is excited to present 10 startups selected for #DigitalAgriculture and #FinancialInclusion Acceleration Programs

[](<

                                https://www.startupbangladesh.vc/cultivating-smes-entrepreneurship-development-gender-and-technology-in-bangladesh-cambodia-ethiopia-senegal/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Cultivating SMEs: Entrepreneurship Development, Gender and Technology in Bangladesh, Cambodia, Ethiopia & Senegal

[](<

                                https://www.startupbangladesh.vc/3-bangladeshi-researchers-make-it-to-asian-scientist-100-list/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### 3 Bangladeshi researchers make it to Asian Scientist 100 list

[](<

                                https://www.startupbangladesh.vc/forbes-30-under-30-asia/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Forbes 30 under 30 Asia

[](<

                                https://www.startupbangladesh.vc/angel-investing-101-doing-it-right-in-bangladesh/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Angel investing 101: Doing it right in Bangladesh

[](<

                                https://www.startupbangladesh.vc/a-snapshot-of-the-amazing-impact-startups-in-financialinclusion-for-bangladesh-and-digitalagriculture-for-uganda-cohorts/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### SDG Impact Accelerator

[](<

                                https://www.startupbangladesh.vc/leaving-no-micro-merchants-behind-in-the-digital-era-in-bangladesh/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Leaving no micro merchants behind in the digital era in Bangladesh

[](<

                                https://www.startupbangladesh.vc/startup-bangladesh-limited-collaborates-with-united-nations-development-programme-in-bangladesh-citi-islamic-development-bank-lightcastle-partners/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Startup Bangladesh Limited collaborates with United Nations Development Programme in Bangladesh, Citi, Islamic Development Bank & LightCastle Partners

[](<

                                https://www.startupbangladesh.vc/grameenphone-choosetochallenge/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Grameenphone – ChooseToChallenge

[](<

                                https://www.startupbangladesh.vc/1174-2/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Partnership between the EdTech Consortium and Education Ministry is led by Startup Bangladesh Limited

[](<

                                https://www.startupbangladesh.vc/the-women-enterprise-recovery/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

January 16, 2021

#### The Women Enterprise Recovery

[](<

                                https://www.startupbangladesh.vc/isocial-voicebridge-announce-collaboration-on-bridging-digital-divide/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

January 13, 2021

#### iSocial, VoiceBridge announce collaboration on bridging digital divide

[](<

                                https://www.startupbangladesh.vc/4-ways-start-ups-can-keep-raising-funds-during-the-covid-pandemic/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

June 30, 2020

#### 4 ways start-ups can keep raising funds during the COVID pandemic

[](<

                                https://www.startupbangladesh.vc/six-changemakers-from-bangladesh-honoured-at-diana-award-2020/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

July 3, 2020

#### Six changemakers from Bangladesh honoured at Diana Award 2020

[](<

                                https://www.startupbangladesh.vc/nsu-startups-next-a-platform-to-set-ideas-free-2/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

July 6, 2020

#### NSU Startups Next: A platform to set ideas free

[](<

                                https://www.startupbangladesh.vc/bangladesh-startup-ecosystem-the-untapped-digital-goldmine-of-asia/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

September 12, 2020

#### Bangladesh Startup Ecosystem- The Untapped Digital Goldmine of Asia

[](<

                                https://www.startupbangladesh.vc/apply-now-100000-for-blockchain-solutions-from-unicef-innovation-fund/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

July 20, 2020

#### Apply Now: $100,000 for Blockchain Solutions from UNICEF Innovation Fund

[](<

                                https://www.startupbangladesh.vc/lightcastle-bangladesh-startup-ecosystem-report-2020/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

August 8, 2020

#### LightCastle Bangladesh Startup Ecosystem Report 2020

[](<

                                https://www.startupbangladesh.vc/tina-jabeen-a-mentor-who-helps-founders-selflessly-2/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

August 19, 2020

#### Tina Jabeen – A Mentor Who Helps Founders Selflessly

[](<

                                https://www.startupbangladesh.vc/%e0%a6%b8%e0%a7%8c%e0%a6%b0-%e0%a6%ac%e0%a6%bf%e0%a6%a6%e0%a7%8d%e0%a6%af%e0%a7%81%e0%a7%8e-%e0%a6%ad%e0%a6%be%e0%a6%97%e0%a6%be%e0%a6%ad%e0%a6%be%e0%a6%97%e0%a6%bf-%e0%a6%b9%e0%a6%9a%e0%a7%8d/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

August 22, 2020

#### সৌর বিদ্যুৎ ভাগাভাগি হচ্ছে বাংলাদেশের গ্রামে

[](<

                                https://www.startupbangladesh.vc/startups-in-pandemic-days-a-tale-of-despair-and-dreams-2/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

September 7, 2020

#### Startups in pandemic days: A tale of despair and dreams

[](<

                                https://www.startupbangladesh.vc/start-ups-are-already-shaping-the-future-of-bangladesh/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

September 13, 2020

#### Start-ups are already shaping the future of Bangladesh

[](<

                                https://www.startupbangladesh.vc/%e0%a7%aa%e0%a6%b0%e0%a7%8d%e0%a6%a5-%e0%a6%9c%e0%a6%be%e0%a6%a4%e0%a7%80%e0%a7%9f-%e0%a6%a4%e0%a6%b0%e0%a7%81%e0%a6%a3-%e0%a6%89%e0%a6%a6%e0%a7%8d%e0%a6%af%e0%a7%8b%e0%a6%95%e0%a7%8d%e0%a6%a4/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

September 9, 2020

#### ৪র্থ জাতীয় তরুণ উদ্যোক্তা সম্মেলন-২০২০

[](<

                                https://www.startupbangladesh.vc/finance-for-women-you/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

October 8, 2020

#### FINANCE FOR WOMEN & YOU

[](<

                                https://www.startupbangladesh.vc/shopup-raises-22-5-million-to-digitize-millions-of-mom-and-pop-shops-in-bangladesh/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

October 20, 2020

#### ShopUp raises $22.5 million to digitize millions of mom-and-pop shops in Bangladesh

[](<

                                https://www.startupbangladesh.vc/she-loves-tech-bangladesh-2020/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

October 25, 2020

#### She Loves Tech Bangladesh 2020

[](<

                                https://www.startupbangladesh.vc/bangladeshi-youth-wins-prestigious-intl-award/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

October 25, 2020

#### Bangladeshi youth wins prestigious int’l award

[](<

                                https://www.startupbangladesh.vc/complex-angioplasty-by-bangladeshi-doctor-recognised-as-worlds-best/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

October 25, 2020

#### Complex angioplasty by Bangladeshi doctor recognised as world’s best

[](<

                                https://www.startupbangladesh.vc/start-ups-to-take-care-of-our-mind-and-body/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

November 4, 2020

#### Start-ups to take care of our mind and body

[](<

                                https://www.startupbangladesh.vc/citi-undp-stand-beside-young-bangladeshi-entrepreneurs/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

November 5, 2020

#### Citi, UNDP stand beside young Bangladeshi entrepreneurs

[](<

                                https://www.startupbangladesh.vc/discard-the-word-impossible-rather-say-why-not/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

November 9, 2020

#### Discard the word ‘impossible’, rather say ‘why not?’

[](<

                                https://www.startupbangladesh.vc/start-ups-to-support-our-agriculture-and-environment/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

November 12, 2020

#### Start-ups to support our agriculture and environment

[](<

                                https://www.startupbangladesh.vc/start-ups-that-are-transforming-the-future-of-education/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

November 26, 2020

#### Start-ups that are transforming the future of education

[](<

                                https://www.startupbangladesh.vc/democratising-education-through-e-learning/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

January 14, 2021

#### Democratising education through e-learning

[](<

                                https://www.startupbangladesh.vc/facebook-partners-with-bangladeshi-organizations-on-mental-health/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

January 8, 2021

#### Facebook partners with Bangladeshi organizations on mental health

[](<

                                https://www.startupbangladesh.vc/%e0%a6%a4%e0%a6%a5%e0%a7%8d%e0%a6%af-%e0%a6%aa%e0%a7%8d%e0%a6%b0%e0%a6%af%e0%a7%81%e0%a6%95%e0%a7%8d%e0%a6%a4%e0%a6%bf%e0%a6%b0-%e0%a6%a6%e0%a7%81%e0%a6%a8%e0%a6%bf%e0%a7%9f%e0%a6%be-%e0%a6%aa/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

December 9, 2020

#### তথ্য-প্রযুক্তির দুনিয়া, পর্ব ১৩

[](<

                                https://www.startupbangladesh.vc/sdg-impact-accelerator-opens-its-second-global-call-for-startups/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

December 18, 2020

#### SDG IMPACT ACCELERATOR OPENS ITS SECOND GLOBAL CALL FOR STARTUPS

[](<

                                https://www.startupbangladesh.vc/women-enterprise-recovery-fund/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

January 8, 2021

#### Women Enterprise Recovery Fund

[](<

                                https://www.startupbangladesh.vc/united-nations-launches-a-women-enterprise-recovery-fund/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

February 16, 2021

#### United Nations Launches A Women Enterprise Recovery Fund

[](<

                                https://www.startupbangladesh.vc/start-ups-that-empower-women/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

December 17, 2020

#### Start-ups that empower women

[](<

                                https://www.startupbangladesh.vc/tina-f-jabeen-cpa-is-appointed-as-the-first-managing-director-and-chief-executive-officer-of-startup-bangladesh-limited-ict-division-govt-of-the-peoples-republic-of-bangladesh/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Tina F. Jabeen, CPA is appointed as the first Managing Director and Chief Executive Officer of Startup Bangladesh Limited, ICT Division, Gov’t of the People’s Republic of Bangladesh

[](<

                                https://www.startupbangladesh.vc/startups-in-pandemic-days-a-tale-of-despair-and-dreams/

                                                >)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

December 14, 2020

#### Startups in pandemic days: a tale of despair and dreams

© 2025 Startup Bangladesh Limited