---
source: "Bangladesh Trade Portal"
tier: 1
category: "Trade portal"
url: "https://bangladeshtradeportal.gov.bd/index.php?r=site/display&id=4"
title: "SPS-TBT Enquiry Points"
scraped_at: "2026-07-02"
---

![](./images/banner.jpg) 

[Home](/index.php) » SPS-TBT Enquiry Points

The Bangladesh Trade Portal (BTP) is an official source of all regulatory information relevant to traders who wish to import goods into Bangladesh or export to other countries. The Ministry of Commerce of the Bangladesh Government has established the Portal in order to improve the predictability and transparency of the country�s trading laws and processes.

## SPS-TBT Enquiry Points

## WTO-TBT activities in BSTI

  
Bangladesh is a member of the World Trade Organization (WTO) since 1 January 1995. Each WTO member must set up a National Enquiry Point which is able to answer all reasonable enquiries on standards, technical regulations, conformity assessment procedures, etc. from other members of WTO and other interested parties there.

BSTI is the National Enquiry Point. There is an internal committee on WTO affairs in BSTI and it participates in the notification activities to WTO through the Ministry of Commerce and the Ministry of Industries.

### **The contact address of the Bangladesh WTO-TBT National Enquiry Point****:**     

#### **Maan Bhaban**

116/A, Tejgaon Industrial Area, Dhaka-1208

Tel: +88-02 8870278 ( off) , Fax : +88-02-9131581

Mob: +8801552402985, +8801915479519

E-mail; rezaulkarim60@gmail.com

Link to BSTI: [WTO-TBT activities in BSTI](http://bsti.gov.bd/wto.html)

To make an enquiry, [Click Here](?r=site/contact).

## **Sanitary and Phytosanitary Measures (SPS)**

**The basic rules governing food safety and animal and plant health standards are covered by the Agreement on the Application of Sanitary and Phytosanitary Measures (SPS Agreement) of the [World Trade Organization](http://www.wto.org/) (WTO).**

SPS measures are those that are used to protect human, animal, or plant life or health from risks that come from the spread of pests and diseases, or from additives, toxins, or contaminants found in food, beverages, or feedstuffs.

The SPS Agreement requires that WTO members establish a national “Enquiry Point" to answer enquiries from other members regarding the technical requirements and SPS-related measures for products sold in their countries.

#### **The contact address of the Bangladesh SPS National Enquiry Point is:**   

Dr. Md. Alam Mostafa, Joint Secretary ( WTO Wing )

Ministry of Commerce, Bangladesh Secretariat

Dhaka- 1000, Bangladesh

Email: js1.wto@mincom.gov.bd; Mobile: +8801314141414

To make an enquiry, [Click Here](?r=site/contact)

  

# National Enquiry Point for Trade

[Click here to submit query](https://enquiry.bangladeshtradeportal.gov.bd)

# Women Entrepreneurs Networking Platform

[Click here to visit WENP](https://wenp.bangladeshtradeportal.gov.bd/)

Member Area

Email \* 

Password \* 

![](/index.php?r=site/captcha&v=6a46d9de86366)

Verify Code 

 Remember me 

[Register](?r=site/registration) | [Forget Password](?r=site/ResetPasswordNotification)

Search this Site

 

Contents

## Download Trade Portal Apps

 [![](/kcfinder/upload/images/download.png)](https://play.google.com/store/apps/details?id=com.mincom.btp&hl=en&gl=US)   [![](/kcfinder/upload/images/AppleStore.png)](https://apps.apple.com/in/app/bangladesh-trade-portal/id1617672911)

## **Search Trade Information** 

![](/kcfinder/upload/images/23.%20Export%20Guide.png)  [What's New](https://www.bangladeshtradeportal.gov.bd/index.php?r=site/display&id=1169)

  [![](/kcfinder/upload/images/16.%20Legal%20Documents.png)](<?r=site/displaythemostrecentxx&category=Legal Document>)  [Legal Documents](/index.php?r=site/displaythemostrecentxx&category=Legal%20Document)

  [![](/kcfinder/upload/images/20.%20Measures%20and%20Standards.png)](?r=SearchMeasures/index)  [Measures & Standards](?r=SearchMeasures/index) 

  [![](/kcfinder/upload/images/12.%20Procedures.png)](?r=SearchProcedure/index)  [Mandatory Products for License](/index.php?r=site/display&id=1378)

  [![](/kcfinder/upload/images/12.%20Procedures.png)](?r=SearchProcedure/index)  [Procedures](?r=SearchProcedure/index)

  ![](/kcfinder/upload/images/19.%20Forms.png)  [Forms](index.php?r=SearchForms/index)

## **Export  Resources**

![](/kcfinder/upload/images/22.%20Commercial%20Exports%282%29.png)  [Commercial Exports](index.php?r=site/display&id=71)

![](/kcfinder/upload/images/15.%20Import%20Policy%20Order.png)  [Export Policy](http://index.php?r=site/display&id=1610)

[](index.php?r=site/display&id=1862)  ![](/kcfinder/upload/images/6.%20Export%20Incentives.png)[Incentives on Export](index.php?r=site/display&id=1862)

[![](/kcfinder/upload/images/1.%20GSP%20Tracker.png)](?r=site/display&id=110)  [GSP Tracker](?r=site/display&id=110)

![](/kcfinder/upload/images/5.%20Expo-Importer%20Database.png)  [Exporters’ Database](/index.php?r=site/display&id=921)

![](/kcfinder/upload/images/23.%20Export%20Guide.png)  [Export Guide & Fair Calendar](index.php?r=site/display&id=598)

![](/kcfinder/upload/images/15.%20Import%20Policy%20Order.png)  [MFN Tariff for Top 10 Export Countries](index.php?r=site/display&id=1154)

![](/kcfinder/upload/images/23.%20Export%20Guide.png)  [Booklet of Trade Agreements](/kcfinder/upload/files/Booklet_of_Trade_Agreements%281%29.pdf)

## **Import Resources**

![](/kcfinder/upload/images/8.%20Commercial%20Imports.png)  [Commercial Imports](index.php?r=site/display&id=104)

![](/kcfinder/upload/images/15.%20Import%20Policy%20Order.png)  [Import Policy Order](index.php?r=site/display&id=1643)

## **Feature Information for Entrepreneur**

![](/kcfinder/upload/images/25.%20Startup%20Process.png)  [Business Startup Process](index.php?r=site/display&id=429)

![](/kcfinder/upload/images/10.%20Market%20Access.png)  [Market Access Information](?r=site/display&id=13)

![](/kcfinder/upload/images/13.%20TBT-SBS%20Inquiry%20Points.png)  [TBT/SPS Enquiry Points](?r=site/display&id=4)

![](/kcfinder/upload/images/13.%20TBT-SBS%20Inquiry%20Points.png)  [TBT/SPS WTO Notification](?r=site/display&id=1206)

![](/kcfinder/upload/images/24.%20Economic%20Overview.png)  [WTO Trade and Tariff Data](https://www.wto.org/english/res_e/statis_e/statis_e.htm)

![](/kcfinder/upload/images/2.png)  [Women Entrepreneurship Development](/index.php?r=site/display&id=1198)

## **News & Articles**

![](/kcfinder/upload/images/23.%20Export%20Guide.png)  [](/kcfinder/upload/files/Booklet_of_Trade_Agreements%281%29.pdf)[NewsLetter](?r=site/display&id=1229)

![](/kcfinder/upload/images/17.%20News.png)  [News](?r=site/displaythemostrecentxx&category=News)

![](/kcfinder/upload/images/26.%20Publications.png)  [Publications](?r=site/displaythemostrecentxx&category=Publication)

![](/kcfinder/upload/images/27.%20Announcements.png)  [Announcements](?r=site/displaythemostrecentxx&category=Announcement)

![](/kcfinder/upload/images/18.%20Useful%20Links.png)  [Useful Links](?r=site/display&id=14)

 **Follow Us**

 [![](/kcfinder/upload/images/4.%20Facebook.png)](https://www.facebook.com/profile.php?id=61576178882365)   [![](/kcfinder/upload/images/7.%20Twitter.png)](http://twitter.com/btpbd)   [![](/kcfinder/upload/images/28.%20Youtube.png)](https://www.youtube.com/@projectdirectorbrcpmoc7474)  [![](/kcfinder/upload/images/3.%20LinkedIn.png)](http://www.linkedin.com/company-beta/13354559)

Upcoming Events

[See all events >>](/index.php?r=site/displaythemostrecentxx&category=Event)

[Site Map](/index.php?r=site/display&id=9) | [Commonly Used Terms](/index.php?r=site/display&id=10) | [Terms and Conditions](/index.php?r=site/display&id=11) | [Feed Back](/index.php?r=site/feedback)

© 2016 Ministry of Commerce, Government of the People's Republic of Bangladesh. All Rights Reserved