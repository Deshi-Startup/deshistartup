---
source: "Bangladesh Bank"
tier: 1
category: "Central bank"
url: "https://bb.org.bd/en/index.php/monetaryactivity/bcr_rate"
title: "Bangladesh Bank"
scraped_at: "2026-07-02"
---

![Alert](/en/assets/img/website/brd_law_banner.jpg)

![Alert](/en/assets/img/website/Popup-psd.jpg)

![Alert](/en/assets/img/website/new-note-secfeature-2.jpg)

![Alert](/en/assets/img/website/crowdfunding_alert_13july2025.jpg)

![BB logo usage alert](/en/assets/img/website/bblogousagealert2025.jpg)

![Offshore Banking Law Feature](/en/assets/img/website/offshore-banking-law-2024.jpg)

![Special Notice](/en/assets/img/website/bb_logo_alert.jpg)

![Cautionary Notice](/en/assets/img/website/web---2.jpg)

![FEPD Notice](/en/assets/img/website/fepd_webnotice_sep2023.jpg)

Honorable Governor

![](/en/assets/img/imggovernors/md_mostaqur_rahman.jpg)

## Md Mostaqur Rahman FCMA Honorable Governor of Bangladesh Bank

[more....](/en/index.php/about/governor)

Recent news

-   [MPC Resolution: 29th June, 2026](../../mediaroom/notice/notice_340.pdf)
-   [Monetary Policy Review 2025-26](<../../pub/halfyearly/monetaryprev/mpr 2025-26.pdf>)
-   [SMESPD Circular Letter No. 03: Addendum of Operating Guidelines for JICA assisted Urban Building Safety Project (UBSP, BD-P84)](../../mediaroom/circulars/smespd/jul022026smespdl03e.pdf)
-   [FEPD-1 Circular No. 16: Forward Rate Agreements to hedge interest rate risk against imports under suppliers’/buyers’ credit](../../mediaroom/circulars/fepd/jul022026fepd-116e.pdf)
-   [PSD-2 Circular Letter No. 05: Determination of Fees/Charges for NPSB Transactions and Government Payments](../../mediaroom/circulars/psd-2/jul012026psd-2l05.pdf)
-   [ACD-1 Circular Letter No. 02: Formulation of Bangladesh Bank Agricultural Development Common Fund (BBADCF)](../../mediaroom/circulars/acd/jul012026acd-1l02.pdf)
-   [SDAD Circular Letter No. 10: Regarding approval of downtime of Citizens Bank Plc.](../../mediaroom/circulars/sdad/jul012026sdadl10.pdf)
-   [SDAD Circular Letter No. 09: Policy regarding investment of scheduled banks in Non-listed securities.](../../mediaroom/circulars/sdad/jul012026sdadl09.pdf)
-   [FEPD-1 Circular No. 15: Pilot framework for digital processing of trade documents under documentary collections and letters of credit through approved trade corridors](../../mediaroom/circulars/fepd/jul012026fepd-115e.pdf)
-   [BRPD-1 Circular Letter No. 23: Special Exit Policy for Recovery/Settlement of Loans](../../mediaroom/circulars/brpd/jun292026brpd-1l23.pdf)
-   [BRPD-1 Circular Letter No. 22: Regarding the Intermediation spread between the weighted average interest rate of advances and deposits.](../../mediaroom/circulars/brpd/jun292026brpd-1l22.pdf)
-   [FCRPD Circular Letter No. 14: Awareness and complaint resolution about online financial fraud.](../../mediaroom/circulars/fid/jun292026fcrpdl14.pdf)

## Monetary Policy

-   [MPS (July-December, 2026)](../../../../../monetaryactivity/mps/mps_h1fy27.pdf)   New
-   [Monetary Policy](/en/index.php/monetaryactivity/monetarypolicy)
-   [MPC Resolution New](/en/index.php/monetaryactivity/mpc_resolution)
-   [Repo Information](/en/index.php/monetaryactivity/repoauction/1)
-   [BB Bill Auction](/en/index.php/monetaryactivity/bbbill)

## [MEDIA & Press Release](/en/index.php/mediaroom/index)

-   [Circulars/Circular Letters](/en/index.php/mediaroom/circular)
-   [Press Release](/en/index.php/mediaroom/press_release)
-   [Regulations And Guidelines](/en/index.php/about/guidelist)
-   [Procurements underway](/en/index.php/about/tenders)

## INVESTMENT FACILITY

-   [Facilities/Incentives](/en/index.php/Investfacility/invesfac)
-   [Inward Remmittance Facilities](/en/index.php/investfacility/drawing)
-   [NRB Bond](/en/index.php/Investfacility/nrbbond)
-   [Prizebond](/en/index.php/Investfacility/prizebond)   |   [Sanchayapatra](/en/index.php/Investfacility/sanchayapatra)

## [ECONOMIC DATA](/en/index.php/econdata/index)

-   [Wage Earner's Remittance Inflow](../../../../econdata/provisionalwrem/premittances.pdf)
-   [BOP, Export & Import](</en/index.php/econdata/bopindex >)
-   [NSDP](../../../../../econdata/nsdp/nsdp_bb.php)
-   [Recent Upload](/en/index.php/econdata/index)

## G-Sec Market

-   [Government Securities Market](/en/index.php/financialactivity/govsecmrkt/index)
-   [Primary Auction of Treasury Bill & Bond](/en/index.php/monetaryactivity/treasury)
-   [G-Sec OMS](https://gsom.bb.org.bd/index.php)  | [YTM Curve](https://gsom.bb.org.bd/dailyYield.php)  | [MTM](https://gsom.bb.org.bd/mtm.php)
-   [BD Govt Investment Sukuk (BGIS)](/en/index.php/monetaryactivity/bgis_home)

## [Payment Systems](/en/index.php/financialactivity/paysystems)

-   [Bangladesh Payment Systems Report (BPSR)](https://www.bb.org.bd/en/index.php/publication/publictn/0/91)
-   [Half-Yearly Payment Platforms](/en/index.php/Financialactivity/platformwise_stat)
-   [Trend Analysis of Payment Platforms](/en/index.php/Financialactivity/payment_transtrend)
-   [National Payment Data](</en/index.php/Financialactivity/nat_payment_list >)

## [LINKS](/en/index.php/links/index)

-   [BFIU Website](https://www.bfiu.org.bd)
-   [BBTA Webportal](../../../../../bbta_portal/index.php/bbta/home)
-   [SME Portal](../../../../../smespd_portal/index.html)
-   [E-Tender](https://etender.bb.org.bd)  |  [E-Recruitment](https://erecruitment.bb.org.bd)
-   [BIDA One Stop Service (OSS) Portal](https://bidaquickserv.org)

## [Financial Stability](/en/index.php/Financialstability/)

-   [Financial Stability Committee](/en/index.php/Financialstability/finstabilitycommittee)
-   [Macroprudential Supervision](/en/index.php/Financialstability/macrosuper)
-   [Guidelines, Circulars and Reports](/en/index.php/Financialstability/reportscirulars)
-   [Contemporary Financial Stability Issues](/en/index.php/Financialstability/stabilityissues)

## INNOVATION CORNER

-   [Innovation Team](/en/index.php/mediaroom/inno_member)
-   [Innovation Action Plan (2023-2024)](../../../../../mediaroom/innovationcorner/actionplan.pdf)
-   [Innovation Guidelines (2023-2024)](../../../../../mediaroom/innovationcorner/actionplanguideline.pdf)
-   [Progress Report](/en/index.php/mediaroom/progress_report)

## [National Integrity Strategy](/en/index.php/about/nis)

-   [Ethics committee](/en/index.php/about/ethics_comm)
-   [Implementation plan](/en/index.php/about/nis)
-   [Integrity Award (FY 2020-21) winner](../../../../../aboutus/dept/sd/intawd_20_21.pdf)
-   [Others](/en/index.php/about/budget_plan)

## Citizen Charter

-   [Citizen Charter of Bangladesh Bank](../../../../../citizen_charter/bb_citizencharter_2024.pdf)
-   [Focal Point](../../../../../citizen_charter/citizen_charter_focal_point.pdf)  |  [Monitoring Committee](../../../../../citizen_charter/cc_monitoring_committee_en.pdf)
-   [Annual Workplan (2023-2024)](../../../../../citizen_charter/annual_workplan_ccharter_2023-24.pdf)
[](../../../../../citizen_charter/annual_workplan_ccharter_2023-24.pdf)-   [](../../../../../citizen_charter/annual_workplan_ccharter_2023-24.pdf)[Recent Information](/en/index.php/home/citizen_charter)
[](/en/index.php/home/citizen_charter)

[](/en/index.php/home/citizen_charter)

[](/en/index.php/home/citizen_charter)

[](/en/index.php/home/citizen_charter)

[](/en/index.php/home/citizen_charter)

[

## National ICT Policy

](/en/index.php/home/citizen_charter)

[

](/en/index.php/home/citizen_charter)

[](/en/index.php/home/citizen_charter)

[](/en/index.php/home/citizen_charter)-   [](/en/index.php/home/citizen_charter)[National ICT Policy](https://ictd.portal.gov.bd/sites/default/files/files/ictd.portal.gov.bd/policies/0b508068_d74f_45a1_864a_516536af3060/%E0%A6%A4%E0%A6%A5%E0%A7%8D%E0%A6%AF%20%E0%A6%93%20%E0%A6%AF%E0%A7%8B%E0%A6%97%E0%A6%BE%E0%A6%AF%E0%A7%8B%E0%A6%97%20%E0%A6%AA%E0%A7%8D%E0%A6%B0%E0%A6%AF%E0%A7%81%E0%A6%95%E0%A7%8D%E0%A6%A4%E0%A6%BF%20%E0%A6%A8%E0%A7%80%E0%A6%A4%E0%A6%BF%E0%A6%AE%E0%A6%BE%E0%A6%B2%E0%A6%BE%20%E0%A7%A8%E0%A7%A6%E0%A7%A7%E0%A7%AE.pdf)
-   [ICT Focal Point](../../../../aboutus/dept/isdsd/focal_point.pdf)
-   [Implementation Committee](../../../../aboutus/dept/isdsd/imp_committee_2018.pdf)

## [SERVICES](/en/index.php/services/index)

-   [E-Services](/en/index.php/services/eservices)
-   [Customer Complaints](https://cmsform.bb.org.bd/apps/f?p=107)
-   [BB Forms](/en/index.php/services/bbforms)
-   [Claim your money](/en/index.php/services/bank_unclaimed_links)

## Recent Upload

-   [News Clips](https://www.bb.org.bd/bblibrary/index.php/bblibrary/newsclip)
-   [Foreign Visit/Passport/NOC](/en/index.php/about/foreign_visit_info)
-   [Notice Board](/en/index.php/mediaroom/noticeboard)  |  [Meeting Minutes](/en/index.php/mediaroom/meeting_minutes)
[](/en/index.php/mediaroom/meeting_minutes)-   [](/en/index.php/mediaroom/meeting_minutes)[Sustainability Rating of Bank & FI](/en/index.php/about/sustainability_rating)
-   [Banknotes & Coins](/en/index.php/currency/index)

## POLICY RATES

Policy Rate (Repo Rate)

10.00%

SLF Rate

11.50%

SDF Rate

7.50%

Bank Rate

4.00%

Last update: 15.02.2026

## RESERVE RATIOS

SLR

CRR

traditional banking

13%

4.0%

islamic banking

5.5%

4.0%

deposit taker FIs

5%

1.5%

non deposit taker FIs

2.5%

Last update: 09.05.2024

## INTER-BANK EXCHANGE RATE

[](#)

(Previous working day)

Currency

Highest

Lowest

WAR

USD

122.8500

122.8500

122.8500

Last update: 2nd July, 2026

[READ MORE](/en/index.php/fxmarket/interbank_fxmarket)

## ICT Security Alert

[ICT Security Advisories & Alerts](/en/index.php/about/secalrt "Security Advisories & Alerts")

## Customers' Interest Protection Center(CIPC)

For any Complaint

Call: 16236  
Email: bb.cipc@bb.org.bd  
[Download Mobile App](https://play.google.com/store/apps/details?id=bd.org.bb.cms "Download Apps from Google Playstore")  
[Submit Online](https://cmsform.bb.org.bd/apps/f?p=107 "Submit Your Complaint at CMS Portal")

[View all →](/en/index.php/services/cipc_procedure)

## \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_  

FX Market Spot Exchange Rate  
(Reference Rate in USDBDT)

02 July, 2026  
(Operation till 05:00 PM)

# 122.8204

[View all →](/en/index.php/econdata/rfrexrate)

##   
\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_  
  
Call Money Rate

02 July, 2026

Weighted Average Interest Rate

# 9.61

[View all →](/en/index.php/monetaryactivity/call_money_market)

##   
\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_  

## Money Market Reference Rate (MMRR)

02 July, 2026

## DOMMR (O/N)

# 9.62

## BOFR (O/N)

# 9.55

[View all →](/en/index.php/monetaryactivity/money_market_ref_rate)

Bill

[July, 2026](/en/index.php/monetaryactivity/auc_calendar/2041)

[05](/en/index.php/monetaryactivity/auc_calendar/2041)

Bond

[July, 2026](/en/index.php/monetaryactivity/auc_calendar/2054)

[07](/en/index.php/monetaryactivity/auc_calendar/2054)

[View all →](/en/index.php/monetaryactivity/auc_calendar)

* * *

## Emergency Hotline

[![](/en/assets/img/website/national-helpline.jpg)](https://bangladesh.gov.bd/site/page/aaebba14-f52a-4a3d-98fd-a3f8b911d3d9)