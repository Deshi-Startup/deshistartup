---
source: "Dhaka Chamber of Commerce & Industry (DCCI)"
tier: 1
category: "Chamber"
url: "https://dhakachamber.com/dcci-former-senior-vice-presidents"
title: "DCCI ::  Former Senior Vice Presidents"
scraped_at: "2026-07-02"
---

# Former Senior Vice Presidents

![](https://dhakachamber.com/storage/dcci-former-svps/January2020/8Q369pq06IrOWpKPK1ZG.png)

### H.M. Shekil

(1967-68)

![](https://dhakachamber.com/storage/dcci-former-svps/October2019/bMDSXglkfBwy6hJt4YZL.jpg)

### A. Sattar Karawadia

(1970-72)

![](https://dhakachamber.com/storage/dcci-former-svps/January2020/MnvdUFBtpqAevQq8xcye.png)

### Khorshed Alam

(1973)

![](https://dhakachamber.com/storage/dcci-former-svps/October2019/6Q12JJuTk04zyDoakdp9.jpg)

### A.M.M Shamsul Alam

(1975)

![](https://dhakachamber.com/storage/dcci-former-svps/October2019/nEleDvqmgtlvyEtv1Hik.jpg)

### Late M.A Huq

(1976-78)

![](https://dhakachamber.com/storage/dcci-former-svps/October2019/IIlIDGdZSswLy6fMG34X.jpg)

### Late M.A. Khaleque

(1978-79)

![](https://dhakachamber.com/storage/dcci-former-svps/October2019/9rY1LyDYTIzkaSlmoSba.jpg)

### Late M. Reza

(1979-82)

![](https://dhakachamber.com/storage/dcci-former-svps/October2019/Qv4ca8xLhOgXqrVoA6GY.jpg)

### Late Shamsuzzoha Khan

(1982-84)

![](https://dhakachamber.com/storage/dcci-former-svps/October2019/3PueZ81qGySWQctfdp6v.jpg)

### Alhaj Abdus Salam

(1984-85)

![](https://dhakachamber.com/storage/dcci-former-svps/January2020/qYwcMM6uieARaWDMoyUJ.png)

### Md. Ali Hossain

(1985-86)

![](https://dhakachamber.com/storage/dcci-former-svps/January2020/KJAeeC4spevWgkM2l2yt.png)

### Md. Ali Hossain

(1986-88)

![](https://dhakachamber.com/storage/dcci-former-svps/June2019/kn43LDz2dPE70sjmCz2B.jpg)

### Late A.M. Mubash-shar

(1989-90)

![](https://dhakachamber.com/storage/dcci-former-svps/June2019/EKWKnvRzoRQmb1sLdjZW.jpg)

### Late A.M. Mubash-shar

(1991-92)

![](https://dhakachamber.com/storage/dcci-former-svps/June2019/5uQSys12BT66nCvt0p75.jpg)

### Late Masudur Rahman

(1992-93)

![](https://dhakachamber.com/storage/dcci-former-svps/October2019/OJOblCqjGDlsQCvYn9uN.jpg)

### Syed Jamaluddin Haider

(1993-94)

![](https://dhakachamber.com/storage/dcci-former-svps/June2019/9olKAr2jrxUkKkfjKtme.jpg)

### Late Sajjatuz Jumma

(1994-95)

![](https://dhakachamber.com/storage/dcci-former-svps/June2019/1KPGiQbKk3ziekOQbLns.jpg)

### Hossain Akkhtar

(1995)

![](https://dhakachamber.com/storage/dcci-former-svps/June2019/teBXFNjt7Q8Ekp34Ri17.jpg)

### Fazle R.M. Hasan, FCA

(1996)

![](https://dhakachamber.com/storage/dcci-former-svps/June2019/abfxNdiiTTI01m6RvkTF.jpg)

### Ashraf Ibn Noor

(1997)

![](https://dhakachamber.com/storage/dcci-former-svps/June2019/2rcjzkaHeIZ9js7Ybqwr.jpg)

### Late Masudur Rahman

(1998)

![](https://dhakachamber.com/storage/dcci-former-svps/June2019/I1n1SaWcK9PNRUd4JfQQ.jpg)

### Late Sajjatuz Jumma

(1999)

![](https://dhakachamber.com/storage/dcci-former-svps/June2019/7hSmUoXYTmmb8hpkNGnZ.jpg)

### Late A.M. Mubash-Shar

(2000)

![](https://dhakachamber.com/storage/dcci-former-svps/June2019/6xEIS7T69L8NfjbMKZNO.jpg)

### Late Mahbub-Uz-Zaman

(2001)

![](https://dhakachamber.com/storage/dcci-former-svps/October2019/shphlAtaaJ5bAKl8mdEK.jpg)

### Shabbir Ahmed Khan

(2002)

![](https://dhakachamber.com/storage/dcci-former-svps/June2019/uuJaH0PzGmBX6nE2h3B1.jpg)

### Zafar Osman

(2003)

![](https://dhakachamber.com/storage/dcci-former-svps/June2019/6L7OA41hB38ffkUdvWji.jpg)

### Late A.M. Mubasher-Shar

(2004)

![](https://dhakachamber.com/storage/dcci-former-svps/June2019/LytyH63plL4ykVXPAN40.jpg)

### Manzur-Ur-Rahman (Ruskin)

(2005)

![](https://dhakachamber.com/storage/dcci-former-svps/June2019/lplSebrSChNa4jwlDhyG.jpg)

### Hossain Khaled

(2006)

![](https://dhakachamber.com/storage/dcci-former-svps/June2019/tWCuP1ipoGTXXAOglHfO.jpg)

### Late M. Shahjahan Khan

(2007)

![](https://dhakachamber.com/storage/dcci-former-svps/June2019/xjhN6qpgdLAxpGxtsiXA.jpg)

### Late Salahuddin Abdullah

(2008)

![](https://dhakachamber.com/storage/dcci-former-svps/June2019/iziXv3e9estkWtuGobzD.jpg)

### M.S. Shekil Chowdhury

(2009)

![](https://dhakachamber.com/storage/dcci-former-svps/June2019/5Y9GAKtQgpdGBjsBGbwL.jpg)

### Late M. Shahjahan Khan

(2010)

![](https://dhakachamber.com/storage/dcci-former-svps/June2019/Yf7nzlQT8w2LIlmmeiWg.jpg)

### T.I.M. Nurul Kabir

(2011)

![](https://dhakachamber.com/storage/dcci-former-svps/June2019/1WWQTb4KJkbTCzwiYLIz.jpg)

### Haider Ahmed Khan, FCA

(2012)

![](https://dhakachamber.com/storage/dcci-former-svps/June2019/Y2auaPJlWXVkwJ2BuLxS.jpg)

### Nessar Maksud Khan

(2013)

![](https://dhakachamber.com/storage/dcci-former-svps/June2019/lziF2v0EAY2ayg9tgtCj.jpg)

### Osama Taseer

(2014)

![](https://dhakachamber.com/storage/dcci-former-svps/June2019/ppdyi8a1CiTz1rVxDUPG.jpg)

### Humayun Rashid

(2015-2016)

![](https://dhakachamber.com/storage/dcci-former-svps/June2019/YSJykp4CQ0beiiqEYCnI.jpg)

### Kamrul Islam,FCA

(2017-2018)

![](https://dhakachamber.com/storage/dcci-former-svps/December2019/Bh2WB8QcTVQNARgmTHal.jpg)

### Waqar Ahmad Choudhury

(2019)

![](https://dhakachamber.com/storage/dcci-former-svps/December2021/k3lHR4JjbL5okJ00qXhP.jpg)

### N K A Mobin, FCS, FCA

(2020-2021)

![](https://dhakachamber.com/storage/dcci-former-svps/December2022/vgK4QUtSL2FR4QuDH7fA.jpg)

### Arman Haque

(2022)

![](https://dhakachamber.com/storage/dcci-former-svps/December2023/WLJ0xmmmMG6WQuItlNxK.jpg)

### S M Golam Faruk Alamgir (Arman)

(2023)

![](https://dhakachamber.com/storage/dcci-former-svps/December2024/rnJn37Emr5qj3PIFKUOQ.jpg)

### Malik Talha Ismail Bari

(2024)

### ABOUT US

-   [Board of Directors](https://dhakachamber.com/board-of-directors)
-   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
-   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)

### USEFUL LINKS

-   [DBI College](http://www.dbicollege.edu.bd)
-   [DCCI Business Institute](http://dcci-dbi.edu.bd)
-   [BUILD](http://www.buildbd.org)
-   [BIAC](https://www.biac.org.bd)
-   [ICCB](https://iccbangladesh.org.bd)

### MEMBERSHIP

-   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
-   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
-   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
-   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
-   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
-   [Become a Member](https://membership.dhakachamber.com/register)
-   [Member Login](https://membership.dhakachamber.com)
-   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
-   [Member Query](https://dhakachamber.com/member-query)
-   [Hot Line](https://dhakachamber.com/hot_line)

### MEDIA

-   [Chamber News](https://dhakachamber.com/media/news)
-   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
-   [Photo Gallery](https://dhakachamber.com/albums)
-   [Video Gallery](https://dhakachamber.com/videos)

### DOWNLOAD

-   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
-   [DCCI Reviews](https://dhakachamber.com/publications/reviews)
-   [DCCI Publications](https://dhakachamber.com/publications)
-   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
-   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)

×

-   [Home(current)](https://dhakachamber.com)
-   [About us](#)
    -   [Brief About DCCI](https://dhakachamber.com/about-us)
    -   [International Affiliations](https://dhakachamber.com/international-affiliations)
    -   [DCCI Founders](https://dhakachamber.com/dcci-founders)
    -   [Former Presidents](https://dhakachamber.com/dcci-former-presidents)
    -   [Former Senior Vice Presidents](https://dhakachamber.com/dcci-former-senior-vice-presidents)
    -   [Former Vice Presidents](https://dhakachamber.com/dcci-former-vice-presidents)
    -   [Achievements & Awards](https://dhakachamber.com/achievements-awards)
    -   [Policy and Objectives](https://dhakachamber.com/quality-policy-and-objectives)
-   [Organizational Information](#)
    -   [Board of Directors](https://dhakachamber.com/board-of-directors)
    -   [Previous Board of Directors](https://dhakachamber.com/dcci-allpastmanagement)
    -   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
    -   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)
-   [President](https://dhakachamber.com/president)
-   [Membership](#)
    -   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
    -   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
    -   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
    -   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
    -   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
    -   [Become a Member](https://membership.dhakachamber.com/register)
    -   [Member Login](https://membership.dhakachamber.com)
    -   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
    -   [Member Query](https://dhakachamber.com/member-query)
    -   [Hot Line](https://dhakachamber.com/hot_line)
-   [Projects](https://dhakachamber.com/project-activities)
-   [Seminar](https://dhakachamber.com/media/seminar)
-   [Publications](#)
    -   [DCCI Research Service](https://dhakachamber.com/pdf_viewer/storage/2024/circular/DCCI%20Research%20Service.pdf)
    -   [Research Guideline](https://dhakachamber.com/pdf_viewer/storage/2024/circular/Research%20Guideline.pdf)
    -   [DCCI Journal (DJBEP)](https://journal.dhakachamber.com/)
    -   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
    -   [DCCI Review](https://dhakachamber.com/publications/reviews)
    -   [DCCI Publications](https://dhakachamber.com/publications)
    -   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
    -   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)
    -   [Introducing DCCI 2023](https://www.dhakachamber.com/storage/print_media/2023/07/Introducing%202023.pdf)
-   [Media](#)
    -   [Chamber News](https://dhakachamber.com/media/news)
    -   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
    -   [Photo Gallery](https://dhakachamber.com/albums)
    -   [Video Gallery](https://dhakachamber.com/videos)
    -   [Fairs & Exhibitions](https://www.dhakachamber.com/storage/2026/03/dccifair.pdf)
-   [Policy](#)
    -   [Export Policy](https://www.dhakachamber.com/storage/policy/3VFoMxkr6Z3EZdC8wz7YHfrIBfPP5N0Y6n7eEEFJ.pdf)
    -   [Import Policy](https://www.dhakachamber.com/storage/policy/b6uhXGhpdl30N68gl3Yg9mV5P6vGIPAjquqTu35f.pdf)
    -   [Industry Policy](https://www.dhakachamber.com/storage/policy/kpHRSdbYmY90O7wcyYmkZTSvumKEXfz5uwPTlOn5.pdf)
    -   [ICT Policy](https://www.dhakachamber.com/storage/policy/abTlbODgI2I4Aqbrix5Cs2DHvFD5lW3OwDmfKXmH.pdf)
-   [BILATERAL TRADE](#)
    -   [Bilateral Trade](https://dhakachamber.com/bilateral-trade)
    -   [Africa](https://dhakachamber.com/bilateral-trade/africa)
    -   [America](https://dhakachamber.com/bilateral-trade/america)
    -   [Asian](https://dhakachamber.com/bilateral-trade/asian)
    -   [ASEAN](https://dhakachamber.com/bilateral-trade/asean)
    -   [SAARC](https://dhakachamber.com/bilateral-trade/saarc)
    -   [Middle East](https://dhakachamber.com/bilateral-trade/middle-east)
    -   [European Union](https://dhakachamber.com/bilateral-trade/european-union)
-   [About Bangladesh](#)
    -   [General Information](https://dhakachamber.com/bangladesh-country-profile)
    -   [Business Opportunities in Bangladesh](https://dhakachamber.com/trade-and-business-opportunities-in-bangladesh)
    -   [Useful Links](https://dhakachamber.com/useful-links)
-   [B2B Directory](#)
    -   [B2B Directory](https://dhakachamber.com/b2b)
    -   [B2B Member Login](https://dhakachamber.com/login)
    -   [B2B Registration](https://dhakachamber.com/b2b-reg)