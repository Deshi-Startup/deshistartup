---
source: "Dhaka Chamber of Commerce & Industry (DCCI)"
tier: 1
category: "Chamber"
url: "https://dhakachamber.com/bangladesh-country-profile"
title: "DCCI ::  Bangladesh Country Profile"
scraped_at: "2026-07-02"
---

# Bangladesh Country Profile

## Bangladesh Country Profile

#### Official Name :

People's Republic of Bangladesh

#### Form of Government

Parliamentary Form of Government

#### Head of State

President

#### Head of Government

Prime Minister

#### Geographical Location

In South Asia: between 20 degree 34 and 26 degree 38 North Latitude and between 88 degree 01 and 92 degree 41 East Longitude Consists of mostly flat fertile alluvial land.

#### Boundaries

North: India (West Bengal & Meghalaya), West: India (West Bengal), East: India, (Tripura & Assam) and Myanmar, South: Bay of Bengal

#### Area

147,570 sq km (56,977 sq miles) (Territorial water- 12 nautical miles)

#### Capital City

Dhaka (Metropolitan Area 522 sq. kms.)

#### Standard Time

GMT +6 hours

#### Climate

Tropical; Mild Winter (October to March); Hot, Humid Summer (March to June); Humid- Warm Rainy Monsoon (June to October)     

#### Rainfall

1194 mm to 3454 mm (June- August)

#### Population

159.9 million (2015-16 Projected)

#### Life expectancy

69.4 years (men), 72.0 years (women), 70.9 (Both)

#### Per Capita GDP

US $ 1385

#### Internet domain

.bd

#### International dialing code

+880

#### Land boundaries

Total: 4,246 km (border countries: Myanmar 193 km, India 4,053 km)

#### Highest peak

Keokradong (Bandarban Hill District) 1,230 m

#### Labor force

by occupation: agriculture: 45.1%, industry: 20.08%, services: 34.01% 

#### Literacy Rate

63.6% (HIES 2015) 

#### Language 

95 percent Bengali, 5 percent other dialects. English is widely understood and spoken. 

#### Religion 

Muslim (88.3%), Hindu (10.5%), Buddhist (0.6%), Christian (0.3%) and Animists and believers in tribal faiths (0.3%). 

#### Food 

Rice, bread, fruits, vegetables, pulses, fish, meat and potato 

#### Currency 

Taka (BDT) 

#### Principal Industries 

Jute, Tea, Textiles, Ready Made Garments (RMG), Paper, Newsprint, Fertilizer, Leather and Leather Goods, Sugar, Cement, Fish processing, Pharmaceuticals, Chemical Industries, Plastic and Ceramics. 

#### Major Trading Partners 

USA, EU countries, India, China, Japan, South Korea, Australia, Malaysia, Hong Kong, Taiwan, Indonesia, Thailand, Saudi Arabia, UAE etc. 

#### Traditional Export Goods 

Raw Jute, Jute Goods, Tea, Leather, and Leather Products etc. 

#### Non-traditional Exports 

Ready-made garments, Knitwear, Frozen Shrimps, Other Fish products, Jute Carpet, Shoes and other leather goods, Newsprint, Paper, Naphtha, Furnace Oil, Urea, Fruits & Vegetables, Cut Flower, Handicrafts, Jewelries. 

#### Principal Imports 

Petroleum products, Food Grains, Oil Seeds, Crude Petroleum, Fertilizer, Cement Clinker, Staple Fibers, Yarn, Fabrics, Iron, & Steel, Capital Machineries, Automobiles etc. 

#### International Airports 

Dhaka International Airport, Dhaka, Shah Amanat International Airport, Chittagong and Osmani International Airport, Sylhet. 

#### Domestic Airports 

Dhaka, Chittagong, Sylhet, Cox's Bazar, Thakurgaon, Syedpur, Rajshahi, Jessore, Barisal and Ishwardi. 

#### Domestic Airlines 

Public Sector: Bangladesh Biman, Private Sector: GMG Airlines, Best Air, Royal Bengal and United Airways (BD.) Ltd. 

#### Sea Ports 

Chittagong and Mongla 

#### Inland River Ports 

Dhaka, Chandpur, Barisal, Khulna, Bhairab, Naryanganj, Sirajganj. 

#### Land Ports 

Benapol, Teknaf, Banglabandha, Sonamasjid, Hili, Darshana, Birol, Burimari, Tamabil, Haluaghat, Akhaura, Bibirbazar and Bhomra. 

#### Radio Broadcast Station 

Dhaka, Chittagong, Rajshahi, Khulna, Sylhet, Comilla, Rangamati and Thakurgaon. 

#### TV Broadcast 

Dhaka, Natore, Chittagong, Brahmanbaria, Patuakhali, Noakhali Bangladesh Television, Chanel I, ATN Bangla, NTV etc. 

#### Press 

The Daily Star, The Financial Express, New Age, Prothom alo, Jugantor, Ittefaq, Inquilab etc are some prominent dailies. 

#### News Agency 

Bangladesh Sangbad Sangstha (BSS), UNB, Bdnews24.com etc. 

#### Satellite Station 

Betbunia and Talibabad 

#### Tourist Season 

October to March 

#### Exports - partners 

USA 18.17%, Germany 14.57%, UK 11.13%, France 5.41%, Belgium 2.97%, Italy 4.05%, Canada 3.25%, Netherlands 2.47% 

#### Imports - partners 

China 29.57%, India 13.37%, Singapore 5.25%, Japan 4.84%, Malaysia 3.87%, Korea Rep. of 3.32%, Hong Kong 19.3%, USA 2.64% 

#### Communications 

Railways: 2,877 km, Roadways: total: 21,302 km, Waterways: 24,000 km (Navigable 5968)

### ABOUT US

-   [Board of Directors](https://dhakachamber.com/board-of-directors)
-   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
-   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)

### USEFUL LINKS

-   [DBI College](http://www.dbicollege.edu.bd)
-   [DCCI Business Institute](http://dcci-dbi.edu.bd)
-   [BUILD](http://www.buildbd.org)
-   [BIAC](https://www.biac.org.bd)
-   [ICCB](https://iccbangladesh.org.bd)

### MEMBERSHIP

-   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
-   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
-   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
-   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
-   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
-   [Become a Member](https://membership.dhakachamber.com/register)
-   [Member Login](https://membership.dhakachamber.com)
-   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
-   [Member Query](https://dhakachamber.com/member-query)
-   [Hot Line](https://dhakachamber.com/hot_line)

### MEDIA

-   [Chamber News](https://dhakachamber.com/media/news)
-   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
-   [Photo Gallery](https://dhakachamber.com/albums)
-   [Video Gallery](https://dhakachamber.com/videos)

### DOWNLOAD

-   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
-   [DCCI Reviews](https://dhakachamber.com/publications/reviews)
-   [DCCI Publications](https://dhakachamber.com/publications)
-   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
-   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)

×

-   [Home(current)](https://dhakachamber.com)
-   [About us](#)
    -   [Brief About DCCI](https://dhakachamber.com/about-us)
    -   [International Affiliations](https://dhakachamber.com/international-affiliations)
    -   [DCCI Founders](https://dhakachamber.com/dcci-founders)
    -   [Former Presidents](https://dhakachamber.com/dcci-former-presidents)
    -   [Former Senior Vice Presidents](https://dhakachamber.com/dcci-former-senior-vice-presidents)
    -   [Former Vice Presidents](https://dhakachamber.com/dcci-former-vice-presidents)
    -   [Achievements & Awards](https://dhakachamber.com/achievements-awards)
    -   [Policy and Objectives](https://dhakachamber.com/quality-policy-and-objectives)
-   [Organizational Information](#)
    -   [Board of Directors](https://dhakachamber.com/board-of-directors)
    -   [Previous Board of Directors](https://dhakachamber.com/dcci-allpastmanagement)
    -   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
    -   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)
-   [President](https://dhakachamber.com/president)
-   [Membership](#)
    -   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
    -   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
    -   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
    -   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
    -   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
    -   [Become a Member](https://membership.dhakachamber.com/register)
    -   [Member Login](https://membership.dhakachamber.com)
    -   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
    -   [Member Query](https://dhakachamber.com/member-query)
    -   [Hot Line](https://dhakachamber.com/hot_line)
-   [Projects](https://dhakachamber.com/project-activities)
-   [Seminar](https://dhakachamber.com/media/seminar)
-   [Publications](#)
    -   [DCCI Research Service](https://dhakachamber.com/pdf_viewer/storage/2024/circular/DCCI%20Research%20Service.pdf)
    -   [Research Guideline](https://dhakachamber.com/pdf_viewer/storage/2024/circular/Research%20Guideline.pdf)
    -   [DCCI Journal (DJBEP)](https://journal.dhakachamber.com/)
    -   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
    -   [DCCI Review](https://dhakachamber.com/publications/reviews)
    -   [DCCI Publications](https://dhakachamber.com/publications)
    -   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
    -   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)
    -   [Introducing DCCI 2023](https://www.dhakachamber.com/storage/print_media/2023/07/Introducing%202023.pdf)
-   [Media](#)
    -   [Chamber News](https://dhakachamber.com/media/news)
    -   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
    -   [Photo Gallery](https://dhakachamber.com/albums)
    -   [Video Gallery](https://dhakachamber.com/videos)
    -   [Fairs & Exhibitions](https://www.dhakachamber.com/storage/2026/03/dccifair.pdf)
-   [Policy](#)
    -   [Export Policy](https://www.dhakachamber.com/storage/policy/3VFoMxkr6Z3EZdC8wz7YHfrIBfPP5N0Y6n7eEEFJ.pdf)
    -   [Import Policy](https://www.dhakachamber.com/storage/policy/b6uhXGhpdl30N68gl3Yg9mV5P6vGIPAjquqTu35f.pdf)
    -   [Industry Policy](https://www.dhakachamber.com/storage/policy/kpHRSdbYmY90O7wcyYmkZTSvumKEXfz5uwPTlOn5.pdf)
    -   [ICT Policy](https://www.dhakachamber.com/storage/policy/abTlbODgI2I4Aqbrix5Cs2DHvFD5lW3OwDmfKXmH.pdf)
-   [BILATERAL TRADE](#)
    -   [Bilateral Trade](https://dhakachamber.com/bilateral-trade)
    -   [Africa](https://dhakachamber.com/bilateral-trade/africa)
    -   [America](https://dhakachamber.com/bilateral-trade/america)
    -   [Asian](https://dhakachamber.com/bilateral-trade/asian)
    -   [ASEAN](https://dhakachamber.com/bilateral-trade/asean)
    -   [SAARC](https://dhakachamber.com/bilateral-trade/saarc)
    -   [Middle East](https://dhakachamber.com/bilateral-trade/middle-east)
    -   [European Union](https://dhakachamber.com/bilateral-trade/european-union)
-   [About Bangladesh](#)
    -   [General Information](https://dhakachamber.com/bangladesh-country-profile)
    -   [Business Opportunities in Bangladesh](https://dhakachamber.com/trade-and-business-opportunities-in-bangladesh)
    -   [Useful Links](https://dhakachamber.com/useful-links)
-   [B2B Directory](#)
    -   [B2B Directory](https://dhakachamber.com/b2b)
    -   [B2B Member Login](https://dhakachamber.com/login)
    -   [B2B Registration](https://dhakachamber.com/b2b-reg)