---
source: "Dhaka Chamber of Commerce & Industry (DCCI)"
tier: 1
category: "Chamber"
url: "https://dhakachamber.com/contact-us"
title: "DCCI ::  Contact us"
scraped_at: "2026-07-02"
---

# Contact us

# Our Offices

![Motijheel Main Office](https://dhakachamber.com/storage/eighticons/Motijheel.jpg)

#### Motijheel Main Office

Dhaka Chamber Building,  
65-66 Motijheel C/A, Dhaka-1000, Bangladesh

**Phone:** +88-0247122986

**IP Phone:** +88-09-666-888555

**Fax:** +88-02223380830

**Email:** [info@dhakachamber.com](mailto:info@dhakachamber.com)

**Website:** [www.dhakachamber.com](https://www.dhakachamber.com)

![DCCI Gulshan Centre](https://dhakachamber.com/storage/eighticons/Gulsan.jpg)

#### DCCI Gulshan Centre

BTI Landmark (level-11), Plot-16, Block-CWS(A), Gulshan Avenue, Gulshan-1, Dhaka-1212, Bangladesh

**Phone:** +88-02226601967, +88-02226601968

**IP Phone:** +88-09-666-319654

**Email:** [info@dhakachamber.com](mailto:info@dhakachamber.com)

**Website:** [www.dhakachamber.com](https://www.dhakachamber.com)

![Mohammadpur Service Zone](https://dhakachamber.com/storage/eighticons/Mohammadpur.jpg)

#### Mohammadpur Service Zone

75C Asad Avenue, Mohammadpur,  
Dhaka-1207, Bangladesh

**IP Phone:** +88-09-666-319655

**IP Phone:** +88-09-666-888555

**Email:** [info@dhakachamber.com](mailto:info@dhakachamber.com)

**Website:** [www.dhakachamber.com](https://www.dhakachamber.com)

### Office Time Schedule

Day

Opening Time

Closing Time

Saturday - Wednesday

9:00 AM

4:00 PM

Thursday

9:00 AM

3:00 PM

Friday

Closed

### Membership Help Desk

Day

Opening Time

Closing Time

Saturday - Wednesday

9:00 AM

4:00 PM

Thursday

9:00 AM

4:00 PM

### Contact Us

Send Message

  
  

### ABOUT US

-   [Board of Directors](https://dhakachamber.com/board-of-directors)
-   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
-   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)

### USEFUL LINKS

-   [DBI College](http://www.dbicollege.edu.bd)
-   [DCCI Business Institute](http://dcci-dbi.edu.bd)
-   [BUILD](http://www.buildbd.org)
-   [BIAC](https://www.biac.org.bd)
-   [ICCB](https://iccbangladesh.org.bd)

### MEMBERSHIP

-   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
-   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
-   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
-   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
-   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
-   [Become a Member](https://membership.dhakachamber.com/register)
-   [Member Login](https://membership.dhakachamber.com)
-   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
-   [Member Query](https://dhakachamber.com/member-query)
-   [Hot Line](https://dhakachamber.com/hot_line)

### MEDIA

-   [Chamber News](https://dhakachamber.com/media/news)
-   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
-   [Photo Gallery](https://dhakachamber.com/albums)
-   [Video Gallery](https://dhakachamber.com/videos)

### DOWNLOAD

-   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
-   [DCCI Reviews](https://dhakachamber.com/publications/reviews)
-   [DCCI Publications](https://dhakachamber.com/publications)
-   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
-   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)

×

-   [Home(current)](https://dhakachamber.com)
-   [About us](#)
    -   [Brief About DCCI](https://dhakachamber.com/about-us)
    -   [International Affiliations](https://dhakachamber.com/international-affiliations)
    -   [DCCI Founders](https://dhakachamber.com/dcci-founders)
    -   [Former Presidents](https://dhakachamber.com/dcci-former-presidents)
    -   [Former Senior Vice Presidents](https://dhakachamber.com/dcci-former-senior-vice-presidents)
    -   [Former Vice Presidents](https://dhakachamber.com/dcci-former-vice-presidents)
    -   [Achievements & Awards](https://dhakachamber.com/achievements-awards)
    -   [Policy and Objectives](https://dhakachamber.com/quality-policy-and-objectives)
-   [Organizational Information](#)
    -   [Board of Directors](https://dhakachamber.com/board-of-directors)
    -   [Previous Board of Directors](https://dhakachamber.com/dcci-allpastmanagement)
    -   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
    -   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)
-   [President](https://dhakachamber.com/president)
-   [Membership](#)
    -   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
    -   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
    -   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
    -   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
    -   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
    -   [Become a Member](https://membership.dhakachamber.com/register)
    -   [Member Login](https://membership.dhakachamber.com)
    -   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
    -   [Member Query](https://dhakachamber.com/member-query)
    -   [Hot Line](https://dhakachamber.com/hot_line)
-   [Projects](https://dhakachamber.com/project-activities)
-   [Seminar](https://dhakachamber.com/media/seminar)
-   [Publications](#)
    -   [DCCI Research Service](https://dhakachamber.com/pdf_viewer/storage/2024/circular/DCCI%20Research%20Service.pdf)
    -   [Research Guideline](https://dhakachamber.com/pdf_viewer/storage/2024/circular/Research%20Guideline.pdf)
    -   [DCCI Journal (DJBEP)](https://journal.dhakachamber.com/)
    -   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
    -   [DCCI Review](https://dhakachamber.com/publications/reviews)
    -   [DCCI Publications](https://dhakachamber.com/publications)
    -   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
    -   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)
    -   [Introducing DCCI 2023](https://www.dhakachamber.com/storage/print_media/2023/07/Introducing%202023.pdf)
-   [Media](#)
    -   [Chamber News](https://dhakachamber.com/media/news)
    -   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
    -   [Photo Gallery](https://dhakachamber.com/albums)
    -   [Video Gallery](https://dhakachamber.com/videos)
    -   [Fairs & Exhibitions](https://www.dhakachamber.com/storage/2026/03/dccifair.pdf)
-   [Policy](#)
    -   [Export Policy](https://www.dhakachamber.com/storage/policy/3VFoMxkr6Z3EZdC8wz7YHfrIBfPP5N0Y6n7eEEFJ.pdf)
    -   [Import Policy](https://www.dhakachamber.com/storage/policy/b6uhXGhpdl30N68gl3Yg9mV5P6vGIPAjquqTu35f.pdf)
    -   [Industry Policy](https://www.dhakachamber.com/storage/policy/kpHRSdbYmY90O7wcyYmkZTSvumKEXfz5uwPTlOn5.pdf)
    -   [ICT Policy](https://www.dhakachamber.com/storage/policy/abTlbODgI2I4Aqbrix5Cs2DHvFD5lW3OwDmfKXmH.pdf)
-   [BILATERAL TRADE](#)
    -   [Bilateral Trade](https://dhakachamber.com/bilateral-trade)
    -   [Africa](https://dhakachamber.com/bilateral-trade/africa)
    -   [America](https://dhakachamber.com/bilateral-trade/america)
    -   [Asian](https://dhakachamber.com/bilateral-trade/asian)
    -   [ASEAN](https://dhakachamber.com/bilateral-trade/asean)
    -   [SAARC](https://dhakachamber.com/bilateral-trade/saarc)
    -   [Middle East](https://dhakachamber.com/bilateral-trade/middle-east)
    -   [European Union](https://dhakachamber.com/bilateral-trade/european-union)
-   [About Bangladesh](#)
    -   [General Information](https://dhakachamber.com/bangladesh-country-profile)
    -   [Business Opportunities in Bangladesh](https://dhakachamber.com/trade-and-business-opportunities-in-bangladesh)
    -   [Useful Links](https://dhakachamber.com/useful-links)
-   [B2B Directory](#)
    -   [B2B Directory](https://dhakachamber.com/b2b)
    -   [B2B Member Login](https://dhakachamber.com/login)
    -   [B2B Registration](https://dhakachamber.com/b2b-reg)