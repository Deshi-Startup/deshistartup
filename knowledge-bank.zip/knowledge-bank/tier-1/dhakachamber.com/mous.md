---
source: "Dhaka Chamber of Commerce & Industry (DCCI)"
tier: 1
category: "Chamber"
url: "https://dhakachamber.com/mous"
title: "DCCI ::  Bilateral MOU with DCCI"
scraped_at: "2026-07-02"
---

# Bilateral MOU with DCCI

Logo

MOU Partner

Country

[![Mahratta Chamber of Commerce & Industry](https://dhakachamber.com/storage/bilateral-mous/October2018/oOvL11LKfZ2qLVXg5hnr-small.png)](http://www.mcciapune.com/)

Mahratta Chamber of Commerce & Industry

India

[![Abu Dhabi Chamber of Commerce & Industry](https://dhakachamber.com/storage/bilateral-mous/October2018/q3BGAeaMP2WDGfPuARoc-small.png)](http://www.abudhabichamber.ae/)

Abu Dhabi Chamber of Commerce & Industry

United Arab Emirates (U.A.E.)

[![South Asian Association for Regional Cooperation (SARCO)](https://dhakachamber.com/storage/bilateral-mous/September2020/ktdYGHSJuI4cTUwmtJnC-small.jpg)](https://saarc-sec.org)

South Asian Association for Regional Cooperation (SARCO)

Pakistan

[![China Council for the Promotion of International Trade Beijing Sub-Council](https://dhakachamber.com/storage/bilateral-mous/September2020/Tszdjlc6uiCEOm3FPLbH-small.png)](http://en.ccpit.org/)

China Council for the Promotion of International Trade Beijing Sub-Council

China

[![The Southern Gujarat Chamber of Commerce & Industry (SGCCI)](https://dhakachamber.com/storage/bilateral-mous/September2020/pZyzYdos1zKET5kikXWg-small.jpg)](https://www.sgcci.in/)

The Southern Gujarat Chamber of Commerce & Industry (SGCCI)

India

[![China Foreign Trade Centre](https://dhakachamber.com/storage/bilateral-mous/September2020/Go3IYTKfMfM78o3aICpp-small.png)](https://www.cftc.org.cn/en/)

China Foreign Trade Centre

China

[![Bangladesh Tourism Board](https://dhakachamber.com/storage/bilateral-mous/September2020/zJbn1SsIwVZfp8kNbnX1-small.jpg)](http://www.tourismboard.gov.bd/)

Bangladesh Tourism Board

Bangladesh

[![UNDP](https://dhakachamber.com/storage/bilateral-mous/September2020/0giQsJrDaDUNzARDSuRW-small.jpg)](https://www.undp.org/)

UNDP

Bangladesh

![KOTIPA and KOEXIMA](https://dhakachamber.com/storage/bilateral-mous/September2020/1GT5xgap185fKbRhTy84-small.png)

KOTIPA and KOEXIMA

South Korea

[![Polish Investment and Trade Agency](https://dhakachamber.com/storage/bilateral-mous/September2020/J6DtaiHjyZBiyeHzB60W-small.png)](https://www.paih.gov.pl/en)

Polish Investment and Trade Agency

Poland

-   «
-   1
-   [2](https://dhakachamber.com/mous?page=2)
-   [3](https://dhakachamber.com/mous?page=3)
-   [4](https://dhakachamber.com/mous?page=4)
-   [5](https://dhakachamber.com/mous?page=5)
-   [6](https://dhakachamber.com/mous?page=6)
-   [7](https://dhakachamber.com/mous?page=7)
-   [8](https://dhakachamber.com/mous?page=8)
-   [»](https://dhakachamber.com/mous?page=2)

### ABOUT US

-   [Board of Directors](https://dhakachamber.com/board-of-directors)
-   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
-   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)

### USEFUL LINKS

-   [DBI College](http://www.dbicollege.edu.bd)
-   [DCCI Business Institute](http://dcci-dbi.edu.bd)
-   [BUILD](http://www.buildbd.org)
-   [BIAC](https://www.biac.org.bd)
-   [ICCB](https://iccbangladesh.org.bd)

### MEMBERSHIP

-   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
-   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
-   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
-   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
-   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
-   [Become a Member](https://membership.dhakachamber.com/register)
-   [Member Login](https://membership.dhakachamber.com)
-   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
-   [Member Query](https://dhakachamber.com/member-query)
-   [Hot Line](https://dhakachamber.com/hot_line)

### MEDIA

-   [Chamber News](https://dhakachamber.com/media/news)
-   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
-   [Photo Gallery](https://dhakachamber.com/albums)
-   [Video Gallery](https://dhakachamber.com/videos)

### DOWNLOAD

-   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
-   [DCCI Reviews](https://dhakachamber.com/publications/reviews)
-   [DCCI Publications](https://dhakachamber.com/publications)
-   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
-   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)

×

-   [Home(current)](https://dhakachamber.com)
-   [About us](#)
    -   [Brief About DCCI](https://dhakachamber.com/about-us)
    -   [International Affiliations](https://dhakachamber.com/international-affiliations)
    -   [DCCI Founders](https://dhakachamber.com/dcci-founders)
    -   [Former Presidents](https://dhakachamber.com/dcci-former-presidents)
    -   [Former Senior Vice Presidents](https://dhakachamber.com/dcci-former-senior-vice-presidents)
    -   [Former Vice Presidents](https://dhakachamber.com/dcci-former-vice-presidents)
    -   [Achievements & Awards](https://dhakachamber.com/achievements-awards)
    -   [Policy and Objectives](https://dhakachamber.com/quality-policy-and-objectives)
-   [Organizational Information](#)
    -   [Board of Directors](https://dhakachamber.com/board-of-directors)
    -   [Previous Board of Directors](https://dhakachamber.com/dcci-allpastmanagement)
    -   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
    -   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)
-   [President](https://dhakachamber.com/president)
-   [Membership](#)
    -   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
    -   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
    -   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
    -   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
    -   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
    -   [Become a Member](https://membership.dhakachamber.com/register)
    -   [Member Login](https://membership.dhakachamber.com)
    -   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
    -   [Member Query](https://dhakachamber.com/member-query)
    -   [Hot Line](https://dhakachamber.com/hot_line)
-   [Projects](https://dhakachamber.com/project-activities)
-   [Seminar](https://dhakachamber.com/media/seminar)
-   [Publications](#)
    -   [DCCI Research Service](https://dhakachamber.com/pdf_viewer/storage/2024/circular/DCCI%20Research%20Service.pdf)
    -   [Research Guideline](https://dhakachamber.com/pdf_viewer/storage/2024/circular/Research%20Guideline.pdf)
    -   [DCCI Journal (DJBEP)](https://journal.dhakachamber.com/)
    -   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
    -   [DCCI Review](https://dhakachamber.com/publications/reviews)
    -   [DCCI Publications](https://dhakachamber.com/publications)
    -   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
    -   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)
    -   [Introducing DCCI 2023](https://www.dhakachamber.com/storage/print_media/2023/07/Introducing%202023.pdf)
-   [Media](#)
    -   [Chamber News](https://dhakachamber.com/media/news)
    -   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
    -   [Photo Gallery](https://dhakachamber.com/albums)
    -   [Video Gallery](https://dhakachamber.com/videos)
    -   [Fairs & Exhibitions](https://www.dhakachamber.com/storage/2026/03/dccifair.pdf)
-   [Policy](#)
    -   [Export Policy](https://www.dhakachamber.com/storage/policy/3VFoMxkr6Z3EZdC8wz7YHfrIBfPP5N0Y6n7eEEFJ.pdf)
    -   [Import Policy](https://www.dhakachamber.com/storage/policy/b6uhXGhpdl30N68gl3Yg9mV5P6vGIPAjquqTu35f.pdf)
    -   [Industry Policy](https://www.dhakachamber.com/storage/policy/kpHRSdbYmY90O7wcyYmkZTSvumKEXfz5uwPTlOn5.pdf)
    -   [ICT Policy](https://www.dhakachamber.com/storage/policy/abTlbODgI2I4Aqbrix5Cs2DHvFD5lW3OwDmfKXmH.pdf)
-   [BILATERAL TRADE](#)
    -   [Bilateral Trade](https://dhakachamber.com/bilateral-trade)
    -   [Africa](https://dhakachamber.com/bilateral-trade/africa)
    -   [America](https://dhakachamber.com/bilateral-trade/america)
    -   [Asian](https://dhakachamber.com/bilateral-trade/asian)
    -   [ASEAN](https://dhakachamber.com/bilateral-trade/asean)
    -   [SAARC](https://dhakachamber.com/bilateral-trade/saarc)
    -   [Middle East](https://dhakachamber.com/bilateral-trade/middle-east)
    -   [European Union](https://dhakachamber.com/bilateral-trade/european-union)
-   [About Bangladesh](#)
    -   [General Information](https://dhakachamber.com/bangladesh-country-profile)
    -   [Business Opportunities in Bangladesh](https://dhakachamber.com/trade-and-business-opportunities-in-bangladesh)
    -   [Useful Links](https://dhakachamber.com/useful-links)
-   [B2B Directory](#)
    -   [B2B Directory](https://dhakachamber.com/b2b)
    -   [B2B Member Login](https://dhakachamber.com/login)
    -   [B2B Registration](https://dhakachamber.com/b2b-reg)