---
source: "Dhaka Chamber of Commerce & Industry (DCCI)"
tier: 1
category: "Chamber"
url: "https://dhakachamber.com/membership_application_process"
title: "DCCI ::  DCCI Membership Enrollment Process"
scraped_at: "2026-07-02"
---

# DCCI Membership Enrollment Process

## 

#### REGISTRATION PROCESS

#### REGISTRATION

-   • Go to the Membership Online Service (MOS) portal (https://membership.dhakachamber.com)
-   • For first-time user please register to the MOS system with firm name as per trade license, email ID and phone number (if you're registered, ignore it)

#### VERIFICATION

-   • After clicking Register option, Please verify the Registration through E-mail. ( E-mail ID and MOS portal must be opened in the same browser)

## 

#### DCCI MEMBERSHIP ENTROLLMENT PROCESS

##### The registered Business/ Firm/Company of Dhaka District can only apply for DCCI Membership

##### For General or Associate Membership, There are only 5 easy steps:

#### NAME CLERANCE

-   • Log in to MOS portal and click “Apply for Name Clearance” Button on Dashboard
-   • Fill-up the Name Clearance e-form with necessary information and wait for the approval.
-   • After completing approval process, Both sms and email notification will be sent.

#### MEMBERSHIP e-FORM

-   1\. After getting name clearance notification, “Apply for Membership” e-form on Dashboard will be visible.
-   2\. Fill-up the “Apply for Membership” e-form with necessary information and attach the required documents mentioned in the list:

-   [Proprietorship Firm](#circular)
-   [Partnership Firm](#latest)
-   [Limited Firm](#latest1)

-   • Pay order of BDT. 29,350/- for General Member and BDT. 23,150/- for Associate Member in favor of "Dhaka Chamber of Commerce & Industry (DCCI)"
-   • Updated Trade License
-   • Bank Solvency Certificate
-   • TIN Certificate with Proof of Submission of Return (PSR) of Applicants & Representative
-   • BIN Certificate
-   • NID of Applicants & Representative
-   • Recently taken passport size photograph
-   • Application Letter to the Secretary General, DCCI and it must be written in the letterhead pad of respective interested Firm/Company.
-   • Other: VAT, IRC, ERC (Not Mandatory)

-   • Pay order of BDT. 29,350/- for General Member and BDT. 23,150/- for Associate Member in favor of "Dhaka Chamber of Commerce & Industry (DCCI)"
-   • Bank Certificate
-   • Updated Trade License
-   • Bank Solvency Certificate
-   • TIN Certificate with Proof of Submission of Return (PSR) of Applicants, Representative & Partners
-   • BIN Certificate
-   • NID of Applicants, Representative & Partners
-   • Recently taken passport size photograph
-   • Application Letter to the Secretary General, DCCI and it must be written in the letterhead pad of respective interested Firm/Company
-   • Other: VAT, IRC, ERC (Not Mandatory)
-   • Partnership Deed

-   • Pay order of BDT. 29,350/- for General Member and BDT. 23,150/- for Associate Member in favor of "Dhaka Chamber of Commerce & Industry (DCCI)"
-   • Updated Trade License
-   • Bank Solvency Certificate
-   • TIN Certificate with Proof of Submission of Return (PSR) of Company, Applicants, Representative & Board of Directors.
-   • BIN Certificate
-   • NID of Applicants, Representative & Board of Directors
-   • Recently taken passport size photograph of Representative & Board of Directors
-   • Application Letter to the Secretary General, DCCI and it must be written in the letterhead pad of respective interested Firm/Company.
-   • Memorandum & Articles of Association
-   • Form XII Certificate
-   • Other: VAT, IRC, ERC, Joint Venture Agreement, Passport for foreign nationals, BIDA permission paper, work permit and branch office permission (Not Mandatory for Local Company).

#### PROPOSER

-   • Applicant may send consent request to two valid registered member organizations for getting reference. Applicant may skip this procedure and take signature in the hardcopy from two DCCI members as reference in this application form (please download application form for it).

#### MEMBERSHIP FORM FEE

-   • Pay the Membership Application Form Fees BDT. 150/- online through DCCI’s designated payment options (Mobile wallet, Online Banking, Debit/Credit card) System generated online payment slip will be sent to E-mail.

#### FINAL SUBMISSION

-   • After Download the filled-up Application form. Submit the Application hardcopy Form with, pay order, payment slip, one copy passport size photograph and visiting card of applicant to DCCI. Note: All documents must be attested by the Managing Director/Managing Partner/Proprietor of Applicant Company
-   • Please bring the original papers while submitting the documents. Upon receiving the completed documents, DCCI will verify the documents and will issue Membership e-Certificate and e-Passbook from the MOS portal after necessary approval process.

### MEMBERSHIP APPLICATION FEE:

SL

Category

Fee(BDT)

1

Application Form

150/-

2

General Subscription

29,350/-

3

Associate Subscription

23,150/-

![Membership Application Process](https://dhakachamber.com/images/no_cash.jpg) [Become A Member](https://membership.dhakachamber.com/register) [User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)

### ABOUT US

-   [Board of Directors](https://dhakachamber.com/board-of-directors)
-   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
-   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)

### USEFUL LINKS

-   [DBI College](http://www.dbicollege.edu.bd)
-   [DCCI Business Institute](http://dcci-dbi.edu.bd)
-   [BUILD](http://www.buildbd.org)
-   [BIAC](https://www.biac.org.bd)
-   [ICCB](https://iccbangladesh.org.bd)

### MEMBERSHIP

-   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
-   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
-   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
-   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
-   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
-   [Become a Member](https://membership.dhakachamber.com/register)
-   [Member Login](https://membership.dhakachamber.com)
-   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
-   [Member Query](https://dhakachamber.com/member-query)
-   [Hot Line](https://dhakachamber.com/hot_line)

### MEDIA

-   [Chamber News](https://dhakachamber.com/media/news)
-   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
-   [Photo Gallery](https://dhakachamber.com/albums)
-   [Video Gallery](https://dhakachamber.com/videos)

### DOWNLOAD

-   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
-   [DCCI Reviews](https://dhakachamber.com/publications/reviews)
-   [DCCI Publications](https://dhakachamber.com/publications)
-   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
-   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)

×

-   [Home(current)](https://dhakachamber.com)
-   [About us](#)
    -   [Brief About DCCI](https://dhakachamber.com/about-us)
    -   [International Affiliations](https://dhakachamber.com/international-affiliations)
    -   [DCCI Founders](https://dhakachamber.com/dcci-founders)
    -   [Former Presidents](https://dhakachamber.com/dcci-former-presidents)
    -   [Former Senior Vice Presidents](https://dhakachamber.com/dcci-former-senior-vice-presidents)
    -   [Former Vice Presidents](https://dhakachamber.com/dcci-former-vice-presidents)
    -   [Achievements & Awards](https://dhakachamber.com/achievements-awards)
    -   [Policy and Objectives](https://dhakachamber.com/quality-policy-and-objectives)
-   [Organizational Information](#)
    -   [Board of Directors](https://dhakachamber.com/board-of-directors)
    -   [Previous Board of Directors](https://dhakachamber.com/dcci-allpastmanagement)
    -   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
    -   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)
-   [President](https://dhakachamber.com/president)
-   [Membership](#)
    -   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
    -   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
    -   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
    -   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
    -   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
    -   [Become a Member](https://membership.dhakachamber.com/register)
    -   [Member Login](https://membership.dhakachamber.com)
    -   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
    -   [Member Query](https://dhakachamber.com/member-query)
    -   [Hot Line](https://dhakachamber.com/hot_line)
-   [Projects](https://dhakachamber.com/project-activities)
-   [Seminar](https://dhakachamber.com/media/seminar)
-   [Publications](#)
    -   [DCCI Research Service](https://dhakachamber.com/pdf_viewer/storage/2024/circular/DCCI%20Research%20Service.pdf)
    -   [Research Guideline](https://dhakachamber.com/pdf_viewer/storage/2024/circular/Research%20Guideline.pdf)
    -   [DCCI Journal (DJBEP)](https://journal.dhakachamber.com/)
    -   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
    -   [DCCI Review](https://dhakachamber.com/publications/reviews)
    -   [DCCI Publications](https://dhakachamber.com/publications)
    -   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
    -   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)
    -   [Introducing DCCI 2023](https://www.dhakachamber.com/storage/print_media/2023/07/Introducing%202023.pdf)
-   [Media](#)
    -   [Chamber News](https://dhakachamber.com/media/news)
    -   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
    -   [Photo Gallery](https://dhakachamber.com/albums)
    -   [Video Gallery](https://dhakachamber.com/videos)
    -   [Fairs & Exhibitions](https://www.dhakachamber.com/storage/2026/03/dccifair.pdf)
-   [Policy](#)
    -   [Export Policy](https://www.dhakachamber.com/storage/policy/3VFoMxkr6Z3EZdC8wz7YHfrIBfPP5N0Y6n7eEEFJ.pdf)
    -   [Import Policy](https://www.dhakachamber.com/storage/policy/b6uhXGhpdl30N68gl3Yg9mV5P6vGIPAjquqTu35f.pdf)
    -   [Industry Policy](https://www.dhakachamber.com/storage/policy/kpHRSdbYmY90O7wcyYmkZTSvumKEXfz5uwPTlOn5.pdf)
    -   [ICT Policy](https://www.dhakachamber.com/storage/policy/abTlbODgI2I4Aqbrix5Cs2DHvFD5lW3OwDmfKXmH.pdf)
-   [BILATERAL TRADE](#)
    -   [Bilateral Trade](https://dhakachamber.com/bilateral-trade)
    -   [Africa](https://dhakachamber.com/bilateral-trade/africa)
    -   [America](https://dhakachamber.com/bilateral-trade/america)
    -   [Asian](https://dhakachamber.com/bilateral-trade/asian)
    -   [ASEAN](https://dhakachamber.com/bilateral-trade/asean)
    -   [SAARC](https://dhakachamber.com/bilateral-trade/saarc)
    -   [Middle East](https://dhakachamber.com/bilateral-trade/middle-east)
    -   [European Union](https://dhakachamber.com/bilateral-trade/european-union)
-   [About Bangladesh](#)
    -   [General Information](https://dhakachamber.com/bangladesh-country-profile)
    -   [Business Opportunities in Bangladesh](https://dhakachamber.com/trade-and-business-opportunities-in-bangladesh)
    -   [Useful Links](https://dhakachamber.com/useful-links)
-   [B2B Directory](#)
    -   [B2B Directory](https://dhakachamber.com/b2b)
    -   [B2B Member Login](https://dhakachamber.com/login)
    -   [B2B Registration](https://dhakachamber.com/b2b-reg)