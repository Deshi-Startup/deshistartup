---
source: "Dhaka Chamber of Commerce & Industry (DCCI)"
tier: 1
category: "Chamber"
url: "https://dhakachamber.com/media/news"
title: "DCCI ::  News"
scraped_at: "2026-07-02"
---

# News

![seminar on "The Electric Vehicle (EV): Challenges and Prospects in Bangladesh "](https://dhakachamber.com/storage/posts/June2026/eHZK71yuZwA2jdWRaz82-cropped.jpg)

#### seminar on "The Electric Vehicle (EV): Challenges and Prospects in Bangladesh "

###### 2026-06-27

[Read More](https://dhakachamber.com/media/news/seminar-on-the-electric-vehicle-ev-challenges-and-prospects-in-bangladesh)

![DCCI’s initial reaction to the proposed national budget 2026-27](https://dhakachamber.com/storage/posts/June2026/ZKqSEajipxQ7ydLJ6qGa-cropped.jpg)

#### DCCI’s initial reaction to the proposed national budget 2026-27

###### 2026-06-11

[Read More](https://dhakachamber.com/media/news/dcci-s-initial-reaction-to-the-proposed-national-budget-2026-27)

![New Zealand High Commissioner meets Dhaka Chamber President](https://dhakachamber.com/storage/posts/May2026/Ia3kgTihLEbplRaGWe1N-cropped.jpg)

#### New Zealand High Commissioner meets Dhaka Chamber President

###### 2026-05-20

[Read More](https://dhakachamber.com/media/news/new-zealand-high-commissioner-meets-dhaka-chamber-president)

![Seminar on “Economic Position Index (EPI): Quarterly Macroeconomic State of Dhaka”](https://dhakachamber.com/storage/posts/May2026/sxlcXuZH4yfPosV3udyp-cropped.jpg)

#### Seminar on “Economic Position Index (EPI): Quarterly Macroeconomic State of Dhaka”

###### 2026-05-16

[Read More](https://dhakachamber.com/media/news/seminar-on-economic-position-index-epi-quarterly-macroeconomic-state-of-dhaka)

![Bilateral trade discussion held between DCCI and Turkish business delegation](https://dhakachamber.com/storage/posts/May2026/qfibXLHTHdPNPj6vrssB-cropped.JPG)

#### Bilateral trade discussion held between DCCI and Turkish business delegation

###### 2026-05-13

[Read More](https://dhakachamber.com/media/news/bilateral-trade-discussion-held-between-dcci-and-turkish-business-delegation)

![Dhaka Chamber President pays courtesy call on Minister for Water Resources](https://dhakachamber.com/storage/posts/May2026/EZttFyb1nszw3Yy2NRMM-cropped.jpg)

#### Dhaka Chamber President pays courtesy call on Minister for Water Resources

###### 2026-05-11

[Read More](https://dhakachamber.com/media/news/dhaka-chamber-president-pays-courtesy-call-on-minister-for-water-resources)

![RTD on Integrated Port and Logistics Development for a Trade-Driven Bangladesh](https://dhakachamber.com/storage/posts/May2026/r29EPaiIQ8uXNuNAqSuk-cropped.jpg)

#### RTD on Integrated Port and Logistics Development for a Trade-Driven Bangladesh

###### 2026-05-09

[Read More](https://dhakachamber.com/media/news/rtd-on-integrated-port-and-logistics-development-for-a-trade-driven-bangladesh)

![DCCI submits budget proposals for FY 2026–2027](https://dhakachamber.com/storage/posts/April2026/yFNb9ubKTnjdmmPBsPQO-cropped.jpg)

#### DCCI submits budget proposals for FY 2026–2027

###### 2026-04-22

[Read More](https://dhakachamber.com/media/news/dcci-submits-budget-proposals-for-fy-2026-2027)

![DCCI signs MoC with three Chinese Chambers](https://dhakachamber.com/storage/posts/April2026/H3WmpWQ7jcs1PHFPCAL2-cropped.jpg)

#### DCCI signs MoC with three Chinese Chambers

###### 2026-04-18

[Read More](https://dhakachamber.com/media/news/dcci-signs-moc-with-three-chinese-chambers)

![DCCI delegation participates in Guangzhou Sourcing Fair](https://dhakachamber.com/storage/posts/April2026/hGVqksLILIfL3seXd35v-cropped.jpg)

#### DCCI delegation participates in Guangzhou Sourcing Fair

###### 2026-04-16

[Read More](https://dhakachamber.com/media/news/dcci-delegation-participates-in-guangzhou-sourcing-fair)

![FGD on Synergizing Banking Sector: Lenders’ and Borrowers’ Perspective held at DCCI](https://dhakachamber.com/storage/posts/April2026/ymLLWAyBDIWPqnndzS6V-cropped.jpeg)

#### FGD on Synergizing Banking Sector: Lenders’ and Borrowers’ Perspective held at DCCI

###### 2026-04-15

[Read More](https://dhakachamber.com/media/news/fgd-on-synergizing-banking-sector-lenders-and-borrowers-perspective-held-at-dcci)

![RTD on “Navigating the Global Energy Shock: Impact on Bangladesh and Way Forward”](https://dhakachamber.com/storage/posts/April2026/B2FCpi4Nt1EnbQCZI7GW-cropped.jpg)

#### RTD on “Navigating the Global Energy Shock: Impact on Bangladesh and Way Forward”

###### 2026-04-09

[Read More](https://dhakachamber.com/media/news/rtd-on-navigating-the-global-energy-shock-impact-on-bangladesh-and-way-forward)

-   «
-   1
-   [2](https://dhakachamber.com/media/news?page=2)
-   [3](https://dhakachamber.com/media/news?page=3)
-   [4](https://dhakachamber.com/media/news?page=4)
-   [5](https://dhakachamber.com/media/news?page=5)
-   [6](https://dhakachamber.com/media/news?page=6)
-   [7](https://dhakachamber.com/media/news?page=7)
-   [8](https://dhakachamber.com/media/news?page=8)
-   [9](https://dhakachamber.com/media/news?page=9)
-   [10](https://dhakachamber.com/media/news?page=10)
-   ...
-   [28](https://dhakachamber.com/media/news?page=28)
-   [29](https://dhakachamber.com/media/news?page=29)
-   [»](https://dhakachamber.com/media/news?page=2)

### ABOUT US

-   [Board of Directors](https://dhakachamber.com/board-of-directors)
-   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
-   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)

### USEFUL LINKS

-   [DBI College](http://www.dbicollege.edu.bd)
-   [DCCI Business Institute](http://dcci-dbi.edu.bd)
-   [BUILD](http://www.buildbd.org)
-   [BIAC](https://www.biac.org.bd)
-   [ICCB](https://iccbangladesh.org.bd)

### MEMBERSHIP

-   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
-   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
-   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
-   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
-   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
-   [Become a Member](https://membership.dhakachamber.com/register)
-   [Member Login](https://membership.dhakachamber.com)
-   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
-   [Member Query](https://dhakachamber.com/member-query)
-   [Hot Line](https://dhakachamber.com/hot_line)

### MEDIA

-   [Chamber News](https://dhakachamber.com/media/news)
-   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
-   [Photo Gallery](https://dhakachamber.com/albums)
-   [Video Gallery](https://dhakachamber.com/videos)

### DOWNLOAD

-   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
-   [DCCI Reviews](https://dhakachamber.com/publications/reviews)
-   [DCCI Publications](https://dhakachamber.com/publications)
-   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
-   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)

×

-   [Home(current)](https://dhakachamber.com)
-   [About us](#)
    -   [Brief About DCCI](https://dhakachamber.com/about-us)
    -   [International Affiliations](https://dhakachamber.com/international-affiliations)
    -   [DCCI Founders](https://dhakachamber.com/dcci-founders)
    -   [Former Presidents](https://dhakachamber.com/dcci-former-presidents)
    -   [Former Senior Vice Presidents](https://dhakachamber.com/dcci-former-senior-vice-presidents)
    -   [Former Vice Presidents](https://dhakachamber.com/dcci-former-vice-presidents)
    -   [Achievements & Awards](https://dhakachamber.com/achievements-awards)
    -   [Policy and Objectives](https://dhakachamber.com/quality-policy-and-objectives)
-   [Organizational Information](#)
    -   [Board of Directors](https://dhakachamber.com/board-of-directors)
    -   [Previous Board of Directors](https://dhakachamber.com/dcci-allpastmanagement)
    -   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
    -   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)
-   [President](https://dhakachamber.com/president)
-   [Membership](#)
    -   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
    -   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
    -   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
    -   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
    -   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
    -   [Become a Member](https://membership.dhakachamber.com/register)
    -   [Member Login](https://membership.dhakachamber.com)
    -   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
    -   [Member Query](https://dhakachamber.com/member-query)
    -   [Hot Line](https://dhakachamber.com/hot_line)
-   [Projects](https://dhakachamber.com/project-activities)
-   [Seminar](https://dhakachamber.com/media/seminar)
-   [Publications](#)
    -   [DCCI Research Service](https://dhakachamber.com/pdf_viewer/storage/2024/circular/DCCI%20Research%20Service.pdf)
    -   [Research Guideline](https://dhakachamber.com/pdf_viewer/storage/2024/circular/Research%20Guideline.pdf)
    -   [DCCI Journal (DJBEP)](https://journal.dhakachamber.com/)
    -   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
    -   [DCCI Review](https://dhakachamber.com/publications/reviews)
    -   [DCCI Publications](https://dhakachamber.com/publications)
    -   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
    -   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)
    -   [Introducing DCCI 2023](https://www.dhakachamber.com/storage/print_media/2023/07/Introducing%202023.pdf)
-   [Media](#)
    -   [Chamber News](https://dhakachamber.com/media/news)
    -   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
    -   [Photo Gallery](https://dhakachamber.com/albums)
    -   [Video Gallery](https://dhakachamber.com/videos)
    -   [Fairs & Exhibitions](https://www.dhakachamber.com/storage/2026/03/dccifair.pdf)
-   [Policy](#)
    -   [Export Policy](https://www.dhakachamber.com/storage/policy/3VFoMxkr6Z3EZdC8wz7YHfrIBfPP5N0Y6n7eEEFJ.pdf)
    -   [Import Policy](https://www.dhakachamber.com/storage/policy/b6uhXGhpdl30N68gl3Yg9mV5P6vGIPAjquqTu35f.pdf)
    -   [Industry Policy](https://www.dhakachamber.com/storage/policy/kpHRSdbYmY90O7wcyYmkZTSvumKEXfz5uwPTlOn5.pdf)
    -   [ICT Policy](https://www.dhakachamber.com/storage/policy/abTlbODgI2I4Aqbrix5Cs2DHvFD5lW3OwDmfKXmH.pdf)
-   [BILATERAL TRADE](#)
    -   [Bilateral Trade](https://dhakachamber.com/bilateral-trade)
    -   [Africa](https://dhakachamber.com/bilateral-trade/africa)
    -   [America](https://dhakachamber.com/bilateral-trade/america)
    -   [Asian](https://dhakachamber.com/bilateral-trade/asian)
    -   [ASEAN](https://dhakachamber.com/bilateral-trade/asean)
    -   [SAARC](https://dhakachamber.com/bilateral-trade/saarc)
    -   [Middle East](https://dhakachamber.com/bilateral-trade/middle-east)
    -   [European Union](https://dhakachamber.com/bilateral-trade/european-union)
-   [About Bangladesh](#)
    -   [General Information](https://dhakachamber.com/bangladesh-country-profile)
    -   [Business Opportunities in Bangladesh](https://dhakachamber.com/trade-and-business-opportunities-in-bangladesh)
    -   [Useful Links](https://dhakachamber.com/useful-links)
-   [B2B Directory](#)
    -   [B2B Directory](https://dhakachamber.com/b2b)
    -   [B2B Member Login](https://dhakachamber.com/login)
    -   [B2B Registration](https://dhakachamber.com/b2b-reg)