---
source: "Dhaka Chamber of Commerce & Industry (DCCI)"
tier: 1
category: "Chamber"
url: "https://dhakachamber.com/publications/reviews"
title: "DCCI ::  DCCI REVIEW"
scraped_at: "2026-07-02"
---

# DCCI REVIEW

[![March-2026](https://dhakachamber.com/storage/reviews/May2026/KEGwnVG9zv8590YacVH4.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/May2026/0NOop5JeKaOgDVFsk52X.pdf)

#### [March-2026](https://dhakachamber.com/pdf_viewer/storage/reviews/May2026/0NOop5JeKaOgDVFsk52X.pdf)

[![February-2026](https://dhakachamber.com/storage/reviews/May2026/qYXk7BY30PCIOl4Z1N5k.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/May2026/TSJu7nPKZzAscPSG8RH5.pdf)

#### [February-2026](https://dhakachamber.com/pdf_viewer/storage/reviews/May2026/TSJu7nPKZzAscPSG8RH5.pdf)

[![January -2026](https://dhakachamber.com/storage/reviews/April2026/s8Qax4nkhB4r7g9hw4cC.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/April2026/J1TS6bJMRrIl0CrXv7d9.pdf)

#### [January -2026](https://dhakachamber.com/pdf_viewer/storage/reviews/April2026/J1TS6bJMRrIl0CrXv7d9.pdf)

[![December-2025](https://dhakachamber.com/storage/reviews/February2026/HfUJYdsfhBuTwRCbvPRG.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/February2026/JSoqusT98kvyo0csUEWk.pdf)

#### [December-2025](https://dhakachamber.com/pdf_viewer/storage/reviews/February2026/JSoqusT98kvyo0csUEWk.pdf)

[![November-2025](https://dhakachamber.com/storage/reviews/January2026/zlOkRJEU59rNuXfjG3Ds.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/January2026/ysr6ZHAADajSLh6IRZ5W.pdf)

#### [November-2025](https://dhakachamber.com/pdf_viewer/storage/reviews/January2026/ysr6ZHAADajSLh6IRZ5W.pdf)

[![October-2025](https://dhakachamber.com/storage/reviews/December2025/dM0nIF5SSa6qr9dJpimF.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/December2025/KPu21C6hH6XNd9iXArhQ.pdf)

#### [October-2025](https://dhakachamber.com/pdf_viewer/storage/reviews/December2025/KPu21C6hH6XNd9iXArhQ.pdf)

[![September 2025](https://dhakachamber.com/storage/reviews/October2025/ZxUnYFouwewdkEzM5A90.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/October2025/h6xAedZOcJyufUvHYSzi.pdf)

#### [September 2025](https://dhakachamber.com/pdf_viewer/storage/reviews/October2025/h6xAedZOcJyufUvHYSzi.pdf)

[![August-2025](https://dhakachamber.com/storage/reviews/September2025/tTWDq8P8G7lsEZyBotOp.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/September2025/oQjWso9RN2wKqaazb7oC.pdf)

#### [August-2025](https://dhakachamber.com/pdf_viewer/storage/reviews/September2025/oQjWso9RN2wKqaazb7oC.pdf)

[![July-2025](https://dhakachamber.com/storage/reviews/September2025/z3NCfgBUjRZ5pKsa6Ljh.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/September2025/9vGJyVC0Q0A1cN79AuZG.pdf)

#### [July-2025](https://dhakachamber.com/pdf_viewer/storage/reviews/September2025/9vGJyVC0Q0A1cN79AuZG.pdf)

[![June-2025](https://dhakachamber.com/storage/reviews/July2025/Gnr3SvP3ow06rNZ1C7R6.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/July2025/oGqh6GXU4yYJfulgJRiu.pdf)

#### [June-2025](https://dhakachamber.com/pdf_viewer/storage/reviews/July2025/oGqh6GXU4yYJfulgJRiu.pdf)

[![May-2025](https://dhakachamber.com/storage/reviews/July2025/Y0JW7L3LwX2UsmKseIfm.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/July2025/DU7eDviPplGzI9WOOBGO.pdf)

#### [May-2025](https://dhakachamber.com/pdf_viewer/storage/reviews/July2025/DU7eDviPplGzI9WOOBGO.pdf)

[![April-2025](https://dhakachamber.com/storage/reviews/May2025/HbLH5MffwxbdwaDPIFu4.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/May2025/vwkqgkf5wa1Pinkv6RFQ.pdf)

#### [April-2025](https://dhakachamber.com/pdf_viewer/storage/reviews/May2025/vwkqgkf5wa1Pinkv6RFQ.pdf)

[![March-2025](https://dhakachamber.com/storage/reviews/May2025/XStv9dPfV4jcCt1QCsGU.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/May2025/FDyEo6bxisUwqycsZAuD.pdf)

#### [March-2025](https://dhakachamber.com/pdf_viewer/storage/reviews/May2025/FDyEo6bxisUwqycsZAuD.pdf)

[![February-2025](https://dhakachamber.com/storage/reviews/April2025/charrRvNiTo0LlDenVAL.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/April2025/bcFfgsyqGasNOELuTavJ.pdf)

#### [February-2025](https://dhakachamber.com/pdf_viewer/storage/reviews/April2025/bcFfgsyqGasNOELuTavJ.pdf)

[![January -2025](https://dhakachamber.com/storage/reviews/March2025/gVZh3BwyeCRuLuz5EmeJ.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/March2025/b85Zlpgc0NnWS2KogT8F.pdf)

#### [January -2025](https://dhakachamber.com/pdf_viewer/storage/reviews/March2025/b85Zlpgc0NnWS2KogT8F.pdf)

[![December-2024](https://dhakachamber.com/storage/reviews/February2025/kqMFLq0bHlNGwU7iwabm.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/February2025/wgowNlzExcs5Hc1nClJq.pdf)

#### [December-2024](https://dhakachamber.com/pdf_viewer/storage/reviews/February2025/wgowNlzExcs5Hc1nClJq.pdf)

[![November-2024](https://dhakachamber.com/storage/reviews/January2025/0WhI2hzcXY9zTB993AkR.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/January2025/TmBGS4mfbRgNiqERntq8.pdf)

#### [November-2024](https://dhakachamber.com/pdf_viewer/storage/reviews/January2025/TmBGS4mfbRgNiqERntq8.pdf)

[![October-2024](https://dhakachamber.com/storage/reviews/February2025/x60q56NQ8NuyppmE5Sip.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/February2025/RR2bsdpsDZWcbfKJnL1b.pdf)

#### [October-2024](https://dhakachamber.com/pdf_viewer/storage/reviews/February2025/RR2bsdpsDZWcbfKJnL1b.pdf)

[![August- September 2024](https://dhakachamber.com/storage/reviews/November2024/6zC0unqheswtXqqO9X33.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/November2024/GsvCaxbdMMPdnkBVXphU.pdf)

#### [August- September 2024](https://dhakachamber.com/pdf_viewer/storage/reviews/November2024/GsvCaxbdMMPdnkBVXphU.pdf)

[![June- July 2024](https://dhakachamber.com/storage/reviews/September2024/MHPDcE8c3EBrW4IkMeIw.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/September2024/zMtLKWWj8efGrfqeudua.pdf)

#### [June- July 2024](https://dhakachamber.com/pdf_viewer/storage/reviews/September2024/zMtLKWWj8efGrfqeudua.pdf)

[![April- May 2024](https://dhakachamber.com/storage/reviews/September2024/kOCl0o7AfC4gQfJB8i1P.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/September2024/tX30gyxqWaRzjgngQgzL.pdf)

#### [April- May 2024](https://dhakachamber.com/pdf_viewer/storage/reviews/September2024/tX30gyxqWaRzjgngQgzL.pdf)

[![February- March 2024](https://dhakachamber.com/storage/reviews/July2024/Eqvm1Axsbh68NeYUExb7.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/July2024/kBATYUsoby92HeW5bsUj.pdf)

#### [February- March 2024](https://dhakachamber.com/pdf_viewer/storage/reviews/July2024/kBATYUsoby92HeW5bsUj.pdf)

[![December 2023- January 2024](https://dhakachamber.com/storage/reviews/May2024/JqQZqSFsWtvGsz1hzEVk.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/May2024/VukzIJK4eIcWVQotZAmX.pdf)

#### [December 2023- January 2024](https://dhakachamber.com/pdf_viewer/storage/reviews/May2024/VukzIJK4eIcWVQotZAmX.pdf)

[![May-2023](https://dhakachamber.com/storage/reviews/September2023/Alpw3tIpgeyb5uB8VfDM.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/September2023/We8ZtyiHgoy1JOsiwu2d.pdf)

#### [May-2023](https://dhakachamber.com/pdf_viewer/storage/reviews/September2023/We8ZtyiHgoy1JOsiwu2d.pdf)

[![April-2023](https://dhakachamber.com/storage/reviews/July2023/DxbVPPXBrrWeaNqduZBQ.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/July2023/gAFATEYOvMRYcdmIdjfR.pdf)

#### [April-2023](https://dhakachamber.com/pdf_viewer/storage/reviews/July2023/gAFATEYOvMRYcdmIdjfR.pdf)

[![March-2023](https://dhakachamber.com/storage/reviews/July2023/iST9b0N53zri8JJt0sci.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/July2023/idQNZyvR3lJmf42IT0Qj.pdf)

#### [March-2023](https://dhakachamber.com/pdf_viewer/storage/reviews/July2023/idQNZyvR3lJmf42IT0Qj.pdf)

[![February-2023](https://dhakachamber.com/storage/reviews/May2023/VXZ4Bp4c09rN4uSFE7gf.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/May2023/8ugqws9vSM9iovskBRb2.pdf)

#### [February-2023](https://dhakachamber.com/pdf_viewer/storage/reviews/May2023/8ugqws9vSM9iovskBRb2.pdf)

[![January-2023](https://dhakachamber.com/storage/reviews/April2023/7MTA2Lh7A04rIBTopHts.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/April2023/UhKCIFhfBGpteVdi0Of1.pdf)

#### [January-2023](https://dhakachamber.com/pdf_viewer/storage/reviews/April2023/UhKCIFhfBGpteVdi0Of1.pdf)

[![December-2022](https://dhakachamber.com/storage/reviews/April2023/0KYxhoOgiSd17NLzlRrP.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/April2023/kcikee8xn2K9dU0Ue2CR.pdf)

#### [December-2022](https://dhakachamber.com/pdf_viewer/storage/reviews/April2023/kcikee8xn2K9dU0Ue2CR.pdf)

[![November-2022](https://dhakachamber.com/storage/reviews/January2023/6CjwRloF13G5ZAvP0Id8.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/January2023/GVy3nA6XsRe6VsIqUp2e.pdf)

#### [November-2022](https://dhakachamber.com/pdf_viewer/storage/reviews/January2023/GVy3nA6XsRe6VsIqUp2e.pdf)

[![October-2022](https://dhakachamber.com/storage/reviews/December2022/F3040fHr0hSsqZFcdccA.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/December2022/5laI77MOTVLV30fGATqI.pdf)

#### [October-2022](https://dhakachamber.com/pdf_viewer/storage/reviews/December2022/5laI77MOTVLV30fGATqI.pdf)

[![September 2022](https://dhakachamber.com/storage/reviews/November2022/v6JsoDvIJFVE5TPhu31t.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/November2022/zazu3fwShQHPtMtFLTzI.pdf)

#### [September 2022](https://dhakachamber.com/pdf_viewer/storage/reviews/November2022/zazu3fwShQHPtMtFLTzI.pdf)

[![August 2022](https://dhakachamber.com/storage/reviews/September2022/A9lvIbyxa0FvVRTACQhf.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/September2022/kC8ZOTRK8DYXALbHDqaV.pdf)

#### [August 2022](https://dhakachamber.com/pdf_viewer/storage/reviews/September2022/kC8ZOTRK8DYXALbHDqaV.pdf)

[![July 2022](https://dhakachamber.com/storage/reviews/August2022/Tbn0dTtupBbCKCCaLHgd.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/August2022/6ZIJV1VHqUH4C3u8ZTho.pdf)

#### [July 2022](https://dhakachamber.com/pdf_viewer/storage/reviews/August2022/6ZIJV1VHqUH4C3u8ZTho.pdf)

[![June 2022](https://dhakachamber.com/storage/reviews/August2022/Dju7nR6JzyTj246grm5F.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/August2022/jAKXAkpFUEfjv9bXZOxL.pdf)

#### [June 2022](https://dhakachamber.com/pdf_viewer/storage/reviews/August2022/jAKXAkpFUEfjv9bXZOxL.pdf)

[![May-2022](https://dhakachamber.com/storage/reviews/July2022/Rv0HHxHTXKhqJFYjZGs8.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/July2022/0J4FIHVvojBqglf1dhXT.pdf)

#### [May-2022](https://dhakachamber.com/pdf_viewer/storage/reviews/July2022/0J4FIHVvojBqglf1dhXT.pdf)

[![April-2022](https://dhakachamber.com/storage/reviews/June2022/92527cchCJnViGU309xC.JPG)](https://dhakachamber.com/pdf_viewer/storage/reviews/June2022/XPhABRSqSAeaUSHS7Q1r.htm)

#### [April-2022](https://dhakachamber.com/pdf_viewer/storage/reviews/June2022/XPhABRSqSAeaUSHS7Q1r.htm)

[![March-2022](https://dhakachamber.com/storage/reviews/April2022/FmkgE0mzUqMal2TP6RA5.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/April2022/rxvwatc01xwAMgj6S3jL.pdf)

#### [March-2022](https://dhakachamber.com/pdf_viewer/storage/reviews/April2022/rxvwatc01xwAMgj6S3jL.pdf)

[![February-2022](https://dhakachamber.com/storage/reviews/March2022/MsIPRSYEELduZSLmo96z.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/March2022/fWJ9UXqDHB2yf2L2WAgE.pdf)

#### [February-2022](https://dhakachamber.com/pdf_viewer/storage/reviews/March2022/fWJ9UXqDHB2yf2L2WAgE.pdf)

[![January-2022](https://dhakachamber.com/storage/reviews/February2022/lRxFU5ESlYKFLRcSUHOD.png)](https://dhakachamber.com/pdf_viewer/storage/reviews/February2022/oEb8f79azRLA71nnbSZO.pdf)

#### [January-2022](https://dhakachamber.com/pdf_viewer/storage/reviews/February2022/oEb8f79azRLA71nnbSZO.pdf)

[![December-2021](https://dhakachamber.com/storage/reviews/January2022/TRxCqCIme6YN10zrsmyh.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/January2022/63zTsdT96jrBoC0tD0J9.pdf)

#### [December-2021](https://dhakachamber.com/pdf_viewer/storage/reviews/January2022/63zTsdT96jrBoC0tD0J9.pdf)

[![November-2021](https://dhakachamber.com/storage/reviews/January2022/V75gD6b0idWKosAzcCmu.png)](https://dhakachamber.com/pdf_viewer/storage/reviews/January2022/YVzBATj8efYRvtr5DNC6.pdf)

#### [November-2021](https://dhakachamber.com/pdf_viewer/storage/reviews/January2022/YVzBATj8efYRvtr5DNC6.pdf)

[![October-2021](https://dhakachamber.com/storage/reviews/January2022/kXFzIWzBkeZGEXOTJabc.JPG)](https://dhakachamber.com/pdf_viewer/storage/reviews/January2022/obsDEdABGqPKv5OBIsEh.pdf)

#### [October-2021](https://dhakachamber.com/pdf_viewer/storage/reviews/January2022/obsDEdABGqPKv5OBIsEh.pdf)

[![September-2021](https://dhakachamber.com/storage/reviews/December2021/CPNeLWRPx9ygs9lNVLb0.JPG)](https://dhakachamber.com/pdf_viewer/storage/reviews/December2021/uTpwuMxcU5aDsk5SoxcO.pdf)

#### [September-2021](https://dhakachamber.com/pdf_viewer/storage/reviews/December2021/uTpwuMxcU5aDsk5SoxcO.pdf)

[![August-2021](https://dhakachamber.com/storage/reviews/November2021/iMbrgDzb4M4GqKMC3gqL.JPG)](https://dhakachamber.com/pdf_viewer/storage/reviews/November2021/ksVIJA4jYeVT6buvZ6AY.pdf)

#### [August-2021](https://dhakachamber.com/pdf_viewer/storage/reviews/November2021/ksVIJA4jYeVT6buvZ6AY.pdf)

[![July-2021](https://dhakachamber.com/storage/reviews/August2021/P8qCpHqriA48Y3ap0Tzg.JPG)](https://dhakachamber.com/pdf_viewer/storage/reviews/August2021/C5ugDuY4CR6YQFbdmc4m.pdf)

#### [July-2021](https://dhakachamber.com/pdf_viewer/storage/reviews/August2021/C5ugDuY4CR6YQFbdmc4m.pdf)

[![June-2021](https://dhakachamber.com/storage/reviews/July2021/67VLGR9pqLYnBb3bA68p.png)](https://dhakachamber.com/pdf_viewer/storage/reviews/July2021/gsKCsPmb6h6gdmVSMAsQ.pdf)

#### [June-2021](https://dhakachamber.com/pdf_viewer/storage/reviews/July2021/gsKCsPmb6h6gdmVSMAsQ.pdf)

[![May-2021](https://dhakachamber.com/storage/reviews/June2021/T9YxsGlnqynUkWcW1tJ1.JPG)](https://dhakachamber.com/pdf_viewer/storage/reviews/June2021/yo717fWoIu9om2X8o9H8.pdf)

#### [May-2021](https://dhakachamber.com/pdf_viewer/storage/reviews/June2021/yo717fWoIu9om2X8o9H8.pdf)

[![April-2021](https://dhakachamber.com/storage/reviews/May2021/sYHsOb1KegfeXECITXk0.JPG)](https://dhakachamber.com/pdf_viewer/storage/reviews/May2021/xrnlWvRcgMsX8bJXGQU9.pdf)

#### [April-2021](https://dhakachamber.com/pdf_viewer/storage/reviews/May2021/xrnlWvRcgMsX8bJXGQU9.pdf)

[![March-2021](https://dhakachamber.com/storage/reviews/May2021/vn3m7sWlRy4RdOaZTyOe.png)](https://dhakachamber.com/pdf_viewer/storage/reviews/May2021/fhqCHFNzjMeF2tFXqRpQ.pdf)

#### [March-2021](https://dhakachamber.com/pdf_viewer/storage/reviews/May2021/fhqCHFNzjMeF2tFXqRpQ.pdf)

[![February-2021](https://dhakachamber.com/storage/reviews/March2021/mHjdmsH0zFJmej1ULoZR.png)](https://dhakachamber.com/pdf_viewer/storage/reviews/March2021/0cKTKc4Pw5O92LKs0aFm.pdf)

#### [February-2021](https://dhakachamber.com/pdf_viewer/storage/reviews/March2021/0cKTKc4Pw5O92LKs0aFm.pdf)

[![January-2021](https://dhakachamber.com/storage/reviews/March2021/RA94I34R9IRRO8ZayAPU.png)](https://dhakachamber.com/pdf_viewer/storage/reviews/March2021/fcjw7ziSPbtTRrPbblLb.pdf)

#### [January-2021](https://dhakachamber.com/pdf_viewer/storage/reviews/March2021/fcjw7ziSPbtTRrPbblLb.pdf)

[![December 2020](https://dhakachamber.com/storage/reviews/February2021/pg4sjlE66rzVL52AC7g4.png)](https://dhakachamber.com/pdf_viewer/storage/reviews/February2021/TRCFhYMQCqw7JO576X4s.pdf)

#### [December 2020](https://dhakachamber.com/pdf_viewer/storage/reviews/February2021/TRCFhYMQCqw7JO576X4s.pdf)

[![October-November 2020](https://dhakachamber.com/storage/reviews/January2021/XC7TXAfcgkmr52Hs60in.png)](https://dhakachamber.com/pdf_viewer/storage/reviews/January2021/wLxVPnuZMVYXNUCW0RSq.pdf)

#### [October-November 2020](https://dhakachamber.com/pdf_viewer/storage/reviews/January2021/wLxVPnuZMVYXNUCW0RSq.pdf)

[![August-september 2020](https://dhakachamber.com/storage/reviews/December2020/mT9ieKTQKKV8TY4YvjlB.png)](https://dhakachamber.com/pdf_viewer/storage/reviews/December2020/O98M7g1M5bwL67pWAt6M.pdf)

#### [August-september 2020](https://dhakachamber.com/pdf_viewer/storage/reviews/December2020/O98M7g1M5bwL67pWAt6M.pdf)

[![June-July-2020](https://dhakachamber.com/storage/reviews/December2020/ShUzeFyhivgSlokDVdMF.png)](https://dhakachamber.com/pdf_viewer/storage/reviews/December2020/dzuAKrn5mZflZanRByqM.pdf)

#### [June-July-2020](https://dhakachamber.com/pdf_viewer/storage/reviews/December2020/dzuAKrn5mZflZanRByqM.pdf)

[![April-May-2020](https://dhakachamber.com/storage/reviews/October2020/KjxL505ymdD055Qz1M38.png)](https://dhakachamber.com/pdf_viewer/storage/reviews/October2020/lH9pAZ0QvbzbqYU9bRti.pdf)

#### [April-May-2020](https://dhakachamber.com/pdf_viewer/storage/reviews/October2020/lH9pAZ0QvbzbqYU9bRti.pdf)

[![February-March 2020](https://dhakachamber.com/storage/reviews/July2020/AOxIZIuStRv9B9vpUMDM.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/July2020/kjJXbnHdiVtBE4vO7mnL.pdf)

#### [February-March 2020](https://dhakachamber.com/pdf_viewer/storage/reviews/July2020/kjJXbnHdiVtBE4vO7mnL.pdf)

[![January 2020](https://dhakachamber.com/storage/reviews/July2020/w13U2GUP8ssH2cfObe2s.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/July2020/9dDQCyLCiJiVcytT0I71.pdf)

#### [January 2020](https://dhakachamber.com/pdf_viewer/storage/reviews/July2020/9dDQCyLCiJiVcytT0I71.pdf)

[![December 2019](https://dhakachamber.com/storage/reviews/February2020/jtTeBmQTKBsBsYExoIbL.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/February2020/Abvo5S2lo2Lg0SIaZAVf.pdf)

#### [December 2019](https://dhakachamber.com/pdf_viewer/storage/reviews/February2020/Abvo5S2lo2Lg0SIaZAVf.pdf)

[![October-November 2019](https://dhakachamber.com/storage/reviews/December2019/sYofwPS6ucRe7hTLCAdi.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/December2019/rNRiVr8zaqIxwAqPAzfU.pdf)

#### [October-November 2019](https://dhakachamber.com/pdf_viewer/storage/reviews/December2019/rNRiVr8zaqIxwAqPAzfU.pdf)

[![August-Sept 2019](https://dhakachamber.com/storage/reviews/December2019/7yQG6q7bn2uZ8QZsQbbd.PNG)](https://dhakachamber.com/pdf_viewer/storage/reviews/December2019/zAk3Ya6RlW9t8mShCjbz.pdf)

#### [August-Sept 2019](https://dhakachamber.com/pdf_viewer/storage/reviews/December2019/zAk3Ya6RlW9t8mShCjbz.pdf)

[![June-July 2019](https://dhakachamber.com/storage/reviews/October2019/Cplhl4pEdDn4ma1MvFEX.jpg)](https://dhakachamber.com/pdf_viewer/storage/reviews/October2019/8s5cLLDVwusJJcZl55Ib.pdf)

#### [June-July 2019](https://dhakachamber.com/pdf_viewer/storage/reviews/October2019/8s5cLLDVwusJJcZl55Ib.pdf)

[![May 2019](https://dhakachamber.com/storage/reviews/October2019/gI9H5zb1IE6et8hB6vzj.jpg)](https://dhakachamber.com/pdf_viewer/storage/reviews/October2019/S2uSm1lJ4FJ0x8A0YEBp.pdf)

#### [May 2019](https://dhakachamber.com/pdf_viewer/storage/reviews/October2019/S2uSm1lJ4FJ0x8A0YEBp.pdf)

[![April 2019](https://dhakachamber.com/storage/reviews/October2019/B83lmlZFXQociiN3SLSL.jpg)](https://dhakachamber.com/pdf_viewer/storage/reviews/October2019/fwhiBJ32sI98UNr6OQB9.pdf)

#### [April 2019](https://dhakachamber.com/pdf_viewer/storage/reviews/October2019/fwhiBJ32sI98UNr6OQB9.pdf)

[![March 2019](https://dhakachamber.com/storage/reviews/October2019/zHPjOl0Nuom1PXFUjvuG.jpg)](https://dhakachamber.com/pdf_viewer/storage/reviews/October2019/NpYextiDYkPDGndcJJ6Z.pdf)

#### [March 2019](https://dhakachamber.com/pdf_viewer/storage/reviews/October2019/NpYextiDYkPDGndcJJ6Z.pdf)

[![February 2019](https://dhakachamber.com/storage/reviews/October2019/44u1CKZcGoewEEIElbPq.jpg)](https://dhakachamber.com/pdf_viewer/storage/reviews/May2019/QUYt9IPifYQ1yVUV4UBe.pdf)

#### [February 2019](https://dhakachamber.com/pdf_viewer/storage/reviews/May2019/QUYt9IPifYQ1yVUV4UBe.pdf)

[![January 2019](https://dhakachamber.com/storage/reviews/May2019/TBcKABIFVEISwzYPh5r6.jpg)](https://dhakachamber.com/pdf_viewer/storage/reviews/May2019/BLc60CY0ixlb0bWXWggq.pdf)

#### [January 2019](https://dhakachamber.com/pdf_viewer/storage/reviews/May2019/BLc60CY0ixlb0bWXWggq.pdf)

### ABOUT US

-   [Board of Directors](https://dhakachamber.com/board-of-directors)
-   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
-   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)

### USEFUL LINKS

-   [DBI College](http://www.dbicollege.edu.bd)
-   [DCCI Business Institute](http://dcci-dbi.edu.bd)
-   [BUILD](http://www.buildbd.org)
-   [BIAC](https://www.biac.org.bd)
-   [ICCB](https://iccbangladesh.org.bd)

### MEMBERSHIP

-   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
-   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
-   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
-   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
-   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
-   [Become a Member](https://membership.dhakachamber.com/register)
-   [Member Login](https://membership.dhakachamber.com)
-   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
-   [Member Query](https://dhakachamber.com/member-query)
-   [Hot Line](https://dhakachamber.com/hot_line)

### MEDIA

-   [Chamber News](https://dhakachamber.com/media/news)
-   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
-   [Photo Gallery](https://dhakachamber.com/albums)
-   [Video Gallery](https://dhakachamber.com/videos)

### DOWNLOAD

-   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
-   [DCCI Reviews](https://dhakachamber.com/publications/reviews)
-   [DCCI Publications](https://dhakachamber.com/publications)
-   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
-   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)

×

-   [Home(current)](https://dhakachamber.com)
-   [About us](#)
    -   [Brief About DCCI](https://dhakachamber.com/about-us)
    -   [International Affiliations](https://dhakachamber.com/international-affiliations)
    -   [DCCI Founders](https://dhakachamber.com/dcci-founders)
    -   [Former Presidents](https://dhakachamber.com/dcci-former-presidents)
    -   [Former Senior Vice Presidents](https://dhakachamber.com/dcci-former-senior-vice-presidents)
    -   [Former Vice Presidents](https://dhakachamber.com/dcci-former-vice-presidents)
    -   [Achievements & Awards](https://dhakachamber.com/achievements-awards)
    -   [Policy and Objectives](https://dhakachamber.com/quality-policy-and-objectives)
-   [Organizational Information](#)
    -   [Board of Directors](https://dhakachamber.com/board-of-directors)
    -   [Previous Board of Directors](https://dhakachamber.com/dcci-allpastmanagement)
    -   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
    -   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)
-   [President](https://dhakachamber.com/president)
-   [Membership](#)
    -   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
    -   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
    -   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
    -   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
    -   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
    -   [Become a Member](https://membership.dhakachamber.com/register)
    -   [Member Login](https://membership.dhakachamber.com)
    -   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
    -   [Member Query](https://dhakachamber.com/member-query)
    -   [Hot Line](https://dhakachamber.com/hot_line)
-   [Projects](https://dhakachamber.com/project-activities)
-   [Seminar](https://dhakachamber.com/media/seminar)
-   [Publications](#)
    -   [DCCI Research Service](https://dhakachamber.com/pdf_viewer/storage/2024/circular/DCCI%20Research%20Service.pdf)
    -   [Research Guideline](https://dhakachamber.com/pdf_viewer/storage/2024/circular/Research%20Guideline.pdf)
    -   [DCCI Journal (DJBEP)](https://journal.dhakachamber.com/)
    -   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
    -   [DCCI Review](https://dhakachamber.com/publications/reviews)
    -   [DCCI Publications](https://dhakachamber.com/publications)
    -   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
    -   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)
    -   [Introducing DCCI 2023](https://www.dhakachamber.com/storage/print_media/2023/07/Introducing%202023.pdf)
-   [Media](#)
    -   [Chamber News](https://dhakachamber.com/media/news)
    -   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
    -   [Photo Gallery](https://dhakachamber.com/albums)
    -   [Video Gallery](https://dhakachamber.com/videos)
    -   [Fairs & Exhibitions](https://www.dhakachamber.com/storage/2026/03/dccifair.pdf)
-   [Policy](#)
    -   [Export Policy](https://www.dhakachamber.com/storage/policy/3VFoMxkr6Z3EZdC8wz7YHfrIBfPP5N0Y6n7eEEFJ.pdf)
    -   [Import Policy](https://www.dhakachamber.com/storage/policy/b6uhXGhpdl30N68gl3Yg9mV5P6vGIPAjquqTu35f.pdf)
    -   [Industry Policy](https://www.dhakachamber.com/storage/policy/kpHRSdbYmY90O7wcyYmkZTSvumKEXfz5uwPTlOn5.pdf)
    -   [ICT Policy](https://www.dhakachamber.com/storage/policy/abTlbODgI2I4Aqbrix5Cs2DHvFD5lW3OwDmfKXmH.pdf)
-   [BILATERAL TRADE](#)
    -   [Bilateral Trade](https://dhakachamber.com/bilateral-trade)
    -   [Africa](https://dhakachamber.com/bilateral-trade/africa)
    -   [America](https://dhakachamber.com/bilateral-trade/america)
    -   [Asian](https://dhakachamber.com/bilateral-trade/asian)
    -   [ASEAN](https://dhakachamber.com/bilateral-trade/asean)
    -   [SAARC](https://dhakachamber.com/bilateral-trade/saarc)
    -   [Middle East](https://dhakachamber.com/bilateral-trade/middle-east)
    -   [European Union](https://dhakachamber.com/bilateral-trade/european-union)
-   [About Bangladesh](#)
    -   [General Information](https://dhakachamber.com/bangladesh-country-profile)
    -   [Business Opportunities in Bangladesh](https://dhakachamber.com/trade-and-business-opportunities-in-bangladesh)
    -   [Useful Links](https://dhakachamber.com/useful-links)
-   [B2B Directory](#)
    -   [B2B Directory](https://dhakachamber.com/b2b)
    -   [B2B Member Login](https://dhakachamber.com/login)
    -   [B2B Registration](https://dhakachamber.com/b2b-reg)