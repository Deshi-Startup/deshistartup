---
source: "Dhaka Chamber of Commerce & Industry (DCCI)"
tier: 1
category: "Chamber"
url: "https://dhakachamber.com/publications/budget_proposals"
title: "DCCI ::  DCCI Budget Proposals"
scraped_at: "2026-07-02"
---

# DCCI Budget Proposals

## 

### DCCI Budget proposal 2024-25

![VAT](https://dhakachamber.com/storage/budget-proposals/October2024/zGjXXKDHgLUvqKayvMnW.jpg)

#### VAT

[View Proposal](https://dhakachamber.com/pdf_viewer/storage/budget-proposals/October2024/i8SnNFlOWboorqED0DjR.jpg)

![Income Tax](https://dhakachamber.com/storage/budget-proposals/October2024/OkOTlsC7yC1KqlnItNAX.jpg)

#### Income Tax

[View Proposal](https://dhakachamber.com/pdf_viewer/storage/budget-proposals/October2024/EKp3kysEaj0F01vUPTcx.pdf)

## 

### DCCI Budget proposal 2021-22

![VAT and Custom](https://dhakachamber.com/storage/budget-proposals/June2023/afrl2yiUx27nCmYz8UlY.jpg)

#### VAT and Custom

[View Proposal](https://dhakachamber.com/pdf_viewer/storage/budget-proposals/June2022/HPpCoyfGpVpnXFsoCmFs.pdf)

![Income Tax](https://dhakachamber.com/storage/budget-proposals/June2023/3xd8VCe58bX7WYUrfBt0.jpg)

#### Income Tax

[View Proposal](https://dhakachamber.com/pdf_viewer/storage/budget-proposals/June2022/pNJ3iphdofHMyzJVKeGX.pdf)

## 

### DCCI Budget proposal 2020-21

![VAT and Custom](https://dhakachamber.com/storage/budget-proposals/June2023/Jc86GQNEcm0bNyyXBDkn.jpg)

#### VAT and Custom

[View Proposal](https://dhakachamber.com/pdf_viewer/storage/budget-proposals/June2022/48wIMVpYTA8trZf0KeO2.pdf)

![Income Tax](https://dhakachamber.com/storage/budget-proposals/June2023/tBNSQsaDcMCp9HsRBPrn.jpg)

#### Income Tax

[View Proposal](https://dhakachamber.com/pdf_viewer/storage/budget-proposals/June2022/xLwlPzg4zdq3yoSsUoul.pdf)

## 

### DCCI Budget proposal 2015-16

![Custom, Income Tex & VAT](https://dhakachamber.com/storage/budget-proposals/June2023/fTgygNDubKnlz5yloJdT.jpg)

#### Custom, Income Tex & VAT

[View Proposal](https://dhakachamber.com/pdf_viewer/storage/budget-proposals/October2018/WoAJzR0jVT1w3A9tLgGr.pdf)

## 

### DCCI Budget proposal 2013-14

![VAT](https://dhakachamber.com/storage/budget-proposals/June2023/ChSRqKWSP1XYxsmEdXai.jpg)

#### VAT

[View Proposal](https://dhakachamber.com/pdf_viewer/storage/budget-proposals/October2018/I4TJzf8p8XWwSAWYPgw3.pdf)

![Income Tax](https://dhakachamber.com/storage/budget-proposals/June2023/CQzrzcypIakVIbtxHqUQ.jpg)

#### Income Tax

[View Proposal](https://dhakachamber.com/pdf_viewer/storage/budget-proposals/October2018/MVMu7QsYGlyXCix3VjtK.pdf)

![Custom](https://dhakachamber.com/storage/budget-proposals/October2018/0kkObNj1zPItzhXwAxgA.jpg)

#### Custom

[View Proposal](https://dhakachamber.com/pdf_viewer/storage/budget-proposals/October2018/h1vNTkwEJ0YDQXVNMwKT.pdf)

### ABOUT US

-   [Board of Directors](https://dhakachamber.com/board-of-directors)
-   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
-   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)

### USEFUL LINKS

-   [DBI College](http://www.dbicollege.edu.bd)
-   [DCCI Business Institute](http://dcci-dbi.edu.bd)
-   [BUILD](http://www.buildbd.org)
-   [BIAC](https://www.biac.org.bd)
-   [ICCB](https://iccbangladesh.org.bd)

### MEMBERSHIP

-   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
-   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
-   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
-   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
-   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
-   [Become a Member](https://membership.dhakachamber.com/register)
-   [Member Login](https://membership.dhakachamber.com)
-   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
-   [Member Query](https://dhakachamber.com/member-query)
-   [Hot Line](https://dhakachamber.com/hot_line)

### MEDIA

-   [Chamber News](https://dhakachamber.com/media/news)
-   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
-   [Photo Gallery](https://dhakachamber.com/albums)
-   [Video Gallery](https://dhakachamber.com/videos)

### DOWNLOAD

-   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
-   [DCCI Reviews](https://dhakachamber.com/publications/reviews)
-   [DCCI Publications](https://dhakachamber.com/publications)
-   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
-   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)

×

-   [Home(current)](https://dhakachamber.com)
-   [About us](#)
    -   [Brief About DCCI](https://dhakachamber.com/about-us)
    -   [International Affiliations](https://dhakachamber.com/international-affiliations)
    -   [DCCI Founders](https://dhakachamber.com/dcci-founders)
    -   [Former Presidents](https://dhakachamber.com/dcci-former-presidents)
    -   [Former Senior Vice Presidents](https://dhakachamber.com/dcci-former-senior-vice-presidents)
    -   [Former Vice Presidents](https://dhakachamber.com/dcci-former-vice-presidents)
    -   [Achievements & Awards](https://dhakachamber.com/achievements-awards)
    -   [Policy and Objectives](https://dhakachamber.com/quality-policy-and-objectives)
-   [Organizational Information](#)
    -   [Board of Directors](https://dhakachamber.com/board-of-directors)
    -   [Previous Board of Directors](https://dhakachamber.com/dcci-allpastmanagement)
    -   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
    -   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)
-   [President](https://dhakachamber.com/president)
-   [Membership](#)
    -   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
    -   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
    -   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
    -   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
    -   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
    -   [Become a Member](https://membership.dhakachamber.com/register)
    -   [Member Login](https://membership.dhakachamber.com)
    -   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
    -   [Member Query](https://dhakachamber.com/member-query)
    -   [Hot Line](https://dhakachamber.com/hot_line)
-   [Projects](https://dhakachamber.com/project-activities)
-   [Seminar](https://dhakachamber.com/media/seminar)
-   [Publications](#)
    -   [DCCI Research Service](https://dhakachamber.com/pdf_viewer/storage/2024/circular/DCCI%20Research%20Service.pdf)
    -   [Research Guideline](https://dhakachamber.com/pdf_viewer/storage/2024/circular/Research%20Guideline.pdf)
    -   [DCCI Journal (DJBEP)](https://journal.dhakachamber.com/)
    -   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
    -   [DCCI Review](https://dhakachamber.com/publications/reviews)
    -   [DCCI Publications](https://dhakachamber.com/publications)
    -   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
    -   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)
    -   [Introducing DCCI 2023](https://www.dhakachamber.com/storage/print_media/2023/07/Introducing%202023.pdf)
-   [Media](#)
    -   [Chamber News](https://dhakachamber.com/media/news)
    -   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
    -   [Photo Gallery](https://dhakachamber.com/albums)
    -   [Video Gallery](https://dhakachamber.com/videos)
    -   [Fairs & Exhibitions](https://www.dhakachamber.com/storage/2026/03/dccifair.pdf)
-   [Policy](#)
    -   [Export Policy](https://www.dhakachamber.com/storage/policy/3VFoMxkr6Z3EZdC8wz7YHfrIBfPP5N0Y6n7eEEFJ.pdf)
    -   [Import Policy](https://www.dhakachamber.com/storage/policy/b6uhXGhpdl30N68gl3Yg9mV5P6vGIPAjquqTu35f.pdf)
    -   [Industry Policy](https://www.dhakachamber.com/storage/policy/kpHRSdbYmY90O7wcyYmkZTSvumKEXfz5uwPTlOn5.pdf)
    -   [ICT Policy](https://www.dhakachamber.com/storage/policy/abTlbODgI2I4Aqbrix5Cs2DHvFD5lW3OwDmfKXmH.pdf)
-   [BILATERAL TRADE](#)
    -   [Bilateral Trade](https://dhakachamber.com/bilateral-trade)
    -   [Africa](https://dhakachamber.com/bilateral-trade/africa)
    -   [America](https://dhakachamber.com/bilateral-trade/america)
    -   [Asian](https://dhakachamber.com/bilateral-trade/asian)
    -   [ASEAN](https://dhakachamber.com/bilateral-trade/asean)
    -   [SAARC](https://dhakachamber.com/bilateral-trade/saarc)
    -   [Middle East](https://dhakachamber.com/bilateral-trade/middle-east)
    -   [European Union](https://dhakachamber.com/bilateral-trade/european-union)
-   [About Bangladesh](#)
    -   [General Information](https://dhakachamber.com/bangladesh-country-profile)
    -   [Business Opportunities in Bangladesh](https://dhakachamber.com/trade-and-business-opportunities-in-bangladesh)
    -   [Useful Links](https://dhakachamber.com/useful-links)
-   [B2B Directory](#)
    -   [B2B Directory](https://dhakachamber.com/b2b)
    -   [B2B Member Login](https://dhakachamber.com/login)
    -   [B2B Registration](https://dhakachamber.com/b2b-reg)