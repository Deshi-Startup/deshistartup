---
source: "Dhaka Chamber of Commerce & Industry (DCCI)"
tier: 1
category: "Chamber"
url: "https://dhakachamber.com/"
title: "DCCI :: Dhaka Chamber of Commerce & Industry"
scraped_at: "2026-07-02"
---

![64th Annual General Meeting of DCCI](https://dhakachamber.com/storage/homesliders/December2025/pDYEcMt069QAZWJ7yMTq.jpg) 

# 64th Annual General Meeting of DCCI

![Seminar on Economic Position Index (EPI)](https://dhakachamber.com/storage/homesliders/May2026/IQx6fvX5AAQ4LnFdCek9.jpg) 

# Seminar on Economic Position Index (EPI)

![DCCI Initial Budget Reaction 2026](https://dhakachamber.com/storage/homesliders/June2026/bDUiDjv2HDzADJupbIpm.jpeg) 

# DCCI Initial Budget Reaction 2026

![DCCI President called on Honourable Commerce Minister](https://dhakachamber.com/storage/homesliders/March2026/h9db8wlzNs1c9FWuLUbz.jpeg) 

# DCCI President called on Honourable Commerce Minister

![Seminar on Electric Vehicle Challenges and Prospects in Bangladesh](https://dhakachamber.com/storage/homesliders/June2026/RvPCLXZJil7goZmkKurj.jpeg) 

# Seminar on Electric Vehicle Challenges and Prospects in Bangladesh

![Interntional Business Conference](https://dhakachamber.com/storage/homesliders/December2019/WR8Bxvy6vj2NiKyswYYX.JPG) 

# Interntional Business Conference

![The night glance of Dhaka](https://dhakachamber.com/storage/homesliders/May2022/5CoZsOCVs0Tvva5PY1vn.jpg) 

# The night glance of Dhaka

![DCCI Business Award 2008](https://dhakachamber.com/storage/homesliders/December2019/XSC0XtRzEfbPTRT8gp8Q.JPG) 

# DCCI Business Award 2008

![51st Annual General Meeting](https://dhakachamber.com/storage/homesliders/May2022/sXlWu6T1G4n1JQAKTgyp.jpg) 

# 51st Annual General Meeting

![MoU between DCCI and DUBAI Chambers](https://dhakachamber.com/storage/homesliders/March2025/AG2wkpUCsAlkeRcQzoL5.jpg) 

# MoU between DCCI and DUBAI Chambers

![DCCI President called on Honourable Finance & Planning Minister](https://dhakachamber.com/storage/homesliders/March2026/JRoacGLzVFGwGl4ehPpY.jpeg) 

# DCCI President called on Honourable Finance & Planning Minister

![Live Pre-Budget Discussion](https://dhakachamber.com/storage/homesliders/April2026/ZCDZ8wQpct869mgZisXp.jpeg) 

# Live Pre-Budget Discussion

[](#main-carousel)[](#main-carousel)

## About DCCI

## Dhaka Chamber of Commerce & Industry

Dhaka Chamber of Commerce & Industry (DCCI), established in 1958 under companies Act 1913 is the largest and most vibrant business chamber in Bangladesh. Its membership consists of industrial conglomerates, manufacturers, importers, exporters and traders mostly of small and medium enterprises (SMEs). The main objectives of DCCI are to promote private sector enterprises and businesses with advocacy, awareness and policy inputs to government.

[Read More](https://dhakachamber.com/about-us)

[![Card image cap](https://dhakachamber.com/storage/popups/November2022/banner2.jpeg)](https://dhakachamber.com/storage/popups/November2022/banner22.jpeg)

[![Card image cap](https://dhakachamber.com/storage/popups/November2022/banner33.jpeg)](https://dhakachamber.com/pdf_viewer/storage/2024/circular/DCCI%20Research%20Service.pdf)

[![Card image cap](https://dhakachamber.com/storage/popups/November2022/banner6.jpeg)](https://dhakachamber.com/storage/popups/November2022/banner66.jpeg)

[![Card image cap](https://dhakachamber.com/storage/popups/November2022/banner7.jpeg)](https://dhakachamber.com/storage/popups/November2022/banner77.jpeg)

[](#VerticalNewsSlider)[](#VerticalNewsSlider)

[![logo](https://dhakachamber.com/storage/sixicons/January2020/ALfaq6oTsUOuGC0fxwys.png)

### Become a Member

](http://dhakachamber.com/eligibility-of-membership)

[![logo](https://dhakachamber.com/storage/sixicons/January2020/e1fmPcj5ic1uVE9ZDrrS.png)

### BIDA OSS

](https://bida.gov.bd/)

[![logo](https://dhakachamber.com/storage/sixicons/January2020/bfTdELKN4dXdf5MmnWuW.png)

### Business Scope

](https://dhakachamber.com/bilateral-trade)

[![logo](https://dhakachamber.com/storage/sixicons/January2020/3haR06HwTy7V18ZwRZ6a.png)

### DCCI Projects

](http://dhakachamber.com/project-activities)

[![logo](https://dhakachamber.com/storage/sixicons/January2020/SQfdyyEBSx7uw1JPFz9m.png)

### Research & Publications

](http://dhakachamber.com/publications)

[![logo](https://dhakachamber.com/storage/sixicons/January2020/k7kdSAHg6lus7XUkvwnw.png)

### DCCI Events

](http://dhakachamber.com/media/events)

## From the President

![President](https://dhakachamber.com/storage/messagepresidents/April2025/oNcEFNrbNLGRgnklVU8O.jpg)

### President's Message

Welcome to Dhaka Chamber of Commerce & Industry (DCCI), the largest Chamber in Bangladesh with more than 5,700 regular members from SMEs to large businesses, is a strong partner in the progress of the nation. DCCI is a place where ideas are incubated for the development of the private sector including trade, business, industry and investment by upholding the visions of the government to support the journey of Bangladesh towards a developing economy by 2024 and developed economy by 2041.

[Read More](https://dhakachamber.com/president)

## Latest News

-   ![seminar on "The Electric Vehicle (EV): Challenges and Prospects in Bangladesh "](https://dhakachamber.com/storage/posts/June2026/eHZK71yuZwA2jdWRaz82.jpg)
-   Published on: 2026-06-27

[seminar on "The Electric Vehicle (EV): Challenges and Prospects in Bangladesh "](https://dhakachamber.com/media/news/seminar-on-the-electric-vehicle-ev-challenges-and-prospects-in-bangladesh)

-   ![DCCI’s initial reaction to the proposed national budget 2026-27](https://dhakachamber.com/storage/posts/June2026/ZKqSEajipxQ7ydLJ6qGa.jpg)
-   Published on: 2026-06-11

[DCCI’s initial reaction to the proposed national budget 2026-27](https://dhakachamber.com/media/news/dcci-s-initial-reaction-to-the-proposed-national-budget-2026-27)

-   ![New Zealand High Commissioner meets Dhaka Chamber President](https://dhakachamber.com/storage/posts/May2026/Ia3kgTihLEbplRaGWe1N.jpg)
-   Published on: 2026-05-20

[New Zealand High Commissioner meets Dhaka Chamber President](https://dhakachamber.com/media/news/new-zealand-high-commissioner-meets-dhaka-chamber-president)

-   ![Seminar on “Economic Position Index (EPI): Quarterly Macroeconomic State of Dhaka”](https://dhakachamber.com/storage/posts/May2026/sxlcXuZH4yfPosV3udyp.jpg)
-   Published on: 2026-05-16

[Seminar on “Economic Position Index (EPI): Quarterly Macroeconomic State of Dhaka”](https://dhakachamber.com/media/news/seminar-on-economic-position-index-epi-quarterly-macroeconomic-state-of-dhaka)

-   ![Bilateral trade discussion held between DCCI and Turkish business delegation](https://dhakachamber.com/storage/posts/May2026/qfibXLHTHdPNPj6vrssB.JPG)
-   Published on: 2026-05-13

[Bilateral trade discussion held between DCCI and Turkish business delegation](https://dhakachamber.com/media/news/bilateral-trade-discussion-held-between-dcci-and-turkish-business-delegation)

[](#testimonialSlider)[](#testimonialSlider)

[Chamber News](https://dhakachamber.com/media/news)

[Print Media](https://dhakachamber.com/media/dcci-news-links)

[Electronic Media](https://dhakachamber.com/media/dcci-news-coverage-electronic-media)

-   [Circular](#circular)
-   [Tender](#latest)

[Download](https://dhakachamber.com/storage/tenders/February2026/XOkg59bLEigCKOXav31L.pdf)

### [Request for Quotation (FFQ) for "Cloud Server"](https://dhakachamber.com/storage/tenders/February2026/XOkg59bLEigCKOXav31L.pdf)

2026-02-15

[Download](https://dhakachamber.com/storage/tenders/February2026/dSvEO9uWiasmA409WQMR.pdf)

### [Request for Quotation (FFQ) for "e-Sign Service"](https://dhakachamber.com/storage/tenders/February2026/dSvEO9uWiasmA409WQMR.pdf)

2026-02-05

[Download](https://dhakachamber.com/storage/tenders/January2026/sEZFupUrW5kCbk7Xw2d5.pdf)

### [Request for Quotation of Microsoft 365 Business Basic](https://dhakachamber.com/storage/tenders/January2026/sEZFupUrW5kCbk7Xw2d5.pdf)

2026-01-18

[Download](https://dhakachamber.com/storage/tenders/November2025/tgRpwLKR54MIPqhy2NVo.pdf)

### [২০২৫-২০২৬ অর্থবছরের অডিট কার্যক্রমের জন্য আগ্রহ পত্র আহ্বান প্রসঙ্গে।](https://dhakachamber.com/storage/tenders/November2025/tgRpwLKR54MIPqhy2NVo.pdf)

2025-11-22

[Download](https://dhakachamber.com/storage/tenders/September2025/R0ZOVPZXZBFOXRD7pCRf.pdf)

### [RFQ for Live Streaming Equipment](https://dhakachamber.com/storage/tenders/September2025/R0ZOVPZXZBFOXRD7pCRf.pdf)

2025-09-28

[**More Tenders**](https://dhakachamber.com/tender)

[![Application for Membership(Circular No: 35)](https://dhakachamber.com/storage/posts/July2026/e7S1ImHSBd87IYUQczgN.jpg)](https://dhakachamber.com/media/circular/application-for-membership-circular-no-35)

### [Application for Membership(Circular No: 35)](https://dhakachamber.com/media/circular/application-for-membership-circular-no-35)

2026-06-30

[![Application for Express Membership (Circular No: 94)](https://dhakachamber.com/storage/posts/July2026/2UgDugWeozsMBFiHv8v8.jpg)](https://dhakachamber.com/media/circular/application-for-express-membership-circular-no-94)

### [Application for Express Membership (Circular No: 94)](https://dhakachamber.com/media/circular/application-for-express-membership-circular-no-94)

2026-06-30

[![Application for Membership(Circular No: 31)](https://dhakachamber.com/storage/posts/June2026/4ZcP1BMqgZyTiudloADC.jpg)](https://dhakachamber.com/media/circular/application-for-membership-circular-no-031)

### [Application for Membership(Circular No: 31)](https://dhakachamber.com/media/circular/application-for-membership-circular-no-031)

2026-06-24

[![Application for Membership(Circular No: 30)](https://dhakachamber.com/storage/posts/June2026/Tjz314SCnBtZz7iSMlXZ.jpg)](https://dhakachamber.com/media/circular/application-for-membership-circular-no-30)

### [Application for Membership(Circular No: 30)](https://dhakachamber.com/media/circular/application-for-membership-circular-no-30)

2026-06-21

[![Application for Express Membership (Circular No: 86)](https://dhakachamber.com/storage/posts/June2026/ac47qWqds5SvDFZrQz11.jpg)](https://dhakachamber.com/media/circular/application-for-express-membership-circular-no-86)

### [Application for Express Membership (Circular No: 86)](https://dhakachamber.com/media/circular/application-for-express-membership-circular-no-86)

2026-06-18

[**More Circulars**](https://dhakachamber.com/media/circular)

-   [Workshop](#seminar)
-   [Seminar Recommendation](#trade)

[![Admission in the PGD in 'Customs, VAT and Income Tax Management’ 23rd Batch.](https://dhakachamber.com/storage/posts/June2026/kI3ji0Is38I7gPNtLU0q.jpg)](https://dhakachamber.com/media/seminar/admission-in-the-pgd-in-customs-vat-and-income-tax-management-23rd-batch)

### [Admission in the PGD in 'Customs, VAT and Income Tax Management’ 23rd Batch.](https://dhakachamber.com/media/seminar/admission-in-the-pgd-in-customs-vat-and-income-tax-management-23rd-batch)

2026-06-23

[![Admission to the PGD in ‘International Trade (Export & Import) Management’, 25th Batch](https://dhakachamber.com/storage/posts/June2026/GBLiFpOuFOUXE7KkbiGa.jpg)](https://dhakachamber.com/media/seminar/admission-to-the-pgd-in-international-trade-export-and-import-management-25th-batch)

### [Admission to the PGD in ‘International Trade (Export & Import) Management’, 25th Batch](https://dhakachamber.com/media/seminar/admission-to-the-pgd-in-international-trade-export-and-import-management-25th-batch)

2026-06-23

[![Admission Open: Postgraduate Diploma (PGD) in Supply Chain Management 6th Batch in collaboration with DIU](https://dhakachamber.com/storage/posts/June2026/5bprap6MMRk0J6t7AFF2.jpg)](https://dhakachamber.com/media/seminar/admission-open-postgraduate-diploma-pgd-in-supply-chain-management-6th-batch-in-collaboration-with-diu)

### [Admission Open: Postgraduate Diploma (PGD) in Supply Chain Management 6th Batch in collaboration with DIU](https://dhakachamber.com/media/seminar/admission-open-postgraduate-diploma-pgd-in-supply-chain-management-6th-batch-in-collaboration-with-diu)

2026-06-23

[![Admission to the following online certificate courses.](https://dhakachamber.com/storage/posts/June2026/zLhvqhBOoDKwuP7r56Mv.jpg)](https://dhakachamber.com/media/seminar/admission-to-the-following-online-certificate-courses)

### [Admission to the following online certificate courses.](https://dhakachamber.com/media/seminar/admission-to-the-following-online-certificate-courses)

2026-06-23

[![Admission is going on for the online certificate courses in collaboration with respective partner Universities.](https://dhakachamber.com/storage/posts/June2026/XXCI4yAMRB1XuQrxS54w.jpg)](https://dhakachamber.com/media/seminar/admission-is-going-on-for-the-online-certificate-courses-in-collaboration-with-respective-partner-universities)

### [Admission is going on for the online certificate courses in collaboration with respective partner Universities.](https://dhakachamber.com/media/seminar/admission-is-going-on-for-the-online-certificate-courses-in-collaboration-with-respective-partner-universities)

2026-06-23

[**More Seminars**](https://dhakachamber.com/media/seminar)

### [Seminar on "Biannual Economic State & Future Outlook of Bangladesh Economy: Private Sector Perspective"](https://dhakachamber.com/media/seminar-recommendation/seminar-on-biannual-economic-state-and-future-outlook-of-bangladesh-economy-private-sector-perspective)

2025-09-11

### [FGD on "Decentralisation & Environmental Welfare of the Capital: Towards a Sustainable Dhaka"](https://dhakachamber.com/media/seminar-recommendation/fgd-on-decentralisation-and-environmental-welfare-of-the-capital-towards-a-sustainable-dhaka)

2025-09-10

### [FGD on Implementation of International Financial Reporting Standard (IFRS)](https://dhakachamber.com/media/seminar-recommendation/fgd-on-implementation-of-international-financial-reporting-standard-ifrs20)

2025-04-30

### [FGD on Implementation of the STS for Smooth Transition from LDC Status](https://dhakachamber.com/media/seminar-recommendation/fgd-on-implementation-of-the-sts-for-smooth-transition-from-ldc-status)

2025-03-30

### [DCCI delegation to UAE](https://dhakachamber.com/media/seminar-recommendation/dcci-delegation-to-uae2025)

2025-03-16

[**More Seminar Recommendations**](https://dhakachamber.com/media/seminar-recommendation)

## Fairs & Exhibitions

Saudi Building & Interiors Exhibition

[View Details](https://dhakachamber.com/media/fairs-and-exhibitions/saudi-building-and-interiors-exhibition)

Swiss Fintech Investor Day

[View Details](https://dhakachamber.com/media/fairs-and-exhibitions/swiss-fintech-investor-day)

Horasis Asia Meeting

[View Details](https://dhakachamber.com/media/fairs-and-exhibitions/horasis-asia-meeting)

Aquaculture America

[View Details](https://dhakachamber.com/media/fairs-and-exhibitions/aquaculture-america)

India International Trade Fair

[View Details](https://dhakachamber.com/media/fairs-and-exhibitions/india-international-trade-fair)

[](#testimonial-carousel)[](#testimonial-carousel)

## Information Services

-   [Investment Incentives](#fast)
-   [Project Activities](#reliable)
-   [BIDA OSS](#oss)

![](https://dhakachamber.com/storage/pages/October2018/9jfh8Xa6YQ2Q8eQ7PByl.jpg)

### Investment Incentives

Investment Incentives in Bangladesh In order to encourage the inflows of FDI the government of Bangladesh offers one of the most liberal investment policies and attractive packages of fiscal, financial and other incentives to foreign entrepreneurs in South Asia. Major incentives to stimulate private sector direct investment are listed below.

[View Details](https://dhakachamber.com/investment-incentives)

![](https://dhakachamber.com/storage/pages/October2018/QloPnEOZjan5D2l4xlMT.jpg)

### Trade Information

FOREIGN EXPORTERS

**FUJIAN MINGHUI MECH & ELEC. CO., LTD.**

Add: No. 6 Plot, Jinahan Pushang Gulou Garden Industrial Zone, Fuzhou, Fujian, P. R. China.  
Tel: +86-591-8385586  
Fax : +86-591-8355589

[View Details](https://dhakachamber.com/trade-information)

![](https://dhakachamber.com/storage/pages/October2018/El2zCqMhemTHLHiYEMNF.jpg)

### Economic Indicator

ECONOMIC INDICATORS OF BANGLADESH 

[View Details](https://dhakachamber.com/economic-indicator)

![](https://dhakachamber.com/storage/pages/October2018/4lTv4E8uuVJYMGA1T7S8.jpg)

### Project Activities

[View Details](http://dhakachamber.com/project-activities)

![](http://www.dhakachamber.com/storage/covid-19/bida.png)

### BIDA One Stop Service(OSS)

BIDA is working to create a business-friendly environment in Bangladesh. BIDA has developed an One Stop Service portalunder the OSS Act, 2018 and the OSS (Bangladesh Investment Development Authority) Rules, 2020. This portal aims to provide all services related to businesses from a single window.

[View Details](http://www.dhakachamber.com/storage/covid-19/oss.pdf)

![icon](images/virtual_tour.png)

Virtual Tour

[![icon](https://dhakachamber.com/storage/eighticons/March2021/VmcUO5Joe0G5y8v77NNJ.png)

Photo Gallery

](https://dhakachamber.com/albums)

[](https://dhakachamber.com/albums)

[](https://dhakachamber.com/albums)

[](https://dhakachamber.com/albums)

[](https://dhakachamber.com/albums)

[](https://dhakachamber.com/albums)

[](https://dhakachamber.com/albums)[![icon](https://dhakachamber.com/storage/eighticons/March2021/bZ7TQGHYdabbtssTFVd6.png)

Video Gallery

](https://dhakachamber.com/videos)

[](https://dhakachamber.com/videos)

[](https://dhakachamber.com/videos)

[](https://dhakachamber.com/videos)

[](https://dhakachamber.com/videos)

[](https://dhakachamber.com/videos)

[](https://dhakachamber.com/videos)[![icon](https://dhakachamber.com/storage/eighticons/March2021/xcfOCieME0zLuRnpcobw.png)

CSR Activities

](http://dhakachamber.com/csr-activity)

[](http://dhakachamber.com/csr-activity)

[](http://dhakachamber.com/csr-activity)

[](http://dhakachamber.com/csr-activity)

[](http://dhakachamber.com/csr-activity)

[](http://dhakachamber.com/csr-activity)

[](http://dhakachamber.com/csr-activity)[![icon](https://dhakachamber.com/storage/eighticons/January2020/j0KyDotW1fJQFQjhHfbr.png)

Business Institute

](http://dcci-dbi.edu.bd/home)

[](http://dcci-dbi.edu.bd/home)

[](http://dcci-dbi.edu.bd/home)

[](http://dcci-dbi.edu.bd/home)

[](http://dcci-dbi.edu.bd/home)

[](http://dcci-dbi.edu.bd/home)

[](http://dcci-dbi.edu.bd/home)[![icon](https://dhakachamber.com/storage/eighticons/January2020/3KHKStwf1K3yqbWHG1zy.png)

DBI College

](http://dbicollege.edu.bd)

[](http://dbicollege.edu.bd)

[](http://dbicollege.edu.bd)

[](http://dbicollege.edu.bd)

[](http://dbicollege.edu.bd)

[](http://dbicollege.edu.bd)

[](http://dbicollege.edu.bd)[![icon](https://dhakachamber.com/storage/eighticons/January2020/1gYzwW5XyJlIH7uF9Rq8.png)

BUILD

](http://dhakachamber.com/build)

[](http://dhakachamber.com/build)

[](http://dhakachamber.com/build)

[](http://dhakachamber.com/build)

[](http://dhakachamber.com/build)

[](http://dhakachamber.com/build)

[](http://dhakachamber.com/build)[![icon](https://dhakachamber.com/storage/eighticons/January2020/33yvK1qSDEoW4R6mzTlS.png)

BIAC

](http://dhakachamber.com/biac)

[](http://dhakachamber.com/biac)

[](http://dhakachamber.com/biac)

[](http://dhakachamber.com/biac)

[](http://dhakachamber.com/biac)

[](http://dhakachamber.com/biac)

[](http://dhakachamber.com/biac)

[

## Achievements & Awards





](http://dhakachamber.com/biac)

[](http://dhakachamber.com/biac)

[](http://dhakachamber.com/biac)

[](http://dhakachamber.com/biac)

[](http://dhakachamber.com/biac)

[

![DCCI wins the "MLS-SCM (P) Best Network Partner Institution Award 2010" of International Trade Centre (ITC) - UNCTAD/WTO, Geneva](https://dhakachamber.com/storage/achievements-awards/October2018/V3DlVyDjI2XNkQwbszEq.jpg)



](http://dhakachamber.com/biac)

[](http://dhakachamber.com/biac)

[](http://dhakachamber.com/biac)[DCCI wins the "MLS-SCM (P) Best Network Partner Institution Award 2010" of International Trade Centre (ITC) - UNCTAD/WTO, Geneva](https://dhakachamber.com/achievements-awards)

[Read More](https://dhakachamber.com/achievements-awards)

![ISO certification for the Chamber](https://dhakachamber.com/storage/achievements-awards/October2018/aoRao5T5RqBCwhN8z4Tm.jpg)

[ISO certification for the Chamber](https://dhakachamber.com/achievements-awards)

[Read More](https://dhakachamber.com/achievements-awards)

![CACCI Local Chamber Awards 2010](https://dhakachamber.com/storage/achievements-awards/October2018/2SsXGqbj0zB6mbf8YozB.jpg)

[CACCI Local Chamber Awards 2010](https://dhakachamber.com/achievements-awards)

[Read More](https://dhakachamber.com/achievements-awards)

![World Chambers Competition Award 2007](https://dhakachamber.com/storage/achievements-awards/October2018/S3A8OMeEEZwdhMUJq67V.jpg)

[World Chambers Competition Award 2007](https://dhakachamber.com/achievements-awards)

Dhaka Chamber of Commerce & Industry (DCCI) has won the “World Chambers Competition Award 2007” in “Best Skills Development Programme” category from the World Chambers Federation (WCF).

[Read More](https://dhakachamber.com/achievements-awards)

![Finalist for Best Unconventional Project 2011](https://dhakachamber.com/storage/achievements-awards/September2022/wGW93quRaxWT9LeAMBKK.jpg)

[Finalist for Best Unconventional Project 2011](https://dhakachamber.com/achievements-awards)

[Read More](https://dhakachamber.com/achievements-awards)

[](#Carousel)[](#Carousel)

## Strategic and Projects Partners

[![](<  https://dhakachamber.com/public/images/cl-logo/cl-logo1.jpg>)](https://www.jetro.go.jp/en/)

[![](https://dhakachamber.com/public/images/cl-logo/cl-logo5.jpg)](https://www.undp.org/)

[![](https://dhakachamber.com/public/images/cl-logo/cl-logo4.jpg)](https://saarc-sec.org/)

[![](https://dhakachamber.com/public/images/cl-logo/bida-logo_01.png)](http://bida.gov.bd/)

[![](https://dhakachamber.com/public/images/cl-logo/BIID-LOGO2.png)](https://www.biid.org.bd/)

[![](https://dhakachamber.com/public/images/cl-logo/cccinewlogo1.png)](https://www.chittagongchamber.com/)

[![](<https://dhakachamber.com/public/images/cl-logo/logo \(1\).png>)](https://nationalchamber.lk/)

[![](https://dhakachamber.com/public/images/cl-logo/logo.png)](http://www.mccibd.org/)

## Contact us

## 

#### Motijheel Main Office

Dhaka Chamber Building  
65-66 Motijheel C/A   
Dhaka-1000, Bangladesh

Telephone :+88-0247122986

IP Phone :+88-09-666-888555

FAX : +88-02223380830

Email : [info@dhakachamber.com](http://dhakachamber.com/#)

## 

#### DCCI Gulshan Centre

BTI Landmark (level-11), Plot- 16,  
Block- CWS(A), Gulshan Avenue,  
Gulshan-1, Dhaka-1212, Bangladesh

Telephone : +88-02226601967

Telephone : +88-02226601968

Direct Phone : +88-09-666-319654

Email : [info@dhakachamber.com](http://dhakachamber.com/#)

## 

#### Mohammadpur Service Zone

75C Asad Avenue,Mohammadpur,  
Dhaka-1207, Bangladesh

Phone : +88-09-666-888555

Direct Phone : +88-09-666-319655

Email : [info@dhakachamber.com](http://dhakachamber.com/#)

[](https://www.facebook.com/DhakaCCI/)[](https://www.youtube.com/@DhakaCCI)[](https://www.linkedin.com/company/dccibd)[](#)

### ABOUT US

-   [Board of Directors](https://dhakachamber.com/board-of-directors)
-   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
-   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)

### USEFUL LINKS

-   [DBI College](http://www.dbicollege.edu.bd)
-   [DCCI Business Institute](http://dcci-dbi.edu.bd)
-   [BUILD](http://www.buildbd.org)
-   [BIAC](https://www.biac.org.bd)
-   [ICCB](https://iccbangladesh.org.bd)

### MEMBERSHIP

-   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
-   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
-   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
-   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
-   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
-   [Become a Member](https://membership.dhakachamber.com/register)
-   [Member Login](https://membership.dhakachamber.com)
-   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
-   [Member Query](https://dhakachamber.com/member-query)
-   [Hot Line](https://dhakachamber.com/hot_line)

### MEDIA

-   [Chamber News](https://dhakachamber.com/media/news)
-   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
-   [Photo Gallery](https://dhakachamber.com/albums)
-   [Video Gallery](https://dhakachamber.com/videos)

### DOWNLOAD

-   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
-   [DCCI Reviews](https://dhakachamber.com/publications/reviews)
-   [DCCI Publications](https://dhakachamber.com/publications)
-   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
-   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)

×

-   [Home(current)](https://dhakachamber.com)
-   [About us](#)
    -   [Brief About DCCI](https://dhakachamber.com/about-us)
    -   [International Affiliations](https://dhakachamber.com/international-affiliations)
    -   [DCCI Founders](https://dhakachamber.com/dcci-founders)
    -   [Former Presidents](https://dhakachamber.com/dcci-former-presidents)
    -   [Former Senior Vice Presidents](https://dhakachamber.com/dcci-former-senior-vice-presidents)
    -   [Former Vice Presidents](https://dhakachamber.com/dcci-former-vice-presidents)
    -   [Achievements & Awards](https://dhakachamber.com/achievements-awards)
    -   [Policy and Objectives](https://dhakachamber.com/quality-policy-and-objectives)
-   [Organizational Information](#)
    -   [Board of Directors](https://dhakachamber.com/board-of-directors)
    -   [Previous Board of Directors](https://dhakachamber.com/dcci-allpastmanagement)
    -   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
    -   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)
-   [President](https://dhakachamber.com/president)
-   [Membership](#)
    -   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
    -   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
    -   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
    -   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
    -   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
    -   [Become a Member](https://membership.dhakachamber.com/register)
    -   [Member Login](https://membership.dhakachamber.com)
    -   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
    -   [Member Query](https://dhakachamber.com/member-query)
    -   [Hot Line](https://dhakachamber.com/hot_line)
-   [Projects](https://dhakachamber.com/project-activities)
-   [Seminar](https://dhakachamber.com/media/seminar)
-   [Publications](#)
    -   [DCCI Research Service](https://dhakachamber.com/pdf_viewer/storage/2024/circular/DCCI%20Research%20Service.pdf)
    -   [Research Guideline](https://dhakachamber.com/pdf_viewer/storage/2024/circular/Research%20Guideline.pdf)
    -   [DCCI Journal (DJBEP)](https://journal.dhakachamber.com/)
    -   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
    -   [DCCI Review](https://dhakachamber.com/publications/reviews)
    -   [DCCI Publications](https://dhakachamber.com/publications)
    -   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
    -   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)
    -   [Introducing DCCI 2023](https://www.dhakachamber.com/storage/print_media/2023/07/Introducing%202023.pdf)
-   [Media](#)
    -   [Chamber News](https://dhakachamber.com/media/news)
    -   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
    -   [Photo Gallery](https://dhakachamber.com/albums)
    -   [Video Gallery](https://dhakachamber.com/videos)
    -   [Fairs & Exhibitions](https://www.dhakachamber.com/storage/2026/03/dccifair.pdf)
-   [Policy](#)
    -   [Export Policy](https://www.dhakachamber.com/storage/policy/3VFoMxkr6Z3EZdC8wz7YHfrIBfPP5N0Y6n7eEEFJ.pdf)
    -   [Import Policy](https://www.dhakachamber.com/storage/policy/b6uhXGhpdl30N68gl3Yg9mV5P6vGIPAjquqTu35f.pdf)
    -   [Industry Policy](https://www.dhakachamber.com/storage/policy/kpHRSdbYmY90O7wcyYmkZTSvumKEXfz5uwPTlOn5.pdf)
    -   [ICT Policy](https://www.dhakachamber.com/storage/policy/abTlbODgI2I4Aqbrix5Cs2DHvFD5lW3OwDmfKXmH.pdf)
-   [BILATERAL TRADE](#)
    -   [Bilateral Trade](https://dhakachamber.com/bilateral-trade)
    -   [Africa](https://dhakachamber.com/bilateral-trade/africa)
    -   [America](https://dhakachamber.com/bilateral-trade/america)
    -   [Asian](https://dhakachamber.com/bilateral-trade/asian)
    -   [ASEAN](https://dhakachamber.com/bilateral-trade/asean)
    -   [SAARC](https://dhakachamber.com/bilateral-trade/saarc)
    -   [Middle East](https://dhakachamber.com/bilateral-trade/middle-east)
    -   [European Union](https://dhakachamber.com/bilateral-trade/european-union)
-   [About Bangladesh](#)
    -   [General Information](https://dhakachamber.com/bangladesh-country-profile)
    -   [Business Opportunities in Bangladesh](https://dhakachamber.com/trade-and-business-opportunities-in-bangladesh)
    -   [Useful Links](https://dhakachamber.com/useful-links)
-   [B2B Directory](#)
    -   [B2B Directory](https://dhakachamber.com/b2b)
    -   [B2B Member Login](https://dhakachamber.com/login)
    -   [B2B Registration](https://dhakachamber.com/b2b-reg)

× [![](https://dhakachamber.com/storage/popups/January2025/cXVEqkQlU8E8MxBvqsar.jpg)](https://dhakachamber.com/membership_application_process)

×

![DCCI Building](https://dhakachamber.com/storage/virtualtours/February2025/qm9N2egEWhWCMtS5bfEO.jpg)

##### DCCI Building

![Ground Floor](https://dhakachamber.com/storage/virtualtours/February2025/NW0wQYmHrEq7xXP6S6Do.jpg)

##### Ground Floor

![Ground Floor](https://dhakachamber.com/storage/virtualtours/February2025/msLmFtfxwxzq05YKyrGK.jpg)

##### Ground Floor

![Ground Floor](https://dhakachamber.com/storage/virtualtours/February2025/uhS3aewCnXO6PySlqdV8.jpg)

##### Ground Floor

![Ground Floor](https://dhakachamber.com/storage/virtualtours/February2025/B79BE6WziQZRuTHq8GnD.jpg)

##### Ground Floor

![Ground Floor](https://dhakachamber.com/storage/virtualtours/February2025/R4RIchuTIVSfH1jARIOi.jpg)

##### Ground Floor

![Secretariat Floor](https://dhakachamber.com/storage/virtualtours/February2025/UNrxFkUY2Bww0FuDpFgr.jpg)

##### Secretariat Floor

![Secretariat Floor](https://dhakachamber.com/storage/virtualtours/February2025/30kVe0U6DeBrTfzQ87M0.jpg)

##### Secretariat Floor

![Secretariat Floor](https://dhakachamber.com/storage/virtualtours/February2025/ZFeZuaai8UOrxtqUqiWm.jpg)

##### Secretariat Floor

![Secretariat Floor](https://dhakachamber.com/storage/virtualtours/February2025/eTS8qyBoLNIpMxJGJ5fl.jpg)

##### Secretariat Floor

![Secretariat Floor](https://dhakachamber.com/storage/virtualtours/February2025/n3bqhl3bKQP3s2Zm77Ey.jpg)

##### Secretariat Floor

![Secretariat Floor](https://dhakachamber.com/storage/virtualtours/February2025/ro9USbqsvRQr162CnT6I.jpg)

##### Secretariat Floor

![Secretariat Floor](https://dhakachamber.com/storage/virtualtours/February2025/pmJ4zNKo3BLyVRbcWryz.jpg)

##### Secretariat Floor

![Member service](https://dhakachamber.com/storage/virtualtours/December2019/1uf2i9R07jpYpaampc7R.jpg)

##### Member service

![Auditorium](https://dhakachamber.com/storage/virtualtours/December2019/x8cKBEebA7zbmCQY75Vj.jpg)

##### Auditorium

![auditorium](https://dhakachamber.com/storage/virtualtours/December2019/kBqDMG4pDdlBAbPhLUcV.jpg)

##### auditorium

![coffee](https://dhakachamber.com/storage/virtualtours/December2019/cphzMkkxxz2o8EpbYMuk.jpg)

##### coffee

![Executive auditorium](https://dhakachamber.com/storage/virtualtours/December2019/oYsVZruJhNklgutdeIEb.jpg)

##### Executive auditorium

![executive loby](https://dhakachamber.com/storage/virtualtours/December2019/QmWXajGCi21dYKR5854d.jpg)

##### executive loby

![4th floor](https://dhakachamber.com/storage/virtualtours/February2025/WlNW8nMzPyIVvkWTVziJ.JPG)

##### 4th floor

![Executive board room](https://dhakachamber.com/storage/virtualtours/December2019/09gUzLNG8AE9ZEDOtrvG.jpg)

##### Executive board room

![President Room](https://dhakachamber.com/storage/virtualtours/December2019/7xmnyDxOHHkASKFBfzgY.jpg)

##### President Room

![PS Room](https://dhakachamber.com/storage/virtualtours/December2019/7Dppg4o91HybqAn6DLYX.jpg)

##### PS Room

![Waiting room](https://dhakachamber.com/storage/virtualtours/December2019/ki6k0B5V731vl8cMFFdm.jpg)

##### Waiting room

![SVP room](https://dhakachamber.com/storage/virtualtours/December2019/tTUM8HL8OzFbqQ9XRuWY.jpg)

##### SVP room

![VP room](https://dhakachamber.com/storage/virtualtours/December2019/3Af1xoQMYREiGChalsMX.jpg)

##### VP room

![Waiting room](https://dhakachamber.com/storage/virtualtours/December2019/mwVOz7mM05D25wzKDmA1.jpg)

##### Waiting room

![VIP lounge](https://dhakachamber.com/storage/virtualtours/December2019/SReK43OYLwfXVBxHxqLo.jpg)

##### VIP lounge

[Previous](#carouselExampleSlidesOnly) [Next](#carouselExampleSlidesOnly)