---
source: "Dhaka Chamber of Commerce & Industry (DCCI)"
tier: 1
category: "Chamber"
url: "https://dhakachamber.com/media/news/dcci-s-initial-reaction-to-the-proposed-national-budget-2026-27"
title: "DCCI ::  News"
scraped_at: "2026-07-02"
---

# News

## DCCI’s initial reaction to the proposed national budget 2026-27

![](https://www.dhakachamber.com/storage/posts/June2026/ZKqSEajipxQ7ydLJ6qGa.jpg)

Dhaka Chamber of Commerce & Industry (DCCI) President Taskeen Ahmed stated that the proposed national budget for FY2026-27 can be considered as business and investment friendly. However, he emphasized that its actual success will depend on achieving the ambitious revenue targets and ensuring the effective implementation of the announced reforms. Dhaka Chamber President made this remark during DCCI’s initial reaction on the proposed National Budget 2026-27 held on June 11, 2026 at the DCCI Auditorium.

Budget Structure and ADP: The size of the proposed national budget for FY2026-27 is BDT 9,38,000 crore, representing a 19.04% increase over the previous fiscal year. The aimed revenue growth of 30.34% is highly challenging under the current economic circumstances. Moreover, reliance on borrowing to finance the budget deficit may not be favorable for the recovery of the banking sector and the flow of credit to private-sector investment. Nevertheless, the target of reducing operational expenditure appears positive.

The proposed Annual Development Programme (ADP) of BDT 3,00,000 crore, which is 30% higher than that of the previous year, is encouraging. However, the current fiscal year's implementation rate of only 36.19% reflects weak execution capacity. DCCI believes that emphasis should be placed not only on larger budgetary allocations and ADP size but also on ensuring effective implementation.

Tax Management: The provision allowing withholding tax to be treated as advance tax fulfills a longstanding demand of the business community. The reduction of withholding tax on industrial raw materials to 4%, the 0.5% withholding tax on 60 essential commodities, advance announcement of a five-year tax structure and tax incentives for the healthcare, renewable energy, and electric vehicle sectors are commendable measures.

DCCI welcomes the government's decision to broaden the tax base without increasing VAT rates, as well as the provision for quarterly online VAT return submission. However, keeping the tax-free income threshold unchanged despite persistent inflation and setting the highest personal income tax rate at 35% are disappointing. DCCI urges the government to raise the tax-free income threshold to BDT 500,000. The reduction of customs duties on the import of POS machines and the exemption of advance tax on such imports are considered landmark initiatives to promote cashless transactions.

CMSME Sector: The allocation of BDT 5,000 crore under the Bangladesh Bank’s BDT 60,000 crore stimulus package for the CMSME sector is highly appreciated. Exempting turnover tax for SME entrepreneurs with annual turnover up to BDT 50 Lac, and up to BDT 70 Lac for women and persons with disabilities, along with the introduction of e-loans of up to BDT 50,000, are commendable initiatives. DCCI believes that the introduction of a flat turnover tax rate for small businesses and a separate VAT return form will simplify tax compliance and administration.

Industry, Investment and Ease of Doing Business: The reduction of taxes on electric vehicles, mobile phones, refrigerators, air conditioners, and technology products will create new opportunities for domestic industrial investment. The initiative to establish Free Trade Zones is expected to promote trade and investment.

The customs duty and VAT benefits for the local production of electric buses, trucks, and e-bikes, as well as incentives for vendor industries, are praiseworthy. Mandatory implementation of a single-window service system, issuance of work permits within seven days, investor visas within ten days, reduction of withholding tax on interest payments for foreign loans from 20% to 10%, and withdrawal of provisions that disallow expenses due to withholding tax deduction issues are expected to significantly improve the overall investment climate.

Power and Energy: The VAT exemption on electric vehicles until 2030, reduction of advance income tax at the registration stage, and zero-duty facilities on the import of EV charging network equipment are landmark initiatives.

However, DCCI believes that the measures proposed for gas exploration and well drilling are insufficient compared to the country's growing energy demand. Without a clearly defined pricing framework for imported energy, short-term subsidies may encourage inefficiency rather than investment. DCCI therefore calls for the formulation of a long-term energy pricing framework through consultation with relevant stakeholders.

DCCI Senior Vice President Razeev H. Chowdhury, Vice President Md. Salem Sulaiman, and other members of the Board of Directors were also present during the event.

Published on: 2026-06-11

### ABOUT US

-   [Board of Directors](https://dhakachamber.com/board-of-directors)
-   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
-   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)

### USEFUL LINKS

-   [DBI College](http://www.dbicollege.edu.bd)
-   [DCCI Business Institute](http://dcci-dbi.edu.bd)
-   [BUILD](http://www.buildbd.org)
-   [BIAC](https://www.biac.org.bd)
-   [ICCB](https://iccbangladesh.org.bd)

### MEMBERSHIP

-   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
-   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
-   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
-   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
-   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
-   [Become a Member](https://membership.dhakachamber.com/register)
-   [Member Login](https://membership.dhakachamber.com)
-   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
-   [Member Query](https://dhakachamber.com/member-query)
-   [Hot Line](https://dhakachamber.com/hot_line)

### MEDIA

-   [Chamber News](https://dhakachamber.com/media/news)
-   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
-   [Photo Gallery](https://dhakachamber.com/albums)
-   [Video Gallery](https://dhakachamber.com/videos)

### DOWNLOAD

-   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
-   [DCCI Reviews](https://dhakachamber.com/publications/reviews)
-   [DCCI Publications](https://dhakachamber.com/publications)
-   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
-   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)

×

-   [Home(current)](https://dhakachamber.com)
-   [About us](#)
    -   [Brief About DCCI](https://dhakachamber.com/about-us)
    -   [International Affiliations](https://dhakachamber.com/international-affiliations)
    -   [DCCI Founders](https://dhakachamber.com/dcci-founders)
    -   [Former Presidents](https://dhakachamber.com/dcci-former-presidents)
    -   [Former Senior Vice Presidents](https://dhakachamber.com/dcci-former-senior-vice-presidents)
    -   [Former Vice Presidents](https://dhakachamber.com/dcci-former-vice-presidents)
    -   [Achievements & Awards](https://dhakachamber.com/achievements-awards)
    -   [Policy and Objectives](https://dhakachamber.com/quality-policy-and-objectives)
-   [Organizational Information](#)
    -   [Board of Directors](https://dhakachamber.com/board-of-directors)
    -   [Previous Board of Directors](https://dhakachamber.com/dcci-allpastmanagement)
    -   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
    -   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)
-   [President](https://dhakachamber.com/president)
-   [Membership](#)
    -   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
    -   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
    -   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
    -   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
    -   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
    -   [Become a Member](https://membership.dhakachamber.com/register)
    -   [Member Login](https://membership.dhakachamber.com)
    -   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
    -   [Member Query](https://dhakachamber.com/member-query)
    -   [Hot Line](https://dhakachamber.com/hot_line)
-   [Projects](https://dhakachamber.com/project-activities)
-   [Seminar](https://dhakachamber.com/media/seminar)
-   [Publications](#)
    -   [DCCI Research Service](https://dhakachamber.com/pdf_viewer/storage/2024/circular/DCCI%20Research%20Service.pdf)
    -   [Research Guideline](https://dhakachamber.com/pdf_viewer/storage/2024/circular/Research%20Guideline.pdf)
    -   [DCCI Journal (DJBEP)](https://journal.dhakachamber.com/)
    -   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
    -   [DCCI Review](https://dhakachamber.com/publications/reviews)
    -   [DCCI Publications](https://dhakachamber.com/publications)
    -   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
    -   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)
    -   [Introducing DCCI 2023](https://www.dhakachamber.com/storage/print_media/2023/07/Introducing%202023.pdf)
-   [Media](#)
    -   [Chamber News](https://dhakachamber.com/media/news)
    -   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
    -   [Photo Gallery](https://dhakachamber.com/albums)
    -   [Video Gallery](https://dhakachamber.com/videos)
    -   [Fairs & Exhibitions](https://www.dhakachamber.com/storage/2026/03/dccifair.pdf)
-   [Policy](#)
    -   [Export Policy](https://www.dhakachamber.com/storage/policy/3VFoMxkr6Z3EZdC8wz7YHfrIBfPP5N0Y6n7eEEFJ.pdf)
    -   [Import Policy](https://www.dhakachamber.com/storage/policy/b6uhXGhpdl30N68gl3Yg9mV5P6vGIPAjquqTu35f.pdf)
    -   [Industry Policy](https://www.dhakachamber.com/storage/policy/kpHRSdbYmY90O7wcyYmkZTSvumKEXfz5uwPTlOn5.pdf)
    -   [ICT Policy](https://www.dhakachamber.com/storage/policy/abTlbODgI2I4Aqbrix5Cs2DHvFD5lW3OwDmfKXmH.pdf)
-   [BILATERAL TRADE](#)
    -   [Bilateral Trade](https://dhakachamber.com/bilateral-trade)
    -   [Africa](https://dhakachamber.com/bilateral-trade/africa)
    -   [America](https://dhakachamber.com/bilateral-trade/america)
    -   [Asian](https://dhakachamber.com/bilateral-trade/asian)
    -   [ASEAN](https://dhakachamber.com/bilateral-trade/asean)
    -   [SAARC](https://dhakachamber.com/bilateral-trade/saarc)
    -   [Middle East](https://dhakachamber.com/bilateral-trade/middle-east)
    -   [European Union](https://dhakachamber.com/bilateral-trade/european-union)
-   [About Bangladesh](#)
    -   [General Information](https://dhakachamber.com/bangladesh-country-profile)
    -   [Business Opportunities in Bangladesh](https://dhakachamber.com/trade-and-business-opportunities-in-bangladesh)
    -   [Useful Links](https://dhakachamber.com/useful-links)
-   [B2B Directory](#)
    -   [B2B Directory](https://dhakachamber.com/b2b)
    -   [B2B Member Login](https://dhakachamber.com/login)
    -   [B2B Registration](https://dhakachamber.com/b2b-reg)