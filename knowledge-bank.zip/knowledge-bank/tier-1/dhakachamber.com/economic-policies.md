---
source: "Dhaka Chamber of Commerce & Industry (DCCI)"
tier: 1
category: "Chamber"
url: "https://dhakachamber.com/publications/economic-policies"
title: "DCCI ::  DCCI Economic Policy"
scraped_at: "2026-07-02"
---

# DCCI Economic Policy

#### [Access to Finance for SMEs: Problems and Remedies](https://dhakachamber.com/pdf_viewer/storage/economic-policies/June2019/ehRW3xuMtCZyhWRxRkya.pdf)

#### [Anti-Dumping and Countervailing Duty Measures](https://dhakachamber.com/pdf_viewer/storage/economic-policies/June2019/yAEivFSO3mQbvIpWtx2w.pdf)

#### [Assessing Appropriate Technology for SMEs](https://dhakachamber.com/pdf_viewer/storage/economic-policies/June2019/40Le5bu82q2auqmNbMaN.pdf)

#### [Anti-monopoly Competition and Anti-trust Policies](https://dhakachamber.com/pdf_viewer/storage/economic-policies/June2019/wDIhvX8Kg8KCoJlR83iC.pdf)

#### [A High Value Added and Export Oriented Business Sector: Ready Made Garments (RMG)](https://dhakachamber.com/pdf_viewer/storage/economic-policies/June2019/re993euQEwXItlBe8M2c.pdf)

#### [Benchmarking of Regional SME Policies: Identification of Policy Intervention Areas for Bangladesh](https://dhakachamber.com/pdf_viewer/storage/economic-policies/June2019/qjwxRaiBE0niQVMpGRWa.pdf)

#### [Business Organization Laws](https://dhakachamber.com/pdf_viewer/storage/economic-policies/June2019/kYgVPIfpxKNcMJK1kA43.pdf)

#### [Computer Software and Database](https://dhakachamber.com/pdf_viewer/storage/economic-policies/June2019/S2M3twQ0LT2otDoBsfFd.pdf)

#### [Consumer Protection Laws](https://dhakachamber.com/pdf_viewer/storage/economic-policies/June2019/vQd5KwK6TZrXp9pkPQFq.pdf)

#### [Cost of Doing Business in Bangladesh](https://dhakachamber.com/pdf_viewer/storage/economic-policies/June2019/aP436ntUM6CBR6Gg7G5r.pdf)

#### [Copyright, Trademark and Patent Protection](https://dhakachamber.com/pdf_viewer/storage/economic-policies/June2019/AsranlCXTF6eOo9ATPHo.pdf)

#### [Development of High-Value-Added and Export Oriented Business Sector: Leather and Leather Goods](https://dhakachamber.com/pdf_viewer/storage/economic-policies/June2019/uV4IyqgMlu3XOwavQMkZ.pdf)

#### [Export Diversification Tools](https://dhakachamber.com/pdf_viewer/storage/economic-policies/June2019/lAu4TPVlwt7faIpVEhd6.pdf)

#### [E-Commerce a Business Link](https://dhakachamber.com/pdf_viewer/storage/economic-policies/June2019/yFWUe2Lhv4STE1SLp4CE.pdf)

#### [Entrepreneurship Development through Educational Reform](https://dhakachamber.com/pdf_viewer/storage/economic-policies/June2019/u8abgleE2uRWsNtQOO1o.pdf)

#### [Expansion and Diversification of Export: Major Impediments and Limitations](https://dhakachamber.com/pdf_viewer/storage/economic-policies/June2019/O7vKF5DnbPEdJzl71jRJ.pdf)

#### [Financial and Investment Services in a Changing Environment](https://dhakachamber.com/pdf_viewer/storage/economic-policies/June2019/lsqkpX1WD6HxHze48bgg.pdf)

#### [Foreign Investment Protection Policies and Anti-Expropriation Measures](https://dhakachamber.com/pdf_viewer/storage/economic-policies/June2019/egFlZEY9c2deZz7MCtyI.pdf)

#### [High-Value -Added and Export-Oriented Business Sector: Agro-Based Industries](https://dhakachamber.com/pdf_viewer/storage/economic-policies/June2019/UV68Vmg68YZbtewmqArT.pdf)

#### [Impact of Globalization in the Context of Bangladesh](https://dhakachamber.com/pdf_viewer/storage/economic-policies/June2019/sXfHEYhjO0sd4F2wGObK.pdf)

#### [Improving Access for Bangladesh in Global Markets](https://dhakachamber.com/pdf_viewer/storage/economic-policies/June2019/fULzRMlWtBXSE8zvBhzt.pdf)

#### [Institutionalization of Corporate Governance in Bangladesh](https://dhakachamber.com/pdf_viewer/storage/economic-policies/June2019/UUa8RxPej7DoOHOSGriS.pdf)

#### [Labor Laws](https://dhakachamber.com/pdf_viewer/storage/economic-policies/June2019/iLSH9Jy6yejbMIHv4KHH.pdf)

#### [Light Engineering & Electronics Enterprise in Bangladesh](https://dhakachamber.com/pdf_viewer/storage/economic-policies/June2019/IsJ9j0cjbxnDr7Y1PUJo.pdf)

#### [Privatisation Policies](https://dhakachamber.com/pdf_viewer/storage/economic-policies/June2019/IPlw5K2Tyos3Jlqr6gOu.pdf)

#### [Public Procurement](https://dhakachamber.com/pdf_viewer/storage/economic-policies/June2019/Ktw7qQlRvsqlruk0nmZi.pdf)

#### [Policy Towards Investment and Industrialization](https://dhakachamber.com/pdf_viewer/storage/economic-policies/June2019/wJ6vgwZXwTgGl43svOgX.pdf)

#### [Political Decision and Implementation: Effect on Economic Development](https://dhakachamber.com/pdf_viewer/storage/economic-policies/June2019/nKqEk2F0D8xpYRX4VQyZ.pdf)

#### [Relaxation of Controls on Foreign Exchange](https://dhakachamber.com/pdf_viewer/storage/economic-policies/June2019/Iv3wfBvkTNKW5Anic686.pdf)

#### [Reform of Financial Policies for Economic Development](https://dhakachamber.com/pdf_viewer/storage/economic-policies/June2019/e5Dyq2hhzpm74ITkO61U.pdf)

#### [Reforms for Institutional Framework of Business Development Services to Enterprises](https://dhakachamber.com/pdf_viewer/storage/economic-policies/June2019/MjYmdSE06gLIgohRYusF.pdf)

#### [Strengthening Democratic Governance](https://dhakachamber.com/pdf_viewer/storage/economic-policies/June2019/ougP0LvuNCBFN8CXfZ5J.pdf)

#### [Sample Survey on Status of Women Entrepreneurs In Bangladesh](https://dhakachamber.com/pdf_viewer/storage/economic-policies/June2019/ruxuEeIhiPERi1zjcZCe.pdf)

#### [State of Corporate Governance in Bangladesh: Analysis of Private, Financial and State Owned Enterprises](https://dhakachamber.com/pdf_viewer/storage/economic-policies/June2019/vMPpR1GnQRrfD0TK76Zt.pdf)

#### [Transportation (Air, Water, Land) and Policy Related to Infrastructure and Utilities](https://dhakachamber.com/pdf_viewer/storage/economic-policies/June2019/f4gcMaeETNgNXapkm8rS.pdf)

#### [Women Entrepreneurs in Bangladesh](https://dhakachamber.com/pdf_viewer/storage/economic-policies/June2019/f9OaH85GRETDWfoUJ2Rf.pdf)

#### [WTO Agreement on Agriculture: Potentials of Agro-processing Products of Bangladesh](https://dhakachamber.com/pdf_viewer/storage/economic-policies/June2019/iSkZqpfckbRDXpqyXKrm.pdf)

### ABOUT US

-   [Board of Directors](https://dhakachamber.com/board-of-directors)
-   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
-   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)

### USEFUL LINKS

-   [DBI College](http://www.dbicollege.edu.bd)
-   [DCCI Business Institute](http://dcci-dbi.edu.bd)
-   [BUILD](http://www.buildbd.org)
-   [BIAC](https://www.biac.org.bd)
-   [ICCB](https://iccbangladesh.org.bd)

### MEMBERSHIP

-   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
-   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
-   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
-   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
-   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
-   [Become a Member](https://membership.dhakachamber.com/register)
-   [Member Login](https://membership.dhakachamber.com)
-   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
-   [Member Query](https://dhakachamber.com/member-query)
-   [Hot Line](https://dhakachamber.com/hot_line)

### MEDIA

-   [Chamber News](https://dhakachamber.com/media/news)
-   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
-   [Photo Gallery](https://dhakachamber.com/albums)
-   [Video Gallery](https://dhakachamber.com/videos)

### DOWNLOAD

-   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
-   [DCCI Reviews](https://dhakachamber.com/publications/reviews)
-   [DCCI Publications](https://dhakachamber.com/publications)
-   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
-   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)

×

-   [Home(current)](https://dhakachamber.com)
-   [About us](#)
    -   [Brief About DCCI](https://dhakachamber.com/about-us)
    -   [International Affiliations](https://dhakachamber.com/international-affiliations)
    -   [DCCI Founders](https://dhakachamber.com/dcci-founders)
    -   [Former Presidents](https://dhakachamber.com/dcci-former-presidents)
    -   [Former Senior Vice Presidents](https://dhakachamber.com/dcci-former-senior-vice-presidents)
    -   [Former Vice Presidents](https://dhakachamber.com/dcci-former-vice-presidents)
    -   [Achievements & Awards](https://dhakachamber.com/achievements-awards)
    -   [Policy and Objectives](https://dhakachamber.com/quality-policy-and-objectives)
-   [Organizational Information](#)
    -   [Board of Directors](https://dhakachamber.com/board-of-directors)
    -   [Previous Board of Directors](https://dhakachamber.com/dcci-allpastmanagement)
    -   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
    -   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)
-   [President](https://dhakachamber.com/president)
-   [Membership](#)
    -   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
    -   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
    -   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
    -   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
    -   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
    -   [Become a Member](https://membership.dhakachamber.com/register)
    -   [Member Login](https://membership.dhakachamber.com)
    -   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
    -   [Member Query](https://dhakachamber.com/member-query)
    -   [Hot Line](https://dhakachamber.com/hot_line)
-   [Projects](https://dhakachamber.com/project-activities)
-   [Seminar](https://dhakachamber.com/media/seminar)
-   [Publications](#)
    -   [DCCI Research Service](https://dhakachamber.com/pdf_viewer/storage/2024/circular/DCCI%20Research%20Service.pdf)
    -   [Research Guideline](https://dhakachamber.com/pdf_viewer/storage/2024/circular/Research%20Guideline.pdf)
    -   [DCCI Journal (DJBEP)](https://journal.dhakachamber.com/)
    -   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
    -   [DCCI Review](https://dhakachamber.com/publications/reviews)
    -   [DCCI Publications](https://dhakachamber.com/publications)
    -   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
    -   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)
    -   [Introducing DCCI 2023](https://www.dhakachamber.com/storage/print_media/2023/07/Introducing%202023.pdf)
-   [Media](#)
    -   [Chamber News](https://dhakachamber.com/media/news)
    -   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
    -   [Photo Gallery](https://dhakachamber.com/albums)
    -   [Video Gallery](https://dhakachamber.com/videos)
    -   [Fairs & Exhibitions](https://www.dhakachamber.com/storage/2026/03/dccifair.pdf)
-   [Policy](#)
    -   [Export Policy](https://www.dhakachamber.com/storage/policy/3VFoMxkr6Z3EZdC8wz7YHfrIBfPP5N0Y6n7eEEFJ.pdf)
    -   [Import Policy](https://www.dhakachamber.com/storage/policy/b6uhXGhpdl30N68gl3Yg9mV5P6vGIPAjquqTu35f.pdf)
    -   [Industry Policy](https://www.dhakachamber.com/storage/policy/kpHRSdbYmY90O7wcyYmkZTSvumKEXfz5uwPTlOn5.pdf)
    -   [ICT Policy](https://www.dhakachamber.com/storage/policy/abTlbODgI2I4Aqbrix5Cs2DHvFD5lW3OwDmfKXmH.pdf)
-   [BILATERAL TRADE](#)
    -   [Bilateral Trade](https://dhakachamber.com/bilateral-trade)
    -   [Africa](https://dhakachamber.com/bilateral-trade/africa)
    -   [America](https://dhakachamber.com/bilateral-trade/america)
    -   [Asian](https://dhakachamber.com/bilateral-trade/asian)
    -   [ASEAN](https://dhakachamber.com/bilateral-trade/asean)
    -   [SAARC](https://dhakachamber.com/bilateral-trade/saarc)
    -   [Middle East](https://dhakachamber.com/bilateral-trade/middle-east)
    -   [European Union](https://dhakachamber.com/bilateral-trade/european-union)
-   [About Bangladesh](#)
    -   [General Information](https://dhakachamber.com/bangladesh-country-profile)
    -   [Business Opportunities in Bangladesh](https://dhakachamber.com/trade-and-business-opportunities-in-bangladesh)
    -   [Useful Links](https://dhakachamber.com/useful-links)
-   [B2B Directory](#)
    -   [B2B Directory](https://dhakachamber.com/b2b)
    -   [B2B Member Login](https://dhakachamber.com/login)
    -   [B2B Registration](https://dhakachamber.com/b2b-reg)