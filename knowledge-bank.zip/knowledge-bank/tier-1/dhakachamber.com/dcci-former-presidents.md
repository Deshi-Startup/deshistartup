---
source: "Dhaka Chamber of Commerce & Industry (DCCI)"
tier: 1
category: "Chamber"
url: "https://dhakachamber.com/dcci-former-presidents"
title: "DCCI ::  Former Presidents"
scraped_at: "2026-07-02"
---

# Former Presidents

![](https://dhakachamber.com/storage/dcci-former-presidents/May2019/QPubnlICKWhGvu9hIgpO.jpg)

### Late Sakhawat Hossain

(1959-60 and 1963-1964)

![](https://dhakachamber.com/storage/dcci-former-presidents/May2019/zUKy7aIaXzcUq4KLDger.jpg)

### Late Abu Nasir Ahmed

(1960-61)

![](https://dhakachamber.com/storage/dcci-former-presidents/May2019/DMXo0Cme5czxFnLBuZz7.jpg)

### Late Yahya Ahmed Bawany

(1961-62)

![](https://dhakachamber.com/storage/dcci-former-presidents/May2019/6RGdoHPyzVawCINCM0di.jpg)

### Late Nurul Huda

(1962)

![](https://dhakachamber.com/storage/dcci-former-presidents/September2020/Y7ewOcrH1zxTVLlpWmvF.png)

### Late Mohd. Ayub

(1962-63)

![](https://dhakachamber.com/storage/dcci-former-presidents/January2020/h8Y6GRDRE7i3Po36zbpl.png)

### Late Sakhawat Hossain

(1963-64)

![](https://dhakachamber.com/storage/dcci-former-presidents/January2020/hhcjoioPVvLnWnsOnL1M.png)

### Late Ahmed Hossain

(1964-67)

![](https://dhakachamber.com/storage/dcci-former-presidents/January2020/Rf21wswQD0o8kh5AMBe3.png)

### Late Q.J. Ahmed

(1967)

![](https://dhakachamber.com/storage/dcci-former-presidents/May2019/yaXIMkQBKMyPHFD5p6jN.jpg)

### Late A Qasem

(1967-68)

![](https://dhakachamber.com/storage/dcci-former-presidents/January2020/ZNKni5Xfhj2jq8JXlOxN.png)

### Late Akhlaque Ahmed

(1968-69)

![](https://dhakachamber.com/storage/dcci-former-presidents/January2020/4PWlUMBQXn8GgTMfGYBK.JPG)

### Late Matiur Rahman

(1969-72)

![](https://dhakachamber.com/storage/dcci-former-presidents/May2019/vy7Zm4xykS2UWWfOI1X9.jpg)

### Late K.A. Sattar

(1972-76)

![](https://dhakachamber.com/storage/dcci-former-presidents/January2020/vUXoFlibtMzS0OcFsSXB.jpg)

### Late Mirza Golam Hafiz

(1976)

![](https://dhakachamber.com/storage/dcci-former-presidents/May2019/f5csx4SMEdEBU1I0jSDh.jpg)

### Chowdhury Tanbir Ahmed Siddiky

(1976-79)

![](https://dhakachamber.com/storage/dcci-former-presidents/May2019/uFQMz4bqQ8aG7G5soowI.jpg)

### Late Nuruddin Ahmed

(1979-82)

![](https://dhakachamber.com/storage/dcci-former-presidents/May2019/cl3Nt6pdnRi8jqkP6e4b.jpg)

### M. A. Sattar

(1982-84)

![](https://dhakachamber.com/storage/dcci-former-presidents/May2019/BrZJO6ItAsbzhgHPYQHo.jpg)

### Late M Yunus, FCA

(1984-85 & 1992-93)

![](https://dhakachamber.com/storage/dcci-former-presidents/May2019/9RcNxl0ZxZlmVhR372bB.jpg)

### Mahbubur Rahman

(1985-86 & 1991-92)

![](https://dhakachamber.com/storage/dcci-former-presidents/May2019/NcK9VGRRVAuyH8xWWvB6.jpg)

### Late A.S. Mahmud

(1986-90)

![](https://dhakachamber.com/storage/dcci-former-presidents/May2019/GKGaPETDIaqhoHL1lKTu.jpg)

### Late A.T.M. Waziullah

(1993-94)

![](https://dhakachamber.com/storage/dcci-former-presidents/May2019/F6D2gZyzzeXG5V3dHSj8.jpg)

### Late. A. Rob Chowdhury

(1994-95)

![](https://dhakachamber.com/storage/dcci-former-presidents/May2019/TcyHNEDj3suWjFCvhvXW.jpg)

### Late R. Maksud Khan

(1995 and 1998)

![](https://dhakachamber.com/storage/dcci-former-presidents/May2019/zSTNMPSO01fgUoCc20hB.jpg)

### Late Ali Hossain (Hasan)

(1996)

![](https://dhakachamber.com/storage/dcci-former-presidents/May2019/OKKE38K3EL83GaXH1qlH.jpg)

### A.S.M. Quasem

(1997)

![](https://dhakachamber.com/storage/dcci-former-presidents/May2019/zT1VxwgQLlDJTTTHhh5c.jpg)

### M.H. Rahman

(1999)

![](https://dhakachamber.com/storage/dcci-former-presidents/May2019/D1ZCjvgi7RGeumX7VkbK.jpg)

### Aftab-ul Islam

(2000)

![](https://dhakachamber.com/storage/dcci-former-presidents/May2019/br5oormz6GjlYfkIGS2f.jpg)

### Benajir Ahmed

(2001)

![](https://dhakachamber.com/storage/dcci-former-presidents/May2019/q1vW1jsnHq9hoYZ2D8Se.jpg)

### Matiur Rahman

(2002-03)

![](https://dhakachamber.com/storage/dcci-former-presidents/May2019/HMnfu2L2oOhzqyuzG7sx.jpg)

### Fazle R.M. Hasan, FCA

(2004)

![](https://dhakachamber.com/storage/dcci-former-presidents/May2019/KKqWXq8B4uvnsnTa6oc9.jpg)

### Sayeeful Islam

(2005)

![](https://dhakachamber.com/storage/dcci-former-presidents/May2019/GjJZMvGUthr4s5Se4jXU.jpg)

### M A Momen

(2006)

![](https://dhakachamber.com/storage/dcci-former-presidents/May2019/afiCSvkXR2qY4odjexTa.jpg)

### Zafar Osman

(2009)

![](https://dhakachamber.com/storage/dcci-former-presidents/May2019/nel5AVyPdrH1rQyCB0EL.jpg)

### Asif Ibrahim

(2011-2012)

![](https://dhakachamber.com/storage/dcci-former-presidents/May2019/8YxFbCooj5l8rP1iFEwl.jpg)

### Md. Sabur Khan

(2013)

![](https://dhakachamber.com/storage/dcci-former-presidents/May2019/zdMBdhc8euLmajqjvdzA.jpg)

### Late Mohammad Shahjahan Khan

(2014)

![](https://dhakachamber.com/storage/dcci-former-presidents/May2019/XlxzMAH3mU6LX8YZXeTO.jpg)

### Hossain Khaled

(2007-2008 and 2015-2016)

![](https://dhakachamber.com/storage/dcci-former-presidents/May2019/1K2wulArIg6V2u9478OI.jpg)

### Abul Kasem Khan

(2010 and 2017-2018)

![](https://dhakachamber.com/storage/dcci-former-presidents/December2019/VX6G7bfXKeOPEmqwWy1w.jpg)

### Osama Taseer

(2019)

![](https://dhakachamber.com/storage/dcci-former-presidents/December2020/7YhupZ0V1InEjKpwPIGD.jpg)

### Shams Mahmud

(2020)

![](https://dhakachamber.com/storage/dcci-former-presidents/December2022/gjJ9iRjmI15jzfPYI2sM.jpeg)

### Rizwan Rahman

(2021-2022)

![](https://dhakachamber.com/storage/dcci-former-presidents/December2023/8LTyKkh7Fm88UOOjrOeE.JPG)

### Barrister Md. Sameer Sattar

(2023)

![](https://dhakachamber.com/storage/dcci-former-presidents/December2024/zAAW9GUtv9kGBHoJAKrS.jpg)

### Ashraf Ahmed

(2024)

### ABOUT US

-   [Board of Directors](https://dhakachamber.com/board-of-directors)
-   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
-   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)

### USEFUL LINKS

-   [DBI College](http://www.dbicollege.edu.bd)
-   [DCCI Business Institute](http://dcci-dbi.edu.bd)
-   [BUILD](http://www.buildbd.org)
-   [BIAC](https://www.biac.org.bd)
-   [ICCB](https://iccbangladesh.org.bd)

### MEMBERSHIP

-   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
-   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
-   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
-   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
-   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
-   [Become a Member](https://membership.dhakachamber.com/register)
-   [Member Login](https://membership.dhakachamber.com)
-   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
-   [Member Query](https://dhakachamber.com/member-query)
-   [Hot Line](https://dhakachamber.com/hot_line)

### MEDIA

-   [Chamber News](https://dhakachamber.com/media/news)
-   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
-   [Photo Gallery](https://dhakachamber.com/albums)
-   [Video Gallery](https://dhakachamber.com/videos)

### DOWNLOAD

-   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
-   [DCCI Reviews](https://dhakachamber.com/publications/reviews)
-   [DCCI Publications](https://dhakachamber.com/publications)
-   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
-   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)

×

-   [Home(current)](https://dhakachamber.com)
-   [About us](#)
    -   [Brief About DCCI](https://dhakachamber.com/about-us)
    -   [International Affiliations](https://dhakachamber.com/international-affiliations)
    -   [DCCI Founders](https://dhakachamber.com/dcci-founders)
    -   [Former Presidents](https://dhakachamber.com/dcci-former-presidents)
    -   [Former Senior Vice Presidents](https://dhakachamber.com/dcci-former-senior-vice-presidents)
    -   [Former Vice Presidents](https://dhakachamber.com/dcci-former-vice-presidents)
    -   [Achievements & Awards](https://dhakachamber.com/achievements-awards)
    -   [Policy and Objectives](https://dhakachamber.com/quality-policy-and-objectives)
-   [Organizational Information](#)
    -   [Board of Directors](https://dhakachamber.com/board-of-directors)
    -   [Previous Board of Directors](https://dhakachamber.com/dcci-allpastmanagement)
    -   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
    -   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)
-   [President](https://dhakachamber.com/president)
-   [Membership](#)
    -   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
    -   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
    -   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
    -   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
    -   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
    -   [Become a Member](https://membership.dhakachamber.com/register)
    -   [Member Login](https://membership.dhakachamber.com)
    -   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
    -   [Member Query](https://dhakachamber.com/member-query)
    -   [Hot Line](https://dhakachamber.com/hot_line)
-   [Projects](https://dhakachamber.com/project-activities)
-   [Seminar](https://dhakachamber.com/media/seminar)
-   [Publications](#)
    -   [DCCI Research Service](https://dhakachamber.com/pdf_viewer/storage/2024/circular/DCCI%20Research%20Service.pdf)
    -   [Research Guideline](https://dhakachamber.com/pdf_viewer/storage/2024/circular/Research%20Guideline.pdf)
    -   [DCCI Journal (DJBEP)](https://journal.dhakachamber.com/)
    -   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
    -   [DCCI Review](https://dhakachamber.com/publications/reviews)
    -   [DCCI Publications](https://dhakachamber.com/publications)
    -   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
    -   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)
    -   [Introducing DCCI 2023](https://www.dhakachamber.com/storage/print_media/2023/07/Introducing%202023.pdf)
-   [Media](#)
    -   [Chamber News](https://dhakachamber.com/media/news)
    -   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
    -   [Photo Gallery](https://dhakachamber.com/albums)
    -   [Video Gallery](https://dhakachamber.com/videos)
    -   [Fairs & Exhibitions](https://www.dhakachamber.com/storage/2026/03/dccifair.pdf)
-   [Policy](#)
    -   [Export Policy](https://www.dhakachamber.com/storage/policy/3VFoMxkr6Z3EZdC8wz7YHfrIBfPP5N0Y6n7eEEFJ.pdf)
    -   [Import Policy](https://www.dhakachamber.com/storage/policy/b6uhXGhpdl30N68gl3Yg9mV5P6vGIPAjquqTu35f.pdf)
    -   [Industry Policy](https://www.dhakachamber.com/storage/policy/kpHRSdbYmY90O7wcyYmkZTSvumKEXfz5uwPTlOn5.pdf)
    -   [ICT Policy](https://www.dhakachamber.com/storage/policy/abTlbODgI2I4Aqbrix5Cs2DHvFD5lW3OwDmfKXmH.pdf)
-   [BILATERAL TRADE](#)
    -   [Bilateral Trade](https://dhakachamber.com/bilateral-trade)
    -   [Africa](https://dhakachamber.com/bilateral-trade/africa)
    -   [America](https://dhakachamber.com/bilateral-trade/america)
    -   [Asian](https://dhakachamber.com/bilateral-trade/asian)
    -   [ASEAN](https://dhakachamber.com/bilateral-trade/asean)
    -   [SAARC](https://dhakachamber.com/bilateral-trade/saarc)
    -   [Middle East](https://dhakachamber.com/bilateral-trade/middle-east)
    -   [European Union](https://dhakachamber.com/bilateral-trade/european-union)
-   [About Bangladesh](#)
    -   [General Information](https://dhakachamber.com/bangladesh-country-profile)
    -   [Business Opportunities in Bangladesh](https://dhakachamber.com/trade-and-business-opportunities-in-bangladesh)
    -   [Useful Links](https://dhakachamber.com/useful-links)
-   [B2B Directory](#)
    -   [B2B Directory](https://dhakachamber.com/b2b)
    -   [B2B Member Login](https://dhakachamber.com/login)
    -   [B2B Registration](https://dhakachamber.com/b2b-reg)