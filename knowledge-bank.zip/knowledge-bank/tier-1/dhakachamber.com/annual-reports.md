---
source: "Dhaka Chamber of Commerce & Industry (DCCI)"
tier: 1
category: "Chamber"
url: "https://dhakachamber.com/publications/annual_reports"
title: "DCCI ::  DCCI Annual Reports"
scraped_at: "2026-07-02"
---

# DCCI Annual Reports

[![Annual Report-2025](https://dhakachamber.com/storage/annual-reports/December2025/R6sBOvwtFTxrjsVs7STt.PNG)](https://dhakachamber.com/pdf_viewer/storage/annual-reports/December2025/V9qPKP6L42f0SZgS4YVs.pdf)

#### [Annual Report-2025](https://dhakachamber.com/pdf_viewer/storage/annual-reports/December2025/V9qPKP6L42f0SZgS4YVs.pdf)

[![Annual Report-2024](https://dhakachamber.com/storage/annual-reports/December2024/MM1cjKuoM0hSGWP8QSJA.PNG)](https://dhakachamber.com/pdf_viewer/storage/annual-reports/December2024/mGX5d9ZvCX6QC4JDeCFg.pdf)

#### [Annual Report-2024](https://dhakachamber.com/pdf_viewer/storage/annual-reports/December2024/mGX5d9ZvCX6QC4JDeCFg.pdf)

[![Annual Report-2023](https://dhakachamber.com/storage/annual-reports/January2024/vSbxArNRpE24WWlbIhK7.PNG)](https://dhakachamber.com/pdf_viewer/storage/annual-reports/January2024/HjKTmKnh3coRSjjSgco5.pdf)

#### [Annual Report-2023](https://dhakachamber.com/pdf_viewer/storage/annual-reports/January2024/HjKTmKnh3coRSjjSgco5.pdf)

[![Annual Report-2022](https://dhakachamber.com/storage/annual-reports/December2022/nmHkamkLX2tPIojSrG7L.PNG)](https://dhakachamber.com/pdf_viewer/storage/annual-reports/December2022/SsJRXEHGuuGPvefyA6pE.pdf)

#### [Annual Report-2022](https://dhakachamber.com/pdf_viewer/storage/annual-reports/December2022/SsJRXEHGuuGPvefyA6pE.pdf)

[![Annual Report-2021](https://dhakachamber.com/storage/annual-reports/February2022/r0cJr6lYASuZ1nwTajtC.png)](https://dhakachamber.com/pdf_viewer/storage/annual-reports/February2022/OZmBTqBebh0lwrlfVkfd.pdf)

#### [Annual Report-2021](https://dhakachamber.com/pdf_viewer/storage/annual-reports/February2022/OZmBTqBebh0lwrlfVkfd.pdf)

[![Annual Report-2020](https://dhakachamber.com/storage/annual-reports/March2021/7SQ1s0hQMjCmNhMcFWIv.png)](https://dhakachamber.com/pdf_viewer/storage/annual-reports/March2021/0RecWYydSqhD1SQsXCSr.pdf)

#### [Annual Report-2020](https://dhakachamber.com/pdf_viewer/storage/annual-reports/March2021/0RecWYydSqhD1SQsXCSr.pdf)

[![Annual Report-2019](https://dhakachamber.com/storage/annual-reports/December2019/Y956Y3vmHQPE02VbZyLO.PNG)](https://dhakachamber.com/pdf_viewer/storage/annual-reports/December2019/Vj7BhE7oaBaQzYSrQOJN.pdf)

#### [Annual Report-2019](https://dhakachamber.com/pdf_viewer/storage/annual-reports/December2019/Vj7BhE7oaBaQzYSrQOJN.pdf)

[![Annual Report-2018](https://dhakachamber.com/storage/annual-reports/December2019/PkzRpYzO8SJTqDcanI9o.JPG)](https://dhakachamber.com/pdf_viewer/storage/annual-reports/December2019/ryigGIQUG8W63rX1u6fP.pdf)

#### [Annual Report-2018](https://dhakachamber.com/pdf_viewer/storage/annual-reports/December2019/ryigGIQUG8W63rX1u6fP.pdf)

[![Annual Report 2017](https://dhakachamber.com/storage/annual-reports/October2018/2I7KYr1r9TFoFsq6ZCYU.jpg)](https://dhakachamber.com/pdf_viewer/storage/annual-reports/October2018/ppXwIPeRt2h3OkIzbV47.pdf)

#### [Annual Report 2017](https://dhakachamber.com/pdf_viewer/storage/annual-reports/October2018/ppXwIPeRt2h3OkIzbV47.pdf)

[![Annual Report-2016](https://dhakachamber.com/storage/annual-reports/December2019/CkUKzVuKSBgBzB3CYNmW.jpg)](https://dhakachamber.com/pdf_viewer/storage/annual-reports/December2019/Fc4RDFqJg0M9YyTrSuk0.pdf)

#### [Annual Report-2016](https://dhakachamber.com/pdf_viewer/storage/annual-reports/December2019/Fc4RDFqJg0M9YyTrSuk0.pdf)

[![Annual Report-2015](https://dhakachamber.com/storage/annual-reports/May2022/MSvwzsTVElAPv00tmtv1.PNG)](https://dhakachamber.com/pdf_viewer/storage/annual-reports/May2022/GPbuSQ7znGsTGeSnzrHu.pdf)

#### [Annual Report-2015](https://dhakachamber.com/pdf_viewer/storage/annual-reports/May2022/GPbuSQ7znGsTGeSnzrHu.pdf)

[![Annual Report-2014](https://dhakachamber.com/storage/annual-reports/May2022/IGGAnDiitasQC362VhVj.PNG)](https://dhakachamber.com/pdf_viewer/storage/annual-reports/May2022/QuIL604hyHHGuZ9hihNw.pdf)

#### [Annual Report-2014](https://dhakachamber.com/pdf_viewer/storage/annual-reports/May2022/QuIL604hyHHGuZ9hihNw.pdf)

[![Annual Report 2013](https://dhakachamber.com/storage/annual-reports/October2018/xVPWCeV4gVAK6HeMMNI6.jpg)](https://dhakachamber.com/pdf_viewer/storage/annual-reports/October2018/WUTg3QZjcKICaLODUWCr.pdf)

#### [Annual Report 2013](https://dhakachamber.com/pdf_viewer/storage/annual-reports/October2018/WUTg3QZjcKICaLODUWCr.pdf)

[![Annual Report-2012](https://dhakachamber.com/storage/annual-reports/May2022/XLyV96xNGQe2RDRTy2RW.PNG)](https://dhakachamber.com/pdf_viewer/storage/annual-reports/May2022/ej8Wt0tEJQ93Io97VoFv.pdf)

#### [Annual Report-2012](https://dhakachamber.com/pdf_viewer/storage/annual-reports/May2022/ej8Wt0tEJQ93Io97VoFv.pdf)

[![Annual Report-2011](https://dhakachamber.com/storage/annual-reports/May2022/S9Em4snGPji2siQ2f0Di.PNG)](https://dhakachamber.com/pdf_viewer/storage/annual-reports/May2022/LT0lo0uEWbmvhF6Hk8OF.pdf)

#### [Annual Report-2011](https://dhakachamber.com/pdf_viewer/storage/annual-reports/May2022/LT0lo0uEWbmvhF6Hk8OF.pdf)

### ABOUT US

-   [Board of Directors](https://dhakachamber.com/board-of-directors)
-   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
-   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)

### USEFUL LINKS

-   [DBI College](http://www.dbicollege.edu.bd)
-   [DCCI Business Institute](http://dcci-dbi.edu.bd)
-   [BUILD](http://www.buildbd.org)
-   [BIAC](https://www.biac.org.bd)
-   [ICCB](https://iccbangladesh.org.bd)

### MEMBERSHIP

-   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
-   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
-   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
-   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
-   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
-   [Become a Member](https://membership.dhakachamber.com/register)
-   [Member Login](https://membership.dhakachamber.com)
-   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
-   [Member Query](https://dhakachamber.com/member-query)
-   [Hot Line](https://dhakachamber.com/hot_line)

### MEDIA

-   [Chamber News](https://dhakachamber.com/media/news)
-   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
-   [Photo Gallery](https://dhakachamber.com/albums)
-   [Video Gallery](https://dhakachamber.com/videos)

### DOWNLOAD

-   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
-   [DCCI Reviews](https://dhakachamber.com/publications/reviews)
-   [DCCI Publications](https://dhakachamber.com/publications)
-   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
-   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)

×

-   [Home(current)](https://dhakachamber.com)
-   [About us](#)
    -   [Brief About DCCI](https://dhakachamber.com/about-us)
    -   [International Affiliations](https://dhakachamber.com/international-affiliations)
    -   [DCCI Founders](https://dhakachamber.com/dcci-founders)
    -   [Former Presidents](https://dhakachamber.com/dcci-former-presidents)
    -   [Former Senior Vice Presidents](https://dhakachamber.com/dcci-former-senior-vice-presidents)
    -   [Former Vice Presidents](https://dhakachamber.com/dcci-former-vice-presidents)
    -   [Achievements & Awards](https://dhakachamber.com/achievements-awards)
    -   [Policy and Objectives](https://dhakachamber.com/quality-policy-and-objectives)
-   [Organizational Information](#)
    -   [Board of Directors](https://dhakachamber.com/board-of-directors)
    -   [Previous Board of Directors](https://dhakachamber.com/dcci-allpastmanagement)
    -   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
    -   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)
-   [President](https://dhakachamber.com/president)
-   [Membership](#)
    -   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
    -   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
    -   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
    -   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
    -   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
    -   [Become a Member](https://membership.dhakachamber.com/register)
    -   [Member Login](https://membership.dhakachamber.com)
    -   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
    -   [Member Query](https://dhakachamber.com/member-query)
    -   [Hot Line](https://dhakachamber.com/hot_line)
-   [Projects](https://dhakachamber.com/project-activities)
-   [Seminar](https://dhakachamber.com/media/seminar)
-   [Publications](#)
    -   [DCCI Research Service](https://dhakachamber.com/pdf_viewer/storage/2024/circular/DCCI%20Research%20Service.pdf)
    -   [Research Guideline](https://dhakachamber.com/pdf_viewer/storage/2024/circular/Research%20Guideline.pdf)
    -   [DCCI Journal (DJBEP)](https://journal.dhakachamber.com/)
    -   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
    -   [DCCI Review](https://dhakachamber.com/publications/reviews)
    -   [DCCI Publications](https://dhakachamber.com/publications)
    -   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
    -   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)
    -   [Introducing DCCI 2023](https://www.dhakachamber.com/storage/print_media/2023/07/Introducing%202023.pdf)
-   [Media](#)
    -   [Chamber News](https://dhakachamber.com/media/news)
    -   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
    -   [Photo Gallery](https://dhakachamber.com/albums)
    -   [Video Gallery](https://dhakachamber.com/videos)
    -   [Fairs & Exhibitions](https://www.dhakachamber.com/storage/2026/03/dccifair.pdf)
-   [Policy](#)
    -   [Export Policy](https://www.dhakachamber.com/storage/policy/3VFoMxkr6Z3EZdC8wz7YHfrIBfPP5N0Y6n7eEEFJ.pdf)
    -   [Import Policy](https://www.dhakachamber.com/storage/policy/b6uhXGhpdl30N68gl3Yg9mV5P6vGIPAjquqTu35f.pdf)
    -   [Industry Policy](https://www.dhakachamber.com/storage/policy/kpHRSdbYmY90O7wcyYmkZTSvumKEXfz5uwPTlOn5.pdf)
    -   [ICT Policy](https://www.dhakachamber.com/storage/policy/abTlbODgI2I4Aqbrix5Cs2DHvFD5lW3OwDmfKXmH.pdf)
-   [BILATERAL TRADE](#)
    -   [Bilateral Trade](https://dhakachamber.com/bilateral-trade)
    -   [Africa](https://dhakachamber.com/bilateral-trade/africa)
    -   [America](https://dhakachamber.com/bilateral-trade/america)
    -   [Asian](https://dhakachamber.com/bilateral-trade/asian)
    -   [ASEAN](https://dhakachamber.com/bilateral-trade/asean)
    -   [SAARC](https://dhakachamber.com/bilateral-trade/saarc)
    -   [Middle East](https://dhakachamber.com/bilateral-trade/middle-east)
    -   [European Union](https://dhakachamber.com/bilateral-trade/european-union)
-   [About Bangladesh](#)
    -   [General Information](https://dhakachamber.com/bangladesh-country-profile)
    -   [Business Opportunities in Bangladesh](https://dhakachamber.com/trade-and-business-opportunities-in-bangladesh)
    -   [Useful Links](https://dhakachamber.com/useful-links)
-   [B2B Directory](#)
    -   [B2B Directory](https://dhakachamber.com/b2b)
    -   [B2B Member Login](https://dhakachamber.com/login)
    -   [B2B Registration](https://dhakachamber.com/b2b-reg)