---
source: "Dhaka Chamber of Commerce & Industry (DCCI)"
tier: 1
category: "Chamber"
url: "http://dhakachamber.com/project-activities"
title: "DCCI ::  Project Activities"
scraped_at: "2026-07-02"
---

# Project Activities

## 

### Strengthening Urban Public-Private Programming for Earthquake Resilience (SUPER) Project

Dhaka Chamber of Commerce & Industry (DCCI) has started a new Project named "Strengthening Urban Public-Private Programming for Earthquake Resilience (SUPER)" Project funded by European Civil Protection and Humanitarian Aid Operations (ECHO) under the framework of partnership with ActionAid International Italia Onlus (ActionAid Italy), ActionAid Bangladesh (AAB), World Vision Bangladesh (WVB), United Purpose (UP) and Dhaka Chamber of Commerce and Industry (DCCI). The project aims to increase collaboration and multi-stakeholder initiatives engaging the private sector in creating more resilient urban communities in Bangladesh.

Overall, the country has global recognition as a country of resilience. Amid commendable progress in disaster risk reduction and humanitarian response coordination in Bangladesh, there is a huge opportunity to engage the private sector institutionally. The SUPER project has been designed to maximize this opportunity and minimize the existing gap in the humanitarian architecture of the country. Though the project's primary focus is Earthquake Disaster Risk Management (EQDRM) and the project will contribute to the overall system.

The SUPER project has established a Private Sector Emergency Operation Centre (PEOC) in DCCI premises to activate a Private Sector Working Group under Humanitarian Coordination Task Team (HCTT) and a learning sharing platform in coordination with other humanitarian actors, including UN clusters ensuring synergy among and promoting public-private DRR initiatives.

During this year, a TV talk show, two roundtable discussions, three workshops, three mock fire drills in different areas in Dhaka city, and many multi-sector meetings and advocacy campaigns were organized under this project.

## 

### Export Launchpad Bangladesh

The Export LaunchPad Bangladesh, a project jointly funded by International Islamic Trade Finance Corporation (ITFC) of the Islamic Development Bank (IDB) group and Global Affairs Canada (GAC) through its Women in Trade for Inclusive and Sustainable (WITISG) project, is designed to help SME exporters in Bangladesh take full advantage of international market opportunities (including duty-free and quota-free access through the Market Access Initiative), and thus contribute to economic growth and poverty reduction for the country. The jute and processed food sectors are the primary areas to focus on. The project has two components. The beneficiaries of the first component, funded by ITFC, will be the technical trade support officers of TSIs/TPOs/BSOs in Bangladesh. The primary direct beneficiaries of the second component, funded by GAC, will be the SMEs in the identified sectors in Bangladesh. SMEs will include both women and men-led businesses.

To achieve this goal, the Export Launchpad Bangladesh program will train national trainers, who, in turn, will provide training and coaching to SMEs in Bangladesh. Under this new initiative, 4 DCCI officials have received a 9-day long online TOT on the Export Launchpad Bangladesh export training program and attended a 2-day long SME training workshop. As a part of the activities, Trainers will provide physical training and coaching to SMEs in Bangladesh.

## 

### SheTrades Project

The SheTrade in the Commonwealth project aims to increase economic growth and job creation in Commonwealth countries by enabling increased participation of women-owned businesses in international trade. The International Trade Centre (ITC) works towards creating "trade impact for good" by fostering women entrepreneurship through inclusive and sustainable development of small and medium-sized enterprises (SMEs). ITC's SheTrades initiative works with partners worldwide to unleash the economic power of women.

As a part of the project, ITC worked with partner Business Support Organizations (BSOs) to support those providing better services for women entrepreneurs. ITC has delivered several capacity-building activities to equip BSOs to design, develop, and deliver more inclusive business support services to achieve this objective. As a part of the activities, DCCI officials and members have participated in different workshops and training programs under this project.

## 

### USAID’s Agricultural Value Chains (AVC) Project

DCCI has entered into an Adaptive Market Actor Agreement with Feed the Future Bangladesh Agriculture Value Chain Activity (AVC), under which DCCI received a fixed award grant to implement activities that will help to engage public and private partners in key agricultural sectors such as agricultural marketing and commercialization, investment in agriculture, and assessing the impact of Global G.A.P. and other compliance certifications as promotional tools and tactics. DCCI has completed Phase-1 and 2 of DCCI’s AVC Project from 2016 to 2019. As part of the project, DCCI has organized different activities includes a “National Agro Value Chain Actor Fair” and “International Flower Exhibition & Conference” in Dhaka. More than 100 companies from home and abroad have participated in these national and international events. The purpose of these events is to attract immediate to near-term investment from businesses or investors to develop the agro and flower industry in Bangladesh and build connections among the actors in the broader Asian regional market. It was a platform for participants to exchange the latest information on new varieties and techniques.

## 

### Resource efficient supply Chain for metal products in Building Sector in South Asia (METABUILD)

**Objective of Project:** 1. Improved production process in metal components for building sector in Bangladesh, India, Nepal, Sri Lanka 2. Improved Environment quality in target location and 3. Improved working and living condition through emission reduction and resource efficiency throughout the entire supply chain management process focusing metal components.

**Target Group:**SME Metal finishing suppliers, Financial Institutions, Building materials procurers and Public Officials, Building consulting Firms.

**Project Overview:**

DCCI inked the project deal(Consortium Agreement) on February 15, 2016.  
The project was undertaken by a consortium consisting of a number of organizations from India, Nepal, Sri Lanka, Bangladesh, Austria and Germany for 48 months until 2020.

## 

### Enhancing Export Capacities of Asian LDCs for Intra-regional Trade

ITC funds DCCI-ITC Project for Enhancing Export Capacities of Asian LDCs for Intra-regional Trade, aims at increasing exports of Small and Medium-sized Enterprises (SMEs) from Bangladesh, including 6 Asian LDCs to China to take advantage of Asia's largest and most dynamic import market, as a stimulus to boost intra-regional trade. Under this project support, every year, some companies have received online training on "building export capacity in exporting to the Chinese market." Last year three companies had participated in the international fair (virtual fair) named "China International Import Expo (CIIE)" in November.

## 

### DCCI Entrepreneurship & Innovation Expo

In cooperation with Bangladesh Bank, the Dhaka Chamber of Commerce & Industry (DCCI) has created 2000 new entrepreneurs. The main objective of this project is to create employment opportunities for our young generation and contribute to the GDP. The expo was inaugurated on 06 October 2013 by the Honorable President of Bangladesh. The project's activity started in 2013, and DCCI is operating the project under the guidance of the Bangladesh Bank. Under this project, DCCI has organized a mega-expo, namely the "DCCI Entrepreneurship and Innovation Expo" in Dhaka in May 2014. To operationalize the E2K objectives and its network in 2020, the activities of E2K are being linked with DCCI's other Projects as well.

## 

### METI Global Internship Program in FY 2014

The Overseas Human Resources and Industry Development Association (HIDA) and the Japan External Trade Organization (JETRO) are jointly conducting 'the METI Global Internship Program for FY 2014', entrusted by the Ministry of Economy, Trade and Industry' of Japan (METI).

The Program aims to develop human resources that can serve as a bridge for strengthening economic cooperation and developing business ties between Japan and host countries. To that end, this internship program dispatches young and promising Japanese people to governments, government agencies, industrial organizations, local companies, and Japanese companies overseas, in developing countries. DCCI takes the Program as an opportunity to strengthen bilateral relations through the creation of networks with Japanese companies, the acquisition of knowhow and knowledge on Japanese business customs and attitudes, and the revitalization of the companies/organizations themselves as they guide and interact with interns.

## 

### NTF III Bangladesh Project

The NTF III Bangladesh project is part of the Netherlands Trust Fund phase III program and builds on the achievements of the project deployed in Bangladesh under the previous Netherlands Trust Fund phase II (NTF 11) program (NTF II Bangladesh project), which took place between October 2010 and June 2013.

The NTF III Project will continue to strengthen institutional marketing capacities, including the B2B capacity of the Dhaka Chamber of Commerce & Industry (DCCI) and Bangladesh Association of Software & Information Services (BASIS) and both on and offline and working with foreign trade representatives. NTF III Project Bangladesh has already recruited 40 companies in selected growth segments of the IT & ITES industry, such as mobile, web and image processing among other areas. The NTF III Bangladesh project aims to increase the income of Bangladeshi IT & ITES exporters by enhancing the competitiveness of the sector, ultimately contributing to sustainable economic development. In order to achieve this objective, the project will focus on strengthening the portfolio of services of the partner, Bangladesh Association of Software & Information Services (BASIS) and Dhaka Chamber of Commerce and Industry (DCCI), with a view to ensure the sustainability of the interventions.

## 

### Business Initiatives Leading Development (BUILD)

Dhaka Chamber of Commerce & Industry (DCCI), Metropolitan Chamber of Commerce and Industry (MCCI) and Chittagong Chamber of Commerce & Industry (CCCI) have joined hands to establish Business Initiative Leading Development (BUILD) as a legal entity. BUILD is a platform for Public Private Dialogue (PPD) that assists in the development of Bangladesh's private sector by addressing investment climate constraints. Since its inception in October 2011, BUILD has been working proactively with the private sector and government of Bangladesh to carry out research on policies, practices and regulations affecting businesses in Bangladesh with the objective of developing recommendations for their reform.

BUILD is now registered under the Trust Act for the purpose of carrying out its activities according to the Deed of Trust signed on November 3, 2013.

### ABOUT US

-   [Board of Directors](https://dhakachamber.com/board-of-directors)
-   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
-   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)

### USEFUL LINKS

-   [DBI College](http://www.dbicollege.edu.bd)
-   [DCCI Business Institute](http://dcci-dbi.edu.bd)
-   [BUILD](http://www.buildbd.org)
-   [BIAC](https://www.biac.org.bd)
-   [ICCB](https://iccbangladesh.org.bd)

### MEMBERSHIP

-   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
-   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
-   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
-   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
-   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
-   [Become a Member](https://membership.dhakachamber.com/register)
-   [Member Login](https://membership.dhakachamber.com)
-   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
-   [Member Query](https://dhakachamber.com/member-query)
-   [Hot Line](https://dhakachamber.com/hot_line)

### MEDIA

-   [Chamber News](https://dhakachamber.com/media/news)
-   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
-   [Photo Gallery](https://dhakachamber.com/albums)
-   [Video Gallery](https://dhakachamber.com/videos)

### DOWNLOAD

-   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
-   [DCCI Reviews](https://dhakachamber.com/publications/reviews)
-   [DCCI Publications](https://dhakachamber.com/publications)
-   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
-   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)

×

-   [Home(current)](https://dhakachamber.com)
-   [About us](#)
    -   [Brief About DCCI](https://dhakachamber.com/about-us)
    -   [International Affiliations](https://dhakachamber.com/international-affiliations)
    -   [DCCI Founders](https://dhakachamber.com/dcci-founders)
    -   [Former Presidents](https://dhakachamber.com/dcci-former-presidents)
    -   [Former Senior Vice Presidents](https://dhakachamber.com/dcci-former-senior-vice-presidents)
    -   [Former Vice Presidents](https://dhakachamber.com/dcci-former-vice-presidents)
    -   [Achievements & Awards](https://dhakachamber.com/achievements-awards)
    -   [Policy and Objectives](https://dhakachamber.com/quality-policy-and-objectives)
-   [Organizational Information](#)
    -   [Board of Directors](https://dhakachamber.com/board-of-directors)
    -   [Previous Board of Directors](https://dhakachamber.com/dcci-allpastmanagement)
    -   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
    -   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)
-   [President](https://dhakachamber.com/president)
-   [Membership](#)
    -   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
    -   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
    -   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
    -   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
    -   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
    -   [Become a Member](https://membership.dhakachamber.com/register)
    -   [Member Login](https://membership.dhakachamber.com)
    -   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
    -   [Member Query](https://dhakachamber.com/member-query)
    -   [Hot Line](https://dhakachamber.com/hot_line)
-   [Projects](https://dhakachamber.com/project-activities)
-   [Seminar](https://dhakachamber.com/media/seminar)
-   [Publications](#)
    -   [DCCI Research Service](https://dhakachamber.com/pdf_viewer/storage/2024/circular/DCCI%20Research%20Service.pdf)
    -   [Research Guideline](https://dhakachamber.com/pdf_viewer/storage/2024/circular/Research%20Guideline.pdf)
    -   [DCCI Journal (DJBEP)](https://journal.dhakachamber.com/)
    -   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
    -   [DCCI Review](https://dhakachamber.com/publications/reviews)
    -   [DCCI Publications](https://dhakachamber.com/publications)
    -   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
    -   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)
    -   [Introducing DCCI 2023](https://www.dhakachamber.com/storage/print_media/2023/07/Introducing%202023.pdf)
-   [Media](#)
    -   [Chamber News](https://dhakachamber.com/media/news)
    -   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
    -   [Photo Gallery](https://dhakachamber.com/albums)
    -   [Video Gallery](https://dhakachamber.com/videos)
    -   [Fairs & Exhibitions](https://www.dhakachamber.com/storage/2026/03/dccifair.pdf)
-   [Policy](#)
    -   [Export Policy](https://www.dhakachamber.com/storage/policy/3VFoMxkr6Z3EZdC8wz7YHfrIBfPP5N0Y6n7eEEFJ.pdf)
    -   [Import Policy](https://www.dhakachamber.com/storage/policy/b6uhXGhpdl30N68gl3Yg9mV5P6vGIPAjquqTu35f.pdf)
    -   [Industry Policy](https://www.dhakachamber.com/storage/policy/kpHRSdbYmY90O7wcyYmkZTSvumKEXfz5uwPTlOn5.pdf)
    -   [ICT Policy](https://www.dhakachamber.com/storage/policy/abTlbODgI2I4Aqbrix5Cs2DHvFD5lW3OwDmfKXmH.pdf)
-   [BILATERAL TRADE](#)
    -   [Bilateral Trade](https://dhakachamber.com/bilateral-trade)
    -   [Africa](https://dhakachamber.com/bilateral-trade/africa)
    -   [America](https://dhakachamber.com/bilateral-trade/america)
    -   [Asian](https://dhakachamber.com/bilateral-trade/asian)
    -   [ASEAN](https://dhakachamber.com/bilateral-trade/asean)
    -   [SAARC](https://dhakachamber.com/bilateral-trade/saarc)
    -   [Middle East](https://dhakachamber.com/bilateral-trade/middle-east)
    -   [European Union](https://dhakachamber.com/bilateral-trade/european-union)
-   [About Bangladesh](#)
    -   [General Information](https://dhakachamber.com/bangladesh-country-profile)
    -   [Business Opportunities in Bangladesh](https://dhakachamber.com/trade-and-business-opportunities-in-bangladesh)
    -   [Useful Links](https://dhakachamber.com/useful-links)
-   [B2B Directory](#)
    -   [B2B Directory](https://dhakachamber.com/b2b)
    -   [B2B Member Login](https://dhakachamber.com/login)
    -   [B2B Registration](https://dhakachamber.com/b2b-reg)