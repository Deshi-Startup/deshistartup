---
source: "Dhaka Chamber of Commerce & Industry (DCCI)"
tier: 1
category: "Chamber"
url: "https://dhakachamber.com/videos"
title: "DCCI ::"
scraped_at: "2026-07-02"
---

# Video Gallery

![](https://i1.ytimg.com/vi/b2gsZ_lkFbA/mqdefault.jpg)

Seminar On Economic Position Index (EPI): Quarterly Macroeconomic State of Dhaka

![](https://i1.ytimg.com/vi/4bQAN4EScc0/mqdefault.jpg)

RTD on Integrated Port and Logistics Development for a Trade-Driven Bangladesh

![](https://i1.ytimg.com/vi/5F5d8KPaGaQ/mqdefault.jpg)

ঢাকা চেম্বার অব কমার্স অ্যান্ড ইন্ডাস্ট্রিপ্রাক-বাজেটআলোচনা ২০২৬-২০২৭বেসরকারি খাতের প্রত্যাশা

![](https://i1.ytimg.com/vi/60_uQ0i61ng/mqdefault.jpg)

Round Table Discussion on Navigating the Global Energy Shock: Impact on Bangladesh and Way forward

![](https://i1.ytimg.com/vi/qntaQVSg-ec/mqdefault.jpg)

Seminar on Bi-annual Economic State & Future outlook of Bangladesh Economy

![](https://i1.ytimg.com/vi/9Mhvv9MFApY/mqdefault.jpg)

নির্বাচন-পরবর্তী উন্নত আইন-শৃঙ্খলা পরিস্থিতি ও সুষ্ঠু বাজার ব্যবস্থাপনা বজায় রাখার অত্যাবশ্যকীয়তা

![](https://i1.ytimg.com/vi/r5imAyKR4uI/mqdefault.jpg)

বিদ্যমান অর্থনৈতিক পরিস্থিতিতে নবগঠিত সরকারের নিকট ডিসিসিআই-এর প্রত্যাশা” শীর্ষক সংবাদ সম্মেলন

![](https://i1.ytimg.com/vi/fDaoD-16u6I/mqdefault.jpg)

Policy Dissemination on “Bangladesh Industrial Energy Efficiency Policy

![](https://i1.ytimg.com/vi/UCUQVdXHkFA/mqdefault.jpg)

Seminar on “Strengthening Confidence in the Healthcare System in Bangladesh"

![](https://i1.ytimg.com/vi/owIIu3CF__k/mqdefault.jpg)

Discussion on Smart Human Capital Development in the Context of the Fourth Industrial Revolution

![](https://i1.ytimg.com/vi/Kj8kFmEvuoQ/mqdefault.jpg)

FGD on Economic Position Index

![](https://i1.ytimg.com/vi/q1Jjs1anaE0/mqdefault.jpg)

FGD on "Development of Bangladesh Halal Industry: Challenges and Opportunities"

-   «
-   1
-   [2](https://dhakachamber.com/videos?page=2)
-   [3](https://dhakachamber.com/videos?page=3)
-   [4](https://dhakachamber.com/videos?page=4)
-   [5](https://dhakachamber.com/videos?page=5)
-   [6](https://dhakachamber.com/videos?page=6)
-   [7](https://dhakachamber.com/videos?page=7)
-   [8](https://dhakachamber.com/videos?page=8)
-   [9](https://dhakachamber.com/videos?page=9)
-   [10](https://dhakachamber.com/videos?page=10)
-   [11](https://dhakachamber.com/videos?page=11)
-   [12](https://dhakachamber.com/videos?page=12)
-   [13](https://dhakachamber.com/videos?page=13)
-   [»](https://dhakachamber.com/videos?page=2)

### ABOUT US

-   [Board of Directors](https://dhakachamber.com/board-of-directors)
-   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
-   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)

### USEFUL LINKS

-   [DBI College](http://www.dbicollege.edu.bd)
-   [DCCI Business Institute](http://dcci-dbi.edu.bd)
-   [BUILD](http://www.buildbd.org)
-   [BIAC](https://www.biac.org.bd)
-   [ICCB](https://iccbangladesh.org.bd)

### MEMBERSHIP

-   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
-   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
-   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
-   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
-   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
-   [Become a Member](https://membership.dhakachamber.com/register)
-   [Member Login](https://membership.dhakachamber.com)
-   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
-   [Member Query](https://dhakachamber.com/member-query)
-   [Hot Line](https://dhakachamber.com/hot_line)

### MEDIA

-   [Chamber News](https://dhakachamber.com/media/news)
-   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
-   [Photo Gallery](https://dhakachamber.com/albums)
-   [Video Gallery](https://dhakachamber.com/videos)

### DOWNLOAD

-   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
-   [DCCI Reviews](https://dhakachamber.com/publications/reviews)
-   [DCCI Publications](https://dhakachamber.com/publications)
-   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
-   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)

×

-   [Home(current)](https://dhakachamber.com)
-   [About us](#)
    -   [Brief About DCCI](https://dhakachamber.com/about-us)
    -   [International Affiliations](https://dhakachamber.com/international-affiliations)
    -   [DCCI Founders](https://dhakachamber.com/dcci-founders)
    -   [Former Presidents](https://dhakachamber.com/dcci-former-presidents)
    -   [Former Senior Vice Presidents](https://dhakachamber.com/dcci-former-senior-vice-presidents)
    -   [Former Vice Presidents](https://dhakachamber.com/dcci-former-vice-presidents)
    -   [Achievements & Awards](https://dhakachamber.com/achievements-awards)
    -   [Policy and Objectives](https://dhakachamber.com/quality-policy-and-objectives)
-   [Organizational Information](#)
    -   [Board of Directors](https://dhakachamber.com/board-of-directors)
    -   [Previous Board of Directors](https://dhakachamber.com/dcci-allpastmanagement)
    -   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
    -   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)
-   [President](https://dhakachamber.com/president)
-   [Membership](#)
    -   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
    -   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
    -   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
    -   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
    -   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
    -   [Become a Member](https://membership.dhakachamber.com/register)
    -   [Member Login](https://membership.dhakachamber.com)
    -   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
    -   [Member Query](https://dhakachamber.com/member-query)
    -   [Hot Line](https://dhakachamber.com/hot_line)
-   [Projects](https://dhakachamber.com/project-activities)
-   [Seminar](https://dhakachamber.com/media/seminar)
-   [Publications](#)
    -   [DCCI Research Service](https://dhakachamber.com/pdf_viewer/storage/2024/circular/DCCI%20Research%20Service.pdf)
    -   [Research Guideline](https://dhakachamber.com/pdf_viewer/storage/2024/circular/Research%20Guideline.pdf)
    -   [DCCI Journal (DJBEP)](https://journal.dhakachamber.com/)
    -   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
    -   [DCCI Review](https://dhakachamber.com/publications/reviews)
    -   [DCCI Publications](https://dhakachamber.com/publications)
    -   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
    -   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)
    -   [Introducing DCCI 2023](https://www.dhakachamber.com/storage/print_media/2023/07/Introducing%202023.pdf)
-   [Media](#)
    -   [Chamber News](https://dhakachamber.com/media/news)
    -   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
    -   [Photo Gallery](https://dhakachamber.com/albums)
    -   [Video Gallery](https://dhakachamber.com/videos)
    -   [Fairs & Exhibitions](https://www.dhakachamber.com/storage/2026/03/dccifair.pdf)
-   [Policy](#)
    -   [Export Policy](https://www.dhakachamber.com/storage/policy/3VFoMxkr6Z3EZdC8wz7YHfrIBfPP5N0Y6n7eEEFJ.pdf)
    -   [Import Policy](https://www.dhakachamber.com/storage/policy/b6uhXGhpdl30N68gl3Yg9mV5P6vGIPAjquqTu35f.pdf)
    -   [Industry Policy](https://www.dhakachamber.com/storage/policy/kpHRSdbYmY90O7wcyYmkZTSvumKEXfz5uwPTlOn5.pdf)
    -   [ICT Policy](https://www.dhakachamber.com/storage/policy/abTlbODgI2I4Aqbrix5Cs2DHvFD5lW3OwDmfKXmH.pdf)
-   [BILATERAL TRADE](#)
    -   [Bilateral Trade](https://dhakachamber.com/bilateral-trade)
    -   [Africa](https://dhakachamber.com/bilateral-trade/africa)
    -   [America](https://dhakachamber.com/bilateral-trade/america)
    -   [Asian](https://dhakachamber.com/bilateral-trade/asian)
    -   [ASEAN](https://dhakachamber.com/bilateral-trade/asean)
    -   [SAARC](https://dhakachamber.com/bilateral-trade/saarc)
    -   [Middle East](https://dhakachamber.com/bilateral-trade/middle-east)
    -   [European Union](https://dhakachamber.com/bilateral-trade/european-union)
-   [About Bangladesh](#)
    -   [General Information](https://dhakachamber.com/bangladesh-country-profile)
    -   [Business Opportunities in Bangladesh](https://dhakachamber.com/trade-and-business-opportunities-in-bangladesh)
    -   [Useful Links](https://dhakachamber.com/useful-links)
-   [B2B Directory](#)
    -   [B2B Directory](https://dhakachamber.com/b2b)
    -   [B2B Member Login](https://dhakachamber.com/login)
    -   [B2B Registration](https://dhakachamber.com/b2b-reg)

×

×

×

×

×

×

×

×

×

×

×

×