---
source: "Dhaka Chamber of Commerce & Industry (DCCI)"
tier: 1
category: "Chamber"
url: "https://dhakachamber.com/media/news/seminar-on-the-electric-vehicle-ev-challenges-and-prospects-in-bangladesh"
title: "DCCI ::  News"
scraped_at: "2026-07-02"
---

# News

## seminar on "The Electric Vehicle (EV): Challenges and Prospects in Bangladesh "

![](https://www.dhakachamber.com/storage/posts/June2026/eHZK71yuZwA2jdWRaz82.jpg)

Dhaka Chamber of Commerce & Industry (DCCI), in collaboration with Bangladesh Sustainable and Renewable Energy Association (BSREA), organized a seminar on "The Electric Vehicle (EV): Challenges and Prospects in Bangladesh " on June 27, 2026 at the DCCI Auditorium. Mohammad Wahid Hossain ndc, Chairman (Senior Secretary), Bangladesh Energy and Power Research Council (BEPRC), GoB and Abdun Naser Khan, Secretary, Ministry of Industries, GoB attended the event as Special Guests. DCCI President Taskeen Ahmed presented the keynote paper.

In his presentation Dhaka Chamber President Taskeen Ahmed stated that the global transportation sector is undergoing a significant shift driven by the goals of sustainable development, climate change mitigation and carbon emission reduction, resulting in the rapid expansion of electric vehicle (EV) adoption worldwide. He noted that in order to support the development of the EV industry in Bangladesh, the government has already introduced various policy measures, including tax and duty incentives. DCCI President suggested that further initiatives such as building adequate charging infrastructure, ensuring reliable electricity supply, establishing advanced battery management systems, providing necessary incentives to the private sector are required to develop this industry. He emphasized that Public-Private Partnership (PPP)-based investment is essential for expanding charging infrastructure, alongside the formulation of a coordinated and long-term policy framework. He mentioned that though nearly 6 million three-wheelers are currently operating across the country, only 669 EV cars have been registered with the Bangladesh Road Transport Authority (BRTA). He urged the government to formulate a comprehensive national EV policy to tap the sector's full potential.

Mohammad Wahid Hossain ndc, Chairman (Senior Secretary), Bangladesh Energy and Power Research Council (BEPRC), GoB stressed that uninterrupted electricity supply is the key factor for the success of the EV sector. He observed that since Bangladesh's economy is primarily driven by the private sector, stronger collaboration between the public and private sector is essential for achieving the country's development goals. He also suggested establishing a dedicated cell involving all relevant government agencies currently working on expanding the EV industry to ensure better policy coordination. Furthermore, he underscored the importance of increasing the share of renewable energy and developing a reliable database on how many electric vehicles are currently operating across the country to facilitate effective planning.

Abdun Naser Khan, Secretary, Ministry of Industries, GoB informed that a draft EV policy has already been prepared and has undergone inter-ministerial consultations as well as stakeholder consultations. He stated that the primary objective of the proposed policy is to reduce dependency on imported fossil fuels while enhancing the country's energy security. He assured that a practical and future-ready EV policy would be finalized based on the recommendations of all stakeholders.

The panel discussion featured Shibir Bicitro Barua, Additional Secretary (IIT), Ministry of Commerce; Md Aminur Rahman, Director (Joint Secretary), Sustainable and Renewable Energy Development Authority (SREDA); Dr. Md. Moksed Ali, ndc, Joint Secretary, Additional Charge of Planning and Activities Branch, Road Transport and Highways Division; Md. Mofijul Islam, Chief Engineer, Bangladesh Power Development Board (BPDB); Dr. Md. Ehsan, Professor, Department of Mechanical Engineering, BUET; Mostafa Al Mahmud, President, Bangladesh Sustainable and Renewable Energy Association (BSREA); Hafizur Rahman Khan, President, Bangladesh Automobiles Assemblers and Manufacturers Association (BAAMA) and Chairman, Runner Automobiles PLC; Tanvir Ebne Bashar, Vice President, Infrastructure Development Company Limited (IDCOL); and Sk. Amin Uddin, Chief Executive Officer of Akij Motors.

Shibir Bicitro Barua, Additional Secretary (IIT), Ministry of Commerce stated that although official statistics indicate that only around 700 EVs have been registered, a significantly larger number of electric vehicles are already operating on Bangladesh's roads. He stressed the importance of obtaining accurate data to facilitate policy support to further develop this industry. He also informed that Ministry of Commerce is working closely with the NBR to address both tariff and non-tariff barriers faced by the stakeholders in the EV sector.

Hafizur Rahman Khan, President, BAAMA and Chairman, Runner Automobiles PLC, said that the EV industry has opened new avenues for employment generation. He further remarked that strengthening backward linkage industries through the manufacturing and export of EV components could substantially increase Bangladesh's export potential.

Md Aminur Rahman, Director, SREDA, informed that the authority has approved 32 EV charging stations so far, of which 9 have already been established. He stressed the need for ensuring quality standards for both EV charging stations and imported electric vehicles.

Dr. Md. Moksed Ali, ndc, Joint Secretary, Road Transport and Highways Division, stated that the government has undertaken several initiatives to promote sustainable transportation and is working towards reducing the existing duty structure applicable to the EV sector.

Md. Mofijul Islam, Chief Engineer, BPDB mentioned that as there is no proper registration process for battery-operated electric vehicles, the government currently lacks accurate information on electricity consumption in the sector. He also observed that the use of substandard batteries is causing considerable electricity wastage.

Mostafa Al Mahmud, President, BSREA noted that Bangladesh spends nearly BDT 65,000 crore annually on fuel for the transport sector, most of which is import-dependent. He stated that increasing EV adoption would significantly reduce pressure on fuel imports and help conserve foreign exchange.

Dr. Md. Ehsan, Professor, BUET observed that Bangladesh has yet to fully assess and utilize its domestic capabilities in the EV sector. He added that the increasing use of electric three-wheelers has reduced diesel imports by approximately 1.5 million tonnes annually as a result pressure on government expenditure and foreign exchange have significantly been reduced.

Tanvir Ebne Bashar, Vice President, IDCOL emphasized the need for the rapid expansion of charging infrastructure, simplification of import procedures, and provision of long-term financing to accelerate EV adoption.

Sk. Amin Uddin, Chief Executive Officer of Akij Motors stated that EVs reduce fuel costs by approximately 30 percent, making them an economically viable transportation solution.

During the open floor discussion, President of BARVIDA Abdul Haque has called for greater emphasis on manufacturing electric three-wheelers and EV components locally. Former DCCI Vice President M. Abu Hurairah stressed the importance of developing a comprehensive implementation plan before introducing the proposed 2,000 electric buses in Dhaka city.

Following the seminar, DCCI and BSREA signed a MoU to promote collaboration in energy policy, innovation, and market development. DCCI Secretary General (Acting) Dr. AKM Asaduzzaman Patwary and Engr. Mohammad Ataur Rahman Sarker, General Secretary of BSREA signed the MoU one behalf of their respective organizations.

DCCI Senior Vice President Razeev H Chowdhury, Vice President Md. Salem Sulaiman, members of the DCCI Board of Directors and representatives from both public and private sectors were also present on the occasion.

Published on: 2026-06-27

### ABOUT US

-   [Board of Directors](https://dhakachamber.com/board-of-directors)
-   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
-   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)

### USEFUL LINKS

-   [DBI College](http://www.dbicollege.edu.bd)
-   [DCCI Business Institute](http://dcci-dbi.edu.bd)
-   [BUILD](http://www.buildbd.org)
-   [BIAC](https://www.biac.org.bd)
-   [ICCB](https://iccbangladesh.org.bd)

### MEMBERSHIP

-   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
-   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
-   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
-   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
-   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
-   [Become a Member](https://membership.dhakachamber.com/register)
-   [Member Login](https://membership.dhakachamber.com)
-   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
-   [Member Query](https://dhakachamber.com/member-query)
-   [Hot Line](https://dhakachamber.com/hot_line)

### MEDIA

-   [Chamber News](https://dhakachamber.com/media/news)
-   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
-   [Photo Gallery](https://dhakachamber.com/albums)
-   [Video Gallery](https://dhakachamber.com/videos)

### DOWNLOAD

-   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
-   [DCCI Reviews](https://dhakachamber.com/publications/reviews)
-   [DCCI Publications](https://dhakachamber.com/publications)
-   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
-   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)

×

-   [Home(current)](https://dhakachamber.com)
-   [About us](#)
    -   [Brief About DCCI](https://dhakachamber.com/about-us)
    -   [International Affiliations](https://dhakachamber.com/international-affiliations)
    -   [DCCI Founders](https://dhakachamber.com/dcci-founders)
    -   [Former Presidents](https://dhakachamber.com/dcci-former-presidents)
    -   [Former Senior Vice Presidents](https://dhakachamber.com/dcci-former-senior-vice-presidents)
    -   [Former Vice Presidents](https://dhakachamber.com/dcci-former-vice-presidents)
    -   [Achievements & Awards](https://dhakachamber.com/achievements-awards)
    -   [Policy and Objectives](https://dhakachamber.com/quality-policy-and-objectives)
-   [Organizational Information](#)
    -   [Board of Directors](https://dhakachamber.com/board-of-directors)
    -   [Previous Board of Directors](https://dhakachamber.com/dcci-allpastmanagement)
    -   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
    -   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)
-   [President](https://dhakachamber.com/president)
-   [Membership](#)
    -   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
    -   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
    -   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
    -   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
    -   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
    -   [Become a Member](https://membership.dhakachamber.com/register)
    -   [Member Login](https://membership.dhakachamber.com)
    -   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
    -   [Member Query](https://dhakachamber.com/member-query)
    -   [Hot Line](https://dhakachamber.com/hot_line)
-   [Projects](https://dhakachamber.com/project-activities)
-   [Seminar](https://dhakachamber.com/media/seminar)
-   [Publications](#)
    -   [DCCI Research Service](https://dhakachamber.com/pdf_viewer/storage/2024/circular/DCCI%20Research%20Service.pdf)
    -   [Research Guideline](https://dhakachamber.com/pdf_viewer/storage/2024/circular/Research%20Guideline.pdf)
    -   [DCCI Journal (DJBEP)](https://journal.dhakachamber.com/)
    -   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
    -   [DCCI Review](https://dhakachamber.com/publications/reviews)
    -   [DCCI Publications](https://dhakachamber.com/publications)
    -   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
    -   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)
    -   [Introducing DCCI 2023](https://www.dhakachamber.com/storage/print_media/2023/07/Introducing%202023.pdf)
-   [Media](#)
    -   [Chamber News](https://dhakachamber.com/media/news)
    -   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
    -   [Photo Gallery](https://dhakachamber.com/albums)
    -   [Video Gallery](https://dhakachamber.com/videos)
    -   [Fairs & Exhibitions](https://www.dhakachamber.com/storage/2026/03/dccifair.pdf)
-   [Policy](#)
    -   [Export Policy](https://www.dhakachamber.com/storage/policy/3VFoMxkr6Z3EZdC8wz7YHfrIBfPP5N0Y6n7eEEFJ.pdf)
    -   [Import Policy](https://www.dhakachamber.com/storage/policy/b6uhXGhpdl30N68gl3Yg9mV5P6vGIPAjquqTu35f.pdf)
    -   [Industry Policy](https://www.dhakachamber.com/storage/policy/kpHRSdbYmY90O7wcyYmkZTSvumKEXfz5uwPTlOn5.pdf)
    -   [ICT Policy](https://www.dhakachamber.com/storage/policy/abTlbODgI2I4Aqbrix5Cs2DHvFD5lW3OwDmfKXmH.pdf)
-   [BILATERAL TRADE](#)
    -   [Bilateral Trade](https://dhakachamber.com/bilateral-trade)
    -   [Africa](https://dhakachamber.com/bilateral-trade/africa)
    -   [America](https://dhakachamber.com/bilateral-trade/america)
    -   [Asian](https://dhakachamber.com/bilateral-trade/asian)
    -   [ASEAN](https://dhakachamber.com/bilateral-trade/asean)
    -   [SAARC](https://dhakachamber.com/bilateral-trade/saarc)
    -   [Middle East](https://dhakachamber.com/bilateral-trade/middle-east)
    -   [European Union](https://dhakachamber.com/bilateral-trade/european-union)
-   [About Bangladesh](#)
    -   [General Information](https://dhakachamber.com/bangladesh-country-profile)
    -   [Business Opportunities in Bangladesh](https://dhakachamber.com/trade-and-business-opportunities-in-bangladesh)
    -   [Useful Links](https://dhakachamber.com/useful-links)
-   [B2B Directory](#)
    -   [B2B Directory](https://dhakachamber.com/b2b)
    -   [B2B Member Login](https://dhakachamber.com/login)
    -   [B2B Registration](https://dhakachamber.com/b2b-reg)