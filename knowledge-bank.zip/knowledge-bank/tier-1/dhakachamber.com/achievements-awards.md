---
source: "Dhaka Chamber of Commerce & Industry (DCCI)"
tier: 1
category: "Chamber"
url: "https://dhakachamber.com/achievements-awards"
title: "DCCI ::  Achievements & Awards"
scraped_at: "2026-07-02"
---

# Achievements & Awards

![DCCI wins the ](https://dhakachamber.com/storage/achievements-awards/October2018/V3DlVyDjI2XNkQwbszEq-cropped.jpg)

![ISO certification for the Chamber](https://dhakachamber.com/storage/achievements-awards/October2018/aoRao5T5RqBCwhN8z4Tm-cropped.jpg)

![CACCI Local Chamber Awards 2010](https://dhakachamber.com/storage/achievements-awards/October2018/2SsXGqbj0zB6mbf8YozB-cropped.jpg)

![World Chambers Competition Award 2007](https://dhakachamber.com/storage/achievements-awards/October2018/S3A8OMeEEZwdhMUJq67V-cropped.jpg)

![Finalist for Best Unconventional Project 2011](https://dhakachamber.com/storage/achievements-awards/September2022/wGW93quRaxWT9LeAMBKK-cropped.jpg)

![Institutional Appreciation Award 2019](https://dhakachamber.com/storage/achievements-awards/September2022/MLr90iMseP3XXlfDWHpa-cropped.jpg)

[Previous](#award-carousel) [Next](#award-carousel)

##### 

#### DCCI wins the "MLS-SCM (P) Best Network Partner Institution Award 2010" of International Trade Centre (ITC) - UNCTAD/WTO, Geneva

Dhaka Chamber of Commerce & Industry (DCCI) was awarded with the “MLS-SCM (P) Best Network Partner Institution Award 2010” of International Trade Centre (ITC) - UNCTAD/WTO, Geneva, among 120 partner Institutions in 69 countries, at the “MLS-SCM (P) Global Network Roundtable, Malaysia, 2011”, held at Kuala Lumpur during 06-08 April, 2011.

The Roundtable was organized by ITC jointly with MAPICS, Malaysia with the support of the Govt. of Switzerland. Sixty Nine (69) participants from different countries participated in the Roundtable. A five-member delegation, headed by Asif Ibrahim, President, Dhaka Chamber of Commerce & Industry (DCCI) participated in the Roundtable. The other members of the delegation were the lead trainers of DCCI Business Institute (DBI), namely, Syed Asgar Ali, Enayet Hossain, Kamruzzaman and Md. Rashid Ali.

During the Roundtable, the President of DCCI presented a power point presentation regarding the achievement of DCCI in promoting and developing the Modular Learning System in Supply Chain Management (MLS-SCM(P)) of ITC in Bangladesh. ITC has developed 18 modules of MLS-SCM (P) to help companies achieve excellence in the supply chain. The symbol (P) signifies the power of purchasing which is the key element of the programme. Among other things, he mentioned that DCCI has developed an excellent infrastructure and a pool of experienced trainers through ToT Workshops for conducting Certificate/Diploma course in Supply Chain Management. This is a unique, proven and powerful management system to cut cost, reduce lead time and become competitive in the Global Market.

After taking necessary preparation for 3 years from 2004, DCCI Business Institute (DBI) has been offering regular courses from 2007. So far, 334 participants have been trained for Certificate Course, 146 participants for Advanced Certificate and 85 participants for Diploma. Of them 48 have received certificates and 21 received Advanced Certificate. About 20 have been working for Diploma. In the mean time, the MLS-SCM (P) of DBI has become popular in Bangladesh and participants from Business, Govt. and Non-Govt. organizations are coming in large numbers. In 2010, 84 participants have been admitted for the course. In view of the excellent performance of DBI, DCCI was awarded with the Certificate of the MLS-SCM(P) Best Network Partner Institution Award 2010.

One Lead Trainer of DBI, Syed Asgar Ali, Import Manager, BOC Bangladesh Ltd. was awarded the Certificate of “the Best Success Story Winner 2010” during the Roundtable. He had demonstrated that by using the tools and techniques of MLS-SCM how he could yield an astonishing 2.6 million Euros in saving.

##### 

#### ISO certification for the Chamber

DCCI has achieved ISO 9001:2008 certification on 13 October, 2010 with the assistance of a consultant firm named Quality Institute of England. The certificate of ISO 9001:2008 was awarded by Australian business improvement firm SAI GLOBAL Limited- an US accredited body for SAI Global clients. Dhaka Chamber of Commerce and Industry (DCCI) is now certified to ISO 9001:2008, the brand new version of Quality Management System Standard published by International Organization for Standardization. The Chamber is now more committed to maintain quality and customer satisfaction sincerely through its services provided to its members.

A Management Review Committee of DCCI along with its all employees were involved in process of documentation for qualifying ISO9001:2008 certification. A number of internal and external audits had been completed for availing this achievement. It is the outstanding teamwork through which we have achieved the success of ISO 9001:2008 certification. An award giving ceremony on ISO 9001:2008 to DCCI was held on November 24, 2010 where Honourable Commerce Minister Mr. Muhammad Faruk Khan, M.P. was present as Chief Guest.

##### 

#### CACCI Local Chamber Awards 2010

In recognition of its crucial role in promoting the cause of business community in Bangladesh, DCCI won the 4th Confederation of Asia Pacific Chambers of Commerce & Industry (CACCI) Award in Big Chamber Category on July 6, 2010.

DCCI received the award from the newly elected President of CACCI Ambassador Benedicto V. Yujuico at the award- giving ceremony of the 24th Conference of the Confederation at Colombo, Sri Lanka. A total of six nominations from Asian countries were received for the 4th CACCI local Chamber Awards under the Big Chamber Category.

DCCI attended the ceremony with three member delegation including Mr. Nessar M. Khan and Mr. Waqar Ahmad Choudhury, Directors of DCCI.

The Awards committee evaluated all the nominations based on some set criterion: outstanding services to members (policy advocacy efforts, training programs), outstanding services to community and to country (trade and investment promotion projects, employment generation activities), participation in CACCI activities and projects. Based on the evaluation of the Award Committee, the CACCI Board of Judges of Award Committee nominated DCCI for Best Local Chamber Award of 2010.

##### 

#### World Chambers Competition Award 2007

Dhaka Chamber of Commerce & Industry (DCCI) has won the “World Chambers Competition Award 2007” in “Best Skills Development Programme” category from the World Chambers Federation (WCF). The WCF, ICC’s specialized division for Chambers affairs organized “5th World Chambers Congress” on 4-6 July, 2007 at Istanbul, Turkey. On this occasion, WCF organized the World Chambers Competition (WCC) 2007. It is the only global award programme to recognize the most innovative projects undertaken by Chambers from around the world. The competition provided a unique opportunity for Chambers to : 1) showcase originality and ingenuity, 2) demonstrate determination to strengthen SMEs, 3) improve services to members.

In 2007 World Chambers Competition, competition finalists for four categories presented their dossiers to the international judging panel. The four categories included in the competition are : 1) Best Unconventional Project for SMEs, 2) Best International Cooperation between Chambers, 3) Best Skills Development Programme, and 4) Best New Membership Recruitment Project.

The Selection Criteria for the Award were : 1) The innovative nature of the project, 2) The impact of the project on the chamber and/or the business community, 3) measurable outcomes, 4) the relevance of the project in the target category, 5) potential for the project to be successfully adopted by other Chambers of Commerce throughout the world.

DCCI participated in the category of “Best Skills Development Programme”. In its Dossier, DCCI highlighted the various activities of its Research and DCCI Business institute (DBI) for development of looking entrepreneurs and business executives. DCCI competed with 38 countries for the award from which WCF received 58 applications.

##### 

#### Finalist for Best Unconventional Project 2011

Finalist for Best Unconventional Project 2011

##### 

#### Institutional Appreciation Award 2019

Institutional Appreciation Award 2019 , National Productivity Organization , Ministry of Industries, GoB

### ABOUT US

-   [Board of Directors](https://dhakachamber.com/board-of-directors)
-   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
-   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)

### USEFUL LINKS

-   [DBI College](http://www.dbicollege.edu.bd)
-   [DCCI Business Institute](http://dcci-dbi.edu.bd)
-   [BUILD](http://www.buildbd.org)
-   [BIAC](https://www.biac.org.bd)
-   [ICCB](https://iccbangladesh.org.bd)

### MEMBERSHIP

-   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
-   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
-   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
-   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
-   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
-   [Become a Member](https://membership.dhakachamber.com/register)
-   [Member Login](https://membership.dhakachamber.com)
-   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
-   [Member Query](https://dhakachamber.com/member-query)
-   [Hot Line](https://dhakachamber.com/hot_line)

### MEDIA

-   [Chamber News](https://dhakachamber.com/media/news)
-   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
-   [Photo Gallery](https://dhakachamber.com/albums)
-   [Video Gallery](https://dhakachamber.com/videos)

### DOWNLOAD

-   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
-   [DCCI Reviews](https://dhakachamber.com/publications/reviews)
-   [DCCI Publications](https://dhakachamber.com/publications)
-   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
-   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)

×

-   [Home(current)](https://dhakachamber.com)
-   [About us](#)
    -   [Brief About DCCI](https://dhakachamber.com/about-us)
    -   [International Affiliations](https://dhakachamber.com/international-affiliations)
    -   [DCCI Founders](https://dhakachamber.com/dcci-founders)
    -   [Former Presidents](https://dhakachamber.com/dcci-former-presidents)
    -   [Former Senior Vice Presidents](https://dhakachamber.com/dcci-former-senior-vice-presidents)
    -   [Former Vice Presidents](https://dhakachamber.com/dcci-former-vice-presidents)
    -   [Achievements & Awards](https://dhakachamber.com/achievements-awards)
    -   [Policy and Objectives](https://dhakachamber.com/quality-policy-and-objectives)
-   [Organizational Information](#)
    -   [Board of Directors](https://dhakachamber.com/board-of-directors)
    -   [Previous Board of Directors](https://dhakachamber.com/dcci-allpastmanagement)
    -   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
    -   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)
-   [President](https://dhakachamber.com/president)
-   [Membership](#)
    -   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
    -   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
    -   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
    -   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
    -   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
    -   [Become a Member](https://membership.dhakachamber.com/register)
    -   [Member Login](https://membership.dhakachamber.com)
    -   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
    -   [Member Query](https://dhakachamber.com/member-query)
    -   [Hot Line](https://dhakachamber.com/hot_line)
-   [Projects](https://dhakachamber.com/project-activities)
-   [Seminar](https://dhakachamber.com/media/seminar)
-   [Publications](#)
    -   [DCCI Research Service](https://dhakachamber.com/pdf_viewer/storage/2024/circular/DCCI%20Research%20Service.pdf)
    -   [Research Guideline](https://dhakachamber.com/pdf_viewer/storage/2024/circular/Research%20Guideline.pdf)
    -   [DCCI Journal (DJBEP)](https://journal.dhakachamber.com/)
    -   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
    -   [DCCI Review](https://dhakachamber.com/publications/reviews)
    -   [DCCI Publications](https://dhakachamber.com/publications)
    -   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
    -   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)
    -   [Introducing DCCI 2023](https://www.dhakachamber.com/storage/print_media/2023/07/Introducing%202023.pdf)
-   [Media](#)
    -   [Chamber News](https://dhakachamber.com/media/news)
    -   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
    -   [Photo Gallery](https://dhakachamber.com/albums)
    -   [Video Gallery](https://dhakachamber.com/videos)
    -   [Fairs & Exhibitions](https://www.dhakachamber.com/storage/2026/03/dccifair.pdf)
-   [Policy](#)
    -   [Export Policy](https://www.dhakachamber.com/storage/policy/3VFoMxkr6Z3EZdC8wz7YHfrIBfPP5N0Y6n7eEEFJ.pdf)
    -   [Import Policy](https://www.dhakachamber.com/storage/policy/b6uhXGhpdl30N68gl3Yg9mV5P6vGIPAjquqTu35f.pdf)
    -   [Industry Policy](https://www.dhakachamber.com/storage/policy/kpHRSdbYmY90O7wcyYmkZTSvumKEXfz5uwPTlOn5.pdf)
    -   [ICT Policy](https://www.dhakachamber.com/storage/policy/abTlbODgI2I4Aqbrix5Cs2DHvFD5lW3OwDmfKXmH.pdf)
-   [BILATERAL TRADE](#)
    -   [Bilateral Trade](https://dhakachamber.com/bilateral-trade)
    -   [Africa](https://dhakachamber.com/bilateral-trade/africa)
    -   [America](https://dhakachamber.com/bilateral-trade/america)
    -   [Asian](https://dhakachamber.com/bilateral-trade/asian)
    -   [ASEAN](https://dhakachamber.com/bilateral-trade/asean)
    -   [SAARC](https://dhakachamber.com/bilateral-trade/saarc)
    -   [Middle East](https://dhakachamber.com/bilateral-trade/middle-east)
    -   [European Union](https://dhakachamber.com/bilateral-trade/european-union)
-   [About Bangladesh](#)
    -   [General Information](https://dhakachamber.com/bangladesh-country-profile)
    -   [Business Opportunities in Bangladesh](https://dhakachamber.com/trade-and-business-opportunities-in-bangladesh)
    -   [Useful Links](https://dhakachamber.com/useful-links)
-   [B2B Directory](#)
    -   [B2B Directory](https://dhakachamber.com/b2b)
    -   [B2B Member Login](https://dhakachamber.com/login)
    -   [B2B Registration](https://dhakachamber.com/b2b-reg)