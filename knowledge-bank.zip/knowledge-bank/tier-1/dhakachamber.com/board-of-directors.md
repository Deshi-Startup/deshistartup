---
source: "Dhaka Chamber of Commerce & Industry (DCCI)"
tier: 1
category: "Chamber"
url: "https://dhakachamber.com/board-of-directors"
title: "DCCI ::  Board of Directors"
scraped_at: "2026-07-02"
---

# Board of Directors

![](https://dhakachamber.com/storage/board-members/April2025/Omw4HKox54UujRvNp8Lu.jpg)

### TASKEEN AHMED

President

![](https://dhakachamber.com/storage/board-members/December2024/pQCKfuVCCq8SDq59Yd6T.jpg)

### RAZEEV H CHOWDHURY

Sr. Vice President

![](https://dhakachamber.com/storage/board-members/December2024/XGvTPhmak35tr1YzTCzf.jpg)

### MD. SALEM SULAIMAN

Vice President

![](https://dhakachamber.com/storage/board-members/December2024/hEr4M3G2yamh5PKn9ryX.jpg)

### ASHRAF AHMED

Director & Immediate Former President

![](https://dhakachamber.com/storage/board-members/December2024/rQEOjjKPdKUgatc4FlXv.jpg)

### ENAMUL HAQUE PATWARY

Director

![](https://dhakachamber.com/storage/board-members/December2023/a6JTf1d8kORXbUp6f5nF.jpg)

### ENGR. M A WAHAB

Director

![](https://dhakachamber.com/storage/board-members/December2025/bi3ZYfrUKW24WmDwWOea.jpeg)

### FURKAAN MUHAMMAD N HOSSAIN

Director

![](https://dhakachamber.com/storage/board-members/December2023/nJFWNIFcKBRdiPufiL1f.jpg)

### KAMRUL HASAN TUHIN

Director

![](https://dhakachamber.com/storage/board-members/December2023/rY52swzWBhBwlV7SkOl4.jpg)

### M. MOSHARROF HOSSAIN

Director

![](https://dhakachamber.com/storage/board-members/December2024/1MHlcolyyVT2Esq3kKAL.jpg)

### MD. MOSTAFA KAMAL, PEng

Director

![](https://dhakachamber.com/storage/board-members/December2024/coWJkcstiuVw2CzX2Gfe.jpg)

### MD. SIAAM AL-DDIN MALIK

Director

![](https://dhakachamber.com/storage/board-members/December2024/Yu1pTW2grZJRJ7ri37DO.jpg)

### MINHAJ AHMED

Director

![](https://dhakachamber.com/storage/board-members/December2023/uapOewoOrzwaP0oBpN5k.jpg)

### MOHAMMAD SAIFUR RAHMAN SAIF

Director

![](https://dhakachamber.com/storage/board-members/December2024/s86kcgW1Sk9KAnhF8DJR.jpg)

### MUHAMMAD ZAMSHER ALI

Director

![](https://dhakachamber.com/storage/board-members/December2023/5tIkLcjfA7h5eibjagr5.jpg)

### NAYEEMUR RAHMAN

Director

![](https://dhakachamber.com/storage/board-members/December2024/lXwXfCU5mNuWSQ9UgsFV.jpg)

### RASHEED MYMUNUL ISLAM

Director

![](https://dhakachamber.com/storage/board-members/December2023/jkptf30gMO6aAvzmcmkW.jpg)

### SAIF UDDOWLAH

Director

![](https://dhakachamber.com/storage/board-members/April2023/OdwPhaMhGNi7G5JPikGJ.jpg)

### SYED MAMNUN QUADER

Director

### ABOUT US

-   [Board of Directors](https://dhakachamber.com/board-of-directors)
-   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
-   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)

### USEFUL LINKS

-   [DBI College](http://www.dbicollege.edu.bd)
-   [DCCI Business Institute](http://dcci-dbi.edu.bd)
-   [BUILD](http://www.buildbd.org)
-   [BIAC](https://www.biac.org.bd)
-   [ICCB](https://iccbangladesh.org.bd)

### MEMBERSHIP

-   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
-   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
-   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
-   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
-   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
-   [Become a Member](https://membership.dhakachamber.com/register)
-   [Member Login](https://membership.dhakachamber.com)
-   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
-   [Member Query](https://dhakachamber.com/member-query)
-   [Hot Line](https://dhakachamber.com/hot_line)

### MEDIA

-   [Chamber News](https://dhakachamber.com/media/news)
-   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
-   [Photo Gallery](https://dhakachamber.com/albums)
-   [Video Gallery](https://dhakachamber.com/videos)

### DOWNLOAD

-   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
-   [DCCI Reviews](https://dhakachamber.com/publications/reviews)
-   [DCCI Publications](https://dhakachamber.com/publications)
-   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
-   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)

×

-   [Home(current)](https://dhakachamber.com)
-   [About us](#)
    -   [Brief About DCCI](https://dhakachamber.com/about-us)
    -   [International Affiliations](https://dhakachamber.com/international-affiliations)
    -   [DCCI Founders](https://dhakachamber.com/dcci-founders)
    -   [Former Presidents](https://dhakachamber.com/dcci-former-presidents)
    -   [Former Senior Vice Presidents](https://dhakachamber.com/dcci-former-senior-vice-presidents)
    -   [Former Vice Presidents](https://dhakachamber.com/dcci-former-vice-presidents)
    -   [Achievements & Awards](https://dhakachamber.com/achievements-awards)
    -   [Policy and Objectives](https://dhakachamber.com/quality-policy-and-objectives)
-   [Organizational Information](#)
    -   [Board of Directors](https://dhakachamber.com/board-of-directors)
    -   [Previous Board of Directors](https://dhakachamber.com/dcci-allpastmanagement)
    -   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
    -   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)
-   [President](https://dhakachamber.com/president)
-   [Membership](#)
    -   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
    -   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
    -   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
    -   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
    -   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
    -   [Become a Member](https://membership.dhakachamber.com/register)
    -   [Member Login](https://membership.dhakachamber.com)
    -   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
    -   [Member Query](https://dhakachamber.com/member-query)
    -   [Hot Line](https://dhakachamber.com/hot_line)
-   [Projects](https://dhakachamber.com/project-activities)
-   [Seminar](https://dhakachamber.com/media/seminar)
-   [Publications](#)
    -   [DCCI Research Service](https://dhakachamber.com/pdf_viewer/storage/2024/circular/DCCI%20Research%20Service.pdf)
    -   [Research Guideline](https://dhakachamber.com/pdf_viewer/storage/2024/circular/Research%20Guideline.pdf)
    -   [DCCI Journal (DJBEP)](https://journal.dhakachamber.com/)
    -   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
    -   [DCCI Review](https://dhakachamber.com/publications/reviews)
    -   [DCCI Publications](https://dhakachamber.com/publications)
    -   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
    -   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)
    -   [Introducing DCCI 2023](https://www.dhakachamber.com/storage/print_media/2023/07/Introducing%202023.pdf)
-   [Media](#)
    -   [Chamber News](https://dhakachamber.com/media/news)
    -   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
    -   [Photo Gallery](https://dhakachamber.com/albums)
    -   [Video Gallery](https://dhakachamber.com/videos)
    -   [Fairs & Exhibitions](https://www.dhakachamber.com/storage/2026/03/dccifair.pdf)
-   [Policy](#)
    -   [Export Policy](https://www.dhakachamber.com/storage/policy/3VFoMxkr6Z3EZdC8wz7YHfrIBfPP5N0Y6n7eEEFJ.pdf)
    -   [Import Policy](https://www.dhakachamber.com/storage/policy/b6uhXGhpdl30N68gl3Yg9mV5P6vGIPAjquqTu35f.pdf)
    -   [Industry Policy](https://www.dhakachamber.com/storage/policy/kpHRSdbYmY90O7wcyYmkZTSvumKEXfz5uwPTlOn5.pdf)
    -   [ICT Policy](https://www.dhakachamber.com/storage/policy/abTlbODgI2I4Aqbrix5Cs2DHvFD5lW3OwDmfKXmH.pdf)
-   [BILATERAL TRADE](#)
    -   [Bilateral Trade](https://dhakachamber.com/bilateral-trade)
    -   [Africa](https://dhakachamber.com/bilateral-trade/africa)
    -   [America](https://dhakachamber.com/bilateral-trade/america)
    -   [Asian](https://dhakachamber.com/bilateral-trade/asian)
    -   [ASEAN](https://dhakachamber.com/bilateral-trade/asean)
    -   [SAARC](https://dhakachamber.com/bilateral-trade/saarc)
    -   [Middle East](https://dhakachamber.com/bilateral-trade/middle-east)
    -   [European Union](https://dhakachamber.com/bilateral-trade/european-union)
-   [About Bangladesh](#)
    -   [General Information](https://dhakachamber.com/bangladesh-country-profile)
    -   [Business Opportunities in Bangladesh](https://dhakachamber.com/trade-and-business-opportunities-in-bangladesh)
    -   [Useful Links](https://dhakachamber.com/useful-links)
-   [B2B Directory](#)
    -   [B2B Directory](https://dhakachamber.com/b2b)
    -   [B2B Member Login](https://dhakachamber.com/login)
    -   [B2B Registration](https://dhakachamber.com/b2b-reg)

×

![President](https://dhakachamber.com/storage/board-members/April2025/Omw4HKox54UujRvNp8Lu.jpg)

* * *

#### Corporate Address

Ifad Tower, 7 Tejgaon I/A  
Dhaka-1208, Bangladesh.  
  
Mobile: +88-01711541919  
Mobile: +88-01720033180 (PS to President)  
E-mail: president@dhakachamber.com  
taskeenahmed@ifadgroup.com  
Web: www.dhakachamber.com  
www.ifadgroup.com/ifad-motors-ltd

![President](https://dhakachamber.com/storage/board-members/April2025/Omw4HKox54UujRvNp8Lu.jpg)

* * *

### TASKEEN AHMED

President

* * *

#### Vice Chairman

Ifad Group

* * *

#### Corporate Address

Ifad Tower, 7 Tejgaon I/A  
Dhaka-1208, Bangladesh.  
  
Mobile: +88-01711541919  
Mobile: +88-01720033180 (PS to President)  
E-mail: president@dhakachamber.com  
taskeenahmed@ifadgroup.com  
Web: www.dhakachamber.com  
www.ifadgroup.com/ifad-motors-ltd

* * *

#### Line of Business:

Automobiles, FMCG

×

![Sr. Vice President](https://dhakachamber.com/storage/board-members/December2024/pQCKfuVCCq8SDq59Yd6T.jpg)

* * *

#### Corporate Address

Apt#1B, H-30, Rd#111  
Gulshan–2, Dhaka-1212, Bangladesh.  
Mobile: +88-01724802209  
E-mail: svp@dhakachamber.com  
razeevc@ddebd.com  
Web: www.ddebd.com  
www.microsec.co.uk  
www.watchesworldbd.com

![Sr. Vice President](https://dhakachamber.com/storage/board-members/December2024/pQCKfuVCCq8SDq59Yd6T.jpg)

* * *

### RAZEEV H CHOWDHURY

Sr. Vice President

* * *

#### Proprietor

Defense Dynamics Enterprise

#### Managing Director

MICROSEC International Ltd.  
(A British-Bangladesh JV IT Company)  
Defense Dynamics Enterprise Ltd.  
Arco Cold Storage Ltd.  
Watches World Ltd.

* * *

#### Corporate Address

Apt#1B, H-30, Rd#111  
Gulshan–2, Dhaka-1212, Bangladesh.  
Mobile: +88-01724802209  
E-mail: svp@dhakachamber.com  
razeevc@ddebd.com  
Web: www.ddebd.com  
www.microsec.co.uk  
www.watchesworldbd.com

* * *

#### Line of Business:

Trading, Retail, Government and Defense indenting, Cold storage, Infrastructure development, Information technology (IT)

×

![Vice President](https://dhakachamber.com/storage/board-members/December2024/XGvTPhmak35tr1YzTCzf.jpg)

* * *

#### Corporate Address

Massons Building (Level#2)  
2/A Abul Hasnat Road  
Dhaka-1100, Bangladesh.  
Tel: +88-02-57318979, 57316243  
Fax: +88-02-57314707  
Mobile: +88-01819227305  
E-mail: vp@dhakachamber.com  
massons@dhaka.net  
Website: massonsgroupbd.com

![Vice President](https://dhakachamber.com/storage/board-members/December2024/XGvTPhmak35tr1YzTCzf.jpg)

* * *

### MD. SALEM SULAIMAN

Vice President

* * *

#### Managing Director

Massons Polymer Corporation  
Lalbagh Metal Industries Ltd.  
Champion & Massons Ltd.  
Ssamsons Corporation

* * *

#### Corporate Address

Massons Building (Level#2)  
2/A Abul Hasnat Road  
Dhaka-1100, Bangladesh.  
Tel: +88-02-57318979, 57316243  
Fax: +88-02-57314707  
Mobile: +88-01819227305  
E-mail: vp@dhakachamber.com  
massons@dhaka.net  
Website: massonsgroupbd.com

* * *

#### Line of Business:

Polymers, PVC Resin, EVA, GPPS, HIPS, Pet Chips, Stearic Acid, Tapioca Starch, Raw Rubber, SBR, BR, Food Products, Petrochemicals & Industrial Chemicals.

×

![Director  & Immediate Former President](https://dhakachamber.com/storage/board-members/December2024/hEr4M3G2yamh5PKn9ryX.jpg)

* * *

#### Corporate Address

House#10, Road#6, Block#C  
Banani, Dhaka-1213, Bangladesh.  
Tel: +88-02-9898190, 9898203  
Mobile: +88-01720033180 (PS)  
Email: md@riveretone.com.bd  
Web: www.dhakachamber.com  
www.riverstone.com.bd

![Director  & Immediate Former President](https://dhakachamber.com/storage/board-members/December2024/hEr4M3G2yamh5PKn9ryX.jpg)

* * *

### ASHRAF AHMED

Director & Immediate Former President

* * *

#### Chief Executive Officer

Riverstone Capital Limited

* * *

#### Corporate Address

House#10, Road#6, Block#C  
Banani, Dhaka-1213, Bangladesh.  
Tel: +88-02-9898190, 9898203  
Mobile: +88-01720033180 (PS)  
Email: md@riveretone.com.bd  
Web: www.dhakachamber.com  
www.riverstone.com.bd

* * *

#### Line of Business:

Merchant Banking

×

![Director](https://dhakachamber.com/storage/board-members/December2024/rQEOjjKPdKUgatc4FlXv.jpg)

* * *

#### Corporate Address

Karim Chamber (1st floor)  
Room # 203, 99 Motijheel C/A  
Dhaka-1000, Bangladesh  
  
Mobile: +88-01711-642184, +88-01711-547655  
E-mail:jute.bags@ymail.com  
expojute@gmail.com

![Director](https://dhakachamber.com/storage/board-members/December2024/rQEOjjKPdKUgatc4FlXv.jpg)

* * *

### ENAMUL HAQUE PATWARY

Director

* * *

#### Proprietor

Jute & Bags Export Corporation

* * *

#### Corporate Address

Karim Chamber (1st floor)  
Room # 203, 99 Motijheel C/A  
Dhaka-1000, Bangladesh  
  
Mobile: +88-01711-642184, +88-01711-547655  
E-mail:jute.bags@ymail.com  
expojute@gmail.com

* * *

#### Line of Business:

Exporter of Raw Jute and Jute Goods, Import, Sourcing Agent, etc.

×

![Director](https://dhakachamber.com/storage/board-members/December2023/a6JTf1d8kORXbUp6f5nF.jpg)

* * *

#### Corporate Address

House#12 (2nd Floor), Road#16/A  
Gulshan-1, Dhaka-1212, Bangladesh.  
Tel: +88-02-222261748  
Mobile: +88-01711-596377  
E-mail: wahabca59@gmail.com

![Director](https://dhakachamber.com/storage/board-members/December2023/a6JTf1d8kORXbUp6f5nF.jpg)

* * *

### ENGR. M A WAHAB

Director

* * *

#### Managing Director

Accurate Technology Ltd.

* * *

#### Corporate Address

House#12 (2nd Floor), Road#16/A  
Gulshan-1, Dhaka-1212, Bangladesh.  
Tel: +88-02-222261748  
Mobile: +88-01711-596377  
E-mail: wahabca59@gmail.com

* * *

#### Line of Business:

Construction, Developer

×

![Director](https://dhakachamber.com/storage/board-members/December2025/bi3ZYfrUKW24WmDwWOea.jpeg)

* * *

#### Corporate Address

Baitul Hossain Building  
27 Dilkusha, Commercial Area  
Dhaka-1000, Bangladesh  
Telephone: 8802223384037 (Hotline: 16685),  
Mobile: 01329673777  
E-mail: furkaan.hossain@anwargroup.com  
Website: www.anwargroup.com

![Director](https://dhakachamber.com/storage/board-members/December2025/bi3ZYfrUKW24WmDwWOea.jpeg)

* * *

### FURKAAN MUHAMMAD N HOSSAIN

Director

* * *

#### Managing Director

Anwar Enterprise Systems Limited

#### Deputy Managing Director

Anwar Group of Industries

* * *

#### Corporate Address

Baitul Hossain Building  
27 Dilkusha, Commercial Area  
Dhaka-1000, Bangladesh  
Telephone: 8802223384037 (Hotline: 16685),  
Mobile: 01329673777  
E-mail: furkaan.hossain@anwargroup.com  
Website: www.anwargroup.com

* * *

#### Line of Business:

Import, Export, Supply, IT, Software & Hardware

×

![Director](https://dhakachamber.com/storage/board-members/December2023/nJFWNIFcKBRdiPufiL1f.jpg)

* * *

#### Corporate Address

26/1-26/2, Dr. Kudrat-E-Khuda Road  
Suite No# 7/30 (7th Floor), Eastern Mollika  
Dhaka-1205, Bangladesh.  
Tel: +88-02223363698  
Mobile: +88-01922 337 799  
E-mail: tuhinkhn@gmail.com tuhin@iqinternationalbd.com

![Director](https://dhakachamber.com/storage/board-members/December2023/nJFWNIFcKBRdiPufiL1f.jpg)

* * *

### KAMRUL HASAN TUHIN

Director

* * *

#### Proprietor

IQ International

* * *

#### Corporate Address

26/1-26/2, Dr. Kudrat-E-Khuda Road  
Suite No# 7/30 (7th Floor), Eastern Mollika  
Dhaka-1205, Bangladesh.  
Tel: +88-02223363698  
Mobile: +88-01922 337 799  
E-mail: tuhinkhn@gmail.com tuhin@iqinternationalbd.com

* * *

#### Line of Business:

Import and Export

×

![Director](https://dhakachamber.com/storage/board-members/December2023/rY52swzWBhBwlV7SkOl4.jpg)

* * *

#### Corporate Address

Pritam Zaman Tower (9th Floor)  
37/2 Purana Paltan, Box-Culvert Road  
Dhaka-1000, Bangladesh.  
Tel: +88-02-226638314  
Fax: +88-02-9331066  
Mobile: +88-01713002066  
E-mail: aots\_bd@yahoo.com

![Director](https://dhakachamber.com/storage/board-members/December2023/rY52swzWBhBwlV7SkOl4.jpg)

* * *

### M. MOSHARROF HOSSAIN

Director

* * *

#### Proprietor & CEO

Advance Office Technology & Services (AOTS)

#### Advisor

MSK Ship management & Chartering Ltd.

* * *

#### Corporate Address

Pritam Zaman Tower (9th Floor)  
37/2 Purana Paltan, Box-Culvert Road  
Dhaka-1000, Bangladesh.  
Tel: +88-02-226638314  
Fax: +88-02-9331066  
Mobile: +88-01713002066  
E-mail: aots\_bd@yahoo.com

* * *

#### Line of Business:

CMICO Brand Bank Note Counting Machine, Coin Counting Machine & Bank Note Binding, Stapping Machine, X-Ray Baggage Scanner

×

![Director](https://dhakachamber.com/storage/board-members/December2024/1MHlcolyyVT2Esq3kKAL.jpg)

* * *

#### Corporate Address

House-595 (3rd & 6th Floor), Road-09  
Mirpur DOHS, Dhaka Cantonment  
Mirpur, Dhaka-1216, Bangladesh  
  
Telephone: +88-02-58070854-856  
Mobile: +88-01711-821182  
E-mail: kamalorj@gmail.com  
kamal@bnfbd.org

![Director](https://dhakachamber.com/storage/board-members/December2024/1MHlcolyyVT2Esq3kKAL.jpg)

* * *

### MD. MOSTAFA KAMAL, PEng

Director

* * *

#### Managing Director

BNF Engineers Ltd.

#### Chairman

Needs Engineers & Development Ltd.

#### Executive Director

Needs Bay Watch

Needs Hill View

#### Managing Partner

Needs Engineers

The Daily Gonosurja

* * *

#### Corporate Address

House-595 (3rd & 6th Floor), Road-09  
Mirpur DOHS, Dhaka Cantonment  
Mirpur, Dhaka-1216, Bangladesh  
  
Telephone: +88-02-58070854-856  
Mobile: +88-01711-821182  
E-mail: kamalorj@gmail.com  
kamal@bnfbd.org

* * *

#### Line of Business:

Commercial and Residential Buildings

×

![Director](https://dhakachamber.com/storage/board-members/December2024/coWJkcstiuVw2CzX2Gfe.jpg)

* * *

#### Corporate Address

2 Kamal Daha Road, Posta, Chawk Bazar  
Dhaka-1211, Bangladesh.  
Mobile: +88-01777455881  
E-mail: siaam\_6600@hotmail.com

![Director](https://dhakachamber.com/storage/board-members/December2024/coWJkcstiuVw2CzX2Gfe.jpg)

* * *

### MD. SIAAM AL-DDIN MALIK

Director

* * *

#### Proprietor

Siaam Enterprise

* * *

#### Corporate Address

2 Kamal Daha Road, Posta, Chawk Bazar  
Dhaka-1211, Bangladesh.  
Mobile: +88-01777455881  
E-mail: siaam\_6600@hotmail.com

* * *

#### Line of Business:

Selling

×

![Director](https://dhakachamber.com/storage/board-members/December2024/Yu1pTW2grZJRJ7ri37DO.jpg)

* * *

#### Corporate Address

Ahmed Food Bhaban  
M/4/4, Road#7, Section#7  
Mirpur, Dhaka 1216, Bangladesh.  
  
Telephone: +88-01987877877  
Mobile: +88-01937444222  
E-mail: ahmedfd@dhaka.net

![Director](https://dhakachamber.com/storage/board-members/December2024/Yu1pTW2grZJRJ7ri37DO.jpg)

* * *

### MINHAJ AHMED

Director

* * *

#### Managing Director

Ahmed Food Products (Pvt.) Ltd.

* * *

#### Corporate Address

Ahmed Food Bhaban  
M/4/4, Road#7, Section#7  
Mirpur, Dhaka 1216, Bangladesh.  
  
Telephone: +88-01987877877  
Mobile: +88-01937444222  
E-mail: ahmedfd@dhaka.net

* * *

#### Line of Business:

Food processing and Manufacturer

×

![Director](https://dhakachamber.com/storage/board-members/December2023/uapOewoOrzwaP0oBpN5k.jpg)

* * *

#### Corporate Address

Bashati Dream, House#03, A-2(2nd Floor)  
Road#20, Gulshan-1  
Dhaka-1212, Bangladesh.  
Tel: +88-02-222264074  
Mobile: +88-01711588343,  
+88-01708427001  
E-mail: saifrahman@fatbd.com

![Director](https://dhakachamber.com/storage/board-members/December2023/uapOewoOrzwaP0oBpN5k.jpg)

* * *

### MOHAMMAD SAIFUR RAHMAN SAIF

Director

* * *

#### Director

Fair and Appropriate Technology Limited

#### Managing Director

Shayan Resort

* * *

#### Corporate Address

Bashati Dream, House#03, A-2(2nd Floor)  
Road#20, Gulshan-1  
Dhaka-1212, Bangladesh.  
Tel: +88-02-222264074  
Mobile: +88-01711588343,  
+88-01708427001  
E-mail: saifrahman@fatbd.com

* * *

#### Line of Business:

Telecommunication, IT Sector Construction, Hotel and Tourism, Education, Commodities Trade, Import

×

![Director](https://dhakachamber.com/storage/board-members/December2024/s86kcgW1Sk9KAnhF8DJR.jpg)

* * *

#### Corporate Address

38-C Postogola, DIT Plot I/A  
Shampur, Dhaka-1204, Bangladesh  
Telephone: +88-02-47450921  
Mobile: +88-01911151177, 01720004147  
E-mail: mdzamsherali@gmail.com

![Director](https://dhakachamber.com/storage/board-members/December2024/s86kcgW1Sk9KAnhF8DJR.jpg)

* * *

### MUHAMMAD ZAMSHER ALI

Director

* * *

#### Proprietor

Sony Lubricants Center

#### Managing Director

Asian Petrochemicals Limited

* * *

#### Corporate Address

38-C Postogola, DIT Plot I/A  
Shampur, Dhaka-1204, Bangladesh  
Telephone: +88-02-47450921  
Mobile: +88-01911151177, 01720004147  
E-mail: mdzamsherali@gmail.com

* * *

#### Line of Business:

Lubricants and Chemicals (Import, Export, Manufacturer and Distributor

×

![Director](https://dhakachamber.com/storage/board-members/December2023/5tIkLcjfA7h5eibjagr5.jpg)

* * *

#### Corporate Address

Uttara Centre  
102 Shahid Tajuddin Ahmed Sarani  
Tejgaon Industrial Area  
Dhaka-1208, Bangladesh.  
Tel: +88-02-8144330 (Hunting)  
Mobile: +88-01730011700  
E-mail: nmr@ugc-bd.net

![Director](https://dhakachamber.com/storage/board-members/December2023/5tIkLcjfA7h5eibjagr5.jpg)

* * *

### NAYEEMUR RAHMAN

Director

* * *

#### Director (Head of Business Planning)

Uttara Motors Limited

* * *

#### Corporate Address

Uttara Centre  
102 Shahid Tajuddin Ahmed Sarani  
Tejgaon Industrial Area  
Dhaka-1208, Bangladesh.  
Tel: +88-02-8144330 (Hunting)  
Mobile: +88-01730011700  
E-mail: nmr@ugc-bd.net

* * *

#### Line of Business:

Manufacturing & Assembling: Automobiles

×

![Director](https://dhakachamber.com/storage/board-members/December2024/lXwXfCU5mNuWSQ9UgsFV.jpg)

* * *

#### Corporate Address

Haque Tower, 12th Floor, JA-28/8 D,  
Bir Uttam A.K Khondoker Road, Mohakhali C/A, Dhaka-1212  
Telephone: +88-02-223382185  
Mobile: +88-01711425244  
E-mail: rasheed.islam@monno.com

![Director](https://dhakachamber.com/storage/board-members/December2024/lXwXfCU5mNuWSQ9UgsFV.jpg)

* * *

### RASHEED MYMUNUL ISLAM

Director

* * *

#### Managing Director

Monno Ceramic Industries Limited

#### Deputy Managing Director

Monno Agro & General Machinery Ltd.

#### Director

Monno Fabrics Ltd.

#### Chief Executive Officer

MARS Retail Ltd.

* * *

#### Corporate Address

Haque Tower, 12th Floor, JA-28/8 D,  
Bir Uttam A.K Khondoker Road, Mohakhali C/A, Dhaka-1212  
Telephone: +88-02-223382185  
Mobile: +88-01711425244  
E-mail: rasheed.islam@monno.com

* * *

#### Line of Business:

Legal consutancy and avdisory services

×

![Director](https://dhakachamber.com/storage/board-members/December2023/jkptf30gMO6aAvzmcmkW.jpg)

* * *

#### Corporate Address

ABC Heritage (3rd Floor), Plot#2&4  
Jashim Uddin Avenue, Sector#3  
Uttara, Dhaka-1230, Bangladesh  
Tel: +88-02-48961701-3  
Mobile: +88-01713244941  
E-mail: saifuddowlah@petrochembd.com  
Website: www.petrochembd.com

![Director](https://dhakachamber.com/storage/board-members/December2023/jkptf30gMO6aAvzmcmkW.jpg)

* * *

### SAIF UDDOWLAH

Director

* * *

#### Managing Director

Petrochem Group  
Petrochem (Bangladesh) Limited  
Petrochem Agro Industries Limited  
Solar Power Limited  
International Services Limited  
Bangla Solar IT  
Growvita Agro Limited

#### Director

Habitat Builders Limited

* * *

#### Corporate Address

ABC Heritage (3rd Floor), Plot#2&4  
Jashim Uddin Avenue, Sector#3  
Uttara, Dhaka-1230, Bangladesh  
Tel: +88-02-48961701-3  
Mobile: +88-01713244941  
E-mail: saifuddowlah@petrochembd.com  
Website: www.petrochembd.com

* * *

#### Line of Business:

Seed, Fertilizer, Pesticide, LED Lights, Solar Irrigation, Solar Roof Top Solutions, IPP Consultation, Machinery, Vegetable and Fruit Processing

×

![Director](https://dhakachamber.com/storage/board-members/April2023/OdwPhaMhGNi7G5JPikGJ.jpg)

* * *

#### Corporate Address

Haji Komor Uddin Tower (3rd Floor, West Side)  
27 Ashkona, Dakshinkhan  
Dhaka 1230, Bangladesh.  
Tel: +88-02-58951905, 58951809,  
58954170, 58956331  
Fax: +88-02-58954251  
Mobile: +88-01819224701  
E-mail: syed.quader@southtechgroup.com

![Director](https://dhakachamber.com/storage/board-members/April2023/OdwPhaMhGNi7G5JPikGJ.jpg)

* * *

### SYED MAMNUN QUADER

Director

* * *

#### Managing Director

Southtech Limited

* * *

#### Corporate Address

Haji Komor Uddin Tower (3rd Floor, West Side)  
27 Ashkona, Dakshinkhan  
Dhaka 1230, Bangladesh.  
Tel: +88-02-58951905, 58951809,  
58954170, 58956331  
Fax: +88-02-58954251  
Mobile: +88-01819224701  
E-mail: syed.quader@southtechgroup.com

* * *

#### Line of Business:

Information Technology and Software Development