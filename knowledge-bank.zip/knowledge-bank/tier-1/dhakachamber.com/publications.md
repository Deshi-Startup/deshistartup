---
source: "Dhaka Chamber of Commerce & Industry (DCCI)"
tier: 1
category: "Chamber"
url: "http://dhakachamber.com/publications"
title: "DCCI ::  DCCI Publications"
scraped_at: "2026-07-02"
---

# DCCI Publications

[![Dhaka Chamber Business Delegation](https://dhakachamber.com/storage/publications/April2026/Z08eewp1hGbgcBIxrmzz.PNG)](https://dhakachamber.com/pdf_viewer/storage/publications/April2026/48FGUnIZrQGxbQNHPsHC.pdf)

#### [Dhaka Chamber Business Delegation](https://dhakachamber.com/pdf_viewer/storage/publications/April2026/48FGUnIZrQGxbQNHPsHC.pdf)

[![Tax Guide 2024-2025](https://dhakachamber.com/storage/publications/October2025/XHSEDa0jDsmXwxhNShCS.PNG)](https://dhakachamber.com/pdf_viewer/storage/publications/October2025/VKcndRWn4dTwsid5EhtG.pdf)

#### [Tax Guide 2024-2025](https://dhakachamber.com/pdf_viewer/storage/publications/October2025/VKcndRWn4dTwsid5EhtG.pdf)

[![Dhaka Chamber Business Delegation](https://dhakachamber.com/storage/publications/April2026/SbQfq74seMvKLGooQRnM.PNG)](https://dhakachamber.com/pdf_viewer/storage/publications/April2026/r5NPG37UNBRgTjaU5wsS.pdf)

#### [Dhaka Chamber Business Delegation](https://dhakachamber.com/pdf_viewer/storage/publications/April2026/r5NPG37UNBRgTjaU5wsS.pdf)

[![Dhaka Chamber Business Delegation](https://dhakachamber.com/storage/publications/June2025/F7aKN4q9ukjNeNkxRgmz.PNG)](https://dhakachamber.com/pdf_viewer/storage/publications/June2025/Bjqi9fXvpxw0Qajfje8W.pdf)

#### [Dhaka Chamber Business Delegation](https://dhakachamber.com/pdf_viewer/storage/publications/June2025/Bjqi9fXvpxw0Qajfje8W.pdf)

[![Tax Guide 2023-2024](https://dhakachamber.com/storage/publications/October2024/paacKdfbhxoz8K8DtPPB.jpg)](https://dhakachamber.com/pdf_viewer/storage/publications/October2024/OxPDRnmKwYyjD86ifUs3.pdf)

#### [Tax Guide 2023-2024](https://dhakachamber.com/pdf_viewer/storage/publications/October2024/OxPDRnmKwYyjD86ifUs3.pdf)

[![Tax Guide 2022-2023](https://dhakachamber.com/storage/publications/October2024/oQCwVvueb1UE0GqaOhl1.PNG)](https://dhakachamber.com/pdf_viewer/storage/publications/October2024/OdlkpjSIebHEYE3zxwNr.pdf)

#### [Tax Guide 2022-2023](https://dhakachamber.com/pdf_viewer/storage/publications/October2024/OdlkpjSIebHEYE3zxwNr.pdf)

[![Dhaka Chamber Business Delegation](https://dhakachamber.com/storage/publications/August2024/y0oJ5pOGF11gUPYsCwsn.PNG)](https://dhakachamber.com/pdf_viewer/storage/publications/August2024/96WSGjrXq9S1P7eKAfNo.pdf)

#### [Dhaka Chamber Business Delegation](https://dhakachamber.com/pdf_viewer/storage/publications/August2024/96WSGjrXq9S1P7eKAfNo.pdf)

[![Dhaka Chamber Business Delegation](https://dhakachamber.com/storage/publications/October2023/XCtIvK2dNM73rZVYFvCe.PNG)](https://dhakachamber.com/pdf_viewer/storage/publications/October2023/ekGxBhzXQdhzyQP56pDb.pdf)

#### [Dhaka Chamber Business Delegation](https://dhakachamber.com/pdf_viewer/storage/publications/October2023/ekGxBhzXQdhzyQP56pDb.pdf)

[![Easy Access to CMSME Financing](https://dhakachamber.com/storage/publications/November2022/F3PhqsXZ3zH1J6UHgMi8.PNG)](https://dhakachamber.com/pdf_viewer/storage/publications/November2022/hgbIhRkLsMvlywDBEXLL.pdf)

#### [Easy Access to CMSME Financing](https://dhakachamber.com/pdf_viewer/storage/publications/November2022/hgbIhRkLsMvlywDBEXLL.pdf)

[![Dhaka Chamber Business Delegation](https://dhakachamber.com/storage/publications/November2022/9RuDLeEu8YJh9ubkTcrR.jpg)](https://dhakachamber.com/pdf_viewer/storage/publications/October2022/GnhyApUvInEWbcJ7OTum.pdf)

#### [Dhaka Chamber Business Delegation](https://dhakachamber.com/pdf_viewer/storage/publications/October2022/GnhyApUvInEWbcJ7OTum.pdf)

[![Dhaka Chamber Business Delegation](https://dhakachamber.com/storage/publications/November2022/aA6Iit0ebbPnZpwaWpI0.jpg)](https://dhakachamber.com/pdf_viewer/storage/publications/November2022/1iGhQQE9gvrE0mT4SrEO.pdf)

#### [Dhaka Chamber Business Delegation](https://dhakachamber.com/pdf_viewer/storage/publications/November2022/1iGhQQE9gvrE0mT4SrEO.pdf)

[![Tax Guide 2021-2022](https://dhakachamber.com/storage/publications/December2022/4ZuxqRE5GoEsDSQ8HNeJ.PNG)](https://dhakachamber.com/pdf_viewer/storage/publications/December2022/qcmtAnLewfhAqaSkQQwr.pdf)

#### [Tax Guide 2021-2022](https://dhakachamber.com/pdf_viewer/storage/publications/December2022/qcmtAnLewfhAqaSkQQwr.pdf)

[![Tax Guide 2020-2021](https://dhakachamber.com/storage/publications/October2021/XqAtVhTCjLt8ZJxxelVh.JPG)](https://dhakachamber.com/pdf_viewer/storage/publications/October2021/9BPttRyboDCVXjIsA3nm.pdf)

#### [Tax Guide 2020-2021](https://dhakachamber.com/pdf_viewer/storage/publications/October2021/9BPttRyboDCVXjIsA3nm.pdf)

[![Tax Guide 2019-2020](https://dhakachamber.com/storage/publications/February2020/k1duZslBsgYkZHESqvpL.PNG)](https://dhakachamber.com/pdf_viewer/storage/publications/February2020/uW3xBgak0wzJTWV3FWQR.pdf)

#### [Tax Guide 2019-2020](https://dhakachamber.com/pdf_viewer/storage/publications/February2020/uW3xBgak0wzJTWV3FWQR.pdf)

[![Commercial History of Dhaka](https://dhakachamber.com/storage/publications/October2019/kJiuJfDRnP8fQDdbiSAF.jpg)](https://dhakachamber.com/pdf_viewer/storage/publications/October2018/gzkglBHsAaYwqlUybwD7.pdf)

#### [Commercial History of Dhaka](https://dhakachamber.com/pdf_viewer/storage/publications/October2018/gzkglBHsAaYwqlUybwD7.pdf)

[![Business Start-up Licenses A Regulatory Guide](https://dhakachamber.com/storage/publications/October2019/5ql1DNLJNfYCSCGUp3E9.jpg)](https://dhakachamber.com/pdf_viewer/storage/publications/October2018/ocVAdqbKbAlrGGWulRqi.pdf)

#### [Business Start-up Licenses A Regulatory Guide](https://dhakachamber.com/pdf_viewer/storage/publications/October2018/ocVAdqbKbAlrGGWulRqi.pdf)

[![Bangladesh 2030](https://dhakachamber.com/storage/publications/June2019/E3Yt5dNhRcMmRDZeNOaP.JPG)](https://dhakachamber.com/pdf_viewer/storage/publications/June2019/AF0ccgNsWafKVdLozy7P.pdf)

#### [Bangladesh 2030](https://dhakachamber.com/pdf_viewer/storage/publications/June2019/AF0ccgNsWafKVdLozy7P.pdf)

[![Capital Market Leaflet](https://dhakachamber.com/storage/publications/October2019/eiIaflEKxCP3qAfQV80g.jpg)](https://dhakachamber.com/pdf_viewer/storage/publications/June2019/aFg7UWF4viyXl0ECECQd.pdf)

#### [Capital Market Leaflet](https://dhakachamber.com/pdf_viewer/storage/publications/June2019/aFg7UWF4viyXl0ECECQd.pdf)

[![Trade-License-Schedule-2016](https://dhakachamber.com/storage/publications/June2019/79g0Qge2hhQ3NUTpBQj5.JPG)](https://dhakachamber.com/pdf_viewer/storage/publications/June2019/UovQGeIPh10J8c4BgnYe.pdf)

#### [Trade-License-Schedule-2016](https://dhakachamber.com/pdf_viewer/storage/publications/June2019/UovQGeIPh10J8c4BgnYe.pdf)

### ABOUT US

-   [Board of Directors](https://dhakachamber.com/board-of-directors)
-   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
-   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)

### USEFUL LINKS

-   [DBI College](http://www.dbicollege.edu.bd)
-   [DCCI Business Institute](http://dcci-dbi.edu.bd)
-   [BUILD](http://www.buildbd.org)
-   [BIAC](https://www.biac.org.bd)
-   [ICCB](https://iccbangladesh.org.bd)

### MEMBERSHIP

-   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
-   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
-   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
-   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
-   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
-   [Become a Member](https://membership.dhakachamber.com/register)
-   [Member Login](https://membership.dhakachamber.com)
-   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
-   [Member Query](https://dhakachamber.com/member-query)
-   [Hot Line](https://dhakachamber.com/hot_line)

### MEDIA

-   [Chamber News](https://dhakachamber.com/media/news)
-   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
-   [Photo Gallery](https://dhakachamber.com/albums)
-   [Video Gallery](https://dhakachamber.com/videos)

### DOWNLOAD

-   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
-   [DCCI Reviews](https://dhakachamber.com/publications/reviews)
-   [DCCI Publications](https://dhakachamber.com/publications)
-   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
-   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)

×

-   [Home(current)](https://dhakachamber.com)
-   [About us](#)
    -   [Brief About DCCI](https://dhakachamber.com/about-us)
    -   [International Affiliations](https://dhakachamber.com/international-affiliations)
    -   [DCCI Founders](https://dhakachamber.com/dcci-founders)
    -   [Former Presidents](https://dhakachamber.com/dcci-former-presidents)
    -   [Former Senior Vice Presidents](https://dhakachamber.com/dcci-former-senior-vice-presidents)
    -   [Former Vice Presidents](https://dhakachamber.com/dcci-former-vice-presidents)
    -   [Achievements & Awards](https://dhakachamber.com/achievements-awards)
    -   [Policy and Objectives](https://dhakachamber.com/quality-policy-and-objectives)
-   [Organizational Information](#)
    -   [Board of Directors](https://dhakachamber.com/board-of-directors)
    -   [Previous Board of Directors](https://dhakachamber.com/dcci-allpastmanagement)
    -   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
    -   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)
-   [President](https://dhakachamber.com/president)
-   [Membership](#)
    -   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
    -   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
    -   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
    -   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
    -   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
    -   [Become a Member](https://membership.dhakachamber.com/register)
    -   [Member Login](https://membership.dhakachamber.com)
    -   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
    -   [Member Query](https://dhakachamber.com/member-query)
    -   [Hot Line](https://dhakachamber.com/hot_line)
-   [Projects](https://dhakachamber.com/project-activities)
-   [Seminar](https://dhakachamber.com/media/seminar)
-   [Publications](#)
    -   [DCCI Research Service](https://dhakachamber.com/pdf_viewer/storage/2024/circular/DCCI%20Research%20Service.pdf)
    -   [Research Guideline](https://dhakachamber.com/pdf_viewer/storage/2024/circular/Research%20Guideline.pdf)
    -   [DCCI Journal (DJBEP)](https://journal.dhakachamber.com/)
    -   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
    -   [DCCI Review](https://dhakachamber.com/publications/reviews)
    -   [DCCI Publications](https://dhakachamber.com/publications)
    -   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
    -   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)
    -   [Introducing DCCI 2023](https://www.dhakachamber.com/storage/print_media/2023/07/Introducing%202023.pdf)
-   [Media](#)
    -   [Chamber News](https://dhakachamber.com/media/news)
    -   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
    -   [Photo Gallery](https://dhakachamber.com/albums)
    -   [Video Gallery](https://dhakachamber.com/videos)
    -   [Fairs & Exhibitions](https://www.dhakachamber.com/storage/2026/03/dccifair.pdf)
-   [Policy](#)
    -   [Export Policy](https://www.dhakachamber.com/storage/policy/3VFoMxkr6Z3EZdC8wz7YHfrIBfPP5N0Y6n7eEEFJ.pdf)
    -   [Import Policy](https://www.dhakachamber.com/storage/policy/b6uhXGhpdl30N68gl3Yg9mV5P6vGIPAjquqTu35f.pdf)
    -   [Industry Policy](https://www.dhakachamber.com/storage/policy/kpHRSdbYmY90O7wcyYmkZTSvumKEXfz5uwPTlOn5.pdf)
    -   [ICT Policy](https://www.dhakachamber.com/storage/policy/abTlbODgI2I4Aqbrix5Cs2DHvFD5lW3OwDmfKXmH.pdf)
-   [BILATERAL TRADE](#)
    -   [Bilateral Trade](https://dhakachamber.com/bilateral-trade)
    -   [Africa](https://dhakachamber.com/bilateral-trade/africa)
    -   [America](https://dhakachamber.com/bilateral-trade/america)
    -   [Asian](https://dhakachamber.com/bilateral-trade/asian)
    -   [ASEAN](https://dhakachamber.com/bilateral-trade/asean)
    -   [SAARC](https://dhakachamber.com/bilateral-trade/saarc)
    -   [Middle East](https://dhakachamber.com/bilateral-trade/middle-east)
    -   [European Union](https://dhakachamber.com/bilateral-trade/european-union)
-   [About Bangladesh](#)
    -   [General Information](https://dhakachamber.com/bangladesh-country-profile)
    -   [Business Opportunities in Bangladesh](https://dhakachamber.com/trade-and-business-opportunities-in-bangladesh)
    -   [Useful Links](https://dhakachamber.com/useful-links)
-   [B2B Directory](#)
    -   [B2B Directory](https://dhakachamber.com/b2b)
    -   [B2B Member Login](https://dhakachamber.com/login)
    -   [B2B Registration](https://dhakachamber.com/b2b-reg)