---
source: "Dhaka Chamber of Commerce & Industry (DCCI)"
tier: 1
category: "Chamber"
url: "https://dhakachamber.com/dcci-allpastmanagement"
title: "DCCI ::  Previous Board of Directors"
scraped_at: "2026-07-02"
---

# Previous Board of Directors

DCCI Board of Directors 2024

![John Smith](https://dhakachamber.com/public/images/pastmanagement/p_2024.jpg)

#### ASHRAF AHMED

President

![Sarah Johnson](https://dhakachamber.com/public/images/pastmanagement/svp_2024.jpg)

#### MALIK TALHA ISMAIL BARI

Sr. Vice President

![Michael Brown](https://dhakachamber.com/public/images/pastmanagement/vp_2024.jpg)

#### MD. JUNAED IBNA ALI

Vice President

![John Smith](https://dhakachamber.com/public/images/pastmanagement/p_2023.jpg)

#### BARRISTER MD. SAMEER SATTAR

Director

![Sarah Johnson](https://dhakachamber.com/public/images/pastmanagement/5.24.jpg)

#### ENGR. M A WAHAB

Director

![Michael Brown](https://dhakachamber.com/public/images/pastmanagement/6.24.jpg)

#### KAMRUL HASAN TUHIN

Director

![John Smith](https://dhakachamber.com/public/images/pastmanagement/7.24.jpg)

#### M. MOSHARROF HOSSAIN

Director

![Sarah Johnson](https://dhakachamber.com/public/images/pastmanagement/8.2024.jpg)

#### MD. ABDUL MANNAN

Director

![Michael Brown](https://dhakachamber.com/public/images/pastmanagement/9.2024.jpg)

#### MD. HABIB ULLAH TUHIN

Director

![John Smith](https://dhakachamber.com/public/images/pastmanagement/10.2024.jpg)

#### MD. SALEM SULAIMAN

Director

![Sarah Johnson](https://dhakachamber.com/public/images/pastmanagement/11.2024.jpg)

#### MD. SIAAM AL-DDIN MALIK

Director

![Michael Brown](https://dhakachamber.com/public/images/pastmanagement/12.2024.jpg)

#### MOHAMMAD SAIFUR RAHMAN SAIF

Director

![John Smith](https://dhakachamber.com/public/images/pastmanagement/13.2024.jpg)

#### NAYEEMUR RAHMAN

Director

![Sarah Johnson](https://dhakachamber.com/public/images/pastmanagement/14.2024.jpg)

#### RAZEEV H CHOWDHURY

Director

![Michael Brown](https://dhakachamber.com/public/images/pastmanagement/15.2024.jpg)

#### S. M. GOLAM FARUK ALAMGIR (ARMAN)

Director

![John Smith](https://dhakachamber.com/public/images/pastmanagement/16.2024.jpg)

#### SAIF UDDOWLAH

Director

![Sarah Johnson](https://dhakachamber.com/public/images/pastmanagement/17.2024.jpg)

#### SYED MAMNUN QUADER

Director

![Michael Brown](https://dhakachamber.com/public/images/pastmanagement/18.2024.jpg)

#### TASKEEN AHMED

Director

DCCI Board of Directors 2023

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2023/1. DCCI President_Barrister Md. Sameer Sattar.jpg>)

#### Barrister Md. Sameer Sattar

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2023/2. S M Golam Faruk Alomgir \(Arman\)_SVP_DCCI.jpg>)

#### S M Golam Faruk Alomgir (Arman)

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2023/3. Md. Junaed Ibna Ali_VP_DCCI.jpg>)

#### Md. Junaed Ibna Ali

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2023/4. Rizwan Rahman.jpg>)

#### Rizwan Rahman

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2023/5. Golam Zilani.jpg>)

#### Golam Zilani

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2023/6. Hossain A Sikder.jpg>)

#### Hossain A Sikder

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2023/7. Kamrul Hasan Tuhin.jpg>)

#### Kamrul Hasan Tuhin

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2023/8. Khairul Majid Mahmud.jpg>)

#### Khairul Majid Mahmud

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2023/9. M.A. Rashid Shah Shamrat.jpg>)

#### M.A. Rashid Shah Shamrat

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2023/10. Engr. M. A. Wahab.jpg>)

#### Engr. M. A. Wahab

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2023/11. M. Mosharrof Hossain.jpg>)

#### M. Mosharrof Hossain

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2023/12. Malik Talha Ismail Bari.jpg>)

#### Malik Talha Ismail Bari

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2023/13. Md. Abdul Mannan.jpg>)

#### Md. Abdul Mannan

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2023/14. Md. Habib Ullah Tuhin.jpg>)

#### Md. Habib Ullah Tuhin

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2023/15. Nasiruddin A. Ferdous.jpg>)

#### Nasiruddin A. Ferdous

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2023/16. Razeev H Chowdhury.jpg>)

#### Razeev H Chowdhury

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2023/17. Syed Mamnun Quader\(1\).jpg>)

#### Syed Mamnun Quader

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2023/18. Taskeen Ahmed\(1\).jpg>)

#### Taskeen Ahmed

Director

DCCI Board of Directors 2022

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2022/1. Rizwan Rahman.jpg>)

#### Rizwan Rahman

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2022/2. Arman Haque.jpg>)

#### Arman Haque

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2022/3. Monowar Hossain.JPG>)

#### Monowar Hossain

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2022/4. Golam Zilani.jpg>)

#### Golam Zilani

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2022/5. Hossain A Sikder.jpg>)

#### Hossain A Sikder

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2022/6. Khairul Majid Mahmud.jpg>)

#### Khairul Majid Mahmud

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2022/7. M.A. Rashid Shah Shamrat.jpg>)

#### M.A. Rashid Shah Shamrat

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2022/8. Malik Talha Ismail Bari.jpg>)

#### Malik Talha Ismail Bari

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2022/9. Md. Abdul Mannan.jpg>)

#### Md. Abdul Mannan

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2022/10. Md. Habib Ullah Tuhin.jpg>)

#### Md. Habib Ullah Tuhin

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2022/11. Md. Junaed Ibna Ali.jpg>)

#### Md. Junaed Ibna Ali

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2022/12. Md. Shahid Hossain.JPG>)

#### Md. Shahid Hossain

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2022/13. Md. Zia Uddin.jpg>)

#### Md. Zia Uddin

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2022/14. Nasiruddin A. Ferdous.jpg>)

#### Nasiruddin A. Ferdous

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2022/15. N K A Mobin, FCS, FCA.jpg>)

#### N K A Mobin, FCS, FCA

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2022/16. Sameer Sattar.jpg>)

#### Sameer Sattar

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2022/17. Shamsuzzoha Chowdhury.JPG>)

#### Shamsuzzoha Chowdhury

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2022/18. S. M. Golam Faruk Alamgir.jpg>)

#### S. M. Golam Faruk Alamgir

Director

DCCI Board of Directors 2021

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2021/1. Rizwan Rahman.jpg>)

#### Rizwan Rahman

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2021/2. N K A Mobin, FCS, FCA.jpg>)

#### N K A Mobin, FCS, FCA

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2021/3. Monowar Hossain.JPG>)

#### Monowar Hossain

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2021/4. Osama Taseer.jpg>)

#### Osama Taseer

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2021/5. Shams Mahmud.JPG>)

#### Shams Mahmud

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2021/6. Arman Haque.jpg>)

#### Arman Haque

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2021/7. Ashraf Ahmed.JPG>)

#### Ashraf Ahmed

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2021/8. Alhaj Deen Mohammed.JPG>)

#### Alhaj Deen Mohammed

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2021/9. Enamul Haque Patwary.JPG>)

#### Enamul Haque Patwary

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2021/10. Golam Zilani.jpg>)

#### Golam Zilani

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2021/11. Hossain A Sikder.jpg>)

#### Hossain A Sikder

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2021/12. Khairul Majid Mahmud.jpg>)

#### Khairul Majid Mahmud

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2021/13. M.A. Rashid Shah Shamrat.jpg>)

#### M.A. Rashid Shah Shamrat

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2021/14. Md. Rashidul Karim Munnah.JPG>)

#### Md. Rashidul Karim Munnah

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2021/15. Md. Shahid Hossain.JPG>)

#### Md. Shahid Hossain

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2021/16. Md. Zia Uddin.JPG>)

#### Md. Zia Uddin

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2021/17. Nasiruddin A. Ferdous.jpg>)

#### Nasiruddin A. Ferdous

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2021/18. Engr. Shamsuzzoha Chowdhury.JPG>)

#### Engr. Shamsuzzoha Chowdhury

Director

DCCI Board of Directors 2020

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2020/1. Shams Mahmud_President.jpg>)

#### Shams Mahmud

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2020/2. N K A Mobin FCA,FCS.jpg>)

#### N K A Mobin, FCS, FCA

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2020/3. Mohammad Bashiruddin_VP, DCCI.jpg>)

#### Mohammad Bashiruddin

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2020/4. Osama Taseer_President, DCCI.jpg>)

#### Osama Taseer

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2020/5. Andaleeb Hasan.jpg>)

#### Andaleeb Hasan

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2020/6. Arman Haque.jpg>)

#### Arman Haque

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2020/7. Ashraf Ahmed.jpg>)

#### Ashraf Ahmed

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2020/8. Deen Mohammed.jpg>)

#### Alhaj Deen Mohammed

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2020/9. Enamul Haque Patwary.jpg>)

#### Enamul Haque Patwary

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2020/10. Engr Md Al Amin New.jpg>)

#### Engr Md Al Amin

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2020/11. Md. Rashedul Karim Munna.jpg>)

#### Md. Rashedul Karim Munna

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2020/12. Md. Shahid Hossain.jpg>)

#### Md. Shahid Hossain

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2020/13. Md. Zia Uddin.jpg>)

#### Md. Zia Uddin

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2020/14. Monowar Hossain.jpg>)

#### Monowar Hossain

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2020/15. Nuher Latif Khan.jpg>)

#### Nuher Latif Khan

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2020/16. Engr.-Shamsuzzoha-Chowdhury.jpg>)

#### Engr. Shamsuzzoha Chowdhury

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2020/17. S M Zillur Rahman.jpg>)

#### S M Zillur Rahman

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2020/18. Waqar Ahmad Choudhury.jpg>)

#### Waqar Ahmad Choudhury

Director

DCCI Board of Directors 2019

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2019/1. Osama Taseer_President, DCCI.jpg>)

#### Osama Taseer

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2019/2. Waqar Ahmad Choudhury_SVP,DCCI.jpg>)

#### Waqar Ahmad Choudhur

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2019/3. Imran Ahmed_VP, DCCI.jpg>)

#### Imran Ahmed

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2019/4. Abul Kasem Khan.jpg>)

#### Abul Kasem Khan

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2019/5. Kngr. Akbar Hakim.jpg>)

#### Engr. Akbar Hakim

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2019/6. Andaleeb Hasan.jpg>)

#### Andaleeb Hasan

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2019/7. Ashraf Ahmed.jpg>)

#### Ashraf Ahmed

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2019/8. Deen Mohammed.jpg>)

#### Alhaj Deen Mohammed

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2019/9. Enamul Haque Patwary.jpg>)

#### Enamul Haque Patwary

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2019/10. Hossain A Sikder.jpg>)

#### Hossain A Sikde

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2019/11. KH. Rashedul Ahsan.jpg>)

#### KH. Rashedul Ahsan

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2019/12. K M N Monjurul Hoque.jpg>)

#### K M N Monjurul Hoque

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2019/13. Engr Md Al Amin New.jpg>)

#### Engr Md Al Amin

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2019/14. Md. Rashedul Karim Munna.jpg>)

#### Md. Rashedul Karim Munna

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2019/15. Mohammad Bashiruddin.jpg>)

#### Mohammad Bashiruddin

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2019/16. Nuher Latif Khan.jpg>)

#### Nuher Latif Khan

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2019/17. Shams Mahmud.JPG>)

#### Shams Mahmud

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2019/18. S M Zillur Rahman.jpg>)

#### S M Zillur Rahman

Director

DCCI Board of Directors 2018

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2018/1. Abul Kasem Khan_President,DCCI.jpg>)

#### Abul Kasem Khan

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2018/2. Kamrul Islam, FCA-Senior Vice President, DCCI.JPG>)

#### Kamrul Islam, FCA

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2018/3. RIYADH HOSSAIN-VP, DCCI.jpg>)

#### Riyadh Hossain

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2018/4. Engr. Akbar Hakim.jpg>)

#### Engr. Akbar Hakim

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2018/5. Andaleeb Hasan.jpg>)

#### Andaleeb Hasan

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2018/6. Hossain A Sikder.jpg>)

#### Hossain A Sikder

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2018/7. Humayun Rashid-Senior Vice President, DCCI.jpg>)

#### Humayun Rashid

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2018/8. Imran Ahmed.jpg>)

#### Imran Ahmed

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2018/9. KH. Rashedul Ahsan.jpg>)

#### KH. Rashedul Ahsan

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2018/10. K M N Monjurul Hoque.jpg>)

#### K M N Monjurul Hoque

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2018/11. Mamun Akbar.jpg>)

#### Mamun Akbar

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2018/12. Md. Alauddin Malik.jpg>)

#### Md. Alauddin Malik

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2018/13. Engr Md Al Amin New.jpg>)

#### Engr Md Al Amin

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2018/14. Mohammad Bashiruddin.jpg>)

#### Mohammad Bashiruddin

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2018/15. Nuher Latif Khan.jpg>)

#### Nuher Latif Khan

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2018/16. Salim Akhter Khan.jpg>)

#### Salim Akhter Khan

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2018/17. S M Zillur Rahman.jpg>)

#### S M Zillur Rahman

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2018/18. Waqar Ahmad Choudhury.jpg>)

#### Waqar Ahmad Choudhury

Director

DCCI Board of Directors 2017

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2017/1. Abul Kasem Khan_President_DCCI.jpg>)

#### Abul Kasem Khan

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2017/2. Kamrul Islam, FCA-Senior Vice President, DCCI.jpg>)

#### Kamrul Islam, FCA

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2017/3. Hossain A Sikder_VP-DCCI.jpg>)

#### Hossain A Sikder

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2017/4. Hossain Khaled.JPG>)

#### Hossain Khaled

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2017/5. Asif A Chowdhury.jpg>)

#### Asif A Chowdhury

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2017/6. Engr. Ekbar Hakim.jpg>)

#### Engr. Ekbar Hakim

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2017/7. Hossain Akter.jpg>)

#### Hossain Akter

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2017/8. Humayun Rashid-Senior Vice President, DCCI.jpg>)

#### Humayun Rashid

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2017/9. Imran Ahmed.jpg>)

#### Imran Ahmed

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2017/10. KHANDAKAR ABDUL MUKTADIR.jpg>)

#### KHANDAKAR ABDUL MUKTADIR

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2017/11. K. ATIQUE-E- RABBANI, FCA.jpg>)

#### K. ATIQUE-E- RABBANI, FCA

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2017/12. KH. Rashedul Ahsan.jpg>)

#### KH. Rashedul Ahsan

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2017/13. KH. Rashedul Ahsan.jpg>)

#### KH. Rashedul Ahsan

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2017/14. Mamun Akbar.jpg>)

#### Mamun Akbar

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2017/15. Al haj Md. Alauddin Malik.jpg>)

#### Al haj Md. Alauddin Malik

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2017/16. Osman Gani.jpg>)

#### Osman Gani

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2017/17. RIYADH HOSSAIN.jpg>)

#### RIYADH HOSSAIN

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2017/18. Salim Akhter Khan.jpg>)

#### Salim Akhter Khan

Director

DCCI Board of Directors 2016

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2016/1. Hossain Khaled, President.JPG>)

#### Hossain Khaled

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2016/2. Humayun Rashid-Senior Vice President, DCCI.jpg>)

#### Humayun Rashid

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2016/3. K. ATIQUE-E- RABBANI FCA, Vice President, DCCI.jpg>)

#### K. ATIQUE-E- RABBANI FCA

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2016/4. Mohammad Shahjahan Khan.JPG>)

#### Mohammad Shahjahan Khan

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2016/5. A K D Khair Mohammad Khan.jpg>)

#### A K D Khair Mohammad Khan

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2016/6. Asif A Chowdhury.jpg>)

#### Asif A Chowdhury

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2016/7. Hossain Akter.jpg>)

#### Hossain Akter

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2016/8. Kamrul Islam FCA.jpg>)

#### Kamrul Islam FCA

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2016/9. KHANDAKAR ABDUL MUKTADIR.jpg>)

#### KHANDAKAR ABDUL MUKTADIR

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2016/10. K G Karim.jpg>)

#### K G Karim

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2016/11. Mamun Akbar.jpg>)

#### Mamun Akbar

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2016/12. Al haj Md. Alauddin Malik.jpg>)

#### Al haj Md. Alauddin Malik

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2016/13. Muktar Hossain Chowdhury.jpg>)

#### Muktar Hossain Chowdhury

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2016/14. Osman Gani.jpg>)

#### Osman Gani

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2016/15. RIYADH HOSSAIN.jpg>)

#### RIYADH HOSSAIN

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2016/16. Salim Akhter Khan.jpg>)

#### Salim Akhter Khan

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2016/17. S. Rumi Saifullah.jpg>)

#### S. Rumi Saifullah

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2016/18. Sameer Sattar.jpg>)

#### Sameer Sattar

Director

DCCI Board of Directors 2015

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2015/1. Hossain Khaled.JPG>)

#### Hossain Khaled

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2015/2. Mr.Humayun Rashid.jpg>)

#### Mr.Humayun Rashid

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2015/3. Mr. Md. Shoaib Choudhury.jpg>)

#### Mr. Md. Shoaib Choudhury

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2015/4. Mohammad Shahjahan Khan.JPG>)

#### Mohammad Shahjahan Khan

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2015/5. Md. Sabur Khan.jpg>)

#### Md. Sabur Khan

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2015/6. A K D Khair Mohammad Khan.jpg>)

#### A K D Khair Mohammad Khan

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2015/7. Alhaj Abdus Salam.jpg>)

#### Alhaj Abdus Salam

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2015/8. Asif A Chowdhury.jpg>)

#### Asif A Chowdhury

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2015/9. Hossain Akter.jpg>)

#### Hossain Akter

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2015/10. K G Karim.jpg>)

#### K G Karim

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2015/11. KHANDAKAR ABDUL MUKTADIR.jpg>)

#### KHANDAKAR ABDUL MUKTADIR

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2015/12. K. ATIQUE-E- RABBANI FCA.jpg>)

#### K. ATIQUE-E- RABBANI FCA

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2015/13. Muktar Hossain Chowdhury.jpg>)

#### Muktar Hossain Chowdhury

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2015/14. Nessar Maksud Khan.jpg>)

#### Nessar Maksud Khan

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2015/15. Osman Gani.jpeg>)

#### Osman Gani

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2015/16. Mr. Rizwan-ur Rahman.jpg>)

#### Mr. Rizwan-ur Rahman

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2015/17. S. Rumi Saifullah.jpg>)

#### S M Zillur Rahman

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2015/18. Sameer Sattar.jpg>)

#### Sameer Sattar

Director

DCCI Board of Directors 2014

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2014/1. Mohammad Shahjahan Khan.jpg>)

#### Mohammad Shahjahan Khan

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2014/2. Osama Taseer.jpg>)

#### Osama Taseer

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2014/3. Kh. Shahidul Islam.jpg>)

#### Kh. Shahidul Islam

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2014/4. Md. Sabur Khan.jpg>)

#### Md. Sabur Khan

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2014/5. Haider Ahmed Khan, FCA.jpg>)

#### Haider Ahmed Khan, FCA

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2014/6. Abul Hossain.jpg>)

#### Abul Hossain

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2014/7. Md. Iftekharuddin.jpg>)

#### Md. Iftekharuddin

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2014/8. Nessar Maksud Khan.jpg>)

#### Nessar Maksud Khan

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2014/9. Mr. Rizwan-ur Rahman.jpg>)

#### Mr. Rizwan-ur Rahman

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2014/10. Mr.Humayun Rashid.jpg>)

#### Mr.Humayun Rashid

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2014/11. Muktar Hossain Chowdhury.jpg>)

#### Muktar Hossain Chowdhury

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2014/12. S. Rumi Saifullah.jpg>)

#### S. Rumi Saifullah

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2014/13. Sameer Sattar.jpg>)

#### Sameer Satta

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2014/14. Hossain A Sikder.jpg>)

#### Hossain A Sikder

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2014/15. Alhaj Abdus Salam.jpg>)

#### Alhaj Abdus Salam

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2014/16. Mr. Md. Shoaib Choudhury.jpg>)

#### Mr. Md. Shoaib Choudhury

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2014/17. A K D Khair Mohammad Khan.jpg>)

#### A K D Khair Mohammad Khan

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2014/18. K G Karim.jpg>)

#### K G Karim

Director

DCCI Board of Directors 2013

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2013/1. Md. Sabur Khan.jpg>)

#### Md. Sabur Khan

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2013/2. Nessar Maksud Khan.jpg>)

#### Nessar Maksud Khan

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2013/3. Absar Karim Chowdhury.jpg>)

#### Absar Karim Chowdhury

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2013/4. Mohiuddin Monem.jpg>)

#### Mohiuddin Monem

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2013/5. Osman Gani.jpg>)

#### Osman Gani

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2013/6. Khairul Majid Mahmood.jpg>)

#### Khairul Majid Mahmood

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2013/7. K M N Monjurul Hoque.jpg>)

#### K M N Monjurul Hoque

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2013/8. Haider Ahmed Khan, FCA.jpg>)

#### Haider Ahmed Khan, FCA

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2013/9. Abul Hossain.jpg>)

#### Abul Hossain

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2013/10. Osama Taseer.jpg>)

#### Osama Taseer

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2013/11. Md. Iftekharuddin.jpg>)

#### Md. Iftekharuddin

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2013/12. Mr. Rizwan-ur Rahman.jpg>)

#### Mr. Rizwan-ur Rahman

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2013/13. Mr.Humayun Rashid.jpg>)

#### Mr.Humayun Rashid

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2013/14. M Abu Horaira.jpg>)

#### M Abu Horaira

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2013/15. Kh. Shahidul Islam.jpg>)

#### Kh. Shahidul Islam

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2013/16. Hossain A Sikder.jpg>)

#### Hossain A Sikder

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2013/17. Alhaj Abdus Salam.jpg>)

#### Alhaj Abdus Salam

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2013/18. Mr. Md. Shoaib Choudhury.jpg>)

#### Mr. Md. Shoaib Choudhury

Director

DCCI Board of Directors 2012

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2012/1. Asif Ibrahim.jpg>)

#### Asif Ibrahim

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2012/2. Haider Ahmed Khan, FCA.jpg>)

#### Haider Ahmed Khan, FCA

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2012/3. M Bashir Ullah Bhuiyan.jpg>)

#### M Bashir Ullah Bhuiyan

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2012/4. Mahbub Anam.jpg>)

#### Mahbub Anam

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2012/5.TIM Nurul Kabir.jpg>)

#### TIM Nurul Kabir

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2012/6. Waqur Ahmad Choudhury.jpg>)

#### Waqur Ahmad Choudhury

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2012/7. Mohiuddin Monem.jpg>)

#### Mohiuddin Monem

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2012/8. Osman Gani.jpg>)

#### Osman Gani

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2012/9. Khairul Majid Mahmood.jpg>)

#### Khairul Majid Mahmood

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2012/10. K M N Monjurul Hoque.jpg>)

#### K M N Monjurul Hoque

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2012/11. Abul Hossain.jpg>)

#### Abul Hossain

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2012/12. Osama Taseer.jpg>)

#### Osama Taseer

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2012/13. Md. Iftekharuddin.jpg>)

#### Md. Iftekharuddin

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2012/14. KG Karim.jpg>)

#### KG Karim

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2012/15. Absar Karim Chowdhury.jpg>)

#### Absar Karim Chowdhury

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2012/16. M Abu Horaira.jpg>)

#### M Abu Horaira

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2012/17. Kh. Shahidul Islam.jpg>)

#### Kh. Shahidul Islam

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2012/18. Hossain A Sikder.jpg>)

#### Hossain A Sikder

Director

DCCI Board of Directors 2011

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2011/1. Asif Ibrahim.jpg>)

#### Asif Ibrahim

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2011/2.TIM Nurul Kabir.jpg>)

#### TIM Nurul Kabir

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2011/3.Nasir Hossain.jpg>)

#### Nasir Hossain

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2011/4.Waliur Rahman.jpg>)

#### Waliur Rahman

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2011/5.Engr.Syed Mohsarraf Hossain.jpg>)

#### Engr.Syed Mohsarraf Hossain

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2011/6.Hossain A Sikder.jpg>)

#### Hossain A Sikder

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2011/7.Niaz Rahim.jpg>)

#### Niaz Rahim

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2011/8.M Bashir Ullah Bhuiyan.jpg>)

#### M Bashir Ullah Bhuiyan

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2011/9.Mahabub Anam.jpg>)

#### 9.Mahabub Anam.jpg

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2011/10.Waquar Ahmad Choudhury.jpg>)

#### Waquar Ahmad Choudhury

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2011/11.ASM Monhuddin Monem.jpg>)

#### ASM Monhuddin Monem

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2011/12.Osman Gani.jpg>)

#### Osman Gani

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2011/13.Khairul Majid Mahmud.jpg>)

#### Khairul Majid Mahmud

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2011/14.KMN Manjurul Hoque.jpg>)

#### KMN Manjurul Hoque

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2011/15. Al-Haj Md. Hasiruddin Khan.jpg>)

#### Al-Haj Md. Hasiruddin Khan

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2011/16.M Anwarul Haque.jpg>)

#### M Anwarul Haque

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2011/17.KG Karim.jpg>)

#### KG Karim

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2011/18.Absar Karim Chowdhury.jpg>)

#### Absar Karim Chowdhury

Director

DCCI Board of Directors 2010

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2010/1. Abul Kasem Khan_President.jpg>)

#### Abul Kasem Khan

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2010/2. M Shahjahan Khan_Senior Vice President.jpg>)

#### M Shahjahan Khan

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2010/3. Md. Sirajuddin Malik_Vice President.jpg>)

#### Md. Sirajuddin Malik

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2010/4. Rafiqul Islam Khan, FCA.jpg>)

#### Rafiqul Islam Khan, FCA

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2010/5. M A Baten.jpg>)

#### M A Baten

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2010/6. Major Md. Yead Ali Fakir \(Retd.\).jpg>)

#### Major Md. Yead Ali Fakir (Retd.)

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2010/7. Waliur Rahman.jpg>)

#### K M N Monjurul Hoque

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2010/8. Engr. Syed Mosharraf Hossain.jpg>)

#### Engr. Syed Mosharraf Hossain

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2010/9. Hossain A Sikder.jpg>)

#### Hossain A Sikde

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2010/10. Niaz Rahim.jpg>)

#### Niaz Rahim

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2010/11. M Bashir Ullah Bhuiyan.jpg>)

#### M Bashir Ullah Bhuiyan

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2010/12. T I M Nurul Kabir.jpg>)

#### T I M Nurul Kabir

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2010/13. Mahbub Anam.jpg>)

#### Mahbub Anam

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2010/14. Waqar Ahmad Chowdhury.jpg>)

#### Waqar Ahmad Chowdhury

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2010/15. Nessar Maksud Khan.jpg>)

#### Nessar Maksud Khan

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2010/16. Al-Haj Md. Nasiruddin Khan.jpg>)

#### Al-Haj Md. Nasiruddin Khan

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2010/17. M Anwarul Haque.jpg>)

#### M Anwarul Haque

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2010/18. Asif Ibrahim.jpg>)

#### Asif Ibrahim

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2010/19. K G Karim.jpg>)

#### K G Karim

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2010/20. M.S. Shekil Chowdhury.jpg>)

#### M.S. Shekil Chowdhury

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2010/21. Nasir Hossain.jpg>)

#### Nasir Hossain

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2010/22. Md. Sirajul Islam \(Bulbul\).jpg>)

#### Md. Sirajul Islam (Bulbul)

Director

DCCI Board of Directors 2009

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2009/1. Zafar Osman.jpg>)

#### Zafar Osman

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2009/2. M.S. Shekil Chowdhury.jpg>)

#### M.S. Shekil Chowdhury

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2009/3. Md. Sirajuddin Malik_Vice President.jpg>)

#### Md. Sirajuddin Malik

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2009/4. Salahuddin Abdullah.jpg>)

#### Salahuddin Abdullah

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2009/5. Sayed Moazzam Hossain.jpg>)

#### Sayed Moazzam Hossain

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2009/6. Saiful Islam.jpg>)

#### Saiful Islam

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2009/7. Rafiqul Islam Khan, FCA.jpg>)

#### Rafiqul Islam Khan, FCA

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2009/8. Abul Kasem Khan_President.jpg>)

#### Abul Kasem Khan

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2009/9. M A Baten.jpg>)

#### M A Baten

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2009/10. Major Md. Yead Ali Fakir \(Retd.\).jpg>)

#### Major Md. Yead Ali Fakir (Retd.)

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2009/11. Waliur Rahman.jpg>)

#### Waliur Rahman

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2009/12. Engr. Syed Mosharraf Hossain.jpg>)

#### Engr. Syed Mosharraf Hossai

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2009/13. Omar Farque.jpg>)

#### Omar Farque

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2009/14. Niaz Rahim.jpg>)

#### Niaz Rahim

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2009/15. Khandaker Shahidul Islam.jpg>)

#### Khandaker Shahidul Islam

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2009/16. Alhaj Abdul Aziz Sarker.jpg>)

#### Alhaj Abdul Aziz Sarker

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2009/17. Nessar Maksud Khan.jpg>)

#### Nessar Maksud Khan

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2009/18. Al-Haj Md. Nasiruddin Khan.jpg>)

#### Al-Haj Md. Nasiruddin Khan

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2009/19. M Anwarul Haque.jpg>)

#### M Anwarul Haque

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2009/20. Shamsul Arefin.jpg>)

#### Shamsul Arefin

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2009/21. Md. Sirajul Islam \(Bulbul\).jpg>)

#### Md. Sirajul Islam (Bulbul)

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2009/22. M Shahjahan Khan.jpg>)

#### M Shahjahan Khan

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2009/23. Data Magfur.jpg>)

#### Data Magfu

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2009/24. Nasir Hossain.jpg>)

#### Nasir Hossain

Director

DCCI Board of Directors 2008

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2008/1. Hossain Khaled_President.jpg>)

#### Hossain Khaled

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2008/2. Salahuddin Abdullah.jpg>)

#### Salahuddin Abdullah

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2008/3. Khandaker Shahidul Islam.jpg>)

#### Khandaker Shahidul Islam

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2008/4. M A Momen.jpg>)

#### M A Momen

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2008/5. Safina Rahman.jpg>)

#### Safina Rahman

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2008/6. Zafar Osman.jpg>)

#### Zafar Osman

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2008/7. Sayed Moazzam Hossain.jpg>)

#### Sayed Moazzam Hossain

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2008/8. Data Magfur.jpg>)

#### Data Magfur

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2008/9. Sayed Habibur Rahman.jpg>)

#### Sayed Habibur Rahman

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2008/10. Haider Ahmed Khan, FCA.jpg>)

#### Haider Ahmed Khan, FCA

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2008/11. Saiful Islam.jpg>)

#### Saiful Islam

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2008/12. Rafiqul Islam Khan, FCA.jpg>)

#### Rafiqul Islam Khan, FCA

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2008/13. Abul Kasem Khan_President.jpg>)

#### Abul Kasem Khan

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2008/14. M A Baten.jpg>)

#### M A Baten

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2008/15. Major Md. Yead Ali Fakir \(Retd.\).jpg>)

#### Major Md. Yead Ali Fakir (Retd.)

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2008/16. Al-Haj Mohammad Sharfuddin.jpg>)

#### Al-Haj Mohammad Sharfuddin

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2008/17. M Salem Sulaiman.jpg>)

#### M Salem Sulaiman

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2008/18. Alhaj Abdul Aziz Sarker.jpg>)

#### Alhaj Abdul Aziz Sarker

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2008/19. Md. Sirajuddin Malik_Vice President.jpg>)

#### Md. Sirajuddin Malik

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2008/20. Nessar Maksud Khan.jpg>)

#### Nessar Maksud Khan

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2008/21. Asif Ibrahim.jpg>)

#### Asif Ibrahim

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2008/22. Shamsul Arefin.jpg>)

#### Shamsul Arefin

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2008/23. Shafique Hossain.jpg>)

#### Shafique Hossain

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2008/24. M.S. Shekil Chowdhury.jpg>)

#### M.S. Shekil Chowdhury

Director

DCCI Board of Directors 2007

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2007/1. Hossain Khaled_President-DCCI.jpg>)

#### Hossain Khaled

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2007/2. M Shahjahan Khan_Senior Vice President-DCCI.jpg>)

#### M Shahjahan Khan

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2007/3. Al-Haj Md. Alauddin Malik_Vice President-DCCI.jpg>)

#### Al-Haj Md. Alauddin Malik

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2007/4. M A Momen.jpg>)

#### M A Momen

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2007/5. Kamrul Islam, FCA.jpg>)

#### Kamrul Islam, FCA

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2007/6. M. A. Muhaimin Saleh.jpg>)

#### M. A. Muhaimin Saleh

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2007/7. K.M. N Shahidul Haque.jpg>)

#### K.M. N Shahidul Haque

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2007/8. Safina Rahman.jpg>)

#### Safina Rahman

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2007/9. Sayed Habibur Rahman.jpg>)

#### Sayed Habibur Rahman

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2007/10. Haider Ahmed Khan, FCA.jpg>)

#### Haider Ahmed Khan, FCA

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2007/11. Zafar Osman.jpg>)

#### Zafar Osman

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2007/12. Salahuddin Abdullah.jpg>)

#### Salahuddin Abdullah

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2007/13. Sayed Moazzam Hossain.jpg>)

#### Sayed Moazzam Hossain

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2007/14. Saiful Islam.jpg>)

#### Saiful Islam

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2007/15. Manzur-Ur-Rahman \(Ruskin\).jpg>)

#### Manzur-Ur-Rahman (Ruskin)

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2007/16. Al-Haj Mohammad Sharfuddin.jpg>)

#### Al-Haj Mohammad Sharfuddin

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2007/17. M Salem Sulaiman.jpg>)

#### M Salem Sulaiman

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2007/18. Khandaker Shahidul Islam.jpg>)

#### Khandaker Shahidul Islam

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2007/19. Alhaj Abdul Aziz Sarker.jpg>)

#### Alhaj Abdul Aziz Sarker

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2007/20. Asif Ibrahim.jpg>)

#### Asif Ibrahim

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2007/21. Shamsul Arefin.jpg>)

#### Shamsul Arefin

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2007/22. M.S. Shekil Chowdhury.jpg>)

#### M.S. Shekil Chowdhury

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2007/23. Shafique Hossain.jpg>)

#### Shafique Hossain

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2007/24. Mohammad Faiz.jpg>)

#### Mohammad Faiz

Director

DCCI Board of Directors 2006

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2006/1. M A Momen_President, DCCI.jpg>)

#### M A Momen

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2006/2. Hossain Khaled.jpg>)

#### Hossain Khaled

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2006/3. Hossain A Sikder.jpg>)

#### Hossain A Sikder

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2006/4. M H Rahman.jpg>)

#### M H Rahman

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2006/5. Khandker A Salam.jpg>)

#### Khandker A Salam

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2006/5. Md. Sabur Khan.jpg>)

#### Md. Sabur Khan

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2006/6. Schezade A. K. Khan.jpg>)

#### Schezade A. K. Khan

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2006/7. M Shahjahan Khan.jpg>)

#### M Shahjahan Khan

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2006/8. Kamrul Islam, FCA.jpg>)

#### Kamrul Islam, FCA

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2006/9. M.A. Muhaimin Saleh.jpg>)

#### M.A. Muhaimin Saleh

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2006/10. K. M.H. Shahidul Haque.jpg>)

#### K. M.H. Shahidul Haque

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2006/11. Safina Rahman.jpg>)

#### Safina Rahman

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2006/12. Sayed Habibur Rahman.jpg>)

#### Sayed Habibur Rahman

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2006/13. Haider Ahmed Khan, FCA.jpg>)

#### Haider Ahmed Khan, FCA

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2006/14. Alhaj Abdus Salam.jpg>)

#### Alhaj Abdus Salam

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2006/15. Manzur-Ur-Rahman \(Ruskin\).jpg>)

#### Manzur-Ur-Rahman (Ruskin)

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2006/16. Al-Haj Md. Alauddin Malik.jpg>)

#### Al-Haj Md. Alauddin Malik

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2006/17. Al-Haj Mohammad Sharfuddin.jpg>)

#### Al-Haj Mohammad Sharfuddin

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2006/18. M Salem Sulaiman.jpg>)

#### M Salem Sulaiman

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2006/19. Asif Ibrahim.jpg>)

#### Asif Ibrahim

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2006/20. M.S. Shekil Chowdhury.jpg>)

#### M.S. Shekil Chowdhury

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2006/21. Shafique Hossain.jpg>)

#### Shafique Hossain

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2006/22. Arshad Ali.jpg>)

#### Arshad Ali

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2006/23. Masudur Rahman.jpg>)

#### Masudur Rahman

Director

DCCI Board of Directors 2005

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2005/1. Syeeful Islam_President.jpg>)

#### Syeeful Islam

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2005/2. Manzur-Ur-Rahman \(Ruskin\)_Senior Vice President.jpg>)

#### Manzur-Ur-Rahman (Ruskin)

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2005/3. A. Y. Md. Kamal.jpg>)

#### A. Y. Md. Kamal

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2005/4. Omar Faruque.jpg>)

#### Omar Faruque

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2005/5. Najmul Huq.jpg>)

#### Najmul Huq

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2005/6. M. H. Rahman.jpg>)

#### M. H. Rahman

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2005/7. Khandker A Salam.jpg>)

#### Khandker A Salam

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2005/8. Md. Sabur Khan.jpg>)

#### Md. Sabur Khan

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2005/9. Schezade A. K. Khan.jpg>)

#### Schezade A. K. Khan

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2005/10. M Shahjahan Khan.jpg>)

#### M Shahjahan Khan

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2005/11. Kamrul Islam, FCA.jpg>)

#### Kamrul Islam, FCA

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2005/12. M.A. Muhaimin Saleh.jpg>)

#### M.A. Muhaimin Saleh

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2005/13. K. M.H. Shahidul Haque.jpg>)

#### K. M.H. Shahidul Haqu

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2005/14. Nesser Maksud Khan.jpg>)

#### Nesser Maksud Khan

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2005/15. M Abu Horaira.jpg>)

#### M Abu Horaira

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2005/16. Alhaj Abdus Salam.jpg>)

#### Alhaj Abdus Salam

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2005/17. Hossain A Sikder.jpg>)

#### Hossain A Sikder

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2005/18. Al-Haj Md. Alauddin Malik.jpg>)

#### Al-Haj Md. Alauddin Mali

Director

DCCI Board of Directors 2004

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2004/1. Fazle R. M. Hansan, FCA_President.jpg>)

#### Fazle R. M. Hansan, FCA

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2004/2. A.M. Mubash-Shar_Senior Vice President.jpg>)

#### A.M. Mubash-Shar

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2004/3. M Abu Horaira_Vice Pesident.jpg>)

#### M Abu Horaira

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2004/4. Ahmed Hossain  Mojumder.jpg>)

#### Ahmed Hossain Mojumde

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2004/5. Zillur Rahman.jpg>)

#### Zillur Rahman

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2004/6. K. Atique-e-Rabbani, FCA.jpg>)

#### K. Atique-e-Rabbani, FCA

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2004/7. A. Y. Md. Kamal.jpg>)

#### A. Y. Md. Kamal

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2004/8. Omar Faruque.jpg>)

#### Omar Faruque

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2004/9. Syeeful Islam.jpg>)

#### Syeeful Islam

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2004/10. Najmul Huq.jpg>)

#### Najmul Huq

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2004/11. M. H. Rahman.jpg>)

#### M. H. Rahman

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2004/12. Khandker A Salam.jpg>)

#### Khandker A Salam

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2004/13. Md. Sabur Khan.jpg>)

#### Md. Sabur Khan

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2004/14. Schezade A. K. Khan.jpg>)

#### Schezade A. K. Khan

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2004/15. Zafar Osman.jpg>)

#### Zafar Osman

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2004/16. Md. Habib Ullah Habib.jpg>)

#### Md. Habib Ullah Habib

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2004/17. Nesser Maksud Khan.jpg>)

#### Nesser Maksud Khan

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2004/18. Alhaj Abdus Salam.jpg>)

#### Alhaj Abdus Salam

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2004/19. Manjur Ahmad.jpg>)

#### Manjur Ahmad

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2004/20. E.R. Khan.jpg>)

#### E.R. Khan

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2004/21. Arshad Ali.jpg>)

#### Arshad Ali

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2004/22. Absar Karim Chowdhury.jpg>)

#### Absar Karim Chowdhury

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2004/23. Nazir Hossain.jpg>)

#### Nazir Hossain

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2004/24. Hossain Khaled.jpg>)

#### Hossain Khaled

Director

DCCI Board of Directors 2003

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2003/1. Matiur Rahman_President.jpg>)

#### Matiur Rahman

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2003/2. Zafar Osman_Senior VIce President.jpg>)

#### Zafar Osman

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2003/3. Hossain Khaled_Vice President.jpg>)

#### Hossain Khaled

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2003/4. M A Momen.jpg>)

#### M A Momen

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2003/5. Syed Mosharraf Hossain.jpg>)

#### Syed Mosharraf Hossain

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2003/6. Data Magfur.jpg>)

#### Data Magfur

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2003/7. Fazle R M. Hassan, FCA.jpg>)

#### Fazle R M. Hassan, FCA

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2003/8. Ahmed Hossain Mojumder.jpg>)

#### Ahmed Hossain Mojumder

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2003/9. Zillur Rahman.jpg>)

#### Zillur Rahman

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2003/10. K. Atique-e-Rabbani, FCA.jpg>)

#### K. Atique-e-Rabbani, FCA

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2003/11. A. Y. Md. Kamal.jpg>)

#### A. Y. Md. Kamal

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2003/12. Omar Faruque.jpg>)

#### Omar Faruque

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2003/13. Syeeful Islam.jpg>)

#### Syeeful Islam

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2003/14. Najmul Huq.jpg>)

#### Najmul Huq

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2003/15. Mahbub-Uz-Zaman.jpg>)

#### Mahbub-Uz-Zaman

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2003/16. Sabbir Ahmed Khan.jpg>)

#### Sabbir Ahmed Khan

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2003/17. Md. Habib Ullah \(Habib\).jpg>)

#### Md. Habib Ullah (Habib)

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2003/18. Nesser Maksud Khan.jpg>)

#### Nesser Maksud Khan

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2003/19. M Abu Horaira.jpg>)

#### M Abu Horaira

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2003/20. Absar Karim Chowdhury.jpg>)

#### Absar Karim Chowdhury

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2003/21. E. R. Khan.jpg>)

#### E. R. Khan

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2003/22. Arshad Ali.jpg>)

#### Arshad Ali

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2003/23. A.M. Mubash-Shar_Senior Vice President.jpg>)

#### A.M. Mubash-Shar

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2003/24. Nazir Hossain.jpg>)

#### Nazir Hossain

Director

DCCI Board of Directors 2002

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2002/1. Matiur Rahman_President.jpg>)

#### Matiur Rahman

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2002/2. Shabbir Ahmed Khan_ Senior Vice President.jpg>)

#### Shabbir Ahmed Khan

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2002/3. Hossain Khaled_ Vice President.jpg>)

#### Hossain Khaled

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2002/4. Benjir Ahmed.jpg>)

#### Benjir Ahmed

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2002/5. Syed Moazzam Hossain.jpg>)

#### Syed Moazzam Hossain

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2002/6. Salahuddin Abdullah.jpg>)

#### Salahuddin Abdullah

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2002/7. Manzur-Ur-Rahman \(Ruskin\).jpg>)

#### Manzur-Ur-Rahman (Ruskin)

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2002/8. M A Momen.jpg>)

#### M A Momen

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2002/9. Syed Mosharraf Hossain.jpg>)

#### Syed Mosharraf Hossain

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2002/10. Data Magfur.jpg>)

#### Data Magfur

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2002/11. Fazle R. M. Hasan, FCA, FBIM.jpg>)

#### Fazle R. M. Hasan, FCA, FBIM

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2002/12. Ahmed Hossain Mojumder.jpg>)

#### Ahmed Hossain Mojumder

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2002/13. Zillur Rahman.jpg>)

#### Zillur Rahman

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2002/14. K. Atique-e-Rabbani, FCA.jpg>)

#### K. Atique-e-Rabbani, FCA

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2002/14. Saidur Rahman.jpg>)

#### Saidur Rahman

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2002/15. Kamal Uddin Malik.jpg>)

#### Kamal Uddin Malik

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2002/16. Mahbub Uz Zaman.jpg>)

#### Mahbub Uz Zaman

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2002/17. Zafar Osman.jpg>)

#### Zafar Osman

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2002/18. Md. Habib Ullah \(Habib\).jpg>)

#### Md. Habib Ullah (Habib)

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2002/19. Hossain Akhter.jpg>)

#### Hossain Akhter

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2002/20. Absar Karim Chowdhury.jpg>)

#### Absar Karim Chowdhury

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2002/21. Nazir Hossain.jpg>)

#### Nazir Hossain

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2002/22. Arshed Ali.jpg>)

#### Arshad Ali

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2002/23. E.R. Khan.jpg>)

#### E.R. Khan

Director

DCCI Board of Directors 2001

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2001/1. Benjir Ahmed_President.jpg>)

#### Benjir Ahmed

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2001/2. Mahbub Uz Zaman_Senior Vice President.jpg>)

#### Mahbub Uz Zaman

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2001/3. Absar Karim Chowdhury_Vice President.jpg>)

#### Absar Karim Chowdhury

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2001/4. A. Y. Md. Kamal.jpg>)

#### A. Y. Md. Kamal

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2001/5. Mohammed Nurul Alam.jpg>)

#### Mohammed Nurul Alam

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2001/6. Manzur Ahmed.jpg>)

#### Manzur Ahmed

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2001/7. Mamun-Ur Rahman.jpg>)

#### Mamun-Ur Rahman

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2001/8. Syed Moazzam Hossain.jpg>)

#### Syed Moazzam Hossain

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2001/9. Salahuddin Abdullah.jpg>)

#### Salahuddin Abdullah

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2001/10. Manzur-Ur-Rahman \(Ruskin\).jpg>)

#### Manzur-Ur-Rahman (Ruskin)

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2001/11. M A Momen.jpg>)

#### M A Momen

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2001/12. Syed Mosharraf Hossain.jpg>)

#### Syed Mosharraf Hossain

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2001/13. Matiur Rahman.jpg>)

#### Matiur Rahman

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2001/14. Data Magfur.jpg>)

#### Data Magfur

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2001/15. Mohammed Zainul Abden.jpg>)

#### Mohammed Zainul Abden

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2001/16. Md. Mazharul Islam.jpg>)

#### Md. Mazharul Islam

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2001/17. Sayeedur Rahman.jpg>)

#### Sayeedur Rahman

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2001/18. Md. Kamal Uddin Malik.jpg>)

#### Md. Kamal Uddin Malik

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2001/19. Shabbir Ahmed Khan.jpg>)

#### Shabbir Ahmed Khan

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2001/20. Nasir Hossain.jpg>)

#### Nasir Hossain

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2001/21. Hossain Akhtar.jpg>)

#### Hossain Akhtar

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2001/22. Hossain Khaled.jpg>)

#### Hossain Khaled

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2001/23. Geasuddin Ahmed.jpg>)

#### Geasuddin Ahmed

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2001/24. Arshad Ali.jpg>)

#### Arshad Ali

Director

DCCI Board of Directors 2000

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2000/1. Aftab Ul Islam_President.jpg>)

#### Aftab Ul Islam

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2000/2. A. M. Mubash-Shar_Senior Vice President.jpg>)

#### A. M. Mubash-Shar

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2000/3. Muhammad Golam Mustafa_Vice President.jpg>)

#### Muhammad Golam Mustafa

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2000/4. R. Maksud Khan.jpg>)

#### R. Maksud Khan

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2000/5. M. H. Rahman.jpg>)

#### M. H. Rahman

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2000/6. Mohd. Reazuddin.jpg>)

#### Mohd. Reazuddin

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2000/7. A. Y. Md. Kamal.jpg>)

#### A. Y. Md. Kamal

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2000/8. Mohammed Nurul Alam.jpg>)

#### Mohammed Nurul Alam

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2000/9. Manzur Ahmed.jpg>)

#### Manzur Ahmed

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2000/10. Mamun-Ur Rahman.jpg>)

#### Mamun-Ur Rahman

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2000/11. Benajir Ahmed.jpg>)

#### Benajir Ahmed

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2000/12. Sayed Moazzam Hossain.jpg>)

#### Sayed Moazzam Hossain

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2000/13. Salahuddin Abdullah.jpg>)

#### Salahuddin Abdullah

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2000/14. Manzur-Ur-Rahman \(Ruskin\).jpg>)

#### Manzur-Ur-Rahman (Ruskin)

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2000/15. Sajjatuz Jumma.jpg>)

#### Sajjatuz Jumma

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2000/16. Mohammed Mazharul Islam.jpg>)

#### Mohammed Mazharul Islam

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2000/17. Mohammad Zainul Abedin.jpg>)

#### Mohammad Zainul Abedin

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2000/18. Md. Kamal Uddin Malik.jpg>)

#### Md. Kamal Uddin Malik

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2000/19. Sayeedur Rahman.jpg>)

#### Sayeedur Rahman

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/2000/20. Masudur Rahman.jpg>)

#### Masudur Rahman

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/2000/21. Nasir Hossain.jpg>)

#### Nasir Hossain

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2000/22. Hossain Akhtar.jpg>)

#### Hossain Akhtar

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2000/23. Geasuddin Ahmed.jpg>)

#### Geasuddin Ahmed

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/2000/24. Arshad Ali.jpg>)

#### Arshad Ali

Director

DCCI Board of Directors 1999

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1999/1. M. H. Rahman_President.jpg>)

#### M. H. Rahman

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1999/2. Sajjatuz Jumma_Senior Vice President.jpg>)

#### Sajjatuz Jumma

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1999/3. Nasir Hossain_Vice President.jpg>)

#### Nasir Hossain

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1999/4. R Maksud Khan.jpg>)

#### R Maksud Khan

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1999/5. Khandaker A Salam.jpg>)

#### Khandaker A Salam

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1999/6. Iqbal Hasan Mahmud.jpg>)

#### Iqbal Hasan Mahmud

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1999/7. Omar Faruque.jpg>)

#### Omar Faruque

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1999/8. Waliur Rahman.jpg>)

#### Waliur Rahman

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1999/9. Mohd. Riazuddin.jpg>)

#### Mohd. Riazuddin

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1999/10. Aftab-Ul-Islam.jpg>)

#### Aftab-Ul-Islam

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1999/11. A Y Md. Kamal.jpg>)

#### A Y Md. Kamal

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1999/12. Mohammed Nurul Alam.jpg>)

#### Mohammed Nurul Alam

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1999/13. Monjur Ahmed.jpg>)

#### Monjur Ahmed

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1999/14. Mamun-Ur- Rahman.jpg>)

#### Mamun-Ur- Rahman

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1999/15. Ashraf Ibna Nur.jpg>)

#### Ashraf Ibna Nur

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1999/16. Zafar Osman.jpg>)

#### Zafar Osman

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1999/17. Mohammad Golam Mustafa.jpg>)

#### Mohammad Golam Mustafa

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1999/18. Md. Mazharul Islam.jpg>)

#### Md. Mazharul Islam

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1999/19. Mohammad Joynul Abedin.jpg>)

#### Mohammad Joynul Abedin

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1999/20. Khorshid Uddin Mollah.jpg>)

#### Khorshid Uddin Mollah

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1999/21. A.M. Mubash-Shar.jpg>)

#### A.M. Mubash-Shar

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1999/22. Giasuddin Ahmed.jpg>)

#### Giasuddin Ahmed

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1999/23. Masudur Rahman.jpg>)

#### Masudur Rahman

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1999/24. Manwar Hossain.jpg>)

#### Manwar Hossain

Director

DCCI Board of Directors 1998

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1998/1. R Maksud Khan_President.jpg>)

#### R Maksud Khan

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1998/2. Masudur Rahman_Senior Vice President.jpg>)

#### Masudur Rahman

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1998/3. Zafar Osman_Vice President.jpg>)

#### Zafar Osman

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1998/4. Sayed Jamaluddin Haider.jpg>)

#### Sayed Jamaluddin Haider

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1998/5. Md. Habibullah.jpg>)

#### Md. Habibullah

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1998/6. M. A. Momen.jpg>)

#### M. A. Momen

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1998/7. A. M. F. Wabidur Rahman.jpg>)

#### A. M. F. Wabidur Rahman

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1998/8. Khandaker A Salam.jpg>)

#### Khandaker A Salam

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1998/9. Iqbal Hasan Mahmud.jpg>)

#### Iqbal Hasan Mahmud

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1998/10. Omar Faruque.jpg>)

#### Omar Faruque

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1998/11. Waliur Rahman.jpg>)

#### Waliur Rahman

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1998/12. M. H. Rahman_President.jpg>)

#### M. H. Rahman

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1998/13. Mohd. Riazuddin.jpg>)

#### Mohd. Riazuddin

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1998/14. Aftab-Ul-Islam, FCA.jpg>)

#### Aftab-Ul-Islam, FCA

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1998/15. Fazle R. M. Hasan, FCA.jpg>)

#### Fazle R. M. Hasan, FCA

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1998/16. Ashraf Ibna Nur.jpg>)

#### Ashraf Ibna Nur

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1998/17. Johurul Islam Chowdhury.jpg>)

#### Johurul Islam Chowdhury

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1998/18. Sajjatuz Jumma_Senior Vice President.jpg>)

#### Sajjatuz Jumma

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1998/19. Mohammad Golam Mustafa.jpg>)

#### Mohammad Golam Mustafa

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1998/20. Khorshid Uddin Mollah.jpg>)

#### Khorshid Uddin Mollah

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1998/21. A.M. Mubash-Shar.jpg>)

#### A.M. Mubash-Shar

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1998/22. Mashuk Hossain.jpg>)

#### Mashuk Hossain

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1998/23. Manwar Hossain.jpg>)

#### Manwar Hossain

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1998/24. Tuhin Malik.jpg>)

#### Tuhin Malik

Director

DCCI Board of Directors 1997

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1997/1. A.S.M. Quasem_President.jpg>)

#### A.S.M. Quasem

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1997/2. Ashraf Ibna Nur_Senior Vice President.jpg>)

#### Ashraf Ibna Nur

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1997/3. Monjur Hossain_Vice President.jpg>)

#### Monjur Hossain

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1997/4. Ali Hossain.jpg>)

#### Ali Hossain

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1997/5. Ashraf Chowdhury.jpg>)

#### Ashraf Chowdhury

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1997/6. A Z M Nazimuddin.jpg>)

#### A Z M Nazimuddin

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1997/7. Sayed Jamaluddin Haider.jpg>)

#### Sayed Jamaluddin Haider

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1997/8. Md. Habibullah.jpg>)

#### Md. Habibullah

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1997/9. M. A. Momen.jpg>)

#### M. A. Momen

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1997/10. A. M. F. Wabidur Rahman.jpg>)

#### A. M. F. Wabidur Rahman

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1997/11. Khandaker A Salam.jpg>)

#### Khandaker A Salam

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1997/12. Iqbal Hasan Mahmud.jpg>)

#### Iqbal Hasan Mahmud

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1997/13. Omar Faruque.jpg>)

#### Omar Faruque

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1997/14. Waliur Rahman.jpg>)

#### Waliur Rahman

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1997/15. Syed Towfiq Ali.jpg>)

#### Syed Towfiq Ali

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1997/16. Md. Belayet Hossain Sikder.jpg>)

#### Md. Belayet Hossain Sikder

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1997/17. Fazle R. M. Hasan, FCA.jpg>)

#### Fazle R. M. Hasan, FCA

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1997/18. Johurul Islam Chowdhury.jpg>)

#### Johurul Islam Chowdhury

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1997/19. Zafar Osman_Vice President.jpg>)

#### Zafar Osman

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1997/20. Absar Karim Chowdhury.jpg>)

#### Absar Karim Chowdhury

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1997/21. Khorshid Uddin Mollah.jpg>)

#### Khorshid Uddin Mollah

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1997/22. Iqbal Hossain.jpg>)

#### Iqbal Hossain

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1997/23. Mashuk Hossain.jpg>)

#### Mashuk Hossain

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1997/24. Manwar Hossain.jpg>)

#### Manwar Hossain

Director

DCCI Board of Directors 1996

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1996/1. Ali Hossain_President.jpg>)

#### Ali Hossain

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1996/2. Fazle R. M. Hasan, FCA_Senior Vice President.jpg>)

#### Fazle R. M. Hasan, FCA

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1996/3. Absar Karim Chowdhury_Vice President.jpg>)

#### Absar Karim Chowdhury

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1996/4. Mahbubzaman.jpg>)

#### Mahbubzaman

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1996/5. Mohammad Younus.jpg>)

#### Mohammad Younus

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1996/6. Benajir Ahmed.jpg>)

#### Benajir Ahmed

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1996/7. Farhad Mahmud.jpg>)

#### Farhad Mahmud

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1996/8. A.S.M. Quasem_President.jpg>)

#### A.S.M. Quasem

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1996/9. Ashraf Chowdhury.jpg>)

#### Ashraf Chowdhury

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1996/10. A Z M Nazimuddin.jpg>)

#### A Z M Nazimuddin

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1996/11. Sayed Jamaluddin Haider.jpg>)

#### Sayed Jamaluddin Haider

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1996/12. Md. Habibullah.jpg>)

#### Md. Habibullah

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1996/13. M. A. Momen.jpg>)

#### M. A. Momen

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1996/14. A. M. F. Wabidur Rahman.jpg>)

#### A. M. F. Wabidur Rahman

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1996/15. A A Moniruzzaman.jpg>)

#### A A Moniruzzaman

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1996/16. Syed Zahirul Haque.jpg>)

#### Syed Zahirul Haque

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1996/17. Syed Towfiq Ali.jpg>)

#### Syed Towfiq Ali

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1996/18. Md. Belayet Hossain Sikder.jpg>)

#### Md. Belayet Hossain Sikder

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1996/19. Johurul Islam Chowdhury.jpg>)

#### Johurul Islam Chowdhury

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1996/20. Arshad Ali.jpg>)

#### Arshad Ali

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1996/21. Alhaj Nazir Hossain.jpg>)

#### Alhaj Nazir Hossain

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1996/22. Iqbal Hossain.jpg>)

#### Iqbal Hossain

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1996/23. Giasuddin Ahmed.jpg>)

#### Giasuddin Ahmed

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1996/24. Monjur Hossain_Vice President.jpg>)

#### Monjur Hossain

Director

DCCI Board of Directors 1995

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1995/1. R Maksud Khan_President.jpg>)

#### R Maksud Khan

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1995/2. Hossain Akhter_Senior Vice President.jpg>)

#### Hossain Akhte

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1995/3. Syed Towfiq Ali_Vice President.jpg>)

#### Syed Towfiq Ali

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1995/4. M Nurul Huda.jpg>)

#### M Nurul Huda

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1995/5. Sabbir Ahmed Khan.jpg>)

#### Sabbir Ahmed Khan

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1995/6. Golam A Khan.jpg>)

#### Golam A Khan

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1995/7. Mahbubzaman.jpg>)

#### Mahbubzaman

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1995/8. Mohammad Younus.jpg>)

#### Mohammad Younus

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1995/9. Benajir Ahmed.jpg>)

#### Benajir Ahmed

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1995/10. Farhad Mahmud.jpg>)

#### Farhad Mahmud

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1995/11. Ali Hossain.jpg>)

#### Ali Hossain

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1995/12. A.S.M. Quasem_President.jpg>)

#### A.S.M. Quasem

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1995/13. Ashraf Chowdhury.jpg>)

#### Ashraf Chowdhury

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1995/14. A Z M Nazimuddin.jpg>)

#### A Z M Nazimuddin

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1995/15. Alhaj Abdus Salam.jpg>)

#### Alhaj Abdus Salam

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1995/16. Abul Kalam Md. Shamsuddin.jpg>)

#### Abul Kalam Md. Shamsuddin

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1995/17. A A Moniruzzaman.jpg>)

#### A A Moniruzzaman

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1995/18. Syed Zahirul Haque.jpg>)

#### Syed Zahirul Haque

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1995/19. Md. Belayet Hossain Sikder.jpg>)

#### Md. Belayet Hossain Sikder

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1995/20. Arshad Ali.jpg>)

#### Arshad Ali

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1995/21. Absar Karim Chowdhury.jpg>)

#### Absar Karim Chowdhury

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1995/22. Abdul Malek.jpg>)

#### Abdul Malek

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1995/23. Mirza Abdul Kaleq.jpg>)

#### Mirza Abdul Kaleq

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1995/24. Giasuddin Ahmed.jpg>)

#### Giasuddin Ahmed

Director

DCCI Board of Directors 1994

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1994/1. A Rob Chowdhury.jpg>)

#### A Rob Chowdhury

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1994/2. Sajjatuz Jumma_SVP.jpg>)

#### Sajjatuz Jumma

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1994/3. Md. Sirajuddin Malik.jpg>)

#### Md. Sirajuddin Malik

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1994/4. Md. Ali Ashraf.jpg>)

#### Md. Ali Ashraf

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1994/5. M H Rahman.jpg>)

#### M H Rahman

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1994/6. A Y Md. Kamal.jpg>)

#### A Y Md. Kamal

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1994/7. M Nurul Huda.jpg>)

#### M Nurul Huda

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1994/8. R Maksud Khan_President.jpg>)

#### R Maksud Khan

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1994/9. Sabbir Ahmed Khan.jpg>)

#### Sabbir Ahmed Khan

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1994/10. Golam A Khan.jpg>)

#### Golam A Khan

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1994/11. Mahbubzaman.jpg>)

#### Mahbubzaman

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1994/12. Mohammad Younus.jpg>)

#### Mohammad Younus

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1994/13. Benajir Ahmed.jpg>)

#### Benajir Ahmed

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1994/14. Farhad Mahmud.jpg>)

#### Farhad Mahmud

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1994/15. Md. Nasiruddin Khan.jpg>)

#### Md. Nasiruddin Khan

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1994/16. Alhaj Abdus Salam.jpg>)

#### Alhaj Abdus Salam

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1994/17. Abul Kalam Md. Shamsuddin.jpg>)

#### Abul Kalam Md. Shamsuddin

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1994/18. A A Moniruzzaman.jpg>)

#### A A Moniruzzaman

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1994/19. Syed Zahirul Haque.jpg>)

#### Syed Zahirul Haque

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1994/20. A.M. Mubash-Shar.jpg>)

#### A.M. Mubash-Shar

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1994/21. Arshad Ali.jpg>)

#### Arshad Ali

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1994/22. Hossain Akhter_Senior Vice President.jpg>)

#### Hossain Akhter

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1994/23. Abdul Malek.jpg>)

#### Abdul Malek

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1994/24. Mirza Abdul Kaleq.jpg>)

#### Mirza Abdul Kaleq

Director

DCCI Board of Directors 1993

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1993/1. A T M Waziullah_President.jpg>)

#### A T M Waziullah

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1993/2. Sayed Jamaluddin Haider_SVP.jpg>)

#### Sayed Jamaluddin Haider

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1993/3. Khorshed Ali Mollah.jpg>)

#### Khorshed Ali Mollah

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1993/4. M Younus.jpg>)

#### M Younus

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1993/5. Md. Ali Ashraf.jpg>)

#### Md. Ali Ashraf

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1993/6. A Rob Chowdhury.jpg>)

#### A Rob Chowdhury

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1993/7. Shamsuddin Ahmed.jpg>)

#### Shamsuddin Ahmed

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1993/8. Khandaker A Salam.jpg>)

#### Khandaker A Salam

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1993/9. M H Rahman.jpg>)

#### M H Rahman

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1993/10. A Y Md. Kamal.jpg>)

#### A Y Md. Kamal

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1993/11. M Nurul Huda.jpg>)

#### M Nurul Huda

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1993/12. R Maksud Khan.jpg>)

#### R Maksud Khan

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1993/13. Sabbir Ahmed Khan.jpg>)

#### Sabbir Ahmed Khan

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1993/14. Golam M Khan.jpg>)

#### Golam M Khan

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1993/15. Md. Ismail Hossain Miah.jpg>)

#### Md. Ismail Hossain Miah

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1993/16. Sajjatuz Jumma.jpg>)

#### Sajjatuz Jumma

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1993/17. Md. Nasiruddin Khan.jpg>)

#### Md. Nasiruddin Khan

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1993/18. Abul Kalam Shamsuddin.jpg>)

#### Abul Kalam Shamsuddin

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1993/18. Alhaj Abdus Salam.jpg>)

#### Alhaj Abdus Salam

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1993/19. A.M. Mubash-Shar.jpg>)

#### A.M. Mubash-Shar

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1993/19. Masudur Rahman.jpg>)

#### Masudur Rahman

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1993/20.  Md. Sirajduddin Malik.jpg>)

#### Md. Sirajduddin Malik

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1993/21. Hossain A Sikder.jpg>)

#### Hossain A Sikder

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1993/22. Abdul Malek.jpg>)

#### Abdul Malek

Director

DCCI Board of Directors 1992

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1992/1. M Younus_President.jpg>)

#### M Younus

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1992/2. Masudur Rahman_Senior Vice President.jpg>)

#### Masudur Rahman

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1992/3. Md. Ismail Hossain Miah_Vice President.jpg>)

#### Md. Ismail Hossain Miah

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1992/4. Mahbubur Rahman.jpg>)

#### Mahbubur Rahman

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1992/5. A T M Waziullah_President.jpg>)

#### A T M Waziullah

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1992/6. Md. Ali Ashraf.jpg>)

#### Md. Ali Ashraf

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1992/7. A S M Quasem.jpg>)

#### A S M Quasem

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1992/8. Humayun Zahir.jpg>)

#### Humayun Zahir

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1992/9. A Rob Chowdhury.jpg>)

#### A Rob Chowdhury

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1992/10. Shamsuddin Ahmed.jpg>)

#### Shamsuddin Ahmed

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1992/11. Khandaker A Salam.jpg>)

#### Khandaker A Salam

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1992/12. M H Rahman.jpg>)

#### M H Rahman

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1992/13. Miah Abudullah Wazad, MP.jpg>)

#### Miah Abudullah Wazad, MP

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1992/14. A Y Md. Kamal.jpg>)

#### A Y Md. Kamal

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1992/15. Sayed Jamaluddin Haider.jpg>)

#### Sayed Jamaluddin Haider

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1992/16. Sajjatuz Jumma.jpg>)

#### Sajjatuz Jumma

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1992/17. Alhaj Md. Wahiullah.jpg>)

#### Alhaj Md. Wahiullah

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1992/18. Md. Nasiruddin Khan.jpg>)

#### Md. Nasiruddin Khan

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1992/19. Saidur Rahman.jpg>)

#### Saidur Rahman

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1992/20. A.M. Mubash-Shar.jpg>)

#### A.M. Mubash-Shar

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1992/21. Khurshid Ali.jpg>)

#### Khurshid Ali

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1992/22. Alhaj Md. Nazir Hossain.jpg>)

#### Alhaj Md. Nazir Hossain

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1992/23. Md. Sirajduddin Malik.jpg>)

#### Md. Sirajduddin Malik

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1992/24. Monjur Hossasin.jpg>)

#### Monjur Hossasin

Director

DCCI Board of Directors 1991

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1991/1. Mahbubur Rahman_President.jpg>)

#### Mahbubur Rahman

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1991/2. Masudur Rahman_Senior Vice President.jpg>)

#### Masudur Rahman

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1991/3. Md. Ismail Hossain Miah_Vice President.jpg>)

#### Md. Ismail Hossain Miah

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1991/4. M Younus.jpg>)

#### M Younus

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1991/5. A T M Waziullah_President.jpg>)

#### A T M Waziullah

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1991/6. Md. Ali Ashraf.jpg>)

#### Md. Ali Ashraf

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1991/7. A S M Quasem.jpg>)

#### A S M Quasem

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1991/8. Humayun Zahir.jpg>)

#### Humayun Zahir

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1991/9. A Rob Chowdhury.jpg>)

#### A Rob Chowdhury

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1991/10. Shamsuddin Ahmed.jpg>)

#### Shamsuddin Ahmed

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1991/11. Khandaker A Salam.jpg>)

#### Khandaker A Salam

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1991/12. M H Rahman.jpg>)

#### M H Rahman

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1991/13. Miah Abudullah Wazad, MP.jpg>)

#### Miah Abudullah Wazad, MP

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1991/14. A Y Md. Kamal.jpg>)

#### A Y Md. Kamal

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1991/15. Sayed Jamaluddin Haider.jpg>)

#### Sayed Jamaluddin Haider

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1991/16. Sajjatuz Jumma.jpg>)

#### Sajjatuz Jumma

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1991/17. Alhaj Md. Wahiullah.jpg>)

#### Alhaj Md. Wahiullah

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1991/18. Md. Nasiruddin Khan.jpg>)

#### Md. Nasiruddin Khan

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1991/19. Saidur Rahman.jpg>)

#### Saidur Rahman

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1991/20. A.M. Mubash-Shar.jpg>)

#### A.M. Mubash-Shar

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1991/21. Khurshid Ali.jpg>)

#### Khurshid Ali

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1991/22. Alhaj Md. Nazir Hossain.jpg>)

#### Alhaj Md. Nazir Hossain

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1991/23. Hafez Monir Hossain \(Late\).jpg>)

#### Hafez Monir Hossain

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1991/24. Md. Sirajduddin Malik.jpg>)

#### Md. Sirajduddin Malik

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1991/25. Monjur Hossasin.jpg>)

#### Monjur Hossasin

Director

DCCI Board of Directors 1990

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1990/1. Abu Sayeed Mahmud_President.jpg>)

#### Abu Sayeed Mahmud

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1990/2. A.M. Mubash-Shar_SVP.jpg>)

#### A.M. Mubash-Shar

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1990/3. M A Khaleq_Vice President.jpg>)

#### M A Khaleq

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1990/4. Mahbubur Rahman.jpg>)

#### Mahbubur Rahman

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1990/5. A Y M Muklasur Rahman.jpg>)

#### A Y M Muklasur Rahman

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1990/6. A T M Waziullah.jpg>)

#### A T M Waziullah

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1990/7. M N Islam.jpg>)

#### M N Islam

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1990/8. M Nurul Huda.jpg>)

#### M Nurul Huda

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1990/9. Humayun Zahir.jpg>)

#### Humayun Zahir

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1990/10. A S M Quasem.jpg>)

#### A S M Quasem

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1990/11. Ashraf Ud Dowla.jpg>)

#### Ashraf Ud Dowla

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1990/11. Md. Nizam Uddin.jpg>)

#### Md. Nizam Uddin

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1990/12. Niyamat Ullah \(Sabu\).jpg>)

#### Niyamat Ullah (Sabu)

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1990/13. Golam Mohiuddin.jpg>)

#### Golam Mohiuddin

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1990/14. A. Hossain.jpg>)

#### A. Hossain

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1990/15. Sajjatuz Jumma.jpg>)

#### Sajjatuz Jumma

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1990/16. Khurshid Ali.jpg>)

#### Khurshid Ali

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1990/17. Sayed Towfiq Ali.jpg>)

#### Sayed Towfiq Ali

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1990/18. Hafez Monir Hossain \(Late\).jpg>)

#### Hafez Monir Hossain

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1990/19. Sayed Jamaluddin Haider.jpg>)

#### Sayed Jamaluddin Haider

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1990/20. Masudur Rahman.jpg>)

#### Masudur Rahman

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1990/21. Md. Ismail Hossain Miah_Vice President.jpg>)

#### Md. Ismail Hossain Miah

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1990/22. Monjur Hossasin.jpg>)

#### Monjur Hossasin

Director

DCCI Board of Directors 1989

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1989/1. Abu Sayeed Mahmud_President.jpg>)

#### Abu Sayeed Mahmud

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1989/2. A.M. Mubash-Shar_SVP.jpg>)

#### A.M. Mubash-Shar

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1989/3. M A Khaleq_Vice President.jpg>)

#### M A Khaleq

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1989/4. Mahbubur Rahman.jpg>)

#### Mahbubur Rahman

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1989/5. A T M Waziullah.jpg>)

#### A T M Waziullah

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1989/6. M Nurul Huda.jpg>)

#### M Nurul Huda

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1989/7. A Y M Muklasur Rahman.jpg>)

#### A Y M Muklasur Rahman

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1989/8. M N Islam.jpg>)

#### M N Islam

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1989/9. Humayun Zahir.jpg>)

#### Humayun Zahir

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1989/10. A S M Quasem.jpg>)

#### A S M Quasem

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1989/11. Ashraf Ud Dowla.jpg>)

#### Ashraf Ud Dowla

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1989/12. Golam Mohiuddin.jpg>)

#### Golam Mohiuddin

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1989/13. Sajjatuz Jumma.jpg>)

#### Sajjatuz Jumma

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1989/14. Sayed Towfiq Ali.jpg>)

#### Sayed Towfiq Ali

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1989/15. Sayed Jamaluddin Haider.jpg>)

#### Sayed Jamaluddin Haider

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1989/16. Md. Ismail Hossain Miah.jpg>)

#### Md. Ismail Hossain Miah

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1989/17. Md. Nizam Uddin.jpg>)

#### Md. Nizam Uddin

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1989/18. Niyamat Ullah \(Sabu\).jpg>)

#### Niyamat Ullah (Sabu)

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1989/19. A. Hossain.jpg>)

#### A. Hossain

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1989/20. Khurshid Ali.jpg>)

#### Khurshid Ali

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1989/21. Hafez Monir Hossain \(Late\).jpg>)

#### Hafez Monir Hossain

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1989/22. Masudur Rahman.jpg>)

#### Masudur Rahman

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1989/23. Monjur Hossasin.jpg>)

#### Monjur Hossasin

Director

DCCI Board of Directors 1988

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1988/1. Abu Sayeed Mahmud_President.jpg>)

#### Abu Sayeed Mahmud

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1988/2. A.M. Mubash-Shar_SVP.jpg>)

#### A.M. Mubash-Shar

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1988/3. Masudur Rahman_VP.jpg>)

#### Masudur Rahman

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1988/4. Mustafa Zaman Abbasi.jpg>)

#### Mustafa Zaman Abbasi

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1988/5. A R Khan.jpg>)

#### A R Khan

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1988/6. A T M Waziullah.jpg>)

#### A T M Waziullah

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1988/7. Md. Ali Ashraf.jpg>)

#### Md. Ali Ashraf

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1988/8. Dr. A M M Khan.jpg>)

#### Dr. A M M Khan

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1988/9. M Nurul Huda.jpg>)

#### M Nurul Huda

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1988/10. Shah M Selim.jpg>)

#### Shah M Selim

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1988/11. Khurshid Alam.jpg>)

#### Khurshid Alam

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1988/12. A K Mehmud.jpg>)

#### A K Mehmud

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1988/14. F K Chowdhury.jpg>)

#### F K Chowdhury

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1988/15. Iftakher Ahmed.jpg>)

#### Iftakher Ahmed

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1988/16. Md Shahidullah.jpg>)

#### Md Shahidullah

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1988/17. Md. Wahiullah.jpg>)

#### Md. Wahiullah

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1988/18. Khurshid Ali.jpg>)

#### Khurshid Ali

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1988/19. Sayed Towfiq Ali.jpg>)

#### Sayed Towfiq Ali

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1988/20. A N M Bahaual Haque.jpg>)

#### A N M Bahaual Haque

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1988/21. Adam Ali Master.jpg>)

#### Adam Ali Master

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1988/21. Saidur Rahman.jpg>)

#### Saidur Rahman

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1988/22. Mojibur Rahman.jpg>)

#### Mojibur Rahman

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1988/23. Md. Mashuk Hossain.jpg>)

#### Md. Mashuk Hossain

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1988/23. Monjur Hossasin.jpg>)

#### Monjur Hossasin

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1988/24. Hafez Monir Hossain.jpg>)

#### Hafez Monir Hossain

Director

DCCI Board of Directors 1987

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1987/1. Abu Sayeed Mahmud_President.jpg>)

#### Abu Sayeed Mahmud

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1987/2. A.M. Mubash-Shar_SVP.jpg>)

#### A.M. Mubash-Shar

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1987/3. Masudur Rahman_VP.jpg>)

#### Masudur Rahman

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1987/4. Mustafa Zaman Abbasi.jpg>)

#### Mustafa Zaman Abbasi

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1987/5. A R Khan.jpg>)

#### A R Khan

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1987/6. A T M Waziullah.jpg>)

#### A T M Waziullah

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1987/7. Md. Ali Ashraf.jpg>)

#### Md. Ali Ashraf

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1987/8. Dr. A M M Khan.jpg>)

#### Dr. A M M Khan

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1987/9. M Nurul Huda.jpg>)

#### M Nurul Huda

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1987/10. Shah M Selim.jpg>)

#### Shah M Selim

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1987/11. Khurshid Alam.jpg>)

#### Khurshid Alam

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1987/12. A K Mehmud.jpg>)

#### A K Mehmud

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1987/14. F K Chowdhury.jpg>)

#### F K Chowdhury

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1987/15. Iftakher Ahmed.jpg>)

#### Iftakher Ahmed

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1987/16. Md Shahidullah.jpg>)

#### Md Shahidullah

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1987/17. Md. Wahiullah.jpg>)

#### Md. Wahiullah

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1987/18. Khurshid Ali.jpg>)

#### Khurshid Ali

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1987/19. Sayed Towfiq Ali.jpg>)

#### Sayed Towfiq Ali

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1987/20. A N M Bahaual Haque.jpg>)

#### A N M Bahaual Haque

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1987/21. Saidur Rahman.jpg>)

#### Saidur Rahman

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1987/22. Adam Ali Master.jpg>)

#### Adam Ali Master

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1987/23. Mojibur Rahman.jpg>)

#### Mojibur Rahman

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1987/24. Md. Mashuk Hossain.jpg>)

#### Md. Mashuk Hossain

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1987/25. Hafez Monir Hossain.jpg>)

#### Hafez Monir Hossain

Director

DCCI Board of Directors 1986

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1986/1. Abu Sayeed Mahmud_President.jpg>)

#### Abu Sayeed Mahmud

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1986/2. A.M. Mubash-Shar_SVP.jpg>)

#### A.M. Mubash-Shar

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1986/3. Masudur Rahman_VP.jpg>)

#### Masudur Rahman

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1986/4. Mustafa Zaman Abbasi.jpg>)

#### Mustafa Zaman Abbasi

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1986/5. A R Khan.jpg>)

#### A R Khan

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1986/6. A T M Waziullah.jpg>)

#### A T M Waziullah

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1986/7. Md. Ali Ashraf.jpg>)

#### Md. Ali Ashraf

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1986/8. Dr. A M M Khan.jpg>)

#### Dr. A M M Khan

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1986/9. M Nurul Huda.jpg>)

#### M Nurul Huda

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1986/10. Shah M Selim.jpg>)

#### Shah M Selim

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1986/11. Khurshid Alam.jpg>)

#### Khurshid Alam

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1986/12. A K Mehmud.jpg>)

#### A K Mehmud

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1986/14. F K Chowdhury.jpg>)

#### F K Chowdhury

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1986/15. Iftakher Ahmed.jpg>)

#### Iftakher Ahmed

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1986/16. Md Shahidullah.jpg>)

#### Md Shahidullah

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1986/17. Md. Wahiullah.jpg>)

#### Md. Wahiullah

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1986/18. Khurshid Ali.jpg>)

#### Khurshid Ali

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1986/19. Sayed Towfiq Ali.jpg>)

#### Sayed Towfiq Ali

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1986/20. A N M Bahaual Haque.jpg>)

#### A N M Bahaual Haque

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1986/21. Saidur Rahman.jpg>)

#### Saidur Rahman

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1986/22. Adam Ali Master.jpg>)

#### Adam Ali Master

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1986/23. Mojibur Rahman.jpg>)

#### Mojibur Rahman

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1986/24. Md. Mashuk Hossain.jpg>)

#### Md. Mashuk Hossain

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1986/25. Hafez Monir Hossain.jpg>)

#### Hafez Monir Hossain

Director

DCCI Board of Directors 1985

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1985/1. Mahbubur Rahman_President.jpg>)

#### Mahbubur Rahman

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1985/2. Md. Ali. Hossain_SVP.jpg>)

#### Md. Ali. Hossain

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1985/3. Saidur Rahman_Vice President.jpg>)

#### Saidur Rahman

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1985/4. M Younus.jpg>)

#### M Younus

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1985/5. Anwar Hossain.jpg>)

#### Anwar Hossain

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1985/6. Deen Mohammad.jpg>)

#### Deen Mohammad

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1985/7. Abu Naseer Ahmed.jpg>)

#### Abu Naseer Ahmed

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1985/8. Mustafa Zaman Abbasi.jpg>)

#### Mustafa Zaman Abbasi

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1985/9. Abdul Maleq Chowdhury.jpg>)

#### Abdul Maleq Chowdhury

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1985/10. A. R. Khan.jpg>)

#### Shah M Selim

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1985/11. A T M Waziullah.jpg>)

#### A T M Waziullah

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1985/12. Abu Sayeed Mahmud.jpg>)

#### Abu Sayeed Mahmud

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1985/13. Md. Ali Ashraf.jpg>)

#### Md. Ali Ashraf

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1985/14. Dr. A M M Khan.jpg>)

#### Dr. A M M Khan

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1985/15. M Nurul Huda.jpg>)

#### M Nurul Huda

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1985/16. M A Khaleq.jpg>)

#### M A Khaleq

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1985/17. Md Shahidullah.jpg>)

#### Md Shahidullah

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1985/18. A.M. Mubash-Shar.jpg>)

#### A.M. Mubash-Shar

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1985/19. Md. Wahiullah.jpg>)

#### Md. Wahiullah

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1985/20. Khurshid Ali.jpg>)

#### Khurshid Ali

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1985/21. Ashraf Hossain Chowdhury.jpg>)

#### Ashraf Hossain Chowdhury

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1985/22. Adam Ali Master.jpg>)

#### Adam Ali Master

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1985/23. Md. Fozlur Rahman.jpg>)

#### Md. Fozlur Rahman

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1985/24. Md. Mashuk Hossain.jpg>)

#### Md. Mashuk Hossain

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1985/25. Masudur Rahman.jpg>)

#### Masudur Rahman

Director

DCCI Board of Directors 1984

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1984/1. M Younus_President.jpg>)

#### M Younus

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1984/2. Alhaj Abdus Salam_SVP.jpg>)

#### Alhaj Abdus Salam

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1984/3. Ramiz Uddin Fakir_VP.jpg>)

#### Ramiz Uddin Fakir

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1984/4. M A Sattar.jpg>)

#### M A Sattar

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1984/5. Ahaj M A Haq.jpg>)

#### Ahaj M A Haq

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1984/6. L Salam.jpg>)

#### L Salam

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1984/7. M A Quasem.jpg>)

#### M A Quasem

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1984/8. Anwar Hossain.jpg>)

#### Anwar Hossain

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1984/9. Deen Mohammad.jpg>)

#### Deen Mohammad

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1984/10. Mahbubur Rahman.jpg>)

#### Mahbubur Rahman

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1984/11. Abu Naseer Ahmed.jpg>)

#### Abu Naseer Ahmed

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1984/12. Mustafa Zaman Abbasi.jpg>)

#### Mustafa Zaman Abbasi

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1984/13. Abdul Maleq Chowdhury.jpg>)

#### Abdul Maleq Chowdhury

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1984/14. A T M Waziullah.jpg>)

#### A T M Waziullah

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1984/15. Hasem Ali Khan.jpg>)

#### Hasem Ali Khan

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1984/16. Md. Ali. Hossain.jpg>)

#### Md. Ali. Hossain

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1984/17. M A Khaleq.jpg>)

#### M A Khaleq

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1984/18. Md. Shahidullah.jpg>)

#### Md. Shahidullah

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1984/19. A.M. Mubash-Shar.jpg>)

#### A.M. Mubash-Shar

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1984/20. Ashraf Hossain Chowdhury.jpg>)

#### Ashraf Hossain Chowdhury

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1984/21. Saidur Rahman.jpg>)

#### Saidur Rahman

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1984/22. Nazir Hossain.jpg>)

#### Nazir Hossain

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1984/23. Md. Fozlur Rahman.jpg>)

#### Md. Fozlur Rahman

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1984/24. Md. Mashuk Hossain.jpg>)

#### Md. Mashuk Hossain

Director

DCCI Board of Directors 1981-1983

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1983/1. M A Sattar_President.jpg>)

#### M A Sattar

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1983/2. Shamsus Zoha Khan_SVP.jpg>)

#### Shamsus Zoha Khan

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1983/3. A A Moniruzzaman_Junior Vice Pesident.jpg>)

#### A A Moniruzzaman

Junior Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1983/4. Saleh Ahmed.jpg>)

#### Saleh Ahmed

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1983/5. A Qasem.jpg>)

#### A Qasem

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1983/6. Dr. Anwor Hossain.jpg>)

#### Dr. Anwor Hossain

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1983/7. M A Ashraf.jpg>)

#### M A Ashraf

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1983/8. Alhaj M A Haq.jpg>)

#### Alhaj M A Haq

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1983/9. L Salam.jpg>)

#### L Salam

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1983/10. M A Quasem.jpg>)

#### M A Quasem

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1983/11. Anwar Hossain.jpg>)

#### Anwar Hossain

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1983/12. Deen Mohammad.jpg>)

#### Deen Mohammad

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1983/13. Mahbubur Rahman.jpg>)

#### Mahbubur Rahman

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1983/14. M Younus.jpg>)

#### M Younus

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1983/15. Md. Khurshid.jpg>)

#### Md. Khurshid

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1983/16. Hasem Ali Khan.jpg>)

#### Hasem Ali Khan

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1983/17. Alhaj Abdus Salam.jpg>)

#### Alhaj Abdus Salam

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1983/18. Md. Ali Hossain.jpg>)

#### Md. Ali Hossain

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1983/19. M A Khaleq.jpg>)

#### M A Khaleq

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1983/20. Ramiz Uddin Fakir.jpg>)

#### Ramiz Uddin Fakir

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1983/21. Ashraf Hossain Chowdhury.jpg>)

#### Ashraf Hossain Chowdhury

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1983/22. Hafez Monir Hossain.jpg>)

#### Hafez Monir Hossain

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1983/23. Nazir Hossain.jpg>)

#### Nazir Hossain

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1983/24. Md. Fozlur Rahman.jpg>)

#### Md. Fozlur Rahman

Director

DCCI Board of Directors 1976

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1976/1. Chowdhury Tanvir Ahmed Siddiky_President.jpg>)

#### Chowdhury Tanvir Ahmed Siddiky

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1976/2. M. A Haq_Senior Vice President.jpg>)

#### M. A Haq

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1976/3. A. B. Saddique_Junior Vice President.jpg>)

#### A. B. Saddique

Junior Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1976/4. K. A. Sattar.jpg>)

#### K. A. Sattar

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1976/5. M. A. Ashraf.jpg>)

#### M. A. Ashraf

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1976/6. Md. Mofazzal Hossain.jpg>)

#### Md. Mofazzal Hossain

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1976/7. M. A. Sattar.jpg>)

#### M. A. Sattar

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1976/8. Nasiruddin Ahmed.jpg>)

#### Nasiruddin Ahmed

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1976/9. Nasiruddin Ahmed.jpg>)

#### Nasiruddin Ahmed

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1976/10. Anwar Hossain.jpg>)

#### Anwar Hossain

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1976/11. Khan Mohd Iqbal.jpg>)

#### Khan Mohd Iqbal

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1976/12. Mosharraf Hossain.jpg>)

#### Mosharraf Hossain

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1976/13. Md. Akram Hussain.jpg>)

#### Md. Akram Hussain

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1976/14. Ali Hossain.jpg>)

#### Ali Hossain

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1976/15. Md. Nurul Haque.jpg>)

#### Md. Nurul Haque

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1976/16. M. A. Khaleque.jpg>)

#### M16. M. A. Khaleque

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1976/17. Hafez Monir Hossain.jpg>)

#### Hafez Monir Hossain

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1976/18. Md. Abdur Razzaque Miah.jpg>)

#### Md. Abdur Razzaque Miah

Director

DCCI Board of Directors 1975

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1975/K A Sattar \(President\).jpg>)

#### K A Sattar

President

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1975/AMM Shamsul Alam \(Senior Vice President\).jpg>)

#### AMM Shamsul Alam

Sr. Vice President

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1975/M.A. Haq \(Vice President\).jpg>)

#### M.A. Haq

Vice President

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1975/A Sattar.jpg>)

#### A Sattar

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1975/AB Siddique.jpg>)

#### AB Siddique

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1975/AFM Abdul Halim.jpg>)

#### AFM Abdul Halim

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1975/Ali Hossain.jpg>)

#### Ali Hossain

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1975/Altaf Hossain Sardar.jpg>)

#### Altaf Hossain Sardar

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1975/AR Khan.jpg>)

#### AR Khan

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1975/ASM Khaled.jpg>)

#### ASM Khaled

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1975/Ataul Haque.jpg>)

#### Ataul Haque

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1975/Azimuddin Ahmed.jpg>)

#### Azimuddin Ahmed

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1975/Hafej Monir Hossain.jpg>)

#### Hafej Monir Hossain

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1975/M A Ashraf.jpg>)

#### M A Ashraf

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1975/M Ansari.jpg>)

#### M Ansari

Director

![John Smith](<https://dhakachamber.com/public/images/pastmanagement/1975/Mahmudul Hassan Khan.jpg>)

#### Mahmudul Hassan Khan

Director

![Sarah Johnson](<https://dhakachamber.com/public/images/pastmanagement/1975/Md. Akram Hossain.jpg>)

#### Md. Akram Hossain

Director

![Michael Brown](<https://dhakachamber.com/public/images/pastmanagement/1975/Md. Mofazzal Hossain.jpg>)

#### Md. Mofazzal Hossain

Director

DCCI Board of Directors 1967

![Annual Conference 2024](https://dhakachamber.com/public/images/pastmanagement/1967.jpeg)

From Left to Right: Faiz Hossain, Y. A. Bawani (Chairman, E. B), Akhlaque Ahmed, Q. J. Ahmed C.S.P., G.H. Khan, Mujibuddin Ahmed, A. Sattar Karawadia, A. Quasem (President), Matiur Rahman, S. E. Kabir, H. M. Hasan, Syed Ali, Akbar Ali, Ashraf Ahmed, Ataul Hoque, H. M. Shakil (Senior Vice President), Ishaque Mohammed (Junior Vice President)

### ABOUT US

-   [Board of Directors](https://dhakachamber.com/board-of-directors)
-   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
-   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)

### USEFUL LINKS

-   [DBI College](http://www.dbicollege.edu.bd)
-   [DCCI Business Institute](http://dcci-dbi.edu.bd)
-   [BUILD](http://www.buildbd.org)
-   [BIAC](https://www.biac.org.bd)
-   [ICCB](https://iccbangladesh.org.bd)

### MEMBERSHIP

-   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
-   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
-   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
-   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
-   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
-   [Become a Member](https://membership.dhakachamber.com/register)
-   [Member Login](https://membership.dhakachamber.com)
-   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
-   [Member Query](https://dhakachamber.com/member-query)
-   [Hot Line](https://dhakachamber.com/hot_line)

### MEDIA

-   [Chamber News](https://dhakachamber.com/media/news)
-   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
-   [Photo Gallery](https://dhakachamber.com/albums)
-   [Video Gallery](https://dhakachamber.com/videos)

### DOWNLOAD

-   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
-   [DCCI Reviews](https://dhakachamber.com/publications/reviews)
-   [DCCI Publications](https://dhakachamber.com/publications)
-   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
-   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)

×

-   [Home(current)](https://dhakachamber.com)
-   [About us](#)
    -   [Brief About DCCI](https://dhakachamber.com/about-us)
    -   [International Affiliations](https://dhakachamber.com/international-affiliations)
    -   [DCCI Founders](https://dhakachamber.com/dcci-founders)
    -   [Former Presidents](https://dhakachamber.com/dcci-former-presidents)
    -   [Former Senior Vice Presidents](https://dhakachamber.com/dcci-former-senior-vice-presidents)
    -   [Former Vice Presidents](https://dhakachamber.com/dcci-former-vice-presidents)
    -   [Achievements & Awards](https://dhakachamber.com/achievements-awards)
    -   [Policy and Objectives](https://dhakachamber.com/quality-policy-and-objectives)
-   [Organizational Information](#)
    -   [Board of Directors](https://dhakachamber.com/board-of-directors)
    -   [Previous Board of Directors](https://dhakachamber.com/dcci-allpastmanagement)
    -   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
    -   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)
-   [President](https://dhakachamber.com/president)
-   [Membership](#)
    -   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
    -   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
    -   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
    -   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
    -   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
    -   [Become a Member](https://membership.dhakachamber.com/register)
    -   [Member Login](https://membership.dhakachamber.com)
    -   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
    -   [Member Query](https://dhakachamber.com/member-query)
    -   [Hot Line](https://dhakachamber.com/hot_line)
-   [Projects](https://dhakachamber.com/project-activities)
-   [Seminar](https://dhakachamber.com/media/seminar)
-   [Publications](#)
    -   [DCCI Research Service](https://dhakachamber.com/pdf_viewer/storage/2024/circular/DCCI%20Research%20Service.pdf)
    -   [Research Guideline](https://dhakachamber.com/pdf_viewer/storage/2024/circular/Research%20Guideline.pdf)
    -   [DCCI Journal (DJBEP)](https://journal.dhakachamber.com/)
    -   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
    -   [DCCI Review](https://dhakachamber.com/publications/reviews)
    -   [DCCI Publications](https://dhakachamber.com/publications)
    -   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
    -   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)
    -   [Introducing DCCI 2023](https://www.dhakachamber.com/storage/print_media/2023/07/Introducing%202023.pdf)
-   [Media](#)
    -   [Chamber News](https://dhakachamber.com/media/news)
    -   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
    -   [Photo Gallery](https://dhakachamber.com/albums)
    -   [Video Gallery](https://dhakachamber.com/videos)
    -   [Fairs & Exhibitions](https://www.dhakachamber.com/storage/2026/03/dccifair.pdf)
-   [Policy](#)
    -   [Export Policy](https://www.dhakachamber.com/storage/policy/3VFoMxkr6Z3EZdC8wz7YHfrIBfPP5N0Y6n7eEEFJ.pdf)
    -   [Import Policy](https://www.dhakachamber.com/storage/policy/b6uhXGhpdl30N68gl3Yg9mV5P6vGIPAjquqTu35f.pdf)
    -   [Industry Policy](https://www.dhakachamber.com/storage/policy/kpHRSdbYmY90O7wcyYmkZTSvumKEXfz5uwPTlOn5.pdf)
    -   [ICT Policy](https://www.dhakachamber.com/storage/policy/abTlbODgI2I4Aqbrix5Cs2DHvFD5lW3OwDmfKXmH.pdf)
-   [BILATERAL TRADE](#)
    -   [Bilateral Trade](https://dhakachamber.com/bilateral-trade)
    -   [Africa](https://dhakachamber.com/bilateral-trade/africa)
    -   [America](https://dhakachamber.com/bilateral-trade/america)
    -   [Asian](https://dhakachamber.com/bilateral-trade/asian)
    -   [ASEAN](https://dhakachamber.com/bilateral-trade/asean)
    -   [SAARC](https://dhakachamber.com/bilateral-trade/saarc)
    -   [Middle East](https://dhakachamber.com/bilateral-trade/middle-east)
    -   [European Union](https://dhakachamber.com/bilateral-trade/european-union)
-   [About Bangladesh](#)
    -   [General Information](https://dhakachamber.com/bangladesh-country-profile)
    -   [Business Opportunities in Bangladesh](https://dhakachamber.com/trade-and-business-opportunities-in-bangladesh)
    -   [Useful Links](https://dhakachamber.com/useful-links)
-   [B2B Directory](#)
    -   [B2B Directory](https://dhakachamber.com/b2b)
    -   [B2B Member Login](https://dhakachamber.com/login)
    -   [B2B Registration](https://dhakachamber.com/b2b-reg)