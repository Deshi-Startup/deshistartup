---
source: "Dhaka Chamber of Commerce & Industry (DCCI)"
tier: 1
category: "Chamber"
url: "https://dhakachamber.com/dcci-former-vice-presidents"
title: "DCCI ::  Former Vice Presidents"
scraped_at: "2026-07-02"
---

# Former Vice Presidents

![](https://dhakachamber.com/storage/dcci-former-vps/January2020/iUGqONjnEmAxwRdSovel.png)

### Ishak Ahmed

(1967-68)

![](https://dhakachamber.com/storage/dcci-former-vps/June2019/XFldr8KZ1kO0JKiDhjug.jpg)

### Late Mokhlesur Rahman

(1970-72)

![](https://dhakachamber.com/storage/dcci-former-vps/June2019/n83evvWKqn5571dpUy1W.jpg)

### Late Mokhlesur Rahman

(1973)

![](https://dhakachamber.com/storage/dcci-former-vps/June2019/SBGa09hoD4VMx6IDkAyg.jpg)

### Late M.A. Huq

(1975)

![](https://dhakachamber.com/storage/dcci-former-vps/June2019/2gJ95XnDYzg4Jip6QOEP.jpg)

### A.B. Siddique

(1976)

![](https://dhakachamber.com/storage/dcci-former-vps/June2019/ov4Lsr45OwqjROEXjDmU.jpg)

### Late Mosharraf Hossain

(1977-78)

![](https://dhakachamber.com/storage/dcci-former-vps/June2019/2uOhRGAmXz9Q9asJVDWW.jpg)

### Late M.A. Razzaque Miah

(1978-79)

![](https://dhakachamber.com/storage/dcci-former-vps/June2019/LnhExVq1JCuue0Kpko0g.jpg)

### Mojibur Rahman

(1979-82)

![](https://dhakachamber.com/storage/dcci-former-vps/June2019/PdWRinN24wsidVdvoqYA.jpg)

### A.A. Moniruzzaman

(1982-84)

![](https://dhakachamber.com/storage/dcci-former-vps/June2019/tzC6sLq24iBkgVjCSVTP.jpg)

### Late Ramizuddin Fakir

(1984-85)

![](https://dhakachamber.com/storage/dcci-former-vps/June2019/zjA9i2bwANjFT0bQoJ5h.jpg)

### Late Sayeedur Rahman

(1985-86)

![](https://dhakachamber.com/storage/dcci-former-vps/June2019/fDjQgLNeBqCGkfyPBnsB.jpg)

### Late Masudur Rahman

(1986-88)

![](https://dhakachamber.com/storage/dcci-former-vps/June2019/4dklNB2bBbmh9FvgRNmb.jpg)

### Late M.A. Khaleque

(1989-90)

![](https://dhakachamber.com/storage/dcci-former-vps/June2019/b7PdTrejw3DMsibD2FIr.jpg)

### Md. Ismail Hossain Miah

(1991-92)

![](https://dhakachamber.com/storage/dcci-former-vps/June2019/pJKjZyIOdf7uqWTJ3ui6.jpg)

### Md. Ismail Hossain Miah

(1992-93)

![](https://dhakachamber.com/storage/dcci-former-vps/June2019/U8boSJHA4cSgd4aIryAf.jpg)

### Khurshed Ali Mollah

(1993-94)

![](https://dhakachamber.com/storage/dcci-former-vps/June2019/zwgkgsrlrUgaKbw5Q0xy.jpg)

### Late Md. Sirajuddin Malik

(1994-95)

![](https://dhakachamber.com/storage/dcci-former-vps/June2019/hNmJYgilrSWctz4GG8pb.jpg)

### Late Syed Toufique Ali

(1995)

![](https://dhakachamber.com/storage/dcci-former-vps/June2019/hbCDTeE1zhAvByzkl3aE.jpg)

### Absar Karim Chowdhury

(1996)

![](https://dhakachamber.com/storage/dcci-former-vps/October2019/l3Od4F8WcKn1MxQq1Oxt.jpg)

### Manzur Hossain

(1997)

![](https://dhakachamber.com/storage/dcci-former-vps/October2019/K7rURWpPKu2aNtMwx2kx.jpg)

### Zafar Osman

(1998)

![](https://dhakachamber.com/storage/dcci-former-vps/June2019/by4XvNWfRqDXW8Zam2Pn.jpg)

### Nasir Hossain

(1999)

![](https://dhakachamber.com/storage/dcci-former-vps/October2019/3PiLVsYXz0tVKR3wnVN7.jpg)

### Muhammad Golam Mustafa

(2000)

![](https://dhakachamber.com/storage/dcci-former-vps/June2019/C556JuDEaCXsN2XF1I8a.jpg)

### Absar Karim Chowdhury

(2001)

![](https://dhakachamber.com/storage/dcci-former-vps/June2019/Lw7fbqbbImSFAjfY7FMZ.jpg)

### Hossain Khaled

(2002-3)

![](https://dhakachamber.com/storage/dcci-former-vps/June2019/MojqV3WPt9TMBtqRVS0E.jpg)

### M. Abu Hurairah

(2004)

![](https://dhakachamber.com/storage/dcci-former-vps/June2019/uwJz4aWhTDVtsZ8RbL76.jpg)

### Hossain A. Sikder

(2006)

![](https://dhakachamber.com/storage/dcci-former-vps/June2019/X6Ej80E9p84fJvkgRgFX.jpg)

### Al-haj Md. Alauddin Malik

(2007)

![](https://dhakachamber.com/storage/dcci-former-vps/June2019/CiEwiUtlg5neiivBNGwH.jpg)

### Kh. Shahidul Islam

(2008)

![](https://dhakachamber.com/storage/dcci-former-vps/June2019/KG1yhOWbEGasrp3OOaB0.jpg)

### Late Md. Sirajuddin Malik

(2009-10)

![](https://dhakachamber.com/storage/dcci-former-vps/June2019/K8m0nIZo54TXJtHU0MIj.jpg)

### Nasir Hossain

(2011)

![](https://dhakachamber.com/storage/dcci-former-vps/June2019/36lTpaTPub8WGAOlHvIS.jpg)

### Absar Karim Chowdhury

(2013)

![](https://dhakachamber.com/storage/dcci-former-vps/June2019/evq88KCVxoocVEWE7Id0.jpg)

### Kh. Shahidul Islam

(2014)

![](https://dhakachamber.com/storage/dcci-former-vps/June2019/GDHsyFaXwlXQr88hRtWB.jpg)

### Shoaib Chowdhury

(2015)

![](https://dhakachamber.com/storage/dcci-former-vps/June2019/S8s252CVjjHCS89CedZo.jpg)

### K. Atique-E- Rabbani, FCA

(2016)

![](https://dhakachamber.com/storage/dcci-former-vps/June2019/Mgyqatd2vH2AC7GOLL1H.jpg)

### Hossain A. Sikder

(2017)

![](https://dhakachamber.com/storage/dcci-former-vps/June2019/vZwijgDazhuxFRInKEyD.jpg)

### Riyadh Hossain

(2018)

![](https://dhakachamber.com/storage/dcci-former-vps/December2019/R1Krp3Ip54uiPsLQ1UBh.jpg)

### Imran Ahmed

(2019)

![](https://dhakachamber.com/storage/dcci-former-vps/December2020/lwoAFYOZSnt2dlLxy5pU.jpg)

### Mohammad Bashiruddin

(2020)

![](https://dhakachamber.com/storage/dcci-former-vps/December2021/nCHJhua7LuKhoRZiKC6V.jpg)

### Monowar Hossain

(2021-2022)

![](https://dhakachamber.com/storage/dcci-former-vps/December2024/aDESvjvUX7ekj2Ug7Qs6.jpg)

### Md. Junaed Ibna Ali

((2023-2024))

### ABOUT US

-   [Board of Directors](https://dhakachamber.com/board-of-directors)
-   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
-   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)

### USEFUL LINKS

-   [DBI College](http://www.dbicollege.edu.bd)
-   [DCCI Business Institute](http://dcci-dbi.edu.bd)
-   [BUILD](http://www.buildbd.org)
-   [BIAC](https://www.biac.org.bd)
-   [ICCB](https://iccbangladesh.org.bd)

### MEMBERSHIP

-   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
-   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
-   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
-   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
-   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
-   [Become a Member](https://membership.dhakachamber.com/register)
-   [Member Login](https://membership.dhakachamber.com)
-   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
-   [Member Query](https://dhakachamber.com/member-query)
-   [Hot Line](https://dhakachamber.com/hot_line)

### MEDIA

-   [Chamber News](https://dhakachamber.com/media/news)
-   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
-   [Photo Gallery](https://dhakachamber.com/albums)
-   [Video Gallery](https://dhakachamber.com/videos)

### DOWNLOAD

-   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
-   [DCCI Reviews](https://dhakachamber.com/publications/reviews)
-   [DCCI Publications](https://dhakachamber.com/publications)
-   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
-   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)

×

-   [Home(current)](https://dhakachamber.com)
-   [About us](#)
    -   [Brief About DCCI](https://dhakachamber.com/about-us)
    -   [International Affiliations](https://dhakachamber.com/international-affiliations)
    -   [DCCI Founders](https://dhakachamber.com/dcci-founders)
    -   [Former Presidents](https://dhakachamber.com/dcci-former-presidents)
    -   [Former Senior Vice Presidents](https://dhakachamber.com/dcci-former-senior-vice-presidents)
    -   [Former Vice Presidents](https://dhakachamber.com/dcci-former-vice-presidents)
    -   [Achievements & Awards](https://dhakachamber.com/achievements-awards)
    -   [Policy and Objectives](https://dhakachamber.com/quality-policy-and-objectives)
-   [Organizational Information](#)
    -   [Board of Directors](https://dhakachamber.com/board-of-directors)
    -   [Previous Board of Directors](https://dhakachamber.com/dcci-allpastmanagement)
    -   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
    -   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)
-   [President](https://dhakachamber.com/president)
-   [Membership](#)
    -   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
    -   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
    -   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
    -   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
    -   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
    -   [Become a Member](https://membership.dhakachamber.com/register)
    -   [Member Login](https://membership.dhakachamber.com)
    -   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
    -   [Member Query](https://dhakachamber.com/member-query)
    -   [Hot Line](https://dhakachamber.com/hot_line)
-   [Projects](https://dhakachamber.com/project-activities)
-   [Seminar](https://dhakachamber.com/media/seminar)
-   [Publications](#)
    -   [DCCI Research Service](https://dhakachamber.com/pdf_viewer/storage/2024/circular/DCCI%20Research%20Service.pdf)
    -   [Research Guideline](https://dhakachamber.com/pdf_viewer/storage/2024/circular/Research%20Guideline.pdf)
    -   [DCCI Journal (DJBEP)](https://journal.dhakachamber.com/)
    -   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
    -   [DCCI Review](https://dhakachamber.com/publications/reviews)
    -   [DCCI Publications](https://dhakachamber.com/publications)
    -   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
    -   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)
    -   [Introducing DCCI 2023](https://www.dhakachamber.com/storage/print_media/2023/07/Introducing%202023.pdf)
-   [Media](#)
    -   [Chamber News](https://dhakachamber.com/media/news)
    -   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
    -   [Photo Gallery](https://dhakachamber.com/albums)
    -   [Video Gallery](https://dhakachamber.com/videos)
    -   [Fairs & Exhibitions](https://www.dhakachamber.com/storage/2026/03/dccifair.pdf)
-   [Policy](#)
    -   [Export Policy](https://www.dhakachamber.com/storage/policy/3VFoMxkr6Z3EZdC8wz7YHfrIBfPP5N0Y6n7eEEFJ.pdf)
    -   [Import Policy](https://www.dhakachamber.com/storage/policy/b6uhXGhpdl30N68gl3Yg9mV5P6vGIPAjquqTu35f.pdf)
    -   [Industry Policy](https://www.dhakachamber.com/storage/policy/kpHRSdbYmY90O7wcyYmkZTSvumKEXfz5uwPTlOn5.pdf)
    -   [ICT Policy](https://www.dhakachamber.com/storage/policy/abTlbODgI2I4Aqbrix5Cs2DHvFD5lW3OwDmfKXmH.pdf)
-   [BILATERAL TRADE](#)
    -   [Bilateral Trade](https://dhakachamber.com/bilateral-trade)
    -   [Africa](https://dhakachamber.com/bilateral-trade/africa)
    -   [America](https://dhakachamber.com/bilateral-trade/america)
    -   [Asian](https://dhakachamber.com/bilateral-trade/asian)
    -   [ASEAN](https://dhakachamber.com/bilateral-trade/asean)
    -   [SAARC](https://dhakachamber.com/bilateral-trade/saarc)
    -   [Middle East](https://dhakachamber.com/bilateral-trade/middle-east)
    -   [European Union](https://dhakachamber.com/bilateral-trade/european-union)
-   [About Bangladesh](#)
    -   [General Information](https://dhakachamber.com/bangladesh-country-profile)
    -   [Business Opportunities in Bangladesh](https://dhakachamber.com/trade-and-business-opportunities-in-bangladesh)
    -   [Useful Links](https://dhakachamber.com/useful-links)
-   [B2B Directory](#)
    -   [B2B Directory](https://dhakachamber.com/b2b)
    -   [B2B Member Login](https://dhakachamber.com/login)
    -   [B2B Registration](https://dhakachamber.com/b2b-reg)