---
source: "Dhaka Chamber of Commerce & Industry (DCCI)"
tier: 1
category: "Chamber"
url: "https://dhakachamber.com/dcci-secretariat"
title: "DCCI ::  DCCI Secretariat"
scraped_at: "2026-07-02"
---

# DCCI Secretariat

President Secretariat

Sl.

Name

Designation

Ext.

Email

01

Taskeen Ahmed

President

president@dhakachamber.com

02

Razeev H Chowdhury

Sr. Vice President

svp@dhakachamber.com

03

Md. Salem Sulaiman

Vice President

vp@dhakachamber.com

04

Md. Riaz Uddin Khan

PS to President

1003

ps@dhakachamber.com

Administration Department

Sl.

Name

Designation

Ext.

Email

01

Dr. AKM Asaduzzaman Patwary

Secretary General (Acting)

1007

secretary.general@dhakachamber.com

02

Md. Akramul Haque

Additional Executive Secretary

1010

akram@dhakachamber.com

03

Md. Tamzid

Sr. Assistant Executive Secretary (Security & Safety)

199

tamzid@dhakachamber.com

04

Md. Yusuf Ali

Sr. Assistant Executive Secretary (Protocol)

145

yousuf@dhakachamber.com

05

Md Azizur Rahman

Sr. Assistant Executive Secretary (Store)

129

azizur@dhakachamber.com

06

Md. Jahedur Rahman

Assistant Executive Secretary (Despatch, HRD)

1025

jahedur@dhakachamber.com

07

Tanver Ahmed

Assistant Executive Secretary

1025

tanver@dhakachamber.com

Accounts Department

Sl.

Name

Designation

Ext.

Email

01

Iqbal Hossain

Additional Executive Secretary

1008

iqbal@dhakachamber.com

02

Abdul Malek

Joint Executive Secretary

1026

amalek@dhakachamber.com

03

Md. Al-Amin

Sr. Assistant Executive Secretary

123

accounts@dhakachamber.com

04

Fahomida Akter

Assistant Executive Secretary

1024

fahomida@dhakachamber.com

05

Nazmun Naher Suchi

Assistant Executive Secretary

135

suchi@dhakachamber.com

06

Md. Rasel Shawon

Junior Officer

accounts@dhakachamber.com

Board Affairs Department

Sl.

Name

Designation

Ext.

Email

DCCI Business Institute (DBI)

Sl.

Name

Designation

Ext.

Email

01

Tamanna Sultana

Additional Executive Secretary

1014

tamanna@dhakachamber.com

02

Abul Bashar

Sr. Assistant Executive Secretary

1015

bashar@dhakachamber.com

03

Md. Amit Hossain

Assistant Executive Secretary

1034

amit@dhakachamber.com

04

Sheekh Md. Abdul Wasik

Senior Officer

280

wasik@dhakachamber.com

05

Asaduzzaman Adil

Junior Officer

282

adil@dhakachamber.com

Estate Department

Sl.

Name

Designation

Ext.

Email

01

Rafiqul Islam

Deputy Executive Secretary

1027

rafiqul@dhakachamber.com

02

Rafiqul Islam Rony

Assistant Executive Secretary(Electrical Engineer)

136

rony@dhakachamber.com

03

Benajir Ahmed

Electrician

HRM Department

Sl.

Name

Designation

Ext.

Email

Information Technology Department

Sl.

Name

Designation

Ext.

Email

01

Dilip Kumar Roy

Joint Executive Secretary

1013

dilip.kumar@dhakachamber.com

02

Md. Abu Nawim

Assistant Executive Secretary (Web Developer)

130

nawim@dhakachamber.com

03

Rahul Acharjee

Assistant Executive Secretary

1022

rahul@dhakachamber.com

04

Nurul Amin Sabbir

Senior Officer

118

sabbir@dhakachamber.com

05

Md. Arman Hossen

Senior Officer

118

arman@dhakachamber.com

Library Department

Sl.

Name

Designation

Ext.

Email

01

Sumaiya Mostafa

Junior Officer

154

sumaiya@dhakachamber.com

Membership Department

Sl.

Name

Designation

Ext.

Email

01

Abul Hasan Fazle Rabbi

Additional Executive Secretary

1009

fazle.rabbi@dhakachamber.com

02

Khalilur Rahman

Assistant Executive Secretary

1017

membership@dhakachamber.com

03

Monowar Hossain Abhi

Junior Officer

monowar@dhakachamber.com

Public Relation and Event Department

Sl.

Name

Designation

Ext.

Email

01

Abul Hasan Fazle Rabbi

Additional Executive Secretary

1009

fazle.rabbi@dhakachamber.com

02

Md. Akramul Haque

Additional Executive Secretary

1010

akram@dhakachamber.com

03

Md. Abu Sayed

Senior Officer

144

sayed@dhakachamber.com

Project Department

Sl.

Name

Designation

Ext.

Email

01

Sheekh Md. Abdul Wasik

Senior Officer

280

wasik@dhakachamber.com

Research & Development Department

Sl.

Name

Designation

Ext.

Email

01

Dr. AKM Asaduzzaman Patwary

Secretary General (Acting)

1007

asaduzzaman@dhakachamber.com

02

Syed Abdullah Al Ahsan

Joint Executive Secretary

1028

pavel@dhakachamber.com

03

Md. Salehin Surfaraz

Deputy Executive Secretary

1029

surfaraz@dhakachamber.com

04

Dr. Md. Murad Ahmed

Deputy Executive Secretary

116

murad@dhakachamber.com

05

Suhel Rana

Sr. Assistant Executive Secretary

1011

suhel@dhakachamber.com

06

Mahamudul Hassan

Sr. Assistant Executive Secretary

1030

mahamudul@dhakachamber.com

07

Kausar Ahmed Majumder

Sr. Assistant Executive Secretary

1033

kausar@dhakachamber.com

SME Development Department

Sl.

Name

Designation

Ext.

Email

01

Abdullah Al Maruf

Deputy Executive Secretary

1031

maruf@dhakachamber.com

02

Md. Mahan Mia

Assistant Executive Secretary

146

mia.mahan@dhakachamber.com

Trade Facilitation Department

Sl.

Name

Designation

Ext.

Email

01

AHM Maniruzzaman

Additional Executive Secretary

1016

maniruzzaman@dhakachamber.com

02

Farzana Yesmin

Junior Officer

121

farzana@dhakachamber.com

DCCI Gulshan Centre

Sl.

Name

Designation

Ext.

Email

01

Md. Habibur Rahman

Additional Executive Secretary (Incharge DCCI Gulshan Centre)

1019

habib.rahman@dhakachamber.com

02

Kh. Nazmun Nahar Tama

Sr. Assistant Executive Secretary

1023

tama@dhakachamber.com

03

Taslima Akter Joly

Assistant Executive Secretary

1020

taslima@dhakachamber.com

Mohammadpur Service Zone

Sl.

Name

Designation

Ext.

Email

01

Md. Mahan Mia

Assistant Executive Secretary

1021

mia.mahan@dhakachamber.com

02

Md. Amit Hossain

Assistant Executive Secretary

1021

amit@dhakachamber.com

03

Sheekh Md. Abdul Wasik

Senior Officer

1021

wasik@dhakachamber.com

### ABOUT US

-   [Board of Directors](https://dhakachamber.com/board-of-directors)
-   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
-   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)

### USEFUL LINKS

-   [DBI College](http://www.dbicollege.edu.bd)
-   [DCCI Business Institute](http://dcci-dbi.edu.bd)
-   [BUILD](http://www.buildbd.org)
-   [BIAC](https://www.biac.org.bd)
-   [ICCB](https://iccbangladesh.org.bd)

### MEMBERSHIP

-   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
-   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
-   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
-   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
-   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
-   [Become a Member](https://membership.dhakachamber.com/register)
-   [Member Login](https://membership.dhakachamber.com)
-   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
-   [Member Query](https://dhakachamber.com/member-query)
-   [Hot Line](https://dhakachamber.com/hot_line)

### MEDIA

-   [Chamber News](https://dhakachamber.com/media/news)
-   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
-   [Photo Gallery](https://dhakachamber.com/albums)
-   [Video Gallery](https://dhakachamber.com/videos)

### DOWNLOAD

-   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
-   [DCCI Reviews](https://dhakachamber.com/publications/reviews)
-   [DCCI Publications](https://dhakachamber.com/publications)
-   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
-   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)

×

-   [Home(current)](https://dhakachamber.com)
-   [About us](#)
    -   [Brief About DCCI](https://dhakachamber.com/about-us)
    -   [International Affiliations](https://dhakachamber.com/international-affiliations)
    -   [DCCI Founders](https://dhakachamber.com/dcci-founders)
    -   [Former Presidents](https://dhakachamber.com/dcci-former-presidents)
    -   [Former Senior Vice Presidents](https://dhakachamber.com/dcci-former-senior-vice-presidents)
    -   [Former Vice Presidents](https://dhakachamber.com/dcci-former-vice-presidents)
    -   [Achievements & Awards](https://dhakachamber.com/achievements-awards)
    -   [Policy and Objectives](https://dhakachamber.com/quality-policy-and-objectives)
-   [Organizational Information](#)
    -   [Board of Directors](https://dhakachamber.com/board-of-directors)
    -   [Previous Board of Directors](https://dhakachamber.com/dcci-allpastmanagement)
    -   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
    -   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)
-   [President](https://dhakachamber.com/president)
-   [Membership](#)
    -   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
    -   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
    -   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
    -   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
    -   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
    -   [Become a Member](https://membership.dhakachamber.com/register)
    -   [Member Login](https://membership.dhakachamber.com)
    -   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
    -   [Member Query](https://dhakachamber.com/member-query)
    -   [Hot Line](https://dhakachamber.com/hot_line)
-   [Projects](https://dhakachamber.com/project-activities)
-   [Seminar](https://dhakachamber.com/media/seminar)
-   [Publications](#)
    -   [DCCI Research Service](https://dhakachamber.com/pdf_viewer/storage/2024/circular/DCCI%20Research%20Service.pdf)
    -   [Research Guideline](https://dhakachamber.com/pdf_viewer/storage/2024/circular/Research%20Guideline.pdf)
    -   [DCCI Journal (DJBEP)](https://journal.dhakachamber.com/)
    -   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
    -   [DCCI Review](https://dhakachamber.com/publications/reviews)
    -   [DCCI Publications](https://dhakachamber.com/publications)
    -   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
    -   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)
    -   [Introducing DCCI 2023](https://www.dhakachamber.com/storage/print_media/2023/07/Introducing%202023.pdf)
-   [Media](#)
    -   [Chamber News](https://dhakachamber.com/media/news)
    -   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
    -   [Photo Gallery](https://dhakachamber.com/albums)
    -   [Video Gallery](https://dhakachamber.com/videos)
    -   [Fairs & Exhibitions](https://www.dhakachamber.com/storage/2026/03/dccifair.pdf)
-   [Policy](#)
    -   [Export Policy](https://www.dhakachamber.com/storage/policy/3VFoMxkr6Z3EZdC8wz7YHfrIBfPP5N0Y6n7eEEFJ.pdf)
    -   [Import Policy](https://www.dhakachamber.com/storage/policy/b6uhXGhpdl30N68gl3Yg9mV5P6vGIPAjquqTu35f.pdf)
    -   [Industry Policy](https://www.dhakachamber.com/storage/policy/kpHRSdbYmY90O7wcyYmkZTSvumKEXfz5uwPTlOn5.pdf)
    -   [ICT Policy](https://www.dhakachamber.com/storage/policy/abTlbODgI2I4Aqbrix5Cs2DHvFD5lW3OwDmfKXmH.pdf)
-   [BILATERAL TRADE](#)
    -   [Bilateral Trade](https://dhakachamber.com/bilateral-trade)
    -   [Africa](https://dhakachamber.com/bilateral-trade/africa)
    -   [America](https://dhakachamber.com/bilateral-trade/america)
    -   [Asian](https://dhakachamber.com/bilateral-trade/asian)
    -   [ASEAN](https://dhakachamber.com/bilateral-trade/asean)
    -   [SAARC](https://dhakachamber.com/bilateral-trade/saarc)
    -   [Middle East](https://dhakachamber.com/bilateral-trade/middle-east)
    -   [European Union](https://dhakachamber.com/bilateral-trade/european-union)
-   [About Bangladesh](#)
    -   [General Information](https://dhakachamber.com/bangladesh-country-profile)
    -   [Business Opportunities in Bangladesh](https://dhakachamber.com/trade-and-business-opportunities-in-bangladesh)
    -   [Useful Links](https://dhakachamber.com/useful-links)
-   [B2B Directory](#)
    -   [B2B Directory](https://dhakachamber.com/b2b)
    -   [B2B Member Login](https://dhakachamber.com/login)
    -   [B2B Registration](https://dhakachamber.com/b2b-reg)