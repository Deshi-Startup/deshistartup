---
source: "Dhaka Chamber of Commerce & Industry (DCCI)"
tier: 1
category: "Chamber"
url: "https://dhakachamber.com/international-affiliations"
title: "DCCI ::  International Affiliations"
scraped_at: "2026-07-02"
---

# International Affiliations

DCCI has been actively cooperating with various international agencies like UNDP, UNCTAD, WTO, ITC, ESCAP, UNIDO, USAID, CBI, World Bank, ICC, GTZ, ZDH, APO, JICA, IFC-BICF, JETRO, CIPE, SEDF,WCC, CCPIT etc. in carrying out various joint project activities for creation of a favourable investment climate and promotion of trade and industry. Besides, DCCI sings Memorandum of Understanding (MOU) with other Chambers of the world for promotion of bilateral trade and economic cooperation.

[![UNDP](http://www.dhakachamber.com/storage/International-Affiliations/GxMFcrNGJeCUBJpiaXNqR2nlxfRieDp6SSW8ewyd.gif)](https://www.undp.org "UNDP")

![UNICEP](http://www.dhakachamber.com/storage/International-Affiliations/cNR8dioCbMoxEX04Qdgyz443WKzKjrET07TMLgxB.gif)

![UNIDO](http://www.dhakachamber.com/storage/International-Affiliations/qd14b7yXf5NHlxMGmAXzKvbQtbKsXwAts3tUxOqp.gif)

![EU](http://www.dhakachamber.com/storage/International-Affiliations/3SP0R7ZzAT97gp0f1LKmW8YPiuIaMWjJrxLkEm4X.gif)

![ILO](http://www.dhakachamber.com/storage/International-Affiliations/KFY8NvO7RMGJMcJsQoffkbfQcejGIKZMvHgvbQva.gif)

![IFC](http://www.dhakachamber.com/storage/International-Affiliations/S0SID2d0QAQX2saTAgZJrgRsaP5nr5CCPLYyHuMF.gif)

![Oxfam](http://www.dhakachamber.com/storage/International-Affiliations/uUzIc0xFfbOOUSTx9qtiSF8mJ5vwaXctm8bkJ8Cp.gif)

![jica](http://www.dhakachamber.com/storage/International-Affiliations/eNXDlTmxlci25PEW10dnwtuMQyuLqC1MWSKWepGb.gif)

![JETRO](http://www.dhakachamber.com/storage/International-Affiliations/i2JcjudgMKMM64dy2AWzTrp0noCSkx7jazcVCI3G.gif)

![CBI](http://www.dhakachamber.com/storage/International-Affiliations/5OvA4ivbyPWfEbb0FZyflHy214uvufd6XgqUkejy.gif)

![WTO](http://www.dhakachamber.com/storage/International-Affiliations/yPklPhwRHN2QQC6YPM7SY7Rkpc21ibw81aBUwlcM.gif)

![ITC](http://www.dhakachamber.com/storage/International-Affiliations/rJVp5sv7ajtwsbKdoIjzfuoRxKqkscOQwSBCrLoI.gif)

![SAARC](http://www.dhakachamber.com/storage/International-Affiliations/NtWst9u0hzqq3b6RuCHWkQ7qmlORxSrdSko3JKat.gif)

![GIZ](http://www.dhakachamber.com/storage/International-Affiliations/fhYylLltENibWkfNGu4JYJziNQV0RaWi9iM2mHa5.gif)

![](http://www.dhakachamber.com/storage/International-Affiliations/wrfTdfI8eEPsfWHtdJDJHKs9JFvyHUByBjR9tu8k.gif)

![sequa](http://www.dhakachamber.com/storage/International-Affiliations/T6nasVWmAZY1mwlCPjBDb1hfUrHaC100Bh79ETtd.gif)

![WIPO](http://www.dhakachamber.com/storage/International-Affiliations/pTwpEiEGyhc2YigF2cjDTQjrBThY27C1gmpPCTdj.gif)

### ABOUT US

-   [Board of Directors](https://dhakachamber.com/board-of-directors)
-   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
-   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)

### USEFUL LINKS

-   [DBI College](http://www.dbicollege.edu.bd)
-   [DCCI Business Institute](http://dcci-dbi.edu.bd)
-   [BUILD](http://www.buildbd.org)
-   [BIAC](https://www.biac.org.bd)
-   [ICCB](https://iccbangladesh.org.bd)

### MEMBERSHIP

-   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
-   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
-   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
-   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
-   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
-   [Become a Member](https://membership.dhakachamber.com/register)
-   [Member Login](https://membership.dhakachamber.com)
-   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
-   [Member Query](https://dhakachamber.com/member-query)
-   [Hot Line](https://dhakachamber.com/hot_line)

### MEDIA

-   [Chamber News](https://dhakachamber.com/media/news)
-   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
-   [Photo Gallery](https://dhakachamber.com/albums)
-   [Video Gallery](https://dhakachamber.com/videos)

### DOWNLOAD

-   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
-   [DCCI Reviews](https://dhakachamber.com/publications/reviews)
-   [DCCI Publications](https://dhakachamber.com/publications)
-   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
-   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)

×

-   [Home(current)](https://dhakachamber.com)
-   [About us](#)
    -   [Brief About DCCI](https://dhakachamber.com/about-us)
    -   [International Affiliations](https://dhakachamber.com/international-affiliations)
    -   [DCCI Founders](https://dhakachamber.com/dcci-founders)
    -   [Former Presidents](https://dhakachamber.com/dcci-former-presidents)
    -   [Former Senior Vice Presidents](https://dhakachamber.com/dcci-former-senior-vice-presidents)
    -   [Former Vice Presidents](https://dhakachamber.com/dcci-former-vice-presidents)
    -   [Achievements & Awards](https://dhakachamber.com/achievements-awards)
    -   [Policy and Objectives](https://dhakachamber.com/quality-policy-and-objectives)
-   [Organizational Information](#)
    -   [Board of Directors](https://dhakachamber.com/board-of-directors)
    -   [Previous Board of Directors](https://dhakachamber.com/dcci-allpastmanagement)
    -   [DCCI Secretariat](https://dhakachamber.com/dcci-secretariat)
    -   [Bilateral MOU with DCCI](https://dhakachamber.com/mous)
-   [President](https://dhakachamber.com/president)
-   [Membership](#)
    -   [Eligibility](https://dhakachamber.com/eligibility-of-membership)
    -   [Benefit of Being a Member](https://dhakachamber.com/benefit-of-being-a-member)
    -   [Membership Enrollment](https://dhakachamber.com/membership_application_process)
    -   [Membership Renewal](https://dhakachamber.com/membership_renewal_process)
    -   [Certificate of Origin (CO)](https://dhakachamber.com/certificate_of_origin_process)
    -   [Become a Member](https://membership.dhakachamber.com/register)
    -   [Member Login](https://membership.dhakachamber.com)
    -   [Membership User Guideline](https://www.dhakachamber.com/storage/pdfs/wvEXk35CgvyQfjbpn0yNCGz8QPTj8fSdPUrEjeHe.pdf)
    -   [Member Query](https://dhakachamber.com/member-query)
    -   [Hot Line](https://dhakachamber.com/hot_line)
-   [Projects](https://dhakachamber.com/project-activities)
-   [Seminar](https://dhakachamber.com/media/seminar)
-   [Publications](#)
    -   [DCCI Research Service](https://dhakachamber.com/pdf_viewer/storage/2024/circular/DCCI%20Research%20Service.pdf)
    -   [Research Guideline](https://dhakachamber.com/pdf_viewer/storage/2024/circular/Research%20Guideline.pdf)
    -   [DCCI Journal (DJBEP)](https://journal.dhakachamber.com/)
    -   [Annual Reports](https://dhakachamber.com/publications/annual_reports)
    -   [DCCI Review](https://dhakachamber.com/publications/reviews)
    -   [DCCI Publications](https://dhakachamber.com/publications)
    -   [Economic Policy](https://dhakachamber.com/publications/economic-policies)
    -   [DCCI Budget proposal](https://dhakachamber.com/publications/budget_proposals)
    -   [Introducing DCCI 2023](https://www.dhakachamber.com/storage/print_media/2023/07/Introducing%202023.pdf)
-   [Media](#)
    -   [Chamber News](https://dhakachamber.com/media/news)
    -   [Print Media Coverage](https://dhakachamber.com/media/dcci-news-links)
    -   [Photo Gallery](https://dhakachamber.com/albums)
    -   [Video Gallery](https://dhakachamber.com/videos)
    -   [Fairs & Exhibitions](https://www.dhakachamber.com/storage/2026/03/dccifair.pdf)
-   [Policy](#)
    -   [Export Policy](https://www.dhakachamber.com/storage/policy/3VFoMxkr6Z3EZdC8wz7YHfrIBfPP5N0Y6n7eEEFJ.pdf)
    -   [Import Policy](https://www.dhakachamber.com/storage/policy/b6uhXGhpdl30N68gl3Yg9mV5P6vGIPAjquqTu35f.pdf)
    -   [Industry Policy](https://www.dhakachamber.com/storage/policy/kpHRSdbYmY90O7wcyYmkZTSvumKEXfz5uwPTlOn5.pdf)
    -   [ICT Policy](https://www.dhakachamber.com/storage/policy/abTlbODgI2I4Aqbrix5Cs2DHvFD5lW3OwDmfKXmH.pdf)
-   [BILATERAL TRADE](#)
    -   [Bilateral Trade](https://dhakachamber.com/bilateral-trade)
    -   [Africa](https://dhakachamber.com/bilateral-trade/africa)
    -   [America](https://dhakachamber.com/bilateral-trade/america)
    -   [Asian](https://dhakachamber.com/bilateral-trade/asian)
    -   [ASEAN](https://dhakachamber.com/bilateral-trade/asean)
    -   [SAARC](https://dhakachamber.com/bilateral-trade/saarc)
    -   [Middle East](https://dhakachamber.com/bilateral-trade/middle-east)
    -   [European Union](https://dhakachamber.com/bilateral-trade/european-union)
-   [About Bangladesh](#)
    -   [General Information](https://dhakachamber.com/bangladesh-country-profile)
    -   [Business Opportunities in Bangladesh](https://dhakachamber.com/trade-and-business-opportunities-in-bangladesh)
    -   [Useful Links](https://dhakachamber.com/useful-links)
-   [B2B Directory](#)
    -   [B2B Directory](https://dhakachamber.com/b2b)
    -   [B2B Member Login](https://dhakachamber.com/login)
    -   [B2B Registration](https://dhakachamber.com/b2b-reg)