---
source: "BEPZA"
tier: 1
category: "Export zone"
url: "https://bepza.gov.bd/services"
title: "BEPZA"
scraped_at: "2026-07-02"
---

# Our Services

-   [Home](https://bepza.gov.bd)
-   How We Help
-   Our Services

## Major Services:

-   Permission to set up an industry
-   Allotment of Plot/ Standard Factory Building (SFB)
-   Visa and Work Permit-related services
-   Customs-related Services
-   Issuance of Trade License
-   Import and Export Permit
-   Subcontract Permit
-   Local Purchase Permit
-   Inclusion of new products in the existing product line
-   Revision of Project
-   Changing the Name of the Company
-   Permission to transfer and Allotment of Shares
-   Merger & Acquisition/Amalgamation
-   Changing Ownership of the Company