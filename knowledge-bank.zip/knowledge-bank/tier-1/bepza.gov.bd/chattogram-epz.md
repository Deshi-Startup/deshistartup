---
source: "BEPZA"
tier: 1
category: "Export zone"
url: "https://bepza.gov.bd/pages/chattogram-epz"
title: "BEPZA"
scraped_at: "2026-07-02"
---

# Chattogram EPZ

-   [Home](https://bepza.gov.bd)
-   Chattogram EPZ

![ienet](https://bepza.gov.bd/public/storage/upload/content/250902013841-9966chaatagram.jpg)

**Chattogram EPZ – Bangladesh’s First Gateway to Global Exports**

Established in 1983 as the country’s first EPZ, Chattogram EPZ transformed Bangladesh’s coastal landscape into a global export hub. Its proximity to Chattogram Port ensures reduced cost and time for imports and exports, making it a top destination for international investors.

Chattogram EPZ remains the flagship of Bangladesh’s export-oriented industrialization, contributing over US$ 47.24 billion in exports and employing nearly 190,000 workers. Investors from 13 countries produce a wide range of products, from apparel and shoes to bicycles, electronics, and leather goods. With world-class infrastructure, bonded warehouse facilities, and harmonious labour-management relations, it continues to be recognized globally as a model EPZ.

Established

1983

Location

South Halishahar, Chattogram

Zone Area

453 acres

Industrial Plots

501 Nos

Investment

US$ 2,253.68 million

Export

US$ 47,243.98 million

Employment

189,759 nos.

Products

Light Engineering Products, Rope, Leather Products, Shoes, Tent and Camping Items, Electronics and Electrical Products, Bicycles, Textile, Lenses, Golf Shafts, Cap, Industrial Gloves, Ready-made Garments, Garments Accessories, Terry Towels, Metal Products

Investing Countries

China (including Hong Kong and Taiwan), UK, The Netherlands, Malaysia, South Korea, Japan, USA, India, Canada, Pakistan and Bangladesh.