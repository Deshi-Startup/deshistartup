---
source: "BEPZA"
tier: 1
category: "Export zone"
url: "https://bepza.gov.bd/noc-go"
title: "BEPZA"
scraped_at: "2026-07-02"
---

# NOC / GO

-   [Home](https://bepza.gov.bd)
-   Notice
-   NOC / GO

## Bangladesh Export Processing Zones Authority

NOC & GO No

Title

Publication Date

Action

03.06.2616.307.18.619.17-1522

Government Order (G.O.) for  Mr. MAHBUB HOSSAIN JAKIR  (Passport No A04588290), Security Guard, Chattogram Export Processing Zone,

Jun 28, 2026

[View](https://bepza.gov.bd/public/storage/upload/noc_go/260629085721-4577G.O.pdf)

03.06.2616.307.18.220.05.1513

Government Order (G.O.) for  Mr. MD MAKSUD ALAM (Passport No A14779163), Driver, Adamjee EPZ,

Jun 25, 2026

[View](https://bepza.gov.bd/public/storage/upload/noc_go/260628060140-50001513.pdf)

03.06.2616.307.018.008.1994.1354

NOC for receiving E-Passport of Mr. Md. Tanvir Hossain, Bepza Employee ID: (107006).  Executive Director (Investment Development), BEPZA.

Jun 02, 2026

[View](https://bepza.gov.bd/public/storage/upload/noc_go/260602040751-12601354.pdf)

03.06.2616.307.18.060.24.1347

Government Order (G.O.) for Mr. BIDHAN BISWAS (Passport No A11340441), Dispatch Rider, BEPZA Executive Office. for his father BUDDHIMANTA BISWAS's (Passport No A11340440) , India for treatment.

May 25, 2026

[View](https://bepza.gov.bd/public/storage/upload/noc_go/260603051305-28351347.pdf)

03.06.2616.307.18.127.08-1196

Government Order (G.O.) for Mr MD Fahim Hossain (Possport No: E00122414), Assistant Coordination Officer, BEPZA

May 07, 2026

[View](https://bepza.gov.bd/public/storage/upload/noc_go/260511085409-16751196.pdf)

03.06.2616.000.307.08.0001.21.13

Government Order (G.O.) for SUJAN BARUA (Passport No. A20663863), Electrician, CEPZ.

Apr 07, 2026

[View](https://bepza.gov.bd/public/storage/upload/noc_go/260408091538-673930.pdf)

03.06.2616.307.18.002.26.112

NOC for receiving E-Passport of Mr. Monkasir Musfiq, Assistant Director (IP), BEPZA BEPZA.

Jan 14, 2026

[View](<https://bepza.gov.bd/public/storage/upload/noc_go/260120073213-2416E-Passport \(NOC\)- Musfiq sir.pdf>)

## Adamjee Export Processing Zone

NOC & GO No

Title

Publication Date

Action

03.06.6758.307.19.267.26-457

NOC for receiving E-Passport of Ms. Fatema Tuz Zohra, Employee ID:(107056). Director(A.O.) Adamjee EPZ, Siddhirganj, Narayanganj.

Jun 21, 2026

[View](<https://bepza.gov.bd/public/storage/upload/noc_go/260625081529-15370Passport NOC.pdf>)

03.06.6758.307.19.233.25-365

NOC for receiving E-Passport of Mr Imtiaz Ahmed, Bepza Employee ID: (107122). Assistant Director (CO) Adamjee EPZ, Siddhirganj, Narayanganj.

Apr 28, 2026

[View](https://bepza.gov.bd/public/storage/upload/noc_go/260510045910-928425.pdf)

## BEPZA EZ

NOC & GO No

Title

Publication Date

Action

03.06.1553.307.18.195.25-1265

Noc for receving E-passport of Mr. Pankaj Kumar Barua, (Director Administration) Contact Number (101033), Mirsarai Chittagong EPZ.

Apr 16, 2026

[View](https://bepza.gov.bd/public/storage/upload/noc_go/260422053601-34211265.jpg)

## Chattogram Export Processing Zone

NOC & GO No

Title

Publication Date

Action

03.06.2616.307.18.422.15-1194(1)

Government Order (G.O.) for  Mr. S.M Shahanewaz Islam (Passport No A12726303), Office Assistant cum computer Operator, BEPZA Economic Zone, Mirsharai

May 07, 2026

[View](https://bepza.gov.bd/public/storage/upload/noc_go/260511085845-98231194.1.pdf)

03.06.1535.307.49.1449.24-1213

NOC for receiving Passport of Miss Moni Akhter, Office Assistan Cum-Computer Operator, Chittagong EPZ

Jan 08, 2026

[View](<https://bepza.gov.bd/public/storage/upload/noc_go/260120065702-2004noc moni.pdf>)

## Cumilla Export Processing Zone

NOC & GO No

Title

Publication Date

Action

03.06.2616.307.18.053.20-986

Government Order (G.O.) for Miz HASINA IREEN, Passport No:( A17634316), (Counselor cum Inspector (Social), Cumilla EPZ.

Apr 21, 2026

[View](https://bepza.gov.bd/public/storage/upload/noc_go/260422054328-9769986.jpg)

03.06.2616.307.18.014.19-172

NOC for Receving Passport of Mr. Al Masum ID Number(109190) Assistant Engineer (Civil), Cumilla EPZ

Mar 12, 2026

[View](https://bepza.gov.bd/public/storage/upload/noc_go/260324095013-1945Al_Masum_NOC.pdf)

## Dhaka Export Processing Zone

NOC & GO No

Title

Publication Date

Action

03.06.2616.307.18.164.97.1083

Government Order (G.O.) for Mohammad Abu Bakar Siddik, (Passport no.A05430762), Foreman,  Dhaka EPZ.

Apr 27, 2026

[View](https://bepza.gov.bd/public/storage/upload/noc_go/260427100629-8725Scan.pdf)

03.06.2616.307.18.388.12.502

Government Order (G.O) for M A Hannan (Passport No. B00843668), Counselor cum Inspector (Social), Dhaka EPZ

Mar 08, 2026

[View](<https://bepza.gov.bd/public/storage/upload/noc_go/260310062349-7411G.O Hannan.pdf>)

## Ishwardi Export Processing Zone

NOC & GO No

Title

Publication Date

Action

No current NOC available.

## Jashore Export Processing Zone

NOC & GO No

Title

Publication Date

Action

No current NOC available.

## Karnaphuli Export Processing Zone

NOC & GO No

Title

Publication Date

Action

03.06.2616.307.18.374.14.967

NOC for receiving Passport of Mr. Md Titu Khan Contact number(102290) Driver, KEPZ.

Apr 13, 2026

[View](https://bepza.gov.bd/public/storage/upload/noc_go/260415061128-4439967.pdf)

## Mongla Export Processing Zone

NOC & GO No

Title

Publication Date

Action

03.06.2616.307.18.058.08.977

Government Order (G.O.) for Mr. ABDUL KADIR, Passport No:( A13115755), (Imam) Mongla EPZ.

Apr 16, 2026

[View](https://bepza.gov.bd/public/storage/upload/noc_go/260420061948-3958977.jpg)