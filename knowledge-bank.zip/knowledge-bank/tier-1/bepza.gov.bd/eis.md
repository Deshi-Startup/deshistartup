---
source: "BEPZA"
tier: 1
category: "Export zone"
url: "https://bepza.gov.bd/eis"
title: "BEPZA"
scraped_at: "2026-07-02"
---

# EIS-Pilot : BEPZA

-   [Home](https://bepza.gov.bd)
-   EIS-Pilot : BEPZA

## Templates For EIS Pilot Application

#

Title

Action

1

LEAFLET : BEPZA-EIS PILOT

[View](<https://bepza.gov.bd/public/storage/upload/content-file/250910113916-2270Flyer \(2\).pdf>)

2

POSTER : BEPZA-EIS PILOT

[View](<https://bepza.gov.bd/public/storage/upload/content-file/250910114326-4216Poster \(1\).pdf>)

3

Disability Assessment form

[View](<https://bepza.gov.bd/public/storage/upload/content-file/250722093929-9062Disability Assessment form.pdf>)

4

Succession Certificate

[View](<https://bepza.gov.bd/public/storage/upload/content-file/250722094011-1393Succession Certificate.pdf>)

5

Checklist

[View](https://bepza.gov.bd/public/storage/upload/content-file/250722094046-8938Checklist.pdf)

6

Application form for EPZ

[View](<https://bepza.gov.bd/public/storage/upload/content-file/250722094112-5469Application form for EPZ.pdf>)

7

Factory Certificate Template

[View](<https://bepza.gov.bd/public/storage/upload/content-file/250722094152-6481Factory Certificate Template.pdf>)