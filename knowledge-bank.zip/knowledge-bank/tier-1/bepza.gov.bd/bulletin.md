---
source: "BEPZA"
tier: 1
category: "Export zone"
url: "https://bepza.gov.bd/bulletin"
title: "BEPZA"
scraped_at: "2026-07-02"
---

# Bulletin

-   [Home](https://bepza.gov.bd)
-   Media & Publications
-   Publications
-   Bulletin

#

Title

Action

1

January-March 2026

[View](<https://bepza.gov.bd/public/storage/upload/bulletin/260513085722-2139January-March 2026.pdf>)

2

October-December 2025

[View](<https://bepza.gov.bd/public/storage/upload/bulletin/260215103944-1421October-December 2025.pdf>)

3

July-September 2025

[View](<https://bepza.gov.bd/public/storage/upload/bulletin/251016104901-3442July-September 2025.pdf>)

4

April-June 2025

[View](<https://bepza.gov.bd/public/storage/upload/bulletin/250902031341-8366250729081549-7267April-June 2025.pdf>)

5

January-March 2025

[View](<https://bepza.gov.bd/public/storage/upload/bulletin/250505120328-3737January-March 2025.pdf>)

6

October-December 2024

[View](<https://bepza.gov.bd/public/storage/upload/bulletin/250119113527-3445October-December 2024.pdf>)

7

July-September 2024

[View](<https://bepza.gov.bd/public/storage/upload/bulletin/241015080530-6174July-September 2024.pdf>)

8

April-June 2024

[View](<https://bepza.gov.bd/public/storage/upload/bulletin/240813040251-4630BEPZA_Bulletin_July_24_update \(1\)_compressed.pdf>)

9

January-March 2024

[View](<https://bepza.gov.bd/public/storage/upload/bulletin/240519054527-3607January-March 2024.pdf>)

10

October-December 2023

[View](<https://bepza.gov.bd/public/storage/upload/bulletin/240207035320-2864October-December 2023.pdf>)

11

July-September 2023

[View](<https://bepza.gov.bd/public/storage/upload/bulletin/231207084158-4116July-September 2023.pdf>)

12

April-June 2023

[View](<https://bepza.gov.bd/public/storage/upload/bulletin/231002050833-1991April-June 2023.pdf>)

13

January- March 2023

[View](<https://bepza.gov.bd/public/storage/upload/bulletin/230601095703-8714January-March 2023.pdf>)

14

October-December 2022

[View](<https://bepza.gov.bd/public/storage/upload/bulletin/230219061553-9507October -December, 2022.pdf>)

15

July-September 2022

[View](<https://bepza.gov.bd/public/storage/upload/bulletin/221206033921-7491July-September 2022.pdf>)

16

April-June 2022

[View](<https://bepza.gov.bd/public/storage/upload/bulletin/221012052842-7843April-June 2022.pdf>)

17

January- March 2022

[View](<https://bepza.gov.bd/public/storage/upload/bulletin/220530095516-8901January-March, 2022.pdf>)

18

October-December 2021

[View](<https://bepza.gov.bd/public/storage/upload/bulletin/220228085849-2531October-December 2021.pdf>)

19

July-September 2021

[View](<https://bepza.gov.bd/public/storage/upload/bulletin/211102060537-2231July-September 2021.pdf>)

20

April-June 2021

[View](<https://bepza.gov.bd/public/storage/upload/bulletin/210913064544-8318April - June, 2021.pdf>)

21

January- March 2021

[View](<https://bepza.gov.bd/public/storage/upload/bulletin/210630090034-2211January-March 2021.pdf>)

22

October-December 2020

[View](<https://bepza.gov.bd/public/storage/upload/bulletin/210616093731-8316October-December 2020.pdf>)

23

July-September, 2020

[View](https://bepza.gov.bd/public/storage/upload/bulletin/file_1607582836.pdf)

24

January-June, 2020

[View](https://bepza.gov.bd/public/storage/upload/bulletin/file_1600066376.pdf)

25

October-December, 2019

[View](https://bepza.gov.bd/public/storage/upload/bulletin/file_1583140673.pdf)

26

July-September, 2019

[View](https://bepza.gov.bd/public/storage/upload/bulletin/file_1573616162.pdf)

27

April-June, 2019

[View](https://bepza.gov.bd/public/storage/upload/bulletin/file_1564889819.pdf)

28

January-March, 2019

[View](https://bepza.gov.bd/public/storage/upload/bulletin/file_1560420206.pdf)

29

October-December-2018

[View](https://bepza.gov.bd/public/storage/upload/bulletin/file_1552282290.pdf)

30

July-September, 2018

[View](https://bepza.gov.bd/public/storage/upload/bulletin/file_1542167549.pdf)

31

April-June 2018

[View](https://bepza.gov.bd/public/storage/upload/bulletin/file_1536050010.pdf)

32

October-December-2017

[View](https://bepza.gov.bd/public/storage/upload/bulletin/file_1533461106.pdf)

33

July-September, 2017

[View](https://bepza.gov.bd/public/storage/upload/bulletin/file_1533461023.pdf)

34

January-March, 2018

[View](https://bepza.gov.bd/public/storage/upload/bulletin/file_1533120237.pdf)

35

April-June 2017

[View](https://bepza.gov.bd/public/storage/upload/bulletin/file_1507705668.pdf)

36

January-March, 2017

[View](https://bepza.gov.bd/public/storage/upload/bulletin/file_1499665433.pdf)

37

October-December-2016

[View](https://bepza.gov.bd/public/storage/upload/bulletin/file_1489481741.pdf)

38

July-September, 2016

[View](https://bepza.gov.bd/public/storage/upload/bulletin/file_1483005577.pdf)

39

April-June 2016

[View](https://bepza.gov.bd/public/storage/upload/bulletin/file_1476343943.pdf)

40

January-March, 2016

[View](https://bepza.gov.bd/public/storage/upload/bulletin/file_1466317083.pdf)

41

October-December-2015

[View](https://bepza.gov.bd/public/storage/upload/bulletin/file_1470542432.pdf)

42

July-September, 2015

[View](https://bepza.gov.bd/public/storage/upload/bulletin/file_1447063911.pdf)

43

April-June 2015

[View](https://bepza.gov.bd/public/storage/upload/bulletin/file_1444128358.pdf)

44

January-March, 2015

[View](https://bepza.gov.bd/public/storage/upload/bulletin/file_1447063823.pdf)

45

October-December 2014

[View](https://bepza.gov.bd/public/storage/upload/bulletin/file_1424263241.pdf)

46

July-September 2014

[View](https://bepza.gov.bd/public/storage/upload/bulletin/file_1419326804.pdf)

47

April-June 2014

[View](https://bepza.gov.bd/public/storage/upload/bulletin/file_1408430957.pdf)

48

January-March 2014

[View](https://bepza.gov.bd/public/storage/upload/bulletin/file_1400669046.pdf)

49

October-December 2013

[View](https://bepza.gov.bd/public/storage/upload/bulletin/file_1398680331.pdf)