---
source: "BEPZA"
tier: 1
category: "Export zone"
url: "https://bepza.gov.bd/executive-office"
title: "BEPZA"
scraped_at: "2026-07-02"
---

# Executive Office of BEPZA

-   [Home](https://bepza.gov.bd)
-   About BEPZA
-   BEPZA Team
-   Executive Office

#### Executive Chairman

![team](https://bepza.gov.bd/build/theme/images/ec.jpg)

###### Major General Mohammad Moazzem Hossain, ndc, afwc, psc, G, MPhil

Email: [\[email protected\]](/cdn-cgi/l/email-protection) Phone: 0241060869

#### Member

![team](https://bepza.gov.bd/build/theme/images/Member-Engineering.jpg)

###### Abdullah Al Mamun

Member (Engineering), Additional Secretary, Government of Bangladesh.

Email: [\[email protected\]](/cdn-cgi/l/email-protection) Phone: 0241060869

![team](https://bepza.gov.bd/build/theme/images/foyzul.jpg)

###### A N M Foyzul Haque

Member (Finance), Joint Secretary, Government of Bangladesh.

Email: [\[email protected\]](/cdn-cgi/l/email-protection) Phone: 0241060851

![team](https://bepza.gov.bd/build/theme/images/dummy.jpg)

Member (Investment Promotion)

Email: [\[email protected\]](/cdn-cgi/l/email-protection) Phone: 0241060870

#### Executive Director

![team](https://bepza.gov.bd/build/theme/images/EDAdmin.jpg)

###### Samir Biswas

Executive Director (Admin), Deputy Secretary, Government of Bangladesh

Email: [\[email protected\]](/cdn-cgi/l/email-protection) Phone: 0241060852

![team](https://bepza.gov.bd/build/theme/images/EDSecurity.jpg)

###### Mohammad Arifur Rahaman

Executive Director (Security)

Email: [\[email protected\]](/cdn-cgi/l/email-protection) Phone: 0241060854

![team](https://bepza.gov.bd/build/theme/images/Tanvir-Sir.jpg)

###### Md. Tanvir Hossain

Executive Director (Investment Promotion)

Email: [\[email protected\]](/cdn-cgi/l/email-protection) Phone: 0241060116

![team](https://bepza.gov.bd/build/theme/images/khorshid.jpg)

###### Md. Khorshid Alam

Executive Director (Enterprise Services)

Email: [\[email protected\]](/cdn-cgi/l/email-protection) Phone: 02223365517

![team](https://bepza.gov.bd/build/theme/images/jillur.jpg)

###### Md. Jillur Rahman

Executive Director (Maintenance)

Email: [\[email protected\]](/cdn-cgi/l/email-protection) Phone: 029614970

![team](https://bepza.gov.bd/build/theme/images/tofazzel.jpg)

###### Md. Tofazzal Hossain

Chief Accounts & Finance Officer

Email: [\[email protected\]](/cdn-cgi/l/email-protection) Phone: 0241060856

![team](https://bepza.gov.bd/build/theme/images/EDAEPZ.jpg)

###### K. M. MAHBUB-E-SOBHANI

Chief Engineer

Email: [\[email protected\]](/cdn-cgi/l/email-protection) Phone: 0241060865

![team](https://bepza.gov.bd/build/theme/images/mojammel.jpg)

###### A K M Mozammel Haque

Executive Director (MIS)

Email: [\[email protected\]](/cdn-cgi/l/email-protection) Phone: 0241062131

![team](https://bepza.gov.bd/build/theme/images/EDAUDIT.jpg)

###### Khandaker Tariqul Islam

Executive Director (Audit)

Email: [\[email protected\]](/cdn-cgi/l/email-protection) Phone: 0258611036

![team](https://bepza.gov.bd/build/theme/images/anwar.jpg)

###### Abu Syeed Md. Anwar Parvez

Executive Director (Public Relations)

Email: [\[email protected\]](/cdn-cgi/l/email-protection) Phone: 0241060858

![team](https://bepza.gov.bd/build/theme/images/ED-Mahfuza.jpg)

###### Mahfuza Islam

Executive Director

Email: Phone:

![team](https://bepza.gov.bd/build/theme/images/ED-IEPZ.jpg)

###### ABM Shahidul Islam

Executive Director(Attached)

Email: Phone:

#### PS to Executive Chairman

![team](https://bepza.gov.bd/build/theme/images/PS-to-EC.jpg)

###### Md. Nur A Alam

Director

Email: [\[email protected\]](/cdn-cgi/l/email-protection) Phone: 0241060859