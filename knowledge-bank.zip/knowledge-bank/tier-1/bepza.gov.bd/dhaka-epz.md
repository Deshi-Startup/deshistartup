---
source: "BEPZA"
tier: 1
category: "Export zone"
url: "https://bepza.gov.bd/pages/dhaka-epz"
title: "BEPZA"
scraped_at: "2026-07-02"
---

# Dhaka EPZ

-   [Home](https://bepza.gov.bd)
-   Dhaka EPZ

![ienet](https://bepza.gov.bd/public/storage/upload/content/250902014656-7388dhaka.jpg)

**Dhaka EPZ – The Premier Investment Destination**

Established in 1993 as the second EPZ of Bangladesh, Dhaka EPZ is strategically located in Savar, just 35 km from the capital city and near the international airport. Its modern infrastructure, skilled workforce, and prime location make it a leading choice for global investors.

Dhaka EPZ has been instrumental in transforming Savar-Ashulia into an industrial hub. With around US$ 39.5 billion in exports and over 90,000 workers, it is a thriving center for high-end garments, lenses, military uniform, shoes, and electronics. Its strategic location near Dhaka and the airport reduces lead times, while investor-friendly incentives and reliable utilities ensure long-term success.

Established

1993

Location

Savar, Dhaka

Zone Area

356.22 acres

Industrial Plots

451 Nos

Investment

US$ 1,900.57 million

Export

US$ 39,481.67 million

Employment

90,844 nos.

Products

High-end garments, Military uniform, Suit, Lenses, Chemical, Automobile parts, Cap, Shoes, Textile, Ready-made garments, Garments Accessories, Yarn, Plastic & Rubber Products.

Investing Countries

China (including Hong Kong and Taiwan), UK, The Netherlands, Spain, Malaysia, South Korea, Japan, USA, Sri Lanka, India, Germany, Canada, Malta, Australia, British Virgin Island, Indonesia, France, UAE, Belgium, Cayman Island, Singapore and Bangladesh.