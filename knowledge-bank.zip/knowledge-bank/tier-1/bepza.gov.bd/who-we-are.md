---
source: "BEPZA"
tier: 1
category: "Export zone"
url: "https://bepza.gov.bd/pages/who-we-are"
title: "BEPZA"
scraped_at: "2026-07-02"
---

# Who We Are

-   [Home](https://bepza.gov.bd)
-   Who We Are

![ienet](https://bepza.gov.bd/public/storage/upload/content/250902012008-6296why_bepza.jpg)

The Bangladesh Export Processing Zones Authority (BEPZA), established under the BEPZA Act, 1980, is the pioneer investment promotion agency mandated to create, develop, operate, manage, and control Export Processing Zones (EPZs). As a catalyst for industrialization, export growth, and employment generation, BEPZA has been playing a pioneering role in Bangladesh’s economic transformation for four and half decades.

Beginning with the Chattogram EPZ in 1983, BEPZA has expanded its wing to  7 more operational EPZs across the country namely Dhaka EPZ, Mongla EPZ, Cumilla EPZ, Uttara EPZ, Ishwardi EPZ, Karnaphuli EPZ and Adamjee EPZ. A state-of-the-art BEPZA Economic Zone in Mirsharai, Chattogram, is nearing completion. Additional Jashore and Patuakhali EPZ projects are underway, further strengthening the industrial base of the nation.

Guided by the Head of State and supported by a high-level Board of Governors, BEPZA offers a wide range of facilities and incentives to the foreign and local investors. The zones host a wide variety of industries—from RMG to high-end diversified manufacturing units—supported by a skilled and productive workforce.

BEPZA is more than an investment platform—it is a bridge to global markets and a driver of sustainable socio-economic growth, diversifying exports, attracting FDI, and reducing poverty by generating productive employment for hundreds of thousands of Bangladeshis.

  
**Our Vision**  
To become a significant contributor for the economic development of Bangladesh.

  
**Our Mission**

-   To strengthen the economic base of Bangladesh by:
-   Attract foreign & local investment
-   Enhance exports & foreign exchange earnings
-   Create employment opportunities
-   Upgrade skills & transfer technology
-   Drive inclusive socio-economic growth through industrialization