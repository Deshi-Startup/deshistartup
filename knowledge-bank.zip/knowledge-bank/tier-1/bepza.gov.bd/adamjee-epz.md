---
source: "BEPZA"
tier: 1
category: "Export zone"
url: "https://bepza.gov.bd/pages/adamjee-epz"
title: "BEPZA"
scraped_at: "2026-07-02"
---

# Adamjee EPZ

-   [Home](https://bepza.gov.bd)
-   Adamjee EPZ

![ienet](https://bepza.gov.bd/public/storage/upload/content/250902020350-8181adamjee.jpg)

**Adamjee EPZ – Prime Hub near Capital City**

Located in Narayanganj on the site of the historic Adamjee Jute Mills, Adamjee EPZ has been a catalyst for industrial revival since 2006. Now employing 75,959 workers, Adamjee EPZ has attracted US$ 840.40 million in investment and generated US$ 10.93 billion in exports. Its factories produce high-end garments for brands like Tommy Hilfiger, Ralph Lauren, Michael Kors, and Van Heusen. Its location between Dhaka and Chattogram, along with modern facilities, makes it a top choice for global investors.

Established

2006

Location

Siddirganj, Narayanganj

Zone Area

292.62 acres

Industrial Plots

276 Nos

Investment

US$ 840.40 million

Export

US$ 10,934.93 million

Employment

75,959 nos.

Products

Ready Made Garments (RMG), Garment Accessories, Safety Jacket, Blazer, Safety Shoes, Textile, Electronics and Electrical Products, Car Seat Cover etc.

Investing Countries

China, UK, The Netherlands, Spain, Malaysia, South Korea, Japan, USA, Sri Lanka, India, Ukraine, Germany, Canada, Romania and Bangladesh