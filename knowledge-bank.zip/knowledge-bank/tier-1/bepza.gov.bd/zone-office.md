---
source: "BEPZA"
tier: 1
category: "Export zone"
url: "https://bepza.gov.bd/zone-office"
title: "BEPZA"
scraped_at: "2026-07-02"
---

# Zone Office

-   [Home](https://bepza.gov.bd)
-   About BEPZA
-   BEPZA Team
-   Zone Office

#### Zone Authority

Each Zone (EPZ/EZ) is headed by an Executive Director, who manages daily operations and reports to the Executive Chairman.

#### Executive Directors/Project Directors of the Zones

![team](https://bepza.gov.bd/build/theme/images/EDKEPZ.jpg)

###### MOSHIUDDIN BIN MESBAH

Executive Director, CEPZ

Email: [\[email protected\]](/cdn-cgi/l/email-protection) Phone: +88-02-333341446

![team](https://bepza.gov.bd/build/theme/images/EDDEPZ.jpg)

###### MD. SHARIFUL ISLAM

Executive Director, DEPZ

Email: [\[email protected\]](/cdn-cgi/l/email-protection) Phone: +88-02-224498238

![team](https://bepza.gov.bd/build/theme/images/rahaman.jpg)

###### Md. Abdur Rahman Bhuiyan

Executive Director, AEPZ

Email: [\[email protected\]](/cdn-cgi/l/email-protection) Phone: +88-02-997744800

![team](https://bepza.gov.bd/build/theme/images/EDCumillaEPZ.jpg)

###### ABDULLAH AL MAHBUB

Executive Director, BEPZA EZ-2

Email: Phone:

![team](https://bepza.gov.bd/build/theme/images/SIDDIQ.jpeg)

###### MAHBUB AHMED SIDDIQ

Executive Director, KEPZ

Email: [\[email protected\]](/cdn-cgi/l/email-protection) Phone: +88-02-41350244

![team](https://bepza.gov.bd/build/theme/images/EDIEPZ.jpg)

###### MD. ZIAUL HASSAN

Executive Director, IEPZ

Email: [\[email protected\]](/cdn-cgi/l/email-protection) Phone: +88-02-588847802

![team](https://bepza.gov.bd/build/theme/images/EDMEPZ.jpg)

###### KALAM MD. ABUL BASHAR

Executive Director, MEPZ

Email: [\[email protected\]](/cdn-cgi/l/email-protection) Phone: +88-02-478846144

![team](https://bepza.gov.bd/build/theme/images/ED-UEPZ.jpg)

###### MOHAMMAD ABDUL JABBAR

Executive Director, UEPZ

Email: [\[email protected\]](/cdn-cgi/l/email-protection) Phone: +88-02-588819002

![team](https://bepza.gov.bd/build/theme/images/anamul.jpg)

###### MOHAMMAD ANAMUL HAQUE

Project Director, BEPZA EZ

Email: [\[email protected\]](/cdn-cgi/l/email-protection) Phone: +88-02-223365326

![team](https://bepza.gov.bd/build/theme/images/PDPEPZ.jpg)

###### MOHAMMAD SHAFIQUL ISLAM

Executive Director, CumEPZ

Email: [\[email protected\]](/cdn-cgi/l/email-protection) Phone: +88-02-334400055

![team](https://bepza.gov.bd/build/theme/images/PD-PEPZ.jpg)

###### MOHAMMAD MAJEDUR RAHMAN KHAN

Project Director, PEPZ

Email: [\[email protected\]](/cdn-cgi/l/email-protection) Phone: +88-02-41060133

![team](https://bepza.gov.bd/build/theme/images/yousuf.jpg)

###### MD. YOUSUF PASHA

Project Director, JEPZ

Email: [\[email protected\]](/cdn-cgi/l/email-protection) Phone: +88-02-41060425