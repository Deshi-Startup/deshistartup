---
source: "BEPZA"
tier: 1
category: "Export zone"
url: "https://bepza.gov.bd/pages/contact"
title: "BEPZA"
scraped_at: "2026-07-02"
---

# Contact

-   [Home](https://bepza.gov.bd)
-   Contact

**Bangladesh Export Processing Zones Authority (BEPZA)**  
BEPZA COMPLEX, HOUSE: 19/D, ROAD: 6, DHANMONDI R/A, DHAKA, BANGLADESH  
Phone: +880 0241060870, 0241060861, 0241060851, 0241060116, 0241060858

PABX : +880 029613459, 029613467, 029613462

Fax : +880 02223361849, 02223363020, 02223365545

Email: [\[email protected\]](/cdn-cgi/l/email-protection)    
[\[email protected\]](/cdn-cgi/l/email-protection)   
[\[email protected\]](/cdn-cgi/l/email-protection)  
[\[email protected\]](/cdn-cgi/l/email-protection)  
[\[email protected\]](/cdn-cgi/l/email-protection), URL : www.bepza.gov.bd  
  
**Chattogram Export Processing Zone (CEPZ)**  
South Halishahar, Chattogram.

Executive Director Mobile No.:01713-105063  
Phone: +880 2333341446  
Fax: +880 02333340031

Email: [\[email protected\]](/cdn-cgi/l/email-protection)  
 

**Dhaka Export Processing Zone (DEPZ)**  
Ganakbari, Savar, Dhaka.

Executive Director Mobile No.:01713-016415  
Phone: +880 2996689002  
Fax: +880 2996689003

Email: [\[email protected\]](/cdn-cgi/l/email-protection)  
 

**Mongla Export Processing Zone (MEPZ)**  
Mongla, Bagerhat.

Executive Director Mobile No.:01713-402040  
Phone: +880 2478846144  
Fax: +880 2478846145

Email: [\[email protected\]](/cdn-cgi/l/email-protection)  
 

**Cumilla Export Processing Zone (CUMEPZ)**  
Old Airport Area, Cumilla.

Executive Director Mobile No.:01713-106675  
Phone: +880 2334404709  
Fax: +880 2334400056

Email: [\[email protected\]](/cdn-cgi/l/email-protection)

**Ishwardi Export Processing Zone (IEPZ)**  
Ishwardi, Pabna.

Executive Director Mobile No.:01711-419246  
Phone: +880 2588847802  
Fax: +880 2588847808

Email: [\[email protected\]](/cdn-cgi/l/email-protection)

**Uttara Export Processing Zone (UEPZ)**  
Shongalshi, Nilphamari.

Executive Director Mobile No.:01713-201068  
Phone : +880 2588819002  
Fax : +880 2589960302

Email: [\[email protected\]](/cdn-cgi/l/email-protection)

**Adamjee Export Processing Zone (AEPZ)**  
Adamjee Nagar, Siddirgang, Narayangang.

Executive Director Mobile No.:01713-043004  
Phone: +880 2997744800  
Fax: +880 2997744801

Email: [\[email protected\]](/cdn-cgi/l/email-protection)

**Karnaphuli Export Processing Zone (KEPZ)**  
Karnaphuli, Chittagong.

Executive Director Mobile No.:01713-102995  
Phone: +880 2333301469  
Fax: +880 2333301460  
Email: [\[email protected\]](/cdn-cgi/l/email-protection)

**BEPZA Economic Zone (BEPZA EZ)**  
Mirsarai, Chattogram.

Project Director Mobile No.:01720-560729  
Phone: +880 2223365326  
Email: [\[email protected\]](/cdn-cgi/l/email-protection)