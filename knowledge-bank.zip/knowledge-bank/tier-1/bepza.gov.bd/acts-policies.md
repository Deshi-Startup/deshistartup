---
source: "BEPZA"
tier: 1
category: "Export zone"
url: "https://bepza.gov.bd/acts-policies"
title: "BEPZA"
scraped_at: "2026-07-02"
---

# Acts and Policies

-   [Home](https://bepza.gov.bd)
-   How We Help
-   Acts and Policies

## Acts, Policies, SROs related to BEPZA

#

Title

Action

1

The Bangladesh Export Processing Zones Authority Act, 1980

[View](<https://bepza.gov.bd/public/storage/upload/content-file/250831125537-9678The Bangladesh Export Processing Zones Authority Act, 1980.pdf>)

## Acts, Policies, SROs related to NBR, Customs & VAT

#

Title

Action

1

SRO 545-Law-1984-889-Cus\_1984\_TheCustoms(ExportProcessingZones)Rules-1984

[View](<https://bepza.gov.bd/public/storage/upload/content-file/210608063402-2306SRO 545-Law-1984-889-Cus_1984_TheCustoms\(ExportProcessingZones\)Rules-1984_.pdf>)

2

এস.আর.ও.নং ১৩৪-আইন/২০২০/৮৫/কাস্টমস

[View](https://bepza.gov.bd/public/storage/upload/content-file/210608063941-7037SRO-134-2020-BEPZA-Other-Goods-New_.pdf)

3

এস.আর.ও.নং ৩৬৯/আইন/২০১৩

[View](https://bepza.gov.bd/public/storage/upload/content-file/210608064744-3557এস.আর.ও.৩৬৯.pdf)

4

এস.আর.ও.নং ১২২/আইন /২০২০/৭৩/কাস্টমস

[View](https://bepza.gov.bd/public/storage/upload/content-file/210608081350-78053.SRO-122-2020-Indus-Raw-Mat-New.pdf)

5

এস.আর.ও.নং ৯৯/আইন /৯৬/১৬৬২/শুল্ক

[View](https://bepza.gov.bd/public/storage/upload/content-file/210608081725-9855SRO-99-Law-96-1662-Cus.pdf)

6

এস.আর.ও.নং ১০০/আইন /২০১০/২২৮১/শুল্ক

[View](<https://bepza.gov.bd/public/storage/upload/content-file/210608081938-3444SRO-100-Finance Ministry-06 April 2010\(1971-1972\).pdf>)

7

এস.আর.ও.নং ১০১/আইন /২০১০/২২৮০/কাস্টমস ও মুসক

[View](<https://bepza.gov.bd/public/storage/upload/content-file/210608082202-7917SRO-101-Finance Ministry-06 April 2010\(1981-1983\).pdf>)

8

এস.আর.ও.নং ১৮১/আইন /২০০৮/২২০৯/শুল্ক

[View](<https://bepza.gov.bd/public/storage/upload/content-file/210608082435-1209SRO-181-Law-2008-2209-Cus _Bond Licensing Rules_.pdf>)

9

এস.আর.ও.নং ২৩৭/আইন /২০০৯/২২৬৬/শুল্ক

[View](<https://bepza.gov.bd/public/storage/upload/content-file/210608082702-9501SRO-237-Home-01 Nov_2009\(7177-7178\).PDF>)

10

এস.আর.ও.নং ৫৬/আইন /২০১৭/কাস্টমস

[View](https://bepza.gov.bd/public/storage/upload/content-file/210608082945-5565SRO-56.pdf)

11

এস.আর.ও.নং ৬৩/আইন /২০১৭/০৫/কাস্টমস

[View](<https://bepza.gov.bd/public/storage/upload/content-file/210608083143-4593এস. আর. ও.৬৩.pdf>)

12

এস.আর.ও.নং ৩৪/আইন /৯৮/১৭৩৫/শুল্ক

[View](https://bepza.gov.bd/public/storage/upload/content-file/210608083445-1666এস.আর.ও-৩৪.pdf)

13

এস.আর.ও.নং ১৯৪/আইন /২০২০/১০৪/কাস্টমস

[View](<https://bepza.gov.bd/public/storage/upload/content-file/210608083722-3920এস.আর.ও নং ১৯৪.pdf>)

14

এস.আর.ও.নং ১৮৩/আইন /২০২০/৯২/কাস্টমস

[View](https://bepza.gov.bd/public/storage/upload/content-file/210608083928-2167১৮৩.pdf)

15

এস.আর.ও.নং ১১৭-আইন/ ২০০৮

[View](https://bepza.gov.bd/public/storage/upload/content-file/210621064637-8123১১৭.pdf)

16

এস.আর.ও.নং ৬৭/আইন/ ২০২০/৬২/ কাস্টমস 

[View](https://bepza.gov.bd/public/storage/upload/content-file/210621065641-168967.pdf)

17

এস.আর.ও.নং ১৯০/২০১৮/কাস্টমস

[View](https://bepza.gov.bd/public/storage/upload/content-file/210621070530-3049190.pdf)

18

এস.আর.ও.নং ৭৫-আইন/২০১৭/০৬/কাস্টমস

[View](https://bepza.gov.bd/public/storage/upload/content-file/210621070907-1118৭৫.pdf)

19

এস.আর.ও.নং ২৮৮-আইন/২০১৪/২৫২৮/কাস্টমস

[View](https://bepza.gov.bd/public/storage/upload/content-file/210621071256-2257২৮৮.pdf)

20

EPZ Minimum Wage Structure-2023 (Draft Gazette)

[View](<https://bepza.gov.bd/public/storage/upload/content-file/231211092208-2532EPZ minimum Wage, 2023- Gazette Notification.pdf>)

21

VATSRO-1881

[View](https://bepza.gov.bd/public/storage/upload/content-file/210306091013-335VATSRO-1881.pdf)

22

এস.আর.ও নং ১৮৪-আইন/২০২২/ কাস্টমস

[View](https://bepza.gov.bd/public/storage/upload/content-file/231114080421-1969DOC-20231108-WA0001..pdf)

23

এস.আর.ও.নং ১৯/আইন/২০২৪ ( Minimum Wage Structure for EPZ Workers)

[View](<https://bepza.gov.bd/public/storage/upload/content-file/240211093419-9903EPZ Minimum Wage 2023.pdf>)

24

এস.আর.ও.নং ৪৩৮-আইন /২০২৫/১০৮/কাস্টমস

[View](<https://bepza.gov.bd/public/storage/upload/content-file/251109054408-7708SRO 438, 6 November 2025 \(Amend 237 of 2009\).pdf>)

25

VATSRO-1891

[View](https://bepza.gov.bd/public/storage/upload/content-file/210306091044-899VATSRO-1891.pdf)

## Acts, Policies, SROs related to Labour/Minimum Wage/Work Permit

#

Title

Action

1

Bangladesh EPZ Labour Act, 2019 (Bangla)

[View](<https://bepza.gov.bd/public/storage/upload/content-file/250831010618-6057Bangladesh EPZ Labour Act, 2019 \(Bangla\).pdf>)

2

Bangladesh EPZ Labour Act, 2019 (English)

[View](<https://bepza.gov.bd/public/storage/upload/content-file/250831010634-5715Bangladesh EPZ Labour Act, 2019 \(English\).pdf>)

3

Bangladesh EPZ Labour Rules, 2022

[View](<https://bepza.gov.bd/public/storage/upload/content-file/250831010714-9136Bangladesh EPZ Labour Rules, 2022.pdf>)

4

ইপিজেড নিম্নতম মজুরি কাঠামো ২০২৩

[View](<https://bepza.gov.bd/public/storage/upload/content-file/250831010741-6049ইপিজেড নিম্নতম মজুরি কাঠামো ২০২৩.pdf>)

5

১০% বাৎসরিক মজুরি বৃদ্ধি সংক্রান্ত গেজেট (এস. আর. ও নম্বর - ২৬৫ - আইন ২০২৫)

[View](https://bepza.gov.bd/public/storage/upload/content-file/gezet.pdf)

6

EPZ Factory Inspection Checklist

[View](<https://bepza.gov.bd/public/storage/upload/content-file/251013065427-7931EPZ Factory Inspection Checklist.pdf>)

7

BEPZA Work Permit Policy, 2021

[View](<https://bepza.gov.bd/public/storage/upload/content-file/250831010655-7837BEPZA-Work Permit Policy-2021.pdf>)

## Acts, Policies, SROs related to OSS

#

Title

Action

1

BEPZA OSS Rules, 2019

[View](<https://bepza.gov.bd/public/storage/upload/content-file/250831011113-2823BEPZA OSS Rules, 2019.pdf>)

2

One Stop Service (OSS) Act, 2018

[View](<https://bepza.gov.bd/public/storage/upload/content-file/250831011127-8437One Stop Service \(OSS\) Act, 2018.pdf>)

## Other Acts, Policies, SROs

#

Title

Action

1

Foreign Private Investment (Promotion & Protection) Act, 1980 (Act No. XI of 1980)

[View](https://bepza.gov.bd/public/storage/upload/content-file/Foreign.pdf)

2

Guidelines for Foreign Exchange Transactions 2018 (Volume- 1), Bangladesh Bank

[View](https://bepza.gov.bd/public/storage/upload/content-file/GFET-2018.pdf)