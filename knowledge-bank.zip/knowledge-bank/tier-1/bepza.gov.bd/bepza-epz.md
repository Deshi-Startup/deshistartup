---
source: "BEPZA"
tier: 1
category: "Export zone"
url: "https://bepza.gov.bd/pages/bepza-epz"
title: "BEPZA"
scraped_at: "2026-07-02"
---

# BEPZA EZ

-   [Home](https://bepza.gov.bd)
-   BEPZA EZ

![ienet](https://bepza.gov.bd/public/storage/upload/content/250902020808-9343bepza-ez.jpg)

**BEPZA Economic Zone – The Future of Investment**

Launched in 2018 in Mirsharai, Chattogram, BEPZA Economic Zone is the largest initiative of BEPZA, covering 1,138.55 acres. Its proximity to the Bay of Bengal and Dhaka-Chattogram highway offers unmatched connectivity.

358 plots and one factory building of BEPZA EZ have already been allotted to 61 investors. Twelve companies have started operations, employing 5,021 workers, with exports of US$ 48.85 million. Planned to create jobs for half a million people, it offers one-stop services, fully serviced plots, and green investment opportunities. This zone is set to become a landmark industrial destination for Bangladesh.

Established

2018

Location

Mirsharai, Chattogram

Zone Area

1138.55 acres

Industrial Plots

539 Nos

Investment

US$ 96.81 million

Export

US$ 48.85 million

Employment

5,021 nos.

Products

Shoe Accessories, Textile, Ready Made Garments

Investing Countries

China, Malaysia, South Korea, Canada