---
source: "BEPZA"
tier: 1
category: "Export zone"
url: "https://bepza.gov.bd/pages/executive-board"
title: "BEPZA"
scraped_at: "2026-07-02"
---

# Executive Board

-   [Home](https://bepza.gov.bd)
-   Executive Board

**Executive Board**

The Executive Board ensures BEPZA’s effective management and smooth operation under the guidance of the Board of Governors. It consists of:

•    A Chairman (Executive Chairman), who also serves as the Chief Executive Officer (CEO) of BEPZA  
•    Three Members: Investment Promotion, Engineering, and Finance

All are appointed by the Government.