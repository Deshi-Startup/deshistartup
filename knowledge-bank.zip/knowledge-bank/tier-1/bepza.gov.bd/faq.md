---
source: "BEPZA"
tier: 1
category: "Export zone"
url: "https://bepza.gov.bd/faq"
title: "BEPZA"
scraped_at: "2026-07-02"
---

# FAQ

-   [Home](https://bepza.gov.bd)
-   FAQ

## What is the minimum wage in the EPZ?

**USD 70.00 (BDT 5600.00)**

## What are the additional benefits for workers?

**a) Annual increment, Promotion, Festivals Bonus, Earn Leave Encashment, Transport/Transport Allowance, Production Bonus, Attendance Bonus, Tiffin, Lunch/Lunch Allowance, Foreign Training facility, etc. b) 24/7 hours free treatment & medicines in the EPZs hospitals/medical centre. c) Subsidize education facility for the children of EPZs Workers in BEPZA-run School and Colleges.**

## How many weekly holidays for workers?

**01 day**

## How many days for maternity leave?

**16 weeks.**

## How many festival bonuses for workers in year?

**02 Festival Bonuses in a year are mandatory.**

## Do the workers have any right to form association in the EPZ?

**Yes. As per “the EPZ Workers’ Welfare Association and Industrial Relations Act, 2010” workers have the right to form Workers’ Welfare Association.**

## Is there any provident fund facility for workers?

**Yes. As per “The EPZ Employees’ (Contributory) Provident Fund Policy-2012” it is mandatory to establish and operate Provident fund for every enterprises operating in EPZs. The gross wage has been calculated as Basic wage + House rent 40% on Basic + Medical allowance Tk. 560 (Fixed). In addition of the above gross wage, Food or Food allowance and Transport or Transport allowance shall be provided by the enterprises. Considering the production cost investors are being deemed to be satisfied with the overall productivity of the labours.**