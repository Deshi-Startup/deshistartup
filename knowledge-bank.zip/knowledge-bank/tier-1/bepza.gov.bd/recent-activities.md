---
source: "BEPZA"
tier: 1
category: "Export zone"
url: "https://bepza.gov.bd/recent-activities"
title: "BEPZA"
scraped_at: "2026-07-02"
---

# Recent Activities

-   [Home](https://bepza.gov.bd)
-   Media & Publications
-   Events
-   Recent Activities

[![blog-img](https://bepza.gov.bd/public/storage/upload/activity/260701020435-2523DSC00511.JPG\(1\).jpg)](https://bepza.gov.bd/spotlight/another-foreign-investment-in-bepza-economic-zone-deltaport-footwear-to-invest-us-2160-million-in-footwear-manufacturing-plant)

-   [Start: 2026-06-30](#)
-   [End2028-07-31](#)

#### [Deltaport Footwear to invest US$ 21.60 million in footwear manufacturing plant](https://bepza.gov.bd/spotlight/another-foreign-investment-in-bepza-economic-zone-deltaport-footwear-to-invest-us-2160-million-in-footwear-manufacturing-plant)

[![blog-img](https://bepza.gov.bd/public/storage/upload/activity/260625074805-3971EPZ1080.jpg)](https://bepza.gov.bd/spotlight/new-milestone-in-ensuring-social-protection-for-epz-workers-bepza-ilo-reaffirm-joint-commitment-to-establish-a-permanent-employment-injury-scheme-eis)

-   [Start: 2026-06-24](#)
-   [End2027-07-25](#)

#### [New Milestone in Ensuring Social Protection for EPZ Workers BEPZA-ILO Reaffirm Joint Commitment to Establish a Permanent Employment Injury Scheme (EIS)](https://bepza.gov.bd/spotlight/new-milestone-in-ensuring-social-protection-for-epz-workers-bepza-ilo-reaffirm-joint-commitment-to-establish-a-permanent-employment-injury-scheme-eis)

[![blog-img](https://bepza.gov.bd/public/storage/upload/activity/260521073123-9097faiaz.JPG.jpeg)](https://bepza.gov.bd/spotlight/bepza-secures-us-15-million-investment-to-establish-tent-camping-factory-at-bepza-ez)

-   [Start: 2026-05-20](#)
-   [End2026-08-20](#)

#### [BEPZA secures US$ 15 million investment to establish tent & camping factory at BEPZA EZ](https://bepza.gov.bd/spotlight/bepza-secures-us-15-million-investment-to-establish-tent-camping-factory-at-bepza-ez)

[![blog-img](https://bepza.gov.bd/public/storage/upload/activity/260521100842-98331_Signing.jpg)](https://bepza.gov.bd/spotlight/yeijer-shoe-parts-to-produce-footwear-and-footwear-accessories-in-cumilla-epz)

-   [Start: 2026-05-20](#)
-   [End2027-05-28](#)

#### [Yeijer Shoe Parts to produce footwear and footwear accessories in Cumilla EPZ](https://bepza.gov.bd/spotlight/yeijer-shoe-parts-to-produce-footwear-and-footwear-accessories-in-cumilla-epz)

[![blog-img](https://bepza.gov.bd/public/storage/upload/activity/260406112341-5569EPZ_3243.jpg.jpeg)](https://bepza.gov.bd/spotlight/bepza-signs-us-2403-million-investment-deal-with-south-korean-company)

-   [Start: 2026-04-06](#)
-   [End2028-04-12](#)

#### [BEPZA signs US$ 24.03 million investment deal with South Korean company](https://bepza.gov.bd/spotlight/bepza-signs-us-2403-million-investment-deal-with-south-korean-company)

[![blog-img](<https://bepza.gov.bd/public/storage/upload/activity/260308101356-16621.JPG \(1\).jpeg>)](https://bepza.gov.bd/spotlight/bepza-secures-us-1534-million-investment-to-establish-high-end-apparel-factory-at-bepza-ez)

-   [Start: 2026-03-08](#)
-   [End2026-03-15](#)

#### [BEPZA secures US$ 15.34 million investment to establish high-end apparel factory at BEPZA EZ](https://bepza.gov.bd/spotlight/bepza-secures-us-1534-million-investment-to-establish-high-end-apparel-factory-at-bepza-ez)

[![blog-img](https://bepza.gov.bd/public/storage/upload/activity/260304101932-9501_EPZ2656.jpg.jpeg)](https://bepza.gov.bd/spotlight/chinese-company-to-establish-fashion-beauty-products-manufacturing-plant-at-bepza-economic-zone)

-   [Start: 2026-03-04](#)
-   [End2026-03-11](#)

#### [Chinese company to establish fashion & beauty products manufacturing plant at BEPZA Economic Zone](https://bepza.gov.bd/spotlight/chinese-company-to-establish-fashion-beauty-products-manufacturing-plant-at-bepza-economic-zone)

[![blog-img](https://bepza.gov.bd/public/storage/upload/activity/260301100928-6726_EPZ2509.JPG.jpeg)](https://bepza.gov.bd/spotlight/bepza-signs-us-305-million-deal-for-hydroponics-tent-manufacturing-at-bepza-economic-zone)

-   [Start: 2026-03-01](#)
-   [End2026-03-08](#)

#### [BEPZA Signs US$ 30.5 Million Deal for Hydroponics Tent Manufacturing at BEPZA Economic Zone](https://bepza.gov.bd/spotlight/bepza-signs-us-305-million-deal-for-hydroponics-tent-manufacturing-at-bepza-economic-zone)

[![blog-img](<https://bepza.gov.bd/public/storage/upload/activity/260223085131-91301.JPG \(1\).jpeg>)](https://bepza.gov.bd/spotlight/uae-bangladesh-joint-venture-company-to-invest-us-10-million-in-bepza-ez)

-   [Start: 2026-02-23](#)
-   [End2026-03-02](#)

#### [UAE-Bangladesh Joint Venture Company to Invest US$ 10 Million in BEPZA EZ](https://bepza.gov.bd/spotlight/uae-bangladesh-joint-venture-company-to-invest-us-10-million-in-bepza-ez)

[![blog-img](https://bepza.gov.bd/public/storage/upload/activity/260222085633-21581.JPG.jpeg)](https://bepza.gov.bd/spotlight/tianford-bangladesh-textile-to-invest-us-20-million-in-uttara-epz)

-   [Start: 2026-02-22](#)
-   [End2026-03-02](#)

#### [Tianford Bangladesh Textile to invest US$ 20 Million in Uttara EPZ](https://bepza.gov.bd/spotlight/tianford-bangladesh-textile-to-invest-us-20-million-in-uttara-epz)

[![blog-img](https://bepza.gov.bd/public/storage/upload/activity/260127053530-6005_EPZ1472.JPG.jpeg)](https://bepza.gov.bd/spotlight/south-korean-company-park-handbag-to-invest-us-80-million-in-bepza-ez)

-   [Start: 2026-01-27](#)
-   [End2026-02-27](#)

#### [South Korean company Park Handbag to invest US$ 80 Million in BEPZA EZ](https://bepza.gov.bd/spotlight/south-korean-company-park-handbag-to-invest-us-80-million-in-bepza-ez)

[![blog-img](https://bepza.gov.bd/public/storage/upload/activity/260127102123-3569_EPZ1489.JPG.jpeg)](https://bepza.gov.bd/spotlight/chinese-company-to-invest-us-1634-million-in-bepza-economic-zone)

-   [Start: 2026-01-27](#)
-   [End2026-02-27](#)

#### [Chinese company to invest US$ 16.34 million in BEPZA Economic Zone](https://bepza.gov.bd/spotlight/chinese-company-to-invest-us-1634-million-in-bepza-economic-zone)

[![blog-img](<https://bepza.gov.bd/public/storage/upload/activity/251209094215-9070WhatsApp Image 2025-12-09 at 3.36.15 PM.jpeg>)](https://bepza.gov.bd/spotlight/chinese-company-to-invest-us-1032-million-in-bepza-economic-zone)

-   [Start: 2025-12-09](#)
-   [End2025-12-16](#)

#### [Chinese company to invest US$ 10.32 million in BEPZA Economic Zone](https://bepza.gov.bd/spotlight/chinese-company-to-invest-us-1032-million-in-bepza-economic-zone)

[![blog-img](https://bepza.gov.bd/public/storage/upload/activity/250902102313-9964bepza-contributes.jpg)](https://bepza.gov.bd/spotlight/bepza-contributes-1703-to-national-export-in-fy-2024-25)

-   [Start: 2025-11-23](#)
-   [End2026-01-10](#)

#### [BEPZA Contributes 17.03% to National Export in FY 2024–25](https://bepza.gov.bd/spotlight/bepza-contributes-1703-to-national-export-in-fy-2024-25)

[![blog-img](https://bepza.gov.bd/public/storage/upload/activity/251117115541-1486EPZ8721.JPG)](https://bepza.gov.bd/spotlight/bepza-ez-attracts-us-71m-fdi-in-light-engineering-garment-accessories)

-   [Start: 2025-11-17](#)
-   [End2025-11-24](#)

#### [BEPZA EZ attracts US$ 71m FDI in light engineering & garment accessories](https://bepza.gov.bd/spotlight/bepza-ez-attracts-us-71m-fdi-in-light-engineering-garment-accessories)

-   1
-   [2](https://bepza.gov.bd/recent-activities?page=2)
-   [](https://bepza.gov.bd/recent-activities?page=2)