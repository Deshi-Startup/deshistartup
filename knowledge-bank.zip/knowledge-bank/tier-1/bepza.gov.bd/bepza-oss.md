---
source: "BEPZA"
tier: 1
category: "Export zone"
url: "https://bepza.gov.bd/bepza-oss"
title: "BEPZA"
scraped_at: "2026-07-02"
---

# BEPZA OSS

-   [Home](https://bepza.gov.bd)
-   BEPZA OSS

#### About OSS of BEPZA

BEPZA is the pioneer in introducing ‘One Window Same Day Service’ concept in Bangladesh since its inception. Later on, the concept was converted into ‘One Stop Service’ as per “One Stop Service Act 2018” and “One Stop Service (Bangladesh Export Processing Zones Authority) Rules, 2019”. At present, BEPZA has a “Central One Stop Service Authority” and 09 “Regional One Stop Service Centers”. 124 types of BEPZA-related services and 76 types of Other Agencies-related services are provided from these OSS Centers.

#### BEPZA OSS Statistics

###### Please select Fiscal Year: FY-2025 - 2026 FY-2024 - 2025 FY-2023 - 2024

-    ![oss-icon](https://bepza.gov.bd/build/theme/images/oss-icon.png) Monthly Report
-    ![oss-icon](https://bepza.gov.bd/build/theme/images/oss-icon.png) Yearly Report

-   JUL
-   AUG
-   SEP
-   OCT
-   NOV
-   DEC
-   JAN
-   FEB
-   MAR
-   APR
-   MAY
-   JUN

![icon](https://bepza.gov.bd/build/theme/images/check.png)

##### BEPZA’s Internal Services Provided

![icon](https://bepza.gov.bd/build/theme/images/check.png)

##### Other Organization Related Services Provided

![icon](https://bepza.gov.bd/build/theme/images/close.png)

##### BEPZA’s Internal Services Pending

![icon](https://bepza.gov.bd/build/theme/images/close.png)

##### Other Organization Related Services Pending

![icon](https://bepza.gov.bd/build/theme/images/check.png)

##### BEPZA’s Internal Services Provided

![icon](https://bepza.gov.bd/build/theme/images/check.png)

##### Other Organization Related Services Provided

![icon](https://bepza.gov.bd/build/theme/images/close.png)

##### BEPZA’s Internal Services Pending

![icon](https://bepza.gov.bd/build/theme/images/close.png)

##### Other Organization Related Services Pending

![icon](https://bepza.gov.bd/build/theme/images/check.png)

##### BEPZA’s Internal Services Provided

![icon](https://bepza.gov.bd/build/theme/images/check.png)

##### Other Organization Related Services Provided

![icon](https://bepza.gov.bd/build/theme/images/close.png)

##### BEPZA’s Internal Services Pending

![icon](https://bepza.gov.bd/build/theme/images/close.png)

##### Other Organization Related Services Pending

![icon](https://bepza.gov.bd/build/theme/images/check.png)

##### BEPZA’s Internal Services Provided

![icon](https://bepza.gov.bd/build/theme/images/check.png)

##### Other Organization Related Services Provided

![icon](https://bepza.gov.bd/build/theme/images/close.png)

##### BEPZA’s Internal Services Pending

![icon](https://bepza.gov.bd/build/theme/images/close.png)

##### Other Organization Related Services Pending

![icon](https://bepza.gov.bd/build/theme/images/check.png)

##### BEPZA’s Internal Services Provided

![icon](https://bepza.gov.bd/build/theme/images/check.png)

##### Other Organization Related Services Provided

![icon](https://bepza.gov.bd/build/theme/images/close.png)

##### BEPZA’s Internal Services Pending

![icon](https://bepza.gov.bd/build/theme/images/close.png)

##### Other Organization Related Services Pending

![icon](https://bepza.gov.bd/build/theme/images/check.png)

##### BEPZA’s Internal Services Provided

![icon](https://bepza.gov.bd/build/theme/images/check.png)

##### Other Organization Related Services Provided

![icon](https://bepza.gov.bd/build/theme/images/close.png)

##### BEPZA’s Internal Services Pending

![icon](https://bepza.gov.bd/build/theme/images/close.png)

##### Other Organization Related Services Pending

![icon](https://bepza.gov.bd/build/theme/images/check.png)

##### BEPZA’s Internal Services Provided

![icon](https://bepza.gov.bd/build/theme/images/check.png)

##### Other Organization Related Services Provided

![icon](https://bepza.gov.bd/build/theme/images/close.png)

##### BEPZA’s Internal Services Pending

![icon](https://bepza.gov.bd/build/theme/images/close.png)

##### Other Organization Related Services Pending

![icon](https://bepza.gov.bd/build/theme/images/check.png)

##### BEPZA’s Internal Services Provided

![icon](https://bepza.gov.bd/build/theme/images/check.png)

##### Other Organization Related Services Provided

![icon](https://bepza.gov.bd/build/theme/images/close.png)

##### BEPZA’s Internal Services Pending

![icon](https://bepza.gov.bd/build/theme/images/close.png)

##### Other Organization Related Services Pending

![icon](https://bepza.gov.bd/build/theme/images/check.png)

##### BEPZA’s Internal Services Provided

![icon](https://bepza.gov.bd/build/theme/images/check.png)

##### Other Organization Related Services Provided

![icon](https://bepza.gov.bd/build/theme/images/close.png)

##### BEPZA’s Internal Services Pending

![icon](https://bepza.gov.bd/build/theme/images/close.png)

##### Other Organization Related Services Pending

![icon](https://bepza.gov.bd/build/theme/images/check.png)

##### BEPZA’s Internal Services Provided

![icon](https://bepza.gov.bd/build/theme/images/check.png)

##### Other Organization Related Services Provided

![icon](https://bepza.gov.bd/build/theme/images/close.png)

##### BEPZA’s Internal Services Pending

![icon](https://bepza.gov.bd/build/theme/images/close.png)

##### Other Organization Related Services Pending

![icon](https://bepza.gov.bd/build/theme/images/check.png)

##### BEPZA’s Internal Services Provided

![icon](https://bepza.gov.bd/build/theme/images/check.png)

##### Other Organization Related Services Provided

![icon](https://bepza.gov.bd/build/theme/images/close.png)

##### BEPZA’s Internal Services Pending

![icon](https://bepza.gov.bd/build/theme/images/close.png)

##### Other Organization Related Services Pending

![icon](https://bepza.gov.bd/build/theme/images/check.png)

##### BEPZA’s Internal Services Provided

![icon](https://bepza.gov.bd/build/theme/images/check.png)

##### Other Organization Related Services Provided

![icon](https://bepza.gov.bd/build/theme/images/close.png)

##### BEPZA’s Internal Services Pending

![icon](https://bepza.gov.bd/build/theme/images/close.png)

##### Other Organization Related Services Pending

-   2026 - 2027
-   2025 - 2026
-   2024 - 2025
-   2023 - 2024

![icon](https://bepza.gov.bd/build/theme/images/check.png)

##### BEPZA’s Internal Services Provided

![icon](https://bepza.gov.bd/build/theme/images/check.png)

##### Other Organization Related Services Provided

![icon](https://bepza.gov.bd/build/theme/images/close.png)

##### BEPZA’s Internal Services Pending

![icon](https://bepza.gov.bd/build/theme/images/close.png)

##### Other Organization Related Services Pending

;

![icon](https://bepza.gov.bd/build/theme/images/check.png)

##### BEPZA’s Internal Services Provided

![icon](https://bepza.gov.bd/build/theme/images/check.png)

##### Other Organization Related Services Provided

![icon](https://bepza.gov.bd/build/theme/images/close.png)

##### BEPZA’s Internal Services Pending

![icon](https://bepza.gov.bd/build/theme/images/close.png)

##### Other Organization Related Services Pending

;

![icon](https://bepza.gov.bd/build/theme/images/check.png)

##### BEPZA’s Internal Services Provided

![icon](https://bepza.gov.bd/build/theme/images/check.png)

##### Other Organization Related Services Provided

![icon](https://bepza.gov.bd/build/theme/images/close.png)

##### BEPZA’s Internal Services Pending

![icon](https://bepza.gov.bd/build/theme/images/close.png)

##### Other Organization Related Services Pending

;

![icon](https://bepza.gov.bd/build/theme/images/check.png)

##### BEPZA’s Internal Services Provided

![icon](https://bepza.gov.bd/build/theme/images/check.png)

##### Other Organization Related Services Provided

![icon](https://bepza.gov.bd/build/theme/images/close.png)

##### BEPZA’s Internal Services Pending

![icon](https://bepza.gov.bd/build/theme/images/close.png)

##### Other Organization Related Services Pending

;

#### Login to BEPZA OSS

#### BEPZA ONE STOP SERVICE (OSS) PORTAL

[Login to BEPZA OSS](https://oss.bepza.gov.bd)

![portal-img](https://bepza.gov.bd/build/theme/images/portal-img.png)