---
source: "BEPZA"
tier: 1
category: "Export zone"
url: "https://bepza.gov.bd/pages/how-to-apply"
title: "BEPZA"
scraped_at: "2026-07-02"
---

# How to Apply

-   [Home](https://bepza.gov.bd)
-   How to Apply

-   Collect the Prescribed Project Proposal Form from BEPZA on payment of BDT 3000 only.
-   Submit the proposal along with the required documents for review and approval of the project.
-   For execution of the Lease Agreement, the following deposits are required:

Allotted Space

Registration Fee

Security Deposit

Stamp Duty

Land

US$ 500

01 (one) Year's Rent

Applicable

Standard Factory Building

US$ 500

04 (four) Months' Rent

Not Applicable

      The Executive Chairman

      Bangladesh Export Processing Zones Authority (BEPZA)

      Address: BEPZA Executive Office, BEPZA Complex, House: 19/D, Road: 6, Dhanmondi R/A, Dhaka,

      Bangladesh.

      Phone: +880 2 9670530, 9675489, 9613461, 9613459

      Fax: +880 2 9673020, 9668472

      Email: [\[email protected\]](/cdn-cgi/l/email-protection#91f2f9f0f8e3fcf0ffd1f3f4e1ebf0bff6fee7bff3f5)

                [\[email protected\]](/cdn-cgi/l/email-protection#3f525a525d5a4d11564f7f5d5a4f455e11585049115d5b)

      [\[email protected\]](/cdn-cgi/l/email-protection)

-   To download the Proposal please [Click Here](https://www.bepza.gov.bd/public/ckfinder/userfiles/files/Project-Proposal-Form.pdf)