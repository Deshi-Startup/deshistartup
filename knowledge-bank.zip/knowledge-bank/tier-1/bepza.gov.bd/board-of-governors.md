---
source: "BEPZA"
tier: 1
category: "Export zone"
url: "https://bepza.gov.bd/pages/board-of-governors"
title: "BEPZA"
scraped_at: "2026-07-02"
---

# Board of Governors

-   [Home](https://bepza.gov.bd)
-   Board of Governors

![ienet](https://bepza.gov.bd/public/storage/upload/content/260218035844-4712816dc0a6-001c-4a8f-b4b2-9c18afe9d599.jpeg)

**Board of Governors**

The Board of Governors is the highest policy-making body of BEPZA. It is chaired by the Honorable Prime Minister (or a Minister nominated by the Prime Minister). Its members include:

-   Ministers of key ministries such as Industries, Commerce, Finance, Planning, Foreign Affairs, Energy, and Ports & Shipping 
-   Governor of Bangladesh Bank
-   Principal Secretary and Secretaries of relevant Ministries/Divisions (Industries, Commerce, Finance, Planning, Foreign Affairs, Energy, Ports & Shipping, and Internal Resources)
-   Chairman of the Executive Board, who also acts as the Secretary of the Board

The Government, with the approval of the Prime Minister, may also include or exclude any member when necessary.

**Functions**

The Board of Governors is entrusted with key responsibilities:

-   Formulate policies for the operation and management of BEPZA and its zones
-   Review, from time to time, the activities and performance of the Executive Board and the zones
-   Issuing orders and instructions to ensure efficient management and smooth functioning of the Authority