---
source: "BEPZA"
tier: 1
category: "Export zone"
url: "https://bepza.gov.bd/pages/karnaphuli-epz"
title: "BEPZA"
scraped_at: "2026-07-02"
---

# Karnaphuli EPZ

-   [Home](https://bepza.gov.bd)
-   Karnaphuli EPZ

![ienet](https://bepza.gov.bd/public/storage/upload/content/250902020555-7606karnaqfuli.jpg)

**Karnaphuli EPZ – Second EPZ at Port City**

Developed on the former site of Chittagong Steel Mill, Karnaphuli EPZ opened in 2006 with world-class infrastructure and a prime location near Chattogram Port and Airport. Karnaphuli EPZ has quickly grown into a thriving hub with 77,137 workers and US$ 13.90 billion in exports. Its industries produce garments, tents, leather goods, bicycles, furniture, and shoes. Its strategic seaport location ensures short lead times and efficient global shipments, making it a highly competitive choice for export-oriented manufacturing.

Established

2006

Location

North Patenga, Chattogram

Zone Area

209.04 acres

Industrial Plots

258 Nos

Investment

US$ 782.37 million

Export

US$ 13,879.45 million

Employment

77,137 nos.

Products

Ready Made Garments (RMG), Garment Accessories, Tent and Camping Items, Leather Products & Bag, Furniture, Bicycle & Bicycle Accessories, Shoes etc.

Investing Countries

China (including Hong Kong and Taiwan), UK, The Netherlands, Malaysia, South Korea, Japan, USA, Sri Lanka, India, Canada and Bangladesh