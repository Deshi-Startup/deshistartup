---
source: "BEPZA"
tier: 1
category: "Export zone"
url: "https://bepza.gov.bd/pages/ishwardi-epz"
title: "BEPZA"
scraped_at: "2026-07-02"
---

# Ishwardi EPZ

-   [Home](https://bepza.gov.bd)
-   Ishwardi EPZ

![ienet](https://bepza.gov.bd/public/storage/upload/content/250902015532-6596iswardi.jpg)

**Ishwardi EPZ – Eco-Friendly Industrial Pioneer**

Established in 2001 in Pabna, Ishwardi EPZ is strategically positioned with excellent road and rail links to major cities and ports, making it a gateway for investors targeting northern and western Bangladesh.

The zone gained global recognition when Vintage Denim Studio became Bangladesh’s first LEED Platinum Certified Green Factory in 2012. Today, Ishwardi EPZ hosts over US$ 2.28 billion worth of exports, including garments, tents, wigs, gloves, batteries, and plastics. With approximately 21,000 skilled employees, advanced customs and security facilities, and strong eco-friendly initiatives, it offers a secure, sustainable, and investor-friendly environment.

Established

2001

Location

Paksey, Pabna

Zone Area

308.97 acres

Industrial Plots

324 Nos

Investment

US$ 285.61 million

Export

US$ 2,282.93 million

Employment

20,904 nos.

Products

Ready Made Garments (RMG), Garment Accessories, Tent and Camping Items, Wigs, Globatt Battery, Industrial Gloves, Cap, Plastic Products, Sweater, Denim Pant & Jacket, Cigar & Cigarette, High-end Garments, Bullet Proof Jacket, Suit, Lenses, Chemical, Automobile Parts, Cap, Shoes, Textile, Ready-made Garments, Garments Accessories, Yarn, Plastic & Rubber Products.

Investing Countries

China (including Hong Kong), Japan, India, Canada, Marshal Island and Bangladesh