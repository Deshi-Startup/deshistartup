---
source: "BEPZA"
tier: 1
category: "Export zone"
url: "https://bepza.gov.bd/pages/uttara-epz"
title: "BEPZA"
scraped_at: "2026-07-02"
---

# Uttara EPZ

-   [Home](https://bepza.gov.bd)
-   Uttara EPZ

![ienet](https://bepza.gov.bd/public/storage/upload/content/250902020104-6842uttara.jpg)

**Uttara EPZ – Expanding Horizons in Northern Bangladesh**

Established in 2001, Uttara EPZ is the first export-oriented industrial hub in northern Bangladesh, located in Nilphamari. It offers investors unique advantages with comparatively low land and factory rental costs, efficient road and air connectivity, and an easily trainable workforce. The zone has transformed a once agriculture-dependent region into a thriving industrial base.

Uttara EPZ is distinguished by the remarkable diversity of its products, ranging from wigs, optical frames, and toys to high-end garments, and fashion accessories. Spread over 214 acres with 190 plots, the zone has already attracted significant investment, generating exports worth more than US$ 3.22 billion and employing 35,348 workers. By combining cost efficiency with product diversity, Uttara EPZ continues to emerge as a highly competitive and attractive destination for global investors.

Established

2001

Location

Shangalshi, Nilphamari

Zone Area

213.66 acres

Industrial Plots

190 Nos

Investment

US$ 288.33 million

Export

US$ 3,224.69 million

Employment

35,348 nos.

Products

Wig, Bamboo made coffin, Optical frame, Toys and Collectible Items, Fashion Bag, Paper Products and Printed Materials, High-end Garments, Bullet Proof Jacket, Suit, Lenses, Chemical, Automobile Parts, Cap, Shoes, Textile, Ready-made Garments, Garments Accessories, Yarn, Plastic & Rubber Products.

Investing Countries

China (including Hong Kong), UK and Bangladesh