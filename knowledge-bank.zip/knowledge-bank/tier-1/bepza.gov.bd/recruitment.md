---
source: "BEPZA"
tier: 1
category: "Export zone"
url: "https://bepza.gov.bd/recruitment"
title: "BEPZA"
scraped_at: "2026-07-02"
---

# List of Recruitment Notices

-   [Home](https://bepza.gov.bd)
-   List of Recruitment Notices

## Bangladesh Export Processing Zones Authority

Title

Start Date

End Date

Action

03.06.2616.307.11.002.25-1518 - Selected for the post of  12 Catagories " Sub-station Attendant, Storekeeper, Office Assistant-cum-Computer Operator, Draftsman, Surveyor, Pump Operator, Driver, Dispatch Rider, Plumber's Assistant, Gardener, Service Boy, and Electric Helper".

Jun 25, 2026

Dec 24, 2026

[View](https://bepza.gov.bd/public/storage/upload/recruitment/260628062959-38781518.pdf)

03.06.2616.307.11.002.25-1486 - Title: Appointment letter for the post of "Assistant Engineer (Electrical)" from waiting list

Jun 22, 2026

Jun 21, 2027

[View](https://bepza.gov.bd/public/storage/upload/recruitment/260623061106-83451-merged.pdf)

03.06.2616.307.11.002.25-1399 - Practical & Medical Test Result for the post of Driver, Practical Test Result for the post of Dispatch Rider and Viva schedule

Jun 07, 2026

Jun 08, 2027

[View](https://bepza.gov.bd/public/storage/upload/recruitment/260608060234-545550.pdf)

03.06.2616.307.11.002.25-1372 - Appointment letter for the post of "Assistant Engineer (Electrical)"

Jun 04, 2026

Jun 05, 2027

[View](<https://bepza.gov.bd/public/storage/upload/recruitment/260604061004-1857Appointment letter for the post of Assistant Engineer \(Electrical\)2.pdf>)

03.06.2616.307.11.002.25.1371 - Appointment letter for the post of "Assistant Engineer (Civil)"

Jun 04, 2026

Jun 05, 2027

[View](<https://bepza.gov.bd/public/storage/upload/recruitment/260604061728-2436Appointment letter for the post of Assistant Engineer \(Civil\)1.pdf>)

03.06.2616.307.11.002.25.1375 - Appointment letter for the post of ”Sub Assistant Engineer (Civil)"

Jun 04, 2026

Jun 05, 2027

[View](<https://bepza.gov.bd/public/storage/upload/recruitment/260604081454-2392Appointment letter for the post of Sub-Assistant Engineer \(Civil\)6.pdf>)

03.06.2616.307.11.002.25.1376 - Appointment letter for the post of ”Sub Assistant Engineer (Transport)"

Jun 04, 2026

Jun 05, 2027

[View](<https://bepza.gov.bd/public/storage/upload/recruitment/260604081348-6617Appointment letter for the post of Sub-Assistant Engineer \(Transport\)4.pdf>)

03.06.2616.307.11.002.25.1374 - Appointment Letter for the post of "Assistant Computer Programmer"

Jun 04, 2026

Jun 05, 2027

[View](<https://bepza.gov.bd/public/storage/upload/recruitment/260604081840-7374Appointment letter for the post of Assistant Computer Programmer3.pdf>)

03.06.2616.307.11.002.25.1373 - Appointment Letter for the post of " Assistent Engineer (Mechanical)"

Jun 04, 2026

Jun 05, 2027

[View](<https://bepza.gov.bd/public/storage/upload/recruitment/260604082229-7216Appointment letter for the post of Assistant Engineer \(Mechanical\)5.pdf>)

03.06.2616.307.11.002.25-1365 - Results of practical examination for the post of Office Assistant-cum-Computer Operator in the Revenue Department of BEPZA.

Jun 03, 2026

Dec 04, 2026

[View](https://bepza.gov.bd/public/storage/upload/recruitment/260603084921-13501365.pdf)

03.06.2616.307.11.002.25.1353 - Final Result for the post of Assistant Engineer (Civil), Assistant Engineer (Electrical), Assistant Engineer (Mechanical), Assistant Computer Programmer, Sub Assistant Engineer(Civil) and Sub Assistant Engineer (Transport)

Jun 01, 2026

May 31, 2027

[View](<https://bepza.gov.bd/public/storage/upload/recruitment/260601091615-5937Final Result for the post of AE \(C\), AE \(E\), AE \(M\), Assistant Computer Programmer, SAE \(C\), SAE \(T\).pdf>)

03.06.2616.307.11.002.25.1312 - Result of Written Exam of 6 Category Posts held on 18 April 2026 & Viva Schedule

May 23, 2026

Jul 15, 2026

[View](<https://bepza.gov.bd/public/storage/upload/recruitment/260524062534-6555Result of Written Exam of 6 Category Posts held on 18 April 2026 & Viva Schedule.pdf>)

03.06.2616.307.11.002.25.1308 - Result of Written Exam of 6 Category Posts held on 17 April 2026 & Viva Schedule

May 21, 2026

May 20, 2027

[View](<https://bepza.gov.bd/public/storage/upload/recruitment/260521121042-5584Result of Written Exam of 6 Category Posts held on 17 April 2026 & Viva Schedule.pdf>)

03.06.2616.307.11.002.25-1185 - Written Exam Result and Viva Schedule for 6 Category posts of BEPZA

May 04, 2026

May 03, 2027

[View](<https://bepza.gov.bd/public/storage/upload/recruitment/260505044023-7402Officers Written Result and Viva Schedule.pdf>)

## Patuakhali Export Processing Zone

Title

Start Date

End Date

Action

03.06.7895.332.11.003.23-173 - Schedule of Viva Examinations for the recruitment of personnel on an outsourcing basis at Patuakhali EPZ.

Jun 28, 2026

Jul 09, 2026

[View](https://bepza.gov.bd/public/storage/upload/recruitment/260629044000-4515173.pdf)