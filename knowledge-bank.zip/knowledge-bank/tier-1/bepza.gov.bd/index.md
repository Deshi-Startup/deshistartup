---
source: "BEPZA"
tier: 1
category: "Export zone"
url: "https://bepza.gov.bd/"
title: "BEPZA"
scraped_at: "2026-07-02"
---

## WELCOME TO BEPZA YOUR TRUSTED GATEWAY TO INVEST IN BANGLADESH

[Watch Full Video](https://www.youtube.com/watch?v=0x-9e_t25ZU)

![SMART ZONES, SECURE INVESTMENT, SUSTAINABLE FUTURE](https://bepza.gov.bd/public/storage/upload/slider/251218062620-6233.jpeg)

## SMART ZONES, SECURE INVESTMENT, SUSTAINABLE FUTURE

![GROWING TOGETHER WITH GLOBAL STANDARDS](https://bepza.gov.bd/public/storage/upload/slider/251218070216-9866.jpeg)

## GROWING TOGETHER WITH GLOBAL STANDARDS

![ONE PLATFORM FOR SEAMLESS INVESTMENT](https://bepza.gov.bd/public/storage/upload/slider/250911105158-5111.jpeg)

## ONE PLATFORM FOR SEAMLESS INVESTMENT

### WHO WE ARE

BEPZA – the pioneer investment promotion agency of Bangladesh, established in 1980. We drive industrialization, attract investment, boost exports, create employment opportunities, and connect Bangladesh with global markets through 8 Export Processing Zones and a modern Economic Zone.

[More on who we are](https://bepza.gov.bd/pages/who-we-are)

![Who we are](https://bepza.gov.bd/public/storage/upload/content/250902034149-5823250902012008-6296why_bepza.jpg)

### WHY BEPZA

-   Strategic Location
-   Agile Workforce
-   Incentives and Facilities
-   Investment Guarantee  
-   One Window Same Day Services
-   Competitive Rent & Tariff
-   Competitive Labour Wage

[More on why investors choose BEPZA](https://bepza.gov.bd/why-bepza)

![about-img](https://bepza.gov.bd/public/storage/upload/content/250902035337-7529who-we-are.jpg)

### HOW TO INVEST

Investing in BEPZA is simple and straightforward. Just follow a few easy steps to set up your business, begin smooth production, and reach global markets with confidence - watch the animated video for a complete step-by-step guide.

[More on how to invest](https://bepza.gov.bd/pages/invest-bepza)

![about-img](https://bepza.gov.bd/build/theme/images/invest.png)[](https://www.youtube.com/watch?v=RjWHDEUiDFk)

![counter-icon](https://bepza.gov.bd/build/theme/images/counter-icon-1.png)

Industries

![counter-icon](https://bepza.gov.bd/build/theme/images/counter-icon-3.png)

#### US$Billion+

Investment

![counter-icon](https://bepza.gov.bd/build/theme/images/counter-icon-4.png)

Employment

![counter-icon](https://bepza.gov.bd/build/theme/images/counter-icon-5.png)

#### US$B+

Exports

#### EPZs & EZ of BEPZA

![epz-slider](<https://bepza.gov.bd/public/storage/upload/epz_bangladesh/250828111027-8061Adamjee EPZ-2 \(1\) \(1\).jpg>)

#### Adamjee EPZ

-   Location:Siddhirganj, Narayanganj.
-   Zone Area:292.62 acres
-   Industrial Plots:276 Nos

![epz-slider](https://bepza.gov.bd/public/storage/upload/epz_bangladesh/250819070926-3643CumEPZ_600x400.jpg)

#### Cumilla EPZ

-   Location:Old Airport Area, Cumilla
-   Zone Area:267.46 acres
-   Industrial Plots:244

![epz-slider](<https://bepza.gov.bd/public/storage/upload/epz_bangladesh/250819070937-2492CEPZ \(1\).jpg>)

#### Chattogram EPZ

-   Location:South Halishahar, Chattogram
-   Zone Area:453 acres
-   Industrial Plots:501

![epz-slider](<https://bepza.gov.bd/public/storage/upload/epz_bangladesh/250819070912-4272DEPZ \(2\).jpg>)

#### Dhaka EPZ

-   Location:Savar, Dhaka
-   Zone Area:356.22 acres
-   Industrial Plots:451

![epz-slider](https://bepza.gov.bd/public/storage/upload/epz_bangladesh/250819070840-1727IEPZ_600x400.jpg)

#### Ishwardi EPZ

-   Location:Pakshi, Pabna
-   Zone Area:308.97 acres
-   Industrial Plots:324

![epz-slider](https://bepza.gov.bd/public/storage/upload/epz_bangladesh/250819070826-2090KEPZ_600x400.jpg)

#### Karnaphuli EPZ

-   Location:North Patenga, Chattogram
-   Zone Area:209.06 acres
-   Industrial Plots:258 Nos

![epz-slider](https://bepza.gov.bd/public/storage/upload/epz_bangladesh/250819070816-2210MEPZ_600x400.jpg)

#### Mongla EPZ

-   Location:Mongla Port Area, Bagerhat
-   Zone Area:302.97 acres
-   Industrial Plots:278

![epz-slider](https://bepza.gov.bd/public/storage/upload/epz_bangladesh/250819070702-9776UEPZ_600x400.jpg)

#### Uttara EPZ

-   Location:Shangalshi, Nilphamari
-   Zone Area:213.66 acres
-   Industrial Plots:190

![epz-slider](https://bepza.gov.bd/public/storage/upload/epz_bangladesh/patuakhaliepz-gate.jpg)

#### Patuakhali EPZ

-   Location:
-   Zone Area:410.78 acres
-   Industrial Plots:

![epz-slider](<https://bepza.gov.bd/public/storage/upload/epz_bangladesh/250910122934-8957250907072214-7701250827090722-7576JEPZ \(1\).png>)

#### Jashore EPZ

-   Location:
-   Zone Area:
-   Industrial Plots:

![epz-slider](<https://bepza.gov.bd/public/storage/upload/epz_bangladesh/250819070957-7519EZ_600x400 \(1\).jpg>)

#### BEPZA EZ

-   Location:Mirsharai, Chattogram
-   Zone Area:1138.55 Acres
-   Industrial Plots:539 Nos

#### Uttara EPZ

-   **Location:**Shongalshi, Nilphamari
-   **Zone Area:**213.66 acres
-   **Industrial Plots:**190 Nos

#### Ishwardi EPZ

-   **Location:**Pakshi, Pabna
-   **Zone Area:**308.97 acres
-   **Industrial Plots:**324 Nos

#### Dhaka EPZ

-   **Location:**Savar, Dhaka
-   **Zone Area:**356.22 acres
-   **Industrial Plots:**451 Nos

#### Adamjee EPZ

-   **Location:**Siddirganj, Narayanganj
-   **Zone Area:**292.62 acres
-   **Industrial Plots:**276 Nos

#### Jashore EPZ

-   **Location:**Abhaynagar, Jashore
-   **Zone Area:**503 acres
-   **Industrial Plots:**400

#### Mongla EPZ

-   **Location:**Mongla Port Area, Bagerhat
-   **Zone Area:**302.97 acres
-   **Industrial Plots:**278 Nos

#### Cumilla EPZ

-   **Location:**Old Airport Area, Cumilla
-   **Zone Area:**267.46 acres
-   **Industrial Plots:**244 Nos

#### BEPZA EZ

-   **Location:**Mirsharai, Chattogram
-   **Zone Area:**1138.55 acres
-   **Industrial Plots:**539 Nos

#### Chattogram EPZ

-   **Location:**South Halishahar, Chattogram
-   **Zone Area:**453 acres
-   **Industrial Plots:**501 Nos

#### Karnaphuli EPZ

-   **Location:**North Patenga, Chattogram
-   **Zone Area:**209.04 acres
-   **Industrial Plots:**258 Nos

#### Patuakhali EPZ

-   **Location:**Patuakhali Sadar, Patuakhali
-   **Zone Area:**410.78 acres
-   **Industrial Plots:**306

#### Our Investors

![epz-slider](https://bepza.gov.bd/build/theme/images/Youngone.jpg)

#### YOUNGONE (CEPZ) LTD.

Type of Investment

Garments

-   Country: S. Korea
-   Total invested: : $129.91 million
-   Total Employment: 15,212
-   Location: Chattogram EPZ

![epz-slider](https://bepza.gov.bd/build/theme/images/YKK.jpg)

#### YKK BANGLADESH PTE LTD.

Type of Investment

Garment Accessories

-   Country: Japan
-   Total invested: : $280.80 million
-   Total Employment: 1,987
-   Location: Dhaka EPZ

![epz-slider](https://bepza.gov.bd/build/theme/images/Vintage.jpg)

#### VINTAGE DENIM STUDIO LIMITED

Type of Investment

Garments

-   Country: Bangladesh
-   Total invested: : $49.44 million
-   Total Employment: 4,592
-   Location: Ishwardi EPZ

![epz-slider](https://bepza.gov.bd/build/theme/images/Sonic.jpg)

#### SONIC (BANGLADESH) LTD.

Type of Investment

Toys

-   Country: China
-   Total invested: : $67.10 million
-   Total Employment: 4,226
-   Location: Uttara EPZ

![epz-slider](https://bepza.gov.bd/build/theme/images/Ventura.jpg)

#### VENTURA LEATHERWARE MFY (BD) LTD.

Type of Investment

Hand Bag

-   Country: China
-   Total invested: : $40.87 million
-   Total Employment: 6,205
-   Location: Uttara EPZ

#### Support Services

![s-service](https://bepza.gov.bd/build/theme/images/s-service-1.png)

#### Online Automation

![s-service](https://bepza.gov.bd/build/theme/images/s-service-2.png)

#### 24/7 Security

![s-service](https://bepza.gov.bd/build/theme/images/s-service-3.png)

#### Fire Safety

![s-service](https://bepza.gov.bd/build/theme/images/s-service-4.png)

#### Environmental Lab

![s-service](https://bepza.gov.bd/build/theme/images/s-service-5.png)

#### CETP/WTP

![s-service](<https://bepza.gov.bd/build/theme/images/utility_4215723 \(1\).png>)

#### Utility

#### Explore Our Products

[![portfolio](<https://bepza.gov.bd/public/storage/upload/product/250831063752-7478Wedding Gown.jpg>)

##### Wedding Gown





](#)

[![portfolio](https://bepza.gov.bd/public/storage/upload/product/250831063805-3897Wig.jpg)

##### Wig





](#)

[![portfolio](<https://bepza.gov.bd/public/storage/upload/product/250831063833-2284Work wear.jpg>)

##### Work wear





](#)

[![portfolio](https://bepza.gov.bd/public/storage/upload/product/250831063903-2572Yarn.jpg)

##### Yarn





](#)

[![portfolio](https://bepza.gov.bd/public/storage/upload/product/250831063405-2916Tent.jpg)

##### Tent





](#)

[![portfolio](https://bepza.gov.bd/public/storage/upload/product/250831063639-2459Textile.jpg)

##### Textile





](#)

[![portfolio](<https://bepza.gov.bd/public/storage/upload/product/250831063738-3022Vending Machine Push Button.jpg>)

##### Vending Machine Push Button





](#)

[![portfolio](<https://bepza.gov.bd/public/storage/upload/product/250831063307-1894Safety Jacket.jpg>)

##### Safety Jacket





](#)

[![portfolio](https://bepza.gov.bd/public/storage/upload/product/250831063320-7039Shoe.jpg)

##### Shoe





](#)

[![portfolio](<https://bepza.gov.bd/public/storage/upload/product/250831063332-1342Small Indicator Lamp.jpg>)

##### Small Indicator Lamp





](#)

[![portfolio](https://bepza.gov.bd/public/storage/upload/product/250831063350-2287Suit.jpg)

##### Suit





](#)

[![portfolio](https://bepza.gov.bd/public/storage/upload/product/250831063200-4620Medal.jpg)

##### Medal





](#)

[![portfolio](<https://bepza.gov.bd/public/storage/upload/product/250831063212-9538Miniature Toy.JPG>)

##### Miniature Toy





](#)

[![portfolio](<https://bepza.gov.bd/public/storage/upload/product/250831063226-6754Optical Frame & Sunglass.jpg>)

##### Optical Frame & Sunglass





](#)

[![portfolio](<https://bepza.gov.bd/public/storage/upload/product/250831063254-4004Replica Toy.JPG>)

##### Replica Toy





](#)

[![portfolio](<https://bepza.gov.bd/public/storage/upload/product/250831062521-9121Kitchen Utensis.jpg>)

##### Kitchen Utensils





](#)

[![portfolio](<https://bepza.gov.bd/public/storage/upload/product/250831062932-4900Ladies Fashion Bag.jpg>)

##### Ladies Fashion Bag





](#)

[![portfolio](https://bepza.gov.bd/public/storage/upload/product/250831062950-3113Luggage.jpg)

##### Luggage





](#)

[![portfolio](<https://bepza.gov.bd/public/storage/upload/product/250831063020-4546Makeup Item.JPG>)

##### Makeup Item





](#)

[![portfolio](https://bepza.gov.bd/public/storage/upload/product/250831062414-5449Denim.jpg)

##### Denim





](#)

[![portfolio](https://bepza.gov.bd/public/storage/upload/product/250831062425-2983Furniture.jpg)

##### Furniture





](#)

[![portfolio](<https://bepza.gov.bd/public/storage/upload/product/250831062437-4441Golf Shaft.jpg>)

##### Golf Shaft





](#)

[![portfolio](<https://bepza.gov.bd/public/storage/upload/product/250831062449-4600Industrial Gloves.jpg>)

##### Industrial Gloves





](#)

[![portfolio](https://bepza.gov.bd/public/storage/upload/product/250831062509-8271Jacket.jpg)

##### Jacket





](#)

[![portfolio](https://bepza.gov.bd/public/storage/upload/product/250831062301-8175Battery.jpg)

##### Battery





](#)

[![portfolio](https://bepza.gov.bd/public/storage/upload/product/250831062333-8230Bicycle.jpg)

##### Bicycle





](#)

[![portfolio](<https://bepza.gov.bd/public/storage/upload/product/250831062350-8798Bio-degradable Coffin.jpg>)

##### Bio-degradable Coffin





](#)

[![portfolio](https://bepza.gov.bd/public/storage/upload/product/250831062404-7970Cap.jpg)

##### Cap





](#)

[![portfolio](<https://bepza.gov.bd/public/storage/upload/product/250831062239-6134Archery Arrow.jpg>)

##### Archery Arrow





](#)

#### ESG & Compliances

[

![Day Care Center](https://bepza.gov.bd/public/storage/upload/content/250820034515-71469917f2d7-e2e1-47c7-8cac-8ce73106633f-ezgif.com-resize.jpg)

#### Day Care Center





](https://bepza.gov.bd/esg-compliances#day-care-center)

[

![Canteen](https://bepza.gov.bd/public/storage/upload/content/250902064028-7656canteen.jpg)

#### Canteen





](https://bepza.gov.bd/esg-compliances#canteen)

[

![Medical Facilities](https://bepza.gov.bd/public/storage/upload/content/250820034949-265439d360e7-ce47-44bc-b35b-871f364d4b2f-ezgif.com-resize.jpg)

#### Medical Facilities





](https://bepza.gov.bd/esg-compliances#medical-facilities)

[

![Educational Facilities](https://bepza.gov.bd/public/storage/upload/content/250831010358-1287education.jpg)

#### Educational Facilities





](https://bepza.gov.bd/esg-compliances#education)

[

![ESG Commitment](<https://bepza.gov.bd/public/storage/upload/content/250902021525-7352ESG \(2\) \(1\) \(1\).jpg>)

#### ESG Commitment





](https://bepza.gov.bd/esg-compliances#esg)

#### Spotlight

[

![Deltaport Footwear to invest US$ 21.60 million in footwear manufacturing plant](https://bepza.gov.bd/public/storage/upload/activity/260701020435-2523DSC00511.JPG\(1\).jpg)

#### Deltaport Footwear to invest US$ 21.60 million in footwear manufacturing plant



](https://bepza.gov.bd/spotlight/another-foreign-investment-in-bepza-economic-zone-deltaport-footwear-to-invest-us-2160-million-in-footwear-manufacturing-plant)

[

![New Milestone in Ensuring Social Protection for EPZ Workers BEPZA-ILO Reaffirm Joint Commitment to Establish a Permanent Employment Injury Scheme (EIS)](https://bepza.gov.bd/public/storage/upload/activity/260625074805-3971EPZ1080.jpg)

#### New Milestone in Ensuring Social Protection for EPZ Workers BEPZA-ILO Reaffirm Joint Commitment to Establish a Permanent Employment Injury Scheme (EIS)



](https://bepza.gov.bd/spotlight/new-milestone-in-ensuring-social-protection-for-epz-workers-bepza-ilo-reaffirm-joint-commitment-to-establish-a-permanent-employment-injury-scheme-eis)

[

![Yeijer Shoe Parts to produce footwear and footwear accessories in Cumilla EPZ](https://bepza.gov.bd/public/storage/upload/activity/260521100842-98331_Signing.jpg)

#### Yeijer Shoe Parts to produce footwear and footwear accessories in Cumilla EPZ



](https://bepza.gov.bd/spotlight/yeijer-shoe-parts-to-produce-footwear-and-footwear-accessories-in-cumilla-epz)

[

![BEPZA secures US$ 15 million investment to establish tent & camping factory at BEPZA EZ](https://bepza.gov.bd/public/storage/upload/activity/260521073123-9097faiaz.JPG.jpeg)

#### BEPZA secures US$ 15 million investment to establish tent & camping factory at BEPZA EZ



](https://bepza.gov.bd/spotlight/bepza-secures-us-15-million-investment-to-establish-tent-camping-factory-at-bepza-ez)

[

![BEPZA signs US$ 24.03 million investment deal with South Korean company](https://bepza.gov.bd/public/storage/upload/activity/260406112341-5569EPZ_3243.jpg.jpeg)

#### BEPZA signs US$ 24.03 million investment deal with South Korean company



](https://bepza.gov.bd/spotlight/bepza-signs-us-2403-million-investment-deal-with-south-korean-company)

[

![BEPZA secures US$ 15.34 million investment to establish high-end apparel factory at BEPZA EZ](<https://bepza.gov.bd/public/storage/upload/activity/260308101356-16621.JPG \(1\).jpeg>)

#### BEPZA secures US$ 15.34 million investment to establish high-end apparel factory at BEPZA EZ



](https://bepza.gov.bd/spotlight/bepza-secures-us-1534-million-investment-to-establish-high-end-apparel-factory-at-bepza-ez)

[

![Chinese company to establish fashion & beauty products manufacturing plant at BEPZA Economic Zone](https://bepza.gov.bd/public/storage/upload/activity/260304101932-9501_EPZ2656.jpg.jpeg)

#### Chinese company to establish fashion & beauty products manufacturing plant at BEPZA Economic Zone



](https://bepza.gov.bd/spotlight/chinese-company-to-establish-fashion-beauty-products-manufacturing-plant-at-bepza-economic-zone)

#### Testimonials

“I think Bangladesh is still a great place for labor-intensive industries. Workers here don't take the time to become skilled. For entrepreneurs who believe in long-term planning, Bangladesh can be a great investment destination.”

![client](https://bepza.gov.bd/build/theme/images/alena.jpg)

#### Kazantseva Alena

Deputy Managing Director Super Protective Socks (Pvt.) Ltd. Adamjee EPZ

“The business environment in Bangladesh, especially in the EPZs, is very good. I have personally encouraged my business friends to invest in Bangladesh. ”

![client](https://bepza.gov.bd/build/theme/images/ushida.jpeg)

#### Shuhei Ushida

Managing Director Ishwardi Matsuka Bangladesh Limited Ishwardi EPZ

# \*\*\*\*\*

![client](https://bepza.gov.bd/build/theme/images/dummy.jpg)

#### Malik Ma

COO Ventura Leatherware mfy (BD) Ltd.

“We found investment in Bangladesh is very correct and the investment in BEPZA is even more correct. Because as a foreigner when we all come here that is unknown to us BEPZA officials actually helped us a lot.”

![client](https://bepza.gov.bd/build/theme/images/client-1.png)

#### Felix Y.C. Chang

Managing Director Evergreen Products Factory (BD) Ltd

![client](https://bepza.gov.bd/build/theme/images/alena.jpg)

#### Kazantseva Alena

Deputy Managing Director Super Protective Socks (Pvt.) Ltd. Adamjee EPZ

![client](https://bepza.gov.bd/build/theme/images/ushida.jpeg)

#### Shuhei Ushida

Ishwardi Matsuka Bangladesh Limited Ishwardi EPZ

![client](https://bepza.gov.bd/build/theme/images/dummy.jpg)

#### Malik Ma

COO Ventura Leatherware mfy (BD) Ltd.

![client](https://bepza.gov.bd/build/theme/images/client-1.png)

#### Felix Y.C. Chang

Managing Director Evergreen Products Factory (BD) Ltd