---
source: "BEPZA"
tier: 1
category: "Export zone"
url: "https://bepza.gov.bd/citizen-charter"
title: "BEPZA"
scraped_at: "2026-07-02"
---

# Citizen's Charter

-   [Home](https://bepza.gov.bd)
-   How We Help
-   Citizen's Charter

## Citizen Charter

Title

Action

Citizen Charter of BEPZA Executive Office

[View](<https://bepza.gov.bd/public/storage/upload/content-file/250831054919-7989Citizen Chartered Display \(1\).pdf>)

Citizen Charter of AEPZ

[View](https://bepza.gov.bd/public/storage/upload/content-file/210301115741-446CCAEPZ.pdf)

Citizen Charter of CEPZ

[View](https://bepza.gov.bd/public/storage/upload/content-file/210301115840-811CCCEPZ.pdf)

Citizen Charter of Comilla EPZ

[View](https://bepza.gov.bd/public/storage/upload/content-file/210301115918-844CCofComillaEPZ.pdf)

Citizen Charter of DEPZ

[View](https://bepza.gov.bd/public/storage/upload/content-file/210301120003-344CCofDEPZ.pdf)

Citizen Charter of IEPZ

[View](https://bepza.gov.bd/public/storage/upload/content-file/210301120041-827CCofDEPZ.pdf)

Citizen Charter of KEPZ

[View](https://bepza.gov.bd/public/storage/upload/content-file/210301120108-526CCofKEPZ.pdf)

Citizen Charter of MEPZ

[View](https://bepza.gov.bd/public/storage/upload/content-file/210301120137-433CCofMEPZ.pdf)

Citizen Charter of UEPZ

[View](https://bepza.gov.bd/public/storage/upload/content-file/210301120159-598CCofUEPZ.pdf)