---
source: "BEPZA"
tier: 1
category: "Export zone"
url: "https://bepza.gov.bd/why-bepza"
title: "BEPZA"
scraped_at: "2026-07-02"
---

# Why BEPZA

-   [Home](https://bepza.gov.bd)
-   Invest in BEPZA
-   Why BEPZA

## Strategic Location

The comparative advantages of the EPZs in Bangladesh are it’s homogenously, large number of potential human resources, competitive wage level, and its ‘geo-regional location’. Bangladesh is situated in close proximity to the Bay of Bengal, which has given the country with an easy access to the world through sea-way and also by air in terms of import and export. As a result, the foreign investors are always keen to take those strategic advantages. Moreover, most of the EPZs and EZ under BEPZA are located in the strategic location in connection with all the Sea, Air and Land Port of Bangladesh.

## Agile Workforce

The main attraction of investment in Bangladesh is the most inexpensive, productive, abundant and easily trainable workforce. Today Bangladesh has a growing number of managers, engineers, technicians and skilled labour force. The minimum wage of the workers in the EPZs is the lowest in Asia. Changing economic and political conditions in the Asian region are prompting many international investors to reassess their investment strategies and plan for relocating their investments in Bangladesh. Those changes are producing higher opportunities for Bangladesh to attract higher levels of FDI. Most of the countries of the world are experiencing wages increase and rising production costs that are making them less attractive as low cost production base resulting the EPZs of Bangladesh have become a new field and place for foreign investment.  
 

## Mode of Investment

BEPZA pursues an open door policy in regards to foreign or local investment in its EPZs. It attracts investment in three categories, i.e:- 

-   Type - A - Investment with 100% foreign ownership,  
-   Type-B- Joint venture between Bangladeshi and foreign investors with no limit to the extent of equity share,
-   Type-C -100% Bangladeshi ownership.  

## Incentives and Facilities

**The fiscal incentives for Investors of BEPZA include:**

1.    Tax Holiday Facilities for 5 to 10 years  
2.    Duty free import of machinery, equipment & construction materials   
3.    Duty free import of raw materials  
4.    Duty free export of finished goods  
5.    Relief from double taxation  
6.    Exemption from dividend tax for tax holiday period  
7.    Duty free import of two/three duty free vehicles for A & B type industries subject to certain conditions (For the projects approved before March 22, 2009)  
8.    Full repatriation of profit, capital & establishment

**The non-fiscal incentives include:**

1.    100% foreign ownership permissible.  
2.    Enjoy MFN status   
3.    Enjoy GSP benefits in EU countries, Japan, Australia, USA, Canada, Norway etc.  
4.    No ceiling on foreign investment  
5.    Foreign currency loan from abroad under direct automatic route (OBU facilities)  
6.    Non-resident Foreign Currency Deposit (NFCD) allowed for ‘A’ type industries    
7.    Operation of FC account by ‘B’ and ‘C’ type industries allowed  
8.    Residentship / Citizenship granted for foreign investors  
9.    100% backward linkage raw materials, accessories are allowed to sell to export oriented industries inside and outside EPZs   
10.    Taking and offering subcontracting are allowed both inside and outside EPZ  
11.    10% sale of finished products except garments  
12.    10% sale of defective finished goods  
13.    10% sale of surplus raw materials  
 

## Investment Guarantee

Foreign investors are afforded multiple levels of protection in BEPZA. The Foreign Private Investment (Promotion and Protection) Act, 1980 secures all foreign investment in Bangladesh. As a member of OPIC’s (Overseas Private Investment Corporation, USA) insurance and finance programs operable in Bangladesh as well as in the EPZs.  Bangladesh is a member of Multilateral Investment Guarantee Agency (MIGA) which provides safeguards and security under international law. The International Centre for the Settlement of Investment Dispute (ICSID) also provides an additional means of remedy, whilst copyright interests are protected through World Intellectual Property Organization (WIPO).

## Brand Products

![ienet](https://bepza.gov.bd/public/storage/upload/content/250818125427-73326536d40d-875b-45d6-8873-ab104aa14a0e.jpg)

## Infrastructure Facilities

BEPZA provides infrastructure facilities for the investors. It provides fully serviced plots and Standard Factory Building (SFB) for setting up manufacturing industry. Investor can use these plots under a 30 years lease which is renewable. Apart from these plots, an investor may also take lease of Standard Factory Building (SFB) owned by BEPZA on rental basis for 2 to 10 years which also renewable. All the utility connections such as Electricity, Water, Gas Internet & Telecommunication are readily connected in the enterprises of the EPZs.

## Support Service Facilities

BEPZA has allowed setting up of support service business facilities for the investors such as local and foreign banks, Off Shore Banking Units (OBU), insurance companies, C & F agents, freight forwarder and courier service in the EPZs. Other administrative facilities, such as Customs Office, Police Station, BEPZA’s Security, Fire Station, Public Transport, Medical centers etc. are available in the EPZs.

## One Window Same Day Services

BEPZA has been providing “One Window Service’’ to its investors. Foreign investors are required to deal only with BEPZA for sanctioning of the project and all other operational purposes. Starting from the approval of the projects, it provides allotment of land/factory building within the EPZs, issues Import and Export permits within the same day and Work permits to the foreign nationals and all other matters necessary for operation of industrial enterprise. BEPZA also provides same-day services to the investors in some cases through Automation. At present most of the crucial commercial functions such as issuing import permit, export permit, subcontract permission, local purchase permission etc. have been automated to expedite and make it easier for investors to conduct their daily functions smoothly.

## Competitive Rent & Tariff

Zone

Land (US$ / SQM / YEAR)

SFB (US$ / SQM / MONTH)

BEPZA Economic Zone

2.75

3.50

Chittagong, Dhaka, Comilla, Adamjee & Karnaphuli EPZ

2.50

3.00

Mongla, Ishwardi & Uttara EPZ

1.40

1.75

## Competitive Labour Wage

Minimum wage is the minimum amount of remuneration that an employer is required to pay wage earners for the work performed for a given period, as defined by ILO, which cannot be reduced by collective agreement or an individual contract. Continuous lower minimum wage in Bangladesh compared to other Asian countries suggests that Bangladesh aims to ensure a decent standard of living through minimum wage policies.

A comparison of minimum wages in the manufacturing sectors across several Asian countries is presented in the table below. Please note that depending on the region, sectors, and data updates wages can vary significantly within countries. Formal employment ensures higher extent of protection for workers, including adherence of minimum wage laws.

**Approximate Minimum Wages in Manufacturing Sectors in Asian Countries in 2025:**

Country

Minimum Salary Range (USD)

South Korea

1512

China

250-353

Vietnam

136-195

Cambodia

208

India

143-496

Pakistan

123-211

Sri Lanka

183

EPZs in Bangladesh

100