---
source: "BEPZA"
tier: 1
category: "Export zone"
url: "https://bepza.gov.bd/circular"
title: "BEPZA"
scraped_at: "2026-07-02"
---

# Circular / Office Order

-   [Home](https://bepza.gov.bd)
-   Notice
-   Circular / Office Order

## Bangladesh Export Processing Zones Authority

Office Order & Circular No

Title

Start Date

End Date

Action

03.06.2616.307.46.001.25-1241

Office Order “Rest and Recreation Allowance” for the following Officers, Staff and Security Guard the employees of BEPZA

May 14, 2026

Nov 15, 2026

[View](https://bepza.gov.bd/public/storage/upload/circular/260518061227-85551141.pdf)