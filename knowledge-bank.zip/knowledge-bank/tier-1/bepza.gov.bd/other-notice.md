---
source: "BEPZA"
tier: 1
category: "Export zone"
url: "https://bepza.gov.bd/other-notice"
title: "BEPZA"
scraped_at: "2026-07-02"
---

# Other Notices

-   [Home](https://bepza.gov.bd)
-   Notice
-   Other Notices

## Other Notices

Title

Action

Pakistan eager to work jointly with BEPZA: High Commissioner

Japanese investment EPZ"s

Japan keen to invest more in EPZs

BEPZA signed US$ 28 Million investment agreement for EPZs

BEPZA & Two Foreign CO. signs $12 Million investment deal in EPZ

গাইবান্ধার গোবিন্দগঞ্জে রংপুর ইপিজেডে ক্ষুদ্র নৃগোষ্ঠিসহ দুইলক্ষ লোকের কর্মসংস্থান হবে - BEPZA

South Korean Envoy lauds the activities of BEPZA

[View](https://bepza.gov.bd/public/storage/upload/product/211230103805-98811.jpg)

Mongla EPZ starts dormitory for female workers

[View](https://bepza.gov.bd/public/storage/upload/product/211230095503-9114EPZ_4424.JPG)

EPZ Minimum Wage Board recommends 9-10% annual increment for the workers

BEPZA@ 45 Years — A Journey of Commitment, Pride, and Excellence

বেপজার শ্রমিক কল্যান তহবিল (WWF) এর অধীন কাউন্সিলর কাম ইন্সপেক্টর (সোশ্যাল) এবং কাউন্সিলর কাম ইন্সপেক্টর (এনভায়রনমেন্ট) পদে লিখিত পরীক্ষার ফলাফল মৌখিক পরীক্ষার সময়সুচি।

[View](<https://bepza.gov.bd/public/storage/upload/product/260108042635-6279260108082101-7204Counsellor Cum Inspector \(Social\) and Counsellor Cum Inspector \(Environment\) Written Exam Result & Viva Schedule    64.pdf>)

বেপজার শ্রমিক কল্যান তহবিল (WWF) এর অধীন "কাউন্সিলর কাম ইন্সপেক্টর (সোশ্যাল)" পদের নিয়োগপত্র।

[View](<https://bepza.gov.bd/public/storage/upload/product/260124033837-2612Social Counsellor Appointment Letter.pdf>)

বেপজার শ্রমিক কল্যান তহবিল (WWF) এর অধীন "কাউন্সিলর কাম ইন্সপেক্টর (এনভায়রনমেন্ট)" পদের নিয়োগপত্র।

[View](<https://bepza.gov.bd/public/storage/upload/product/260124034034-2595Environment Counsellor Appointment Letter.pdf>)

03.06.2616.307.11.002.25.246 - Recruitment Notice BEPZA

[View](<https://bepza.gov.bd/public/storage/upload/product/260205115635-6246BEPZA Revenue Circular 2026.pdf>)