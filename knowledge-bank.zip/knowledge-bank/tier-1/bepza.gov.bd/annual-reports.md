---
source: "BEPZA"
tier: 1
category: "Export zone"
url: "https://bepza.gov.bd/annual-reports"
title: "BEPZA"
scraped_at: "2026-07-02"
---

# Annual Report

-   [Home](https://bepza.gov.bd)
-   Media & Publications
-   Publications
-   Annual Report

## Bangladesh Export Processing Zones Authority

#

Title

Action

1

Annual Report 2024-25

[View](<https://bepza.gov.bd/public/storage/upload/annual_report/260210081304-3667Annual Report 2024-25.pdf>)

2

Annual Report 2023-24

[View](<https://bepza.gov.bd/public/storage/upload/annual_report/241231055910-7951Annual Report 2023-24.pdf>)

3

Annual Report 2022-2023

[View](<https://bepza.gov.bd/public/storage/upload/annual_report/240821090842-8025Update_Annual Report-2022-23-2 \(1\)-compressed_compressed \(1\).pdf>)

4

Annual Report 2021-22

[View](<https://bepza.gov.bd/public/storage/upload/annual_report/230705080452-6248Annual Report-2021-22.pdf>)

5

Annual Report 2020-21

[View](<https://bepza.gov.bd/public/storage/upload/annual_report/220705031647-6766Annual Report-2020-21.pdf>)

6

Annual Report 2019-20

[View](<https://bepza.gov.bd/public/storage/upload/annual_report/211205090618-7773Annual Report 2019-2020.pdf>)