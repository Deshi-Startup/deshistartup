---
source: "BEPZA"
tier: 1
category: "Export zone"
url: "https://bepza.gov.bd/tender"
title: "BEPZA"
scraped_at: "2026-07-02"
---

# Tender / Auction Notices

-   [Home](https://bepza.gov.bd)
-   Notice
-   Tender / Auction Notices

## Bangladesh Export Processing Zones Authority

Tender No

Title

Start Date

End Date

Action

03.06.2616.324.99.64.2026-23

e-Tender Notice:23/2025-2026. (Repair pothole, carpeting and upgradation of road and footpath from custom gate to ED Bunglow in Chattogram EPZ). Tender Id No:(1303174)

Jun 23, 2026

Jul 23, 2026

[View](https://bepza.gov.bd/public/storage/upload/tender/260624043037-494260.pdf)

03.06.2616.324.99.64.2026-22

e-Tender Notice No:(22/2025-2026). Work-1 (Remaining Up-gradation & Widening of U-drain with RCC in place of the existing brick drain from plot # 91 to existing RCC canal at sector @ 01 of Karnaphuli EPZ, North patenga, Chattogram. Tender Id No:(1301404). Work-2 ( Repair of existing roads with dense bituminous carpeting from SP-06 to plot # 68, 60-63A & 64A-68, Sector # 03 of Karnaphuli, North patenga, Chattogram. Tender Id No:(1301576). Work-3 ( Improvement of footpath & road with dense bituminous carpeting from plot # 35-51, Sector # 03 at Karnaphuli EPZ, North patenga, Chattogram. Tender Id No:(1301568)

Jun 22, 2026

Jul 13, 2026

[View](https://bepza.gov.bd/public/storage/upload/tender/260623044441-709222.pdf)

03.06.2616.324.99.64.2026-21

Tender Notice:21/2025-2026). Work-1: (Up-gradation of peripheral road from plot # 77 to SFB-05, sector # 03 at Karnaphuli EPZ. North patenga, Chattogram.Tender Id No:(1292176) Work-2 :(up-gradation of existing main gate and custom gate at Karnaphuli EPZ, North patenga, chattogram).Tender Id No:(1292162) Work-3: (Repair and painting of A, B, C & D,-type residential building at karnaphuli, North patenga, chattogram.Tender Id No:(1292172) Work-4:(Construction of Dining cum Tin shed kitchen for B-Type Fire Station at BEPZA Economic Zone Mirsarai, Chattogram).Tender Id No:(1299951)

Jun 16, 2026

Jul 07, 2026

[View](https://bepza.gov.bd/public/storage/upload/tender/260618033352-979821.pdf)

03.06.2616.307.11.009.26-1411

Tender Notice (04/2025-2026) Work-1: (Selection of Security Consultant for BEPZA)Tender Id No;(1290876) Work-2:(Selection of Fire Consultant for BEPZA)Tender Id No:(1293842)

Jun 09, 2026

Jul 13, 2026

[View](https://bepza.gov.bd/public/storage/upload/tender/260609094057-7898100.pdf)

03.06.1535.327.07.931.26-503

e-Tender Notice: 24/2025-2026 (Supply, installation, testing and commissioning of 11 kV Gas Insulated Switchgear (GIS) for replacement of existing damaged 11 kV Air Insulated switchgear (AIS) in 33/11 kV substation at Chattogram EPZ) Tender Id No:(1284583)

Jun 01, 2026

Jul 07, 2026

[View](https://bepza.gov.bd/public/storage/upload/tender/260601084910-507012.pdf)

## Adamjee Export Processing Zone

Tender No

Title

Start Date

End Date

Action

03.06.6758.325.07.043.2025-912

Invitation for e-Tender Notice :06/2025-2026). (Installation of barbed wire fencing at the west sode of Non-Bengali residence pond area at Adamjee EPZ). Tender Id No:(1305650)

Jul 30, 2026

Jul 09, 2026

[View](https://bepza.gov.bd/public/storage/upload/tender/260701090804-9610912.pdf)

03.06.6758.327.07.200.26-121

Invitation for e-Tender Notice No:14/2025-2026 ( Construction of new 11 KV feeder line and renovation of existing 11 KV line at Adamjee EPZ) Tender Id No:(1300745)

Jun 21, 2026

Jul 14, 2026

[View](https://bepza.gov.bd/public/storage/upload/tender/260623043646-9193121.pdf)

03.06.6758.327.07.178.26-91

Invitation for e-Tender Notice No:13/2025-2026. Work-1:(Supply of sanitary equipments, pipe fittings and plumbing equipments throughout the year for Adamjee EPZ (Frame Work). Tender Id No:(1281119)

Jun 09, 2026

Jul 09, 2026

[View](https://bepza.gov.bd/public/storage/upload/tender/260618041457-126391.pdf)

## Chattogram Export Processing Zone

Tender No

Title

Start Date

End Date

Action

03.322.018.01.00.505.2015-1667

Auction Notice: Tenders are invited for the sale of old goods stored at the Chattogram EPZ warehouse.

Jun 24, 2026

Dec 29, 2026

[View](<https://bepza.gov.bd/public/storage/upload/tender/260629090831-1818CEPZ Store Goods.pdf>)

## Cumilla Export Processing Zone

Tender No

Title

Start Date

End Date

Action

03.06.1933.325.07.026.26.507

Invitation for e-Tender Notice :19/2025-2026). (Repair of road from plots # 137-141 at Cumilla EPZ). Tender Id No:(1303163)

Jun 22, 2026

Jul 12, 2026

[View](https://bepza.gov.bd/public/storage/upload/tender/260625090404-798821.pdf)

03.06.1933.325.07.023.26-486

e-Tender Notice No:18/2025-2026 (Renovation of residential mosque yard at Cumilla EPZ). Tender Id No:(1300251)

Jun 16, 2026

Jul 08, 2026

[View](https://bepza.gov.bd/public/storage/upload/tender/260622052918-6332486.pdf)

## Dhaka Export Processing Zone

Tender No

Title

Start Date

End Date

Action

03.06.2672.325.07.016.26-23

e-Tender Notice No:(10/2025-2026). (Repair and painting of FSSFB # 05 in extension zone of Dhaka EPZ).Tender Id No: (1296578)

Jun 11, 2026

Jul 06, 2026

[View](https://bepza.gov.bd/public/storage/upload/tender/260615035755-127023.pdf)

## Ishwardi Export Processing Zone

Tender No

Title

Start Date

End Date

Action

No current tenders available.

## Jashore Export Processing Zone

Tender No

Title

Start Date

End Date

Action

No current tenders available.

## Karnaphuli Export Processing Zone

Tender No

Title

Start Date

End Date

Action

No current tenders available.

## Mongla Export Processing Zone

Tender No

Title

Start Date

End Date

Action

03.06.0158.308.07.710.26.337

Invitation for e-Tender Notice No:04/2025-2026. (Supply of Stationeries, Toiletries and printing Goods at MEPZ, Mongla, Bagerhat). Tender Id No:(1302683)

Jun 22, 2026

Jul 14, 2026

[View](https://bepza.gov.bd/public/storage/upload/tender/260624032855-879378.pdf)

03.06.0158.308.07.710.26.333

Invitation for Tender Notice No:(03/2025-2026 (Supply of Furniture at Mongla EPZ, Mongla, Bagerhat). Tender Notice No: (1302079)

Jun 21, 2026

Jul 13, 2026

[View](https://bepza.gov.bd/public/storage/upload/tender/260623084549-222940.pdf)

## Patuakhali Export Processing Zone

Tender No

Title

Start Date

End Date

Action

No current tenders available.

## Uttara Export Processing Zone

Tender No

Title

Start Date

End Date

Action

03.06.7364.308.07.015.2026-310

Invitation for e-Tender Notice (2/2025-2026): (Supply of Different Types of Furniture at Uttara EPZ, shangalshi, Nilphamari). Tender Id No:(1301637)

Jun 21, 2026

Jul 13, 2026

[View](https://bepza.gov.bd/public/storage/upload/tender/260624095242-9226UEPZ.pdf)

03.06.7364.327.35.305.2026-238

e-Tender Notice No:5/2025-2026 (Supply & installation of water line network at Uttara EPZ. Tender Id No:(1296082)

Jun 16, 2026

Jul 13, 2026

[View](https://bepza.gov.bd/public/storage/upload/tender/260622045641-8157238.pdf)