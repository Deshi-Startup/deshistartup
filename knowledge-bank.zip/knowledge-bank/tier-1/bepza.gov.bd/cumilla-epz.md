---
source: "BEPZA"
tier: 1
category: "Export zone"
url: "https://bepza.gov.bd/pages/cumilla-epz"
title: "BEPZA"
scraped_at: "2026-07-02"
---

# Cumilla EPZ

-   [Home](https://bepza.gov.bd)
-   Cumilla EPZ

![ienet](https://bepza.gov.bd/public/storage/upload/content/250902015837-8042cumilla.jpg)

**Cumilla EPZ – Strategic Hub on Dhaka–Chattogram Corridor**

Located at the midpoint of the Dhaka-Chattogram highway, Cumilla EPZ ensures rapid access to both the capital city and the country’s main seaport. Established in 2000, it has become a vital industrial hub in eastern Bangladesh.

Spread over 267 acres, Cumilla EPZ provides employment to approximately 48,800 workers. With exports worth over US$ 7.9 billion, it produces textiles, RMG, footwear, toys, medical equipment, and hair & fashion accessories. A combination of incentive packages, a skilled and energetic workforce with the most competitive wage levels, and a safe and secure customs-bonded enclave has made Cumilla EPZ a lucrative investment destination for global entrepreneurs.

Established

2000

Location

Old Airport Area, Cumilla

Zone Area

267.46 acres

Industrial Plots

244 Nos

Investment

US$ 630.78 million

Export

US$ 7,929.86 million

Employment

48,731 nos.

Products

Textile, Ready-made Garments, Garments Accessories, Safety Jacket, Work Wear, Toy, Kitchen Utensils, Metal Products, Hair & Fashion Accessories, Shoes & Leather Products, Medical Equipment, Electronics and Electrical Products, Chemical Products.

Investing Countries

China (including Hong Kong), UK, The Netherlands, South Korea, Japan, Sri Lanka, Canada, Ireland, Pakistan, Indonesia and Bangladesh.