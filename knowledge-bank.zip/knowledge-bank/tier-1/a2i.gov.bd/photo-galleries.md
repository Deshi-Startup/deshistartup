---
source: "a2i / Aspire to Innovate"
tier: 1
category: "Innovation program"
url: "https://a2i.gov.bd/pages/photo-galleries"
title: "ফটোগ্যালারি | এসপায়ার টু ইনোভেট (এটুআই)"
scraped_at: "2026-07-02"
---

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

## ফটোগ্যালারি

ক্রম অনুসারে ডিফল্ট শিরোনাম,ফটো গ্যালারির ধরণ

পৃষ্ঠা আইটেম ১০ ২০ ৫০ ১০০

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/01e7a9c9585a4362a2cae338d591b62e.jpg)

Defining Roles to Strengthen ekPay’s National Role

[দেখুন](/pages/photo-galleries/defining-roles-to-strengthen-ekpay-s-national-role-f2ae19-6922d95281fc96cef9eb172d)

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/de9aad4baf9b42ddbb850f243eea53b1.jpg)

Experts Discuss Health Data Interoperability Challenges and Solutions

[দেখুন](/pages/photo-galleries/experts-discuss-health-data-interoperability-challenges-and-solutions-90f238-6922d97b81fc96cef9eb23f4)

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/82daa9099db0497485c61d9342d6821a.jpg)

a2i Empowers Education Officials to Use Data for Decisions

[দেখুন](/pages/photo-galleries/a2i-empowers-education-officials-to-use-data-for-decisions-5157ed-6922db0c81fc96cef9eb8b88)

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/42c46880c8ce49df96a52f3567ec8ece.jpg)

Planning Upgrades for National Portal with AI Integration

[দেখুন](/pages/photo-galleries/planning-upgrades-for-national-portal-with-ai-integration-44f3f9-6922dafc81fc96cef9eb8537)

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/e8d89ed3e33d4997b03e4b584bf05b38.jpg)

Officials and Partners Plan Bangladesh’s Digital Strategy

[দেখুন](/pages/photo-galleries/officials-and-partners-plan-bangladesh-s-digital-strategy-952952-6922d93281fc96cef9eb12a3)

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/dec898ab902f4d14847ca718befbac68.jpg)

Aligning Efforts to Improve GovTech Maturity and Citizen Services

[দেখুন](/pages/photo-galleries/aligning-efforts-to-improve-govtech-maturity-and-citizen-services-045b70-6922db3281fc96cef9eb9956)

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/f6711639629149e6bd0329e1c64c9bce.jpg)

Government and Partners Collaborate to Enhance Citizen Services

[দেখুন](/pages/photo-galleries/government-and-partners-collaborate-to-enhance-citizen-services-1537d9-6922ddee81fc96cef9ec17a8)

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/20e0bf05b3214cb196bad73abeef4b48.jpg)

Officials Plan Expansion to 41,000 Digital Centres by December 2025

[দেখুন](/pages/photo-galleries/officials-plan-expansion-to-41-000-digital-centres-by-december-2025-a5ac2b-6922daf781fc96cef9eb82d8)

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/8134b83622c64b9c98497e20343cff9f.jpg)

a2i Conducts Hands-On Training on Data Analytics with R

[দেখুন](/pages/photo-galleries/a2i-conducts-hands-on-training-on-data-analytics-with-r-f17568-6922da6e81fc96cef9eb63e7)

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/b9111308e84f487d85b5f8b4be2c47d6.jpg)

Women Leaders Share STEM Journeys with Students and Faculty at Patuakhali Science and Technology University

[দেখুন](/pages/photo-galleries/women-leaders-share-stem-journeys-with-students-and-faculty-at-patuakhali-science-and-technology-university-8f4847-6922d91281fc96cef9eb0d1d)

-   ১
-   ২
-   ৩
-   ৪
-   ...
-   ৭
-   **পরবর্তী** 🡲
-   পৃষ্ঠায় যান 

আর্কাইভ দেখুন প্রকাশিত দেখুন দেখছেন ১ থেকে ১০ পর্যন্ত, মোট ৬২ এন্ট্রি

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

### এক্সেসিবিলিটি

ফন্ট বৃদ্ধি ফন্ট হ্রাস

 মনোক্রোম

 ইনভার্ট

 বড় কার্সর

 লিঙ্ক হাইলাইট

 শিরোনাম হাইলাইট

 পড়ার গাইড

রিসেট

[স্ক্রিন রিডার ডাউনলোড করুন](https://www.nvaccess.org/files/nvda/releases/2020.4/nvda_2020.4.exe)

[কন্টেন্টে চলে যান](#main-content) [এক্সেসিবিলিটি মেনুতে যান](#accessibility-card-title)