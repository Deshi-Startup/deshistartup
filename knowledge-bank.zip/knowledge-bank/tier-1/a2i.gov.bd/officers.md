---
source: "a2i / Aspire to Innovate"
tier: 1
category: "Innovation program"
url: "https://a2i.gov.bd/pages/officers"
title: "কর্মকর্তাবৃন্দ | এসপায়ার টু ইনোভেট (এটুআই)"
scraped_at: "2026-07-02"
---

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

## কর্মকর্তাবৃন্দ

ক্যাটাগরি ভিত্তিক কর্মকর্তাবৃন্দ

(সকল) প্রকল্প পরিচালকের দপ্তর এটুআই প্রোগ্রাম ম্যানেজমেন্ট ন্যাশনাল পোর্টাল মাইগভ নথি ৩৩৩ কল সেন্টার এসপিএস ই-কোর্ট রিপোর্ট ম্যানেজমেন্ট সিস্টেম একপে ডিজিটাল সেন্টার ডি-টোল ইনোভেশন ল্যাব ডিসেবিলিটি ইনোভেশন সিটিজেন ইনোভেশন ডাটা হেলথ ইনোভেশন রিসার্চ ইন্টারন্যাশনাল পার্টনারশীপ রিসোর্স মোবিলাইজেশন ফিউচার অফ এডুকেশন ফিউচার অফ ওয়ার্ক জুডিসিয়ারি কমিউনিকেশন'স প্রকিউরমেন্ট পিপল এন্ড কালচার টেকনোলোজি ফাইন্যান্স & একাউন্টস এডমিন

ক্রম অনুসারে ডিফল্ট শিরোনাম,পদবি / পোস্ট,ইমেইল,ফোন (অফিস),ইন্টারকম,ফ্যাক্স

পৃষ্ঠা আইটেম ১০ ২০ ৫০ ১০০ ২৫০

### প্রকল্প পরিচালকের দপ্তর

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/a4a1e0578cef40ca8b9a00d81df13f7d.jpg)

নাম

মোহাঃ আব্দুর রফিক

পদবি

প্রকল্প পরিচালক (অতিরিক্ত সচিব)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

pd@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭১৫৩২৫২৯৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোহাঃ-আব্দুর-রফিক-e0522d-6922d8f9933eb65569dfb9b9)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/ca9e98b3a78342f98dc7c037a2fa4b07.jpeg)

নাম

মোঃ কামরুল হাসান

পদবি

যুগ্ম প্রকল্প পরিচালক (যুগ্মসচিব),কম্পোনেন্ট- ১

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

jpd.cabinet@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭১৮৬৬৮০২৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-কামরুল-হাসান-8f1b67-6922df63933eb65569e21a57)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/20082d3e6d3941258e4a720a2231320a.jpg)

নাম

মোঃ রশিদুল মান্নাফ কবীর

পদবি

যুগ্ম প্রকল্প পরিচালক (যুগ্মসচিব), কম্পোনেন্ট- ২, ৩

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

jpd.ict@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭১২-২৫৫৭০০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-রশিদুল-মান্নাফ-কবীর-8f69cd-6922e05c933eb65569e26ad8)

### এটুআই প্রোগ্রাম ম্যানেজমেন্ট

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/89ba76b72bb940908c9ea10473fe4336.png)

নাম

আব্দুল্লাহ আল ফাহিম

পদবি

কনসালটেন্ট (হেড অফ প্রোগ্রাম ম্যানেজমেন্ট)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

fahim.abdullah@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭২২-৬৩২২২২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/আব্দুল্লাহ-আল-ফাহিম-c51015-6922d8d0933eb65569dfa26d)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/de8dbf7b402a4e6e9d9857da10e54e52.jpg)

নাম

মোঃ লুৎফর রহমান

পদবি

কনসালটেন্ট (অ্যাডমিন)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

lutfor.rahman@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৯২০-৮০১৬৮০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-লুৎফর-রহমান-2efa82-6922d911933eb65569dfc4bf)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/0f85725e368d4a39a7342147363d249a.JPG)

নাম

ফারিয়া ই ফেরদৌস

পদবি

জুনিয়র কনসালটেন্ট (প্রোগ্রাম ম্যানেজমেন্ট)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

faria.ferdous@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৮৩-৩৬২৯৮৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ফারিয়া-ই-ফেরদৌস-ace031-6922ddd2933eb65569e16767)

৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/6525ad9cd5f44a98adb680fe1e43a111.jpg)

নাম

মোঃ মাহবুবুর রহমান

পদবি

জুনিয়র কনসালটেন্ট (রিসার্চ)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

mahbub.rahman@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬৭৫-৬৫৯৬১৭

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-মাহবুবুর-রহমান-92740e-6922e086933eb65569e2765b)

৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/d60eebac43bc4c768ed6db5c591c5e19.jpg)

নাম

ফারজানা মুক্তা

পদবি

জুনিয়র কনসালটেন্ট (প্রোগ্রাম ম্যানেজমেন্ট)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

farjana.mukta@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৯১৩৮৯০১২১

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ফারজানা-মুক্তা-358080-6922e184933eb65569e2c750)

৬

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2026/3/dcffb7e0-7cf1-4450-b228-75c0a59a7da6.png)

নাম

মো. মাহমুদুল হাসান

পদবি

জুনিয়র কনসালটেন্ট (ন্যাশনাল পোর্টাল)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

md.mahmudul@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৮৬-৩৪৫৬৬৪

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মো-মাহমুদুল-হাসান-3cf088-6922ddc8933eb65569e163e4)

৭

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/e83a03e31bf548e6afd39136bf5d0736.jpg)

নাম

মুসফিক মোহাম্মদ মোস্তফা

পদবি

জুনিয়র কনসালটেন্ট (প্রোগ্রাম ম্যানেজমেন্ট)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

mushfiq.mostafa@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬৮৫৩৩১১৯৭

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মুসফিক-মোহাম্মদ-মোস্তফা-855196-6922dd92933eb65569e157f9)

৮

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/16877af8a2ba4553a3c8005ba78dc3c7.jpg)

নাম

সুলতানা সুমাইয়া শাইরা

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট

ইমেইল

sumaia.shaira@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৮৯৫৪৮৫৬৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/সুলতানা-সুমাইয়া-শাইরা-b66ad8-6922dfea933eb65569e24a17)

### ন্যাশনাল পোর্টাল

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/5c952352039a4d18a783afe795c3b817.jpg)

নাম

ফজলুল জাহিদ পাভেল

পদবি

সিনিয়র কনসালটেন্ট (ন্যাশনাল পোর্টাল)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

fazlul.zahed@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭২১-৯৭৪৩৫২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ফজলুল-জাহিদ-পাভেল-91a6af-6922db3f933eb65569e09137)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2026/1/77c6226e-bb6c-4e5a-a1a1-d40a65f014ae.jpeg)

নাম

মোঃ রবিউল হাসান

পদবি

কনসালটেন্ট (মাইগভ)

অফিস

এসপায়ার টু ইনোভেট ( এটুআই)

ইমেইল

rabiul.hasan@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৭০৩৪৩৪৯১

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-রবিউল-হাসান-a8cyzh-699e81afa2028309cc732dc6)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/63768470afab4f348d02f5ba19a1b9b7.png)

নাম

মাসরুর মোহাম্মদ শান্ত

পদবি

জুনিয়র কনসালটেন্ট (ন্যাশনাল পোর্টাল)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

mashrur.shanto@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৩৭-২৮৮৩২২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মাসরুর-মোহাম্মদ-শান্ত-053623-6922dc42933eb65569e0f563)

৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2026/1/f3a14b08-c37a-4087-acf1-b0c1a0cecaff.jpg)

নাম

কাজী মোহাইমিনুল ইসলাম

পদবি

জুনিয়র কনসালটেন্ট (ন্যাশনাল পোর্টাল)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

mohaiminul.islam@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৫৬-৬১৪৬৪১

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/কাজী-মোহাইমিনুল-ইসলাম-235d51-6922d971933eb65569dfeb51)

৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/e143d08203104b38ac8775d7ed4b5d4c.jpg)

নাম

শরফুন নাহার

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

sharfun.nahar@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৪০৩০০১৩৫৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/শরফুন-নাহার-8ce23d-6922d961933eb65569dfe7f3)

৬

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/a7df4770d7ef43fe82afe230b5340784.jpg)

নাম

আব্দুল হালিম

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

abdul.halim@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৪২৩০৪৬১৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/আব্দুল-হালিম-3d81a6-6922e17c933eb65569e2c55c)

৭

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/6ae08b22a3724823a6c35c638dd50220.jpeg)

নাম

মোঃ তাওফিক ইবনে আমিন

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

tawfiq.amin@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭২২-১১৯৩৯০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-তাওফিক-ইবনে-আমিন-ed235a-6922e2aa933eb65569e2f4a4)

৮

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/f86cf350f2e143e5a6bba9f37361ca6d.jpg)

নাম

তাসনিভা ইত্তেসাম সুমি

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

tasniva.sumi@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬২০১২০৭৬২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/তাসনিভা-ইত্তেসাম-সুমি-b954a1-6922ddc6933eb65569e162f9)

### মাইগভ

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/5ca0b59bbcee45d2949fd1da92029775.jpg)

নাম

ফজলুল জাহিদ পাভেল

পদবি

সিনিয়র কনসালটেন্ট(ন্যাশনাল পোর্টাল) ( ক্লাস্টার হেড- ডিজিটাল প্রোডাক্ট ম্যানেজমেন্ট -১)

অফিস

এসপায়ার টু ইনোভেট

ইমেইল

fazlul.zahed@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭২১-৯৭৪৩৫২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ফজলুল-জাহিদ-পাভেল-e53d3e-6922e236933eb65569e2e75d)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/aa7645e2ab5e4a68b9ffd630781611f4.jpeg)

নাম

মোমেনা আক্তার

পদবি

কনসালটেন্ট (মাইগভ)

অফিস

এসপায়ার টু ইনোভেট ( এটুআই)

ইমেইল

momena.akhter@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭১৬-০১০১১৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোমেনা-আক্তার-6bdc97-6922dfb0933eb65569e237e1)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/79b4fbbd18904c17bf0678e053b48c15.jpeg)

নাম

রাসেদুল হাসান

পদবি

কনসালটেন্ট (মাইগভ)

অফিস

এসপায়ার টু ইনোভেট ( এটুআই)

ইমেইল

rasedul.hasan@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৫০-৮১৩৬৭০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/রাসেদুল-হাসান-8034e9-6922dff8933eb65569e24de7)

৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/5eb1ffa8780446a88ea4a1c26a4e4187.jpg)

নাম

মোহাম্মদ আব্দুর রহিম

পদবি

কনসালটেন্ট (মাইগভ)

অফিস

এসপায়ার টু ইনোভেট ( এটুআই)

ইমেইল

abdur.rahim@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭১৫-৭৯৬৯৫৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোহাম্মদ-আব্দুর-রহিম-5adef4-6922e0bd933eb65569e28696)

৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/345c320a28424023b93e74d333acf3d1.jpeg)

নাম

সাকেরা নাহার

পদবি

জুনিয়র কনসালটেন্ট (মাইগভ)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

shakera.nahar@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৯১১-৬৪১১২১

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/সাকেরা-নাহার-73e97c-6922deb3933eb65569e1cb68)

৬

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/bfd89a19db294f4b9c7c19734fd66f79.jpeg)

নাম

খালিদ মুহাম্মদ সাইফুল্লাহ

পদবি

জুনিয়র কনসালটেন্ট (মাইগভ)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

khalid.shaifullah@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৯৫৪-৯১৬৩৭০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/খালিদ-মুহাম্মদ-সাইফুল্লাহ-ca94e9-6922dde6933eb65569e16f7e)

৭

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/40a1398aef9340579cc2bb766faac1da.JPG)

নাম

মোঃ এরশাদ আলম

পদবি

জুনিয়র কনসালটেন্ট (মাইগভ)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

ershad.alam@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬৭৫-৯৬৯২১৮

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-এরশাদ-আলম-fc0aa8-6922e1af933eb65569e2d19f)

৮

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/ec6590c8ec624fe0b284c1a17e0543ca.jpeg)

নাম

আয়েশা মোস্তফা

পদবি

জুনিয়র কনসালটেন্ট (মাইগভ)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

ayesha.mostafa@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭১৩-২০১২০১

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/আয়েশা-মোস্তফা-f660e0-6922e1f2933eb65569e2de17)

৯

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/77ccaf47c4514f07bf441dc9349563b5.jpg)

নাম

মো: রুহুল আমিন

পদবি

জুনিয়র কনসালটেন্ট (ফিউচার অফ ওয়ার্ক)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

ruhul.amin@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৪৯৮২৪৩৫৩

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মো-রুহুল-আমিন-a03cf6-6922de26933eb65569e1892c)

১০

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/c90cc362de8f41c1a1745eddb9568a41.jpeg)

নাম

তৌহিদা ফাতেমা

পদবি

জুনিয়র কনসালটেন্ট (ইনোভেশন ল্যাব)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

touhida.fatema@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৪২৪১২১২৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/তৌহিদা-ফাতেমা-c39873-6922d937933eb65569dfd9df)

১১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/cbcdee1cb19a46d0b2fba991ed31254f.jpg)

নাম

মুহতাসিম আল হক

পদবি

জুনিয়র কনসালটেন্ট (মাইগভ)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

mohtasim.haque@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬৮৯৫৭০১৮৩

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মুহতাসিম-আল-হক-a3dd4a-6922e2df933eb65569e2fecd)

১২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/9e088992d18b4793a9e6f5e01515277f.jpeg)

নাম

মো. সুজন

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

md.sujon@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৩০৯৯৮৮১৪১

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মো-সুজন-98e424-6922e1f9933eb65569e2df0c)

১৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2026/2/96cc4748-5a6d-4fbd-a635-aec31cc8680a.jpeg)

নাম

মো. সালাউদ্দিন

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

md.salauddin@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৯৮৭৫৭৪৫৬৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মো-সালাউদ্দিন-0a4809-6922df7a933eb65569e223d3)

১৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/fd2e2be85ff64f30828fe42f05744c47.JPG)

নাম

ইসরাত জাহান

পদবি

ইয়াং প্রোফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

ishrat.jahan@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৮৮৬-৩১৪৭১৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ইসরাত-জাহান-89fb2a-6922d8d2933eb65569dfa3cf)

১৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/da48102f937442f0bca0cce209d74751.jpg)

নাম

মোঃ মাহরুফ জামান

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

mahruf.zaman@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭২০৫৩২৮১৭

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-মাহরুফ-জামান-3f5707-6922ddf2933eb65569e173c7)

১৬

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/3bff8370824642128384a910b045e8ac.jpg)

নাম

নিশি

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

nishi.khan@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/নিশি-7c8e22-6922e216933eb65569e2e328)

১৭

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/3a0f1b81fb304dd9b6d0d160a11b5e87.jpg)

নাম

রূপা খন্দকার

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

rupa.khondokar@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৮১২৫৯৫৪২৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/রূপা-খন্দকার-3b1e1d-6922d8f4933eb65569dfb7d1)

১৮

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/7ef2d06679e64142826c1463d561faf9.jpg)

নাম

কৌশিক সরকার

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

kowshik.sarkar@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৮৬৯৬৯৯৯৯১

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/কৌশিক-সরকার-1cd735-6922e1c0933eb65569e2d52b)

১৯

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/7c2040cd8de142198c3e55b556c8a9ad.jpg)

নাম

মোঃ মুনতাকিমুল হুদা শাওন

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

muntakimul.huda@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬২-১৮৬৮৯৭৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-মুনতাকিমুল-হুদা-শাওন-c2c65f-6922de9b933eb65569e1bf7a)

### নথি

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/7e5e63c08fb84fa28c1a742dc2143df1.jpg)

নাম

ফজলুল জাহিদ পাভেল

পদবি

সিনিয়র কনসালটেন্ট (ন্যাশনাল পোর্টাল)( ক্লাস্টার হেড- ডিজিটাল প্রোডাক্ট ম্যানেজমেন্ট -১)

অফিস

এসপায়ার টু ইনোভেট

ইমেইল

fazlul.zahed@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭২১-৯৭৪৩৫২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ফজলুল-জাহিদ-পাভেল-c88e8f-6922de17933eb65569e182fa)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/91e3afbda7904e0aae089121e332bcda.jpg)

নাম

আবু সালেহ মোঃ মাহফুজুল আলম

পদবি

সিনিয়র কনসালটেন্ট (নথি)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

mahfuzul.alam@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭১৩৭১০০১৭

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/আবু-সালেহ-মোঃ-মাহফুজুল-আলম-45a15b-695b989035ce18e1c05aeba5)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/0191a3e888bf441b9f26a3776581bf7d.jpg)

নাম

ইমরুল হোসাইন

পদবি

কনসালটেন্ট (৩৩৩)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

imrul.hosain@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭১২-৪৮৫৭৪৭

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ইমরুল-হোসাইন-e33101-6922e212933eb65569e2e2aa)

৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/80f614f62d9c41b4a009389cf991ef51.jpg)

নাম

মাজেদুল আলম

পদবি

কনসালটেন্ট (নথি)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

mazedul.maahi@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭১৭-৫৭৯০২৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মাজেদুল-আলম-1a5e30-6922dc90933eb65569e10fcb)

৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/b6969541657b4757b0e4a7a6ca287cf3.jpg)

নাম

বোরহান উদ্দিন

পদবি

জুনিয়র কনসালটেন্ট (নথি)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

borhan.uddin@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৯১৫-৫৩৩১০৪

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/বোরহান-উদ্দিন-19fce2-6922deb2933eb65569e1cb15)

৬

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/a56dc3de9eb44a31b5e708c18c3512f8.jpg)

নাম

মাজেদা খাতুন

পদবি

জুনিয়র কনসালটেন্ট (রিপোর্ট ম্যানেজমেন্ট সিস্টেম)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

mazeda.khatun@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৩৮-৮৩০৩১০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মাজেদা-খাতুন-a46bb6-6922dbc3933eb65569e0c5f3)

৭

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/842424a46cf2473e97933e9b9faa103c.jpg)

নাম

মোঃ সজিবুর রহমান সরদার

পদবি

জুনিয়র কনসালটেন্ট (নথি)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

shzibur.rahman@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৪৪-৭০৭৯৭৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-সজিবুর-রহমান-সরদার-1d183c-6922d994933eb65569dff21f)

৮

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/feff77484653404896df746403a8c35d.jpg)

নাম

মোঃ জেইসন জামান শাওন

পদবি

জুনিয়র কনসালটেন্ট(ই-কোর্ট ইমপ্লিমেন্টেশন)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

jeyson.jaman@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৫৫-১০৩৬০১

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-জেইসন-জামান-শাওন-9a2b77-6922ddd3933eb65569e167aa)

৯

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/a97eb108acc54c8984ad895b758d36cd.jpeg)

নাম

মোঃ শেহেজীন শাহারিয়ার (সোহান)

পদবি

জুনিয়র কনসালটেন্ট (মাইগভ)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

shahazin.shahariar@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭২২-১৫৯৫৮৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-শাহজীন-শাহরীয়ার-সোহান-dc9c97-6922ddcb933eb65569e164bc)

১০

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/7f81842bb84042129323f0559dce9bcf.jpg)

নাম

মাহমুদা আমাতুল্লাহ প্রীতু

পদবি

জুনিয়র কনসালটেন্ট(নথি)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

mahmudah.pritu@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৭০-৭০৫৪৪৮

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মাহমুদা-আমাতুল্লাহ-প্রীতু-2fa037-6922db9e933eb65569e0b570)

১১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/2e94de9e75124e029e93639ef9444153.png)

নাম

মোঃ সুমন খান

পদবি

জুনিয়র কনসালটেন্ট (নথি)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

sumon.khan@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৪৬-৯১০১৩২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-সুমন-খান-49436b-6922e244933eb65569e2e91b)

১২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/30c2ebee30874ac3bacad6ca97321436.jpg)

নাম

মোঃ মাহবুবুর রহমান

পদবি

জুনিয়র কনসালটেন্ট(নথি)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

mahbub.sumon@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৮৪২৩৮১৫১৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-মাহবুবুর-রহমান-d3e9f1-6922e1a2933eb65569e2ce8a)

১৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/1e2f9a1218e14dada5e867ce1d92bf96.png)

নাম

মোঃ সাব্বির আহমেদ

পদবি

জুনিয়র কনসালটেন্ট (নথি)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

sabbir.ahmed@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৬৪৩৭০৭০৬

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-সাব্বির-আহমেদ-83c94e-6922e044933eb65569e26447)

১৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/b0d3c1bf7474487c8b1d6c351a10b7dc.jpg)

নাম

এস.কে. আল-আবিদ

পদবি

জুনিয়র কনসালটেন্ট (নথি)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

sk.abid@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৫২১-৩৩৩৩৬৬

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/এস-কে-আল-আবিদ-d43e38-6922df20933eb65569e200bf)

১৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/4525af3741e74b16b55a1d5d09c5f8f9.jpg)

নাম

কাবেরী সুলতানা

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

kabary.sultana@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৬৩২৯৪৬০৪

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/কাবেরী-সুলতানা-3ce320-6922df9d933eb65569e23092)

১৬

নাম

মাঈশা ফারজানা মৌ

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

mayeesha.farzana@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৯৫৬৪২৭৪৬৮

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মাঈশা-ফারজানা-মৌ-964630-6922d90c933eb65569dfc2ca)

১৭

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/6be53bd9d23a4f45a776104318a5ce7d.jpg)

নাম

মোঃ মাহ্‌বুব নেওয়াজ

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

mahbub.newaz@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৫৯১১৪৭৬৮৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-মাহ্-বুব-নেওয়াজ-6e56d1-6922e26e933eb65569e2ee2e)

১৮

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/5ecc02fd93424c448fc8bc3fbb19740c.jpg)

নাম

আব্দুল্লাহ আল মোহাইমিন সরকার

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

abdullah.muhimin@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৪৬৩৪৪৯৯৩

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/আব্দুল্লাহ-আল-মোহাইমিন-সরকার-728718-6922dab8933eb65569e06344)

১৯

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/cfea3249f2894330a4d0a0606770fd0d.jpg)

নাম

আহমাদুল হাসান

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

ahmadul.hasan@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৫১৮৬০৬৭১৩

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/আহমাদুল-হাসান-72189f-6922e06d933eb65569e27013)

২০

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/bcec06adb96f4ba2b96e29859d5f0c45.jpeg)

নাম

মোছাঃ আনমুন জেসমিন

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

anmun.jesmin@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৯৯৮০৩৬৯৮

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোছাঃ-আনমুন-জেসমিন-7773b8-6922e21f933eb65569e2e45a)

২১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/afc5bf7a5d49404c80660e88281d8ba5.jpg)

নাম

মোঃ রুহুল আমিন শেখ

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

ruhulamin.sheikh@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৫-১৮৬৬০৬৫৪

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-রুহুল-আমিন-শেখ-1e8942-6922d9c7933eb65569e00122)

২২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/42a38f4b5d004467b27dbf6af841a0ea.jpg)

নাম

জাহানারা খাতুন

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

jahanara.khatun@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬৩-২১৫৫১৭১

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/জাহানারা-খাতুন-22bad0-6922e29e933eb65569e2f35f)

### ৩৩৩ কল সেন্টার

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/26c0a88249604d708a300ba626206aac.jpg)

নাম

ফজলুল জাহিদ পাভেল

পদবি

সিনিয়র কনসালটেন্ট (ন্যাশনাল পোর্টাল)( ক্লাস্টার হেড- ডিজিটাল প্রোডাক্ট ম্যানেজমেন্ট -১)

অফিস

এসপায়ার টু ইনোভেট

ইমেইল

fazlul.zahed@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭২১-৯৭৪৩৫২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ফজলুল-জাহিদ-পাভেল-8baec3-6922df64933eb65569e21b10)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/e4dcf48300f5495c9739bcfb5f5946db.JPEG)

নাম

মোহম্মদ ইকবাল হোসেন

পদবি

জুনিয়র কনসালটেন্ট (৩৩৩)

অফিস

এসপায়ার টু ইনোভেট

ইমেইল

iqbal.hossain@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬৭৭০০৪০৮২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোহম্মদ-ইকবাল-হোসেন-2a02df-6922dfb4933eb65569e2391d)

### এসপিএস

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/3067f8873413444699a8eab58e777124.jpg)

নাম

ফজলুল জাহিদ পাভেল

পদবি

সিনিয়র কনসালটেন্ট (ন্যাশনাল পোর্টাল) ( ক্লাস্টার হেড- ডিজিটাল প্রোডাক্ট ম্যানেজমেন্ট -১)

অফিস

এসপায়ার টু ইনোভেট

ইমেইল

fazlul.zahed@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭২১-৯৭৪৩৫২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ফজলুল-জাহিদ-পাভেল-bb2e9c-6922d8dc933eb65569dfab29)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2026/5/167650af-156b-4e80-82a2-db448de762b7.jpg)

নাম

মোঃ ছানাউল ইসলাম

পদবি

কনসালটেন্ট ( সার্ভিস প্রোসেস সিমপ্লিফিকেশন)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

sanaul.islam@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮০ ১৭২৮-৫৭২৬৮৪

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-শিহাব-রায়হান-m2eyvp-6979e15a8591af9b4635b444)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/904f3ba205de435189684a69fe22551d.jpg)

নাম

মোঃ আব্দুল আওয়াল

পদবি

জুনিয়র কনসালটেন্ট (এসপিএস)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

abdul.awal@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬৭৩-৪৮৯১২৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-আব্দুল-আওয়াল-e399f7-6922df63933eb65569e21a93)

৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/16c8f134a18745e8877d53eea72d1e92.jpeg)

নাম

মোঃ সাইফুল ইসলাম

পদবি

প্রজেক্ট অ্যাসিস্ট্যান্ট

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

saiful.islam@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭১৬৭০০৭৫৬

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-সাইফুল-ইসলাম-5ac9f6-6922dd3f933eb65569e141ba)

৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/eff9764e9fbf48a581f9ead439759ea8.jpeg)

নাম

মোঃ আনোয়ার জাহিদ শাওন

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

anwar.zaheed@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৯০৯-৮৭০৫২১

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-আনোয়ার-জাহিদ-শাওন-ef10d2-6922e173933eb65569e2c2de)

৬

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/598c15add725495e93ee642a60deebb9.jpg)

নাম

রিফা আতুন নিছা

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

rifayatun.nisa@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৮৪০৬৮২৩৩০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/রিফা-আতুন-নিছা-279c1c-6922dfb0933eb65569e237bf)

### ই-কোর্ট

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/bd0f78eff9db4c14b651c17f29a8d6a0.jpg)

নাম

ফজলুল জাহিদ পাভেল

পদবি

সিনিয়র কনসালটেন্ট (ন্যাশনাল পোর্টাল) ( ক্লাস্টার হেড- ডিজিটাল প্রোডাক্ট ম্যানেজমেন্ট -১)

অফিস

এসপায়ার টু ইনোভেট

ইমেইল

fazlul.zahed@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭২১-৯৭৪৩৫২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ফজলুল-জাহিদ-পাভেল-71323b-6922d8e8933eb65569dfb1ce)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2026/5/19a093a4-5a0f-4965-9a34-41fafa0b4215.jpeg)

নাম

মোছা: খালেদা খাতুন রেখা

পদবি

কনসালটেন্ট (ই-কোর্ট)

অফিস

এসপায়ার টু ইনোভেট

ইমেইল

khaleda.khatun@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৩২-৭৬০৩২৭

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোছা-খালেদা-খাতুন-রেখা-30020d-6922d8d0933eb65569dfa270)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/eac15cc7d09b43949bf4931a87a82718.jpg)

নাম

ফাহাদ হাসান আদনান

পদবি

জুনিয়র কনসালটেন্ট (৩৩৩)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

fahad.hassan@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৫৭৫২৬৭৬৭৩

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ফাহাদ-হাসান-আদনান-7b72d8-6922e1d8933eb65569e2d9e4)

৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/3928f81514f242e0b3bbdedeed3465a2.png)

নাম

রায়হান মাহমুদ হিমেল

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

raihan.mahmud@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৯০৩৪৪২৪২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/রায়হান-মাহমুদ-হিমেল-ef9835-6922d9c6933eb65569e00076)

### রিপোর্ট ম্যানেজমেন্ট সিস্টেম

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/2b8bb7eb88ba4887baa57afc330b90ed.jpg)

নাম

ফজলুল জাহিদ পাভেল

পদবি

সিনিয়র কনসালটেন্ট (ন্যাশনাল পোর্টাল) ( ক্লাস্টার হেড- ডিজিটাল প্রোডাক্ট ম্যানেজমেন্ট -১)

অফিস

এসপায়ার টু ইনোভেট

ইমেইল

fazlul.zahed@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭২১-৯৭৪৩৫২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ফজলুল-জাহিদ-পাভেল-8b7452-6922e259933eb65569e2eb9d)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/0e412635baa94b7bba448f56afda4c73.jpg)

নাম

মোঃ শিহাব রায়হান

পদবি

কনসালটেন্ট ( রিপোর্ট ম্যানেজমেন্ট সিস্টেম)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

shihab.rayhan@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮০১৭১১০৬১০৭১

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-শিহাব-রায়হান-a7ed9b-695b9af635ce18e1c05af0dd)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/d0cca031d6ba4584a1912a9e76d72a41.jpeg)

নাম

সারাহ আলম

পদবি

জুনিয়র কনসালটেন্ট (রিপোর্ট ম্যানেজমেন্ট সিস্টেম)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

sarah.alam@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৯৯৯-৮১৭০৪৬

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/সারাহ-আলম-63ff90-6922e195933eb65569e2cb98)

৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/3eaa12ed2e20459d86b49addd19884dc.jpg)

নাম

তৌসিফ হাসান

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

hassan.tousif@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৫৫৮১০৩৩২৭

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/তৌসিফ-হাসান-7b2ca3-6922e163933eb65569e2bdd5)

৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/7d1c74f2eb86475797c12836b3ba149c.png)

নাম

শরিফুল ইসলাম রিয়েল

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

shariful.real@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬৮৭৮৩২৮৮৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/শরিফুল-ইসলাম-রিয়েল-b3ea0c-6922e20e933eb65569e2e20a)

### একপে

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2026/5/dc19d26c-5976-40f7-9b03-bdcab3c40f5f.jpg)

নাম

মোহাম্মদ মাসুদুর রহমান

পদবি

সিনিয়র কন্সাল্টেন্ট (চিফ টেকনিক্যাল এডভাইজর), (ক্লাস্টার হেড-ফিনটেক ইনোভেশন)(অতিরিক্ত দায়িত্ব)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

masud.rahman@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৩০৭-৫২১০৪৬

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/আব্দুল্লাহ-আল-ফাহিম-dffef4-6922e1ba933eb65569e2d3ea)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/c093bb07d39649849d193efb39c0bffb.jpg)

নাম

মুহাম্মাদ শাহাদাত হোসেন

পদবি

কনসালটেন্ট (গভর্নমেন্ট পেমেন্ট)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

shahadat.hossain@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৯১১১৬৬৬১২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মুহাম্মাদ-শাহাদাত-হোসেন-ab6d18-6922dadb933eb65569e06f71)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/ecb9ebf57ee44480a22523e91e07bf22.jpeg)

নাম

উছেন অং

পদবি

কনসালটেন্ট (ডিজিটাল ফাইনান্সিয়াল সার্ভিস)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

uchan.aoung@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৩০২-২৬৯৬২১

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/উছেন-অং-fec43b-6922df76933eb65569e22245)

৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/c13b167a149c4eb59ebfad21b29d1c9b.jpg)

নাম

আব্দুল্লাহ ফারহান শৌভিক

পদবি

জুনিয়র কনসালটেন্ট (পার্টনারশিপ এন্ড আউটরিচ)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

abdullah.farhan@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৮৭২১৫২০৭৬

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/আব্দুল্লাহ-ফারহান-শৌভিক-06745d-6922db88933eb65569e0aaf4)

৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/e386adea80d648fa9c7d9f91f16983c9.jpg)

নাম

মোজাম্মেল হোসেন

পদবি

অ্যাসিস্ট্যান্ট ম্যানেজার

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

mojammel.hossain@ekpay.gov.bd

ফোন (অফিস)

০১৭৩৬-৩১৯৮৯৯

ইন্টারকম

কক্ষ নম্বর

মোবাইল

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোজাম্মেল-হোসেন-590449-6922ddc6933eb65569e1630f)

৬

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/b343a0e5e37b4941ab5144523578138f.jpg)

নাম

মোঃ রুহুল আমিন রায়হান

পদবি

এক্সিকিউটিভ

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

ruhul.amin@ekpay.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৫২১৪৭১২২৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-রুহুল-আমিন-রায়হান-977b5f-6922dad3933eb65569e06d09)

৭

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/31ab17147bb84374862d40551ac2a781.jpg)

নাম

মোঃ মোস্তাফিজুর রহমান

পদবি

এক্সিকিউটিভ

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

mostafiz.rahman@ekpay.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৪৪-৪৮৭১৭৬

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-মোস্তাফিজুর-রহমান-43c437-6922d8c8933eb65569df9e26)

৮

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/5154e907b821460a9e117e2f102e7932.jpg)

নাম

নুরেন ফারহান

পদবি

প্রোগ্রাম অ্যাসিস্ট্যান্ট

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

nooren.farhan@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৮৭-৬০০০৭১

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/নুরেন-ফারহান-c87245-6922e1a2933eb65569e2ceac)

৯

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/668a85a09de9495eb7976b7683b3f263.jpg)

নাম

তানসুশীলা

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

tansushila@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬৮৭১৩৩৮৬৮

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/তানসুশীলা-b55c6f-6922d8c5933eb65569df9d13)

১০

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/98123d5a08eb44be8fd05cc7dd9fc0b5.jpg)

নাম

মোঃ আবু নাজিম আজম

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট

ইমেইল

abu.nazim@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

১৭৩৩৭৮৮৮২৪

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-আবু-নাজিম-আজম-9257de-6922e2b5933eb65569e2f5cb)

### ডিজিটাল সেন্টার

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/005b59b5ecae443e90f6f599bc62a230.png)

নাম

আব্দুল্লাহ আল ফাহিম

পদবি

কনসালটেন্ট (হেড অফ প্রোগ্রাম ম্যানেজমেন্ট) (ক্লাস্টার হেড- ফিনটেক ইনোভেশন) (অতিরিক্ত দায়িত্ব)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

fahim.abdullah@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭২২-৬৩২২২২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/আব্দুল্লাহ-আল-ফাহিম-284630-6922e2de933eb65569e2fe79)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/5d1144b3f91549ce96b4b2033388b7f1.jpeg)

নাম

অশোক কুমার বিশ্বাস

পদবি

ক্যাপাসিটি ডেভেলপমেন্ট কো-অর্ডিনেটর

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

ashoke.biswas@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭২৭২২৪৪৯৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/অশোক-কুমার-বিশ্বাস-5351cc-6922e19f933eb65569e2ce05)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/f86a024f3ceb4aa3acfbbb0de8d39dd8.jpeg)

নাম

মোঃ মাসুম বিল্লাহ

পদবি

জুনিয়র কনসালটেন্ট (পার্টনার ও ফিল্ড কো-অর্ডিনেশন)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

masum.billah@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭১১-১৮১৫৪০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-মাসুম-বিল্লাহ-0d92a5-6922dcb9933eb65569e11aec)

৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/16672bd9497b4b51a0c1d34f3ffa67ba.jpg)

নাম

মো: আরিফ হোসাইন

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

arif.hossain@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৮২৯-৮৯৪৬৭৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মো-আরিফ-হোসাইন-df770d-6922d8d1933eb65569dfa2b6)

### ডি-টোল

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2026/5/36aa136d-38c1-41c1-a94c-4d58c110ff0f.jpg)

নাম

মোহাম্মদ মাসুদুর রহমান

পদবি

সিনিয়র কন্সাল্টেন্ট (চিফ টেকনিক্যাল এডভাইজর), ক্লাস্টার হেড(অতিরিক্ত দায়িত্ব)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

masud.rahman@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৩০৭-৫২১০৪৬

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/আব্দুল্লাহ-আল-ফাহিম-ed82f9-6922d8ef933eb65569dfb566)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/8086e7b5973f4ef6aad88658ddd17abb.jpg)

নাম

মোহাম্মদ মশিউর রহমান

পদবি

কনসালটেন্ট (ডি-টোল)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

moshiur.rahman@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭২৯-২১০০৯৭

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোহাম্মদ-মশিউর-রহমান-ef4d6c-6922d98c933eb65569dff076)

### ইনোভেশন ল্যাব

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/7cbd268d4f0e4bd5bb4b132176899e86.jpg)

নাম

মোঃ নাহিদ আলম

পদবি

সিনিয়র কনসালটেন্ট ( এটুআই ইনোভেশন ফান্ড)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

nahid.alam@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৫৫০-০২০৪৪৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-নাহিদ-আলম-256097-6922d8d7933eb65569dfa785)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/7ec618c3570b468abc391070454b6920.jpg)

নাম

তৌফিকুর রহমান

পদবি

কনসালটেন্ট (এটুআই ইনোভেশন ফান্ড)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

taufiqur.rahman@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৮৪৭২১৭১০০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/তৌফিকুর-রহমান-189d93-6922df95933eb65569e22e6e)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/5a17af6c6b504cc8938ffffc711da647.JPG)

নাম

আবদুল্লাহ আল মানসুর

পদবি

জুনিয়র কনসালটেন্ট (ই কোর্ট ইমপ্লিমেন্টেশন)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

abdullah.mansur@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭১০-৭৭৪৪৮২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/আবদুল্লাহ-আল-মানসুর-4ba7fb-6922e235933eb65569e2e739)

৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2026/3/1755365a-f0e5-47af-9c78-6b4d7766bee5.jpeg)

নাম

মোহসীনা তারান্নুম প্রমি

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

mohsina.tarannum@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৮৭৬৩৫৮৭৪৪

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোহসীনা-তারান্নুম-প্রমি-01de33-6922dbb2933eb65569e0beb3)

৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/9940ea71f99e4bb0aeab5b787ac29d69.jpeg)

নাম

কাশফিয়া হাসান

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

kashfia.hasan@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৩২৬১৪০৭৫২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/কাশফিয়া-হাসান-43e711-6922db05933eb65569e07fcb)

৬

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/c7d389ab4c0f427b8ce64053887cf929.jpg)

নাম

এস এম ইসতিয়াক আহমেদ আলভী

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

istiaque.alvi@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬২৫০১২৯৯০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/এস-এম-ইসতিয়াক-আহমেদ-আলভী-0d77aa-6922dfd0933eb65569e2419f)

### ডিসেবিলিটি ইনোভেশন

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/86dbcf351830499db7d4c4be14413ecb.jpg)

নাম

মোঃ নাহিদ আলম

পদবি

সিনিয়র কনসালটেন্ট (এটুআই ইনোভেশন ফান্ড)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

nahid.alam@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৫৫০-০২০৪৪৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-নাহিদ-আলম-044ae5-6922dad4933eb65569e06d8f)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/a5e9ee9130cd48d989664695802c8cc0.jpg)

নাম

ভাস্কর ভট্টাচার্য

পদবি

কনসালটেন্ট (এক্সেসিবিলিটি)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

vashkar.bhattacharjee@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭১৮৩৪৫০৩৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ভাস্কর-ভট্টাচার্য-75ec4e-6922dcad933eb65569e11875)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/dd0c20492f2a4c508544759146534c36.jpg)

নাম

এম এম তরিকুল হক

পদবি

জুনিয়র কনসালটেন্ট

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

tariqul.huq@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৭৭৩৫০৩৯৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/এম-এম-তরিকুল-হক-19ba5d-6922df25933eb65569e202b1)

৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/58a1b5433b6b4def8c4c2e2c119af70a.jpg)

নাম

ফাহিমা মাহজাবীন

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

fahima.mahjabin@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৯৬-৪২০২৮২৭

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ফাহিমা-মাহজাবীন-db8c7b-6922d996933eb65569dff2ec)

### সিটিজেন ইনোভেশন

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/182ad4da6b4b4401965fea7721821897.jpg)

নাম

মোঃ নাহিদ আলম

পদবি

সিনিয়র কনসালটেন্ট (এটুআই ইনোভেশন ফান্ড)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

nahid.alam@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৫৫০-০২০৪৪৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-নাহিদ-আলম-636a9e-6922d9ab933eb65569dff61e)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/8ff22ed825cf47ce846844a5d9828cf7.jpg)

নাম

মোঃ শুয়াইব শাহরিয়ার রুশো

পদবি

জুনিয়র কনসালটেন্ট (এটুআই ইনোভেশন ফান্ড)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

shuaib.rusho@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৮৭৭০৩৮৪২৪

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-শুয়াইব-শাহরিয়ার-রুশো-91612a-6922df63933eb65569e21a8c)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/5b7928c6d8c34e6696116719c7af83d3.jpg)

নাম

জ্যোতির্ময় সিনহা

পদবি

জুনিয়র কনসালটেন্ট (এটুআই ইনোভেশন ফান্ড)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

jotirmoy.sinha@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬৭৭৬৯৫৪৩৩

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/জ্যোতির্ময়-সিনহা-8b1b3a-6922de2a933eb65569e18b5c)

৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/5569bfab580b43fa9654f6001605c09c.jpg)

নাম

মোঃ আব্দুল্লাহ আল মামুন

পদবি

জুনিয়র কনসালটেন্ট (ইনোভেশন ল্যাব)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

mamun.abdullah@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৭৯৭৮৭২৯৭

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-আব্দুল্লাহ-আল-মামুন-f7eda7-6922e182933eb65569e2c6e4)

৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/97186b71cb2b4fc69d982e0dbda9c31b.jpg)

নাম

মো: তাফহীম সাদমান ইসলাম

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

sadman.islam@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৮৭৪২৬৩৩১৭

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মো-তাফহীম-সাদমান-ইসলাম-1a9ed3-6922d9b8933eb65569dffa23)

### ডাটা

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/f0313f79092947e5950ccdcd6c52f397.jpg)

নাম

মোঃ আনোয়ারুল আরিফ খান

পদবি

সিনিয়র কনসালটেন্ট (ডেটা )

অফিস

এসপায়ার টু ইনোভেট

ইমেইল

anowarul.arif@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৫৫-৫৮৯৯০০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-আনোয়ারুল-আরিফ-খান-b0aab5-6922dd6b933eb65569e14f98)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/965f1922eb764af9aa0ae061c2a6c8c0.jpg)

নাম

মোঃ শেখ সাঈদী

পদবি

কনসালটেন্ট (ডেটা ও এসডিজি)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

sheikh.saidy@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬৭০-৯২৮৮৯৬

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-শেখ-সাঈদী-45bd59-6922da0c933eb65569e0217c)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/523e74cfdf384e7bb9ef81ddacfdaf83.jpg)

নাম

জিনিয়া আলম

পদবি

জুনিয়র কনসালটেন্ট (ডেটা ও এসডিজি)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

jinia.alam@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৫৮-৮১৭৪৫৬

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/জিনিয়া-আলম-755ae0-6922deb9933eb65569e1ce44)

৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/8c0b246483904b78856f82a7c3fe38f5.png)

নাম

মোঃ জাকি ফয়সাল

পদবি

জুনিয়র কনসালটেন্ট (ডেটা ও এসডিজি)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

zaki.faisal@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৫৮-৩৮৯০৮০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-জাকি-ফয়সাল-863374-6922ddd6933eb65569e168ec)

৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/23c9191e936045d4936ec0567e52932d.jpg)

নাম

মোঃ আশরাফুল ইসলাম

পদবি

জুনিয়র কনসালটেন্ট (মাইগভ)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

ashraful.islam@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৪৫-৯৩৬৭৪৩

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-আশরাফুল-ইসলাম-08a9ed-6922db8f933eb65569e0ae14)

৬

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/600a5a3abb904c70aff46619688cb8b5.JPG)

নাম

রিফাত-ই-জাহান সিদ্দীকী

পদবি

জুনিয়র কনসালটেন্ট (ডাটা)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

rifat.jahan@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৫২১-২০৮৯৮৮

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/রিফাত-ই-জাহান-সিদ্দীকী-a36eeb-6922de55933eb65569e19ec6)

৭

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2026/0/c4e50f4f-af95-41aa-a447-2995edf89b58.jpg)

নাম

আরেফিন মিজান

পদবি

জুনিয়র কনসালটেন্ট (ডেটা ও এসডিজি)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

arefin.mizan@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮০১৫৫২৫৪৩৪৫৩

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/জুনিয়র-কনসালটেন্ট-ডেটা-ও-এসডিজি-205u5b-696e0ffaf654379dc9c3be60)

৮

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2026/4/88ddb5ae-f1ae-4ddd-8266-51bf5254bead.jpeg)

নাম

অনিক কুমার পাল

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

anik.kumar@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৮৫৭-৩০৯০২৬

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/অনিক-কুমার-পাল-f0a1ca-6922dfc5933eb65569e23e69)

৯

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/8d3a2f4525504f8f8c14afb6171d0fee.jpg)

নাম

ইসমত জাহান খান বৃষ্টি

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

esmat.khan@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬৪২-৪২০৩৬২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ইসমত-জাহান-খান-বৃষ্টি-6bd483-6922de6f933eb65569e1a9c8)

১০

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/9c5ce229713b49e6aa79faa6be65997d.jpg)

নাম

মশিউল হক

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

moshiul.hoque@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৮৭৭৬০৬২৩২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মশিউল-হক-f98fa3-6922e03a933eb65569e26183)

### হেলথ ইনোভেশন

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/695484412f364a35b68ccc94e144aab4.JPG)

নাম

মোঃ আনোয়ারুল আরিফ খান

পদবি

সিনিয়র কনসালটেন্ট (ডেটা )

অফিস

এসপায়ার টু ইনোভেট

ইমেইল

anowarul.arif@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-আনোয়ারুল-আরিফ-খান-b2117b-6922d8d1933eb65569dfa2e4)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/85252ca4503841f99643eb473d02e580.jpeg)

নাম

শবনম মোস্তারী

পদবি

প্রোজেক্ট এনালিস্ট

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

shabnam.mostari@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬১১১৪৯৯৪২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/শবনম-মোস্তারী-dd8e0f-6922e08a933eb65569e277b2)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/64137622dd2b490d8bbd9ba0cd45a6df.jpg)

নাম

আফেলা জাবীন

পদবি

জুনিয়র কনসালটেন্ট (হেল্‌থ ইনোভেশন)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

afela.jabin@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৫২০-০৮৩২০৬

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/আফেলা-জাবীন-c577fb-6922d916933eb65569dfc727)

৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/16259608fe124703b81064b7d090d6b1.jpg)

নাম

মো. শাহিন সিকদার

পদবি

ইয়াং প্রোফেশনাল

অফিস

এসপায়ার টু ইনোভেট

ইমেইল

shahin.sikder@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭১০-২৯০৫০৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মো-শাহিন-সিকদার-0fa8d4-6922de1b933eb65569e184dd)

### রিসার্চ

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/6158b3000a7d4c818abdc7f11f9be75d.JPG)

নাম

মোঃ আনোয়ারুল আরিফ খান

পদবি

সিনিয়র কনসালটেন্ট (ডেটা )

অফিস

এসপায়ার টু ইনোভেট

ইমেইল

anowarul.arif@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৫৫-৫৮৯৯০০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-আনোয়ারুল-আরিফ-খান-dddab3-6922d8e6933eb65569dfb0c0)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/72992e0432b24bd4a2d4350edb910282.JPG)

নাম

মেরাজ আহমেদ

পদবি

কনসালটেন্ট (রিসার্চ)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

meraz.ahmed@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭২০-৩৪৩৩০১

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মেরাজ-আহমেদ-1662b4-6922de85933eb65569e1b417)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/353f3071594b49a4a528f1b3d177cb09.jpg)

নাম

মো. আমরান হোসেন

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

amran.hossain@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৯৯৮-৪৫৩৬১৬

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মো-আমরান-হোসেন-7d7c64-6922df5f933eb65569e218aa)

৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/68bce25de79046eebdf6cb04c3495b13.jpg)

নাম

নিলয় সরকার

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

niloy.sarker@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৮৫২-২২৬৫৪২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/নিলয়-সরকার-8c4857-6922e003933eb65569e250bf)

### ইন্টারন্যাশনাল পার্টনারশীপ

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/9b80f27c48c64256926b28add2bd905c.png)

নাম

এ কে সাব্বির মাহবুব

পদবি

ন্যাশনাল কন্সালট্যান্ট - ইন্টারন্যাশনাল কো-অপারেশন্স ও রিসোর্স মোবিলাইজেশন

অফিস

এসপায়ার টু ইনোভেট

ইমেইল

ak.sabbir@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭১৩-২৪৯৭৫০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/এ-কে-সাব্বির-মাহবুব-3093fa-6922da9a933eb65569e05a6e)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/aa81678351aa4a77adf6a446a73a5dd4.jpg)

নাম

মোঃ তৌহিদুল আবেদীন

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

touhidul.abedin@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৮৫৯০৮৭২৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-তৌহিদুল-আবেদীন-5c3227-6922e288933eb65569e2f111)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/f2064e5a0f834911a049feb4f4d32802.jpg)

নাম

ফাতিন হাসনাত রহমান সেতু

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট

ইমেইল

fatin.hasnat@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

১৬৮৮০৯১৮৫৪

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ফাতিন-হাসনাত-রহমান-সেতু-f02d37-6922d951933eb65569dfe41b)

### রিসোর্স মোবিলাইজেশন

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/548bc4ba6bc3413cb478fbe8d747d59e.png)

নাম

এ কে সাব্বির মাহবুব

পদবি

ন্যাশনাল কন্সালট্যান্ট - ইন্টারন্যাশনাল কো-অপারেশনস ও রিসোর্স মোবিলাইজেশন

অফিস

এসপায়ার টু ইনোভেট

ইমেইল

ak.sabbir@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭১৩-২৪৯৭৫০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/a-k-sabbir-mahbub-1ec3c1-6922e195933eb65569e2cba4)

### ফিউচার অফ এডুকেশন

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/e8c14f10d85f4a4780a8a8fb069de1c7.jpg)

নাম

মির্জা মোহাম্মদ দিদারুল আনাম

পদবি

সহযোগী অধ্যাপক ও সংযুক্ত কর্মকর্তা (শিক্ষা বিশেষজ্ঞ)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

mirza.didarul@a2i.gov.bd

ফোন (অফিস)

০১৭৩৩-৮৮৫৩৩০

ইন্টারকম

কক্ষ নম্বর

মোবাইল

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মির্জা-মোহাম্মদ-দিদারুল-আনাম-e2dc62-6922e1cd933eb65569e2d7b7)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/dbfca4cc59fa46df99afc6fcbc848568.jpg)

নাম

মোঃ সাজ্জাদ হোসেন খান

পদবি

সহকারী অধ্যাপক ও সংযুক্ত কর্মকর্তা। এডুকেশন এক্সপার্ট

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

khan.sazzad@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৮৪-৩৮৭৪১৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-সাজ্জাদ-হোসেন-খান-27db16-6922dc93933eb65569e11086)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/7047a9767f22456290278ff308eb5b6d.jpg)

নাম

আবদুল্লাহ আল মামুন

পদবি

জুনিয়র কনসালটেন্ট (ফিউচার অফ এডুকেশন)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

abdullah.mamun@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৫১৬৭৫৮৪৪৬

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/আবদুল্লাহ-আল-মামুন-410be6-6922e0c1933eb65569e287a0)

৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2026/3/08de21bb-be2b-41d5-8eee-c8e7d2dbf5a7.png)

নাম

মোঃ সাইফুর রহমান

পদবি

জুনিয়র কনসালট্যান্ট (ফিউচার অফ এডুকেশন)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

saifur.rahman@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬৭০৮৬৫৫৮৭

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-সাইফুর-রহমান-ee1e81-6922d8dd933eb65569dfab9b)

৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/700f436cfa32494395942ec9a9b055ff.jpg)

নাম

জাওহার নুসরাত বিনা

পদবি

জুনিয়র কনসালটেন্ট (ফিউচার অফ এডুকেশন)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

jaohar.bina@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

১৬৮৮৬১০০৬৪

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/জাওহার-নুসরাত-বিনা-dedcdc-6922d95f933eb65569dfe76e)

৬

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2026/2/e5d39ac1-d5f9-4e13-839c-0b45d1120405.jpeg)

নাম

ফারিহা হোসেন মুমু

পদবি

ইয়াং প্রোফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

fariha.hossain@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৫২৯৬২৭২১

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ফারিহা-হোসেন-মুমু-fb6f3e-6922db36933eb65569e08ed9)

৭

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/a6db28a67c0b419fb1ec70d96b0911ad.jpg)

নাম

সামিয়া সুলতানা

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

samia.sultana@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

১৮৩৯৩৩৬৪০৭

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/সামিয়া-সুলতানা-85afee-6922dc83933eb65569e10c25)

### ফিউচার অফ ওয়ার্ক

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2026/2/b504fb03-a431-4ce1-b219-f4d01254e838.jpeg)

নাম

সালাহউদ্দিন মোহাম্মদ উজ্জ্বল

পদবি

কনসালটেন্ট (ফিউচার অফ ওয়ার্ক)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

salahuddin.mohammad@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭১১৭৮৬৪৭১

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/সালাহউদ্দিন-মোহাম্মদ-উজ্জ্বল-z34abx-699aba05968ccd0505307949)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/8441d17b96d3485b8c4e6a0feef3ad42.JPG)

নাম

মোঃ হাবিবুর রহমান

পদবি

জুনিয়র কনসালটেন্ট (ফিউচার অফ ওয়ার্ক)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

habibur.rahman@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৯১১৪৩৮৯২৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-হাবিবুর-রহমান-ea06fd-6922d8e0933eb65569dfad3a)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/c5d507af211c4dab9eff486625c07a3e.jpg)

নাম

আলাভী জামান দিশা

পদবি

জুনিয়র কনসালটেন্ট (ফিউচার অফ ওয়ার্ক)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

alavi.zaman@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬৮২১৬১৬২২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/আলাভী-জামান-দিশা-cb1cac-6922e21a933eb65569e2e3a0)

৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/6407cdbcf11e4e0bb9a7852463682be1.jpg)

নাম

তালাল তাকী

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

talal.taki@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬৮৭০৬৫৮৫৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/তালাল-তাকী-8ccaad-6922dbf9933eb65569e0dbf3)

### জুডিসিয়ারি

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/40f93a3fa87f4d9bb4f9677ce092720d.jpg)

নাম

মোঃ আবদুল্লাহ আল আমিন ভূঁইয়া

পদবি

অতিরিক্ত জেলা জজ (সংযুক্ত কর্মকর্তা)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

abdullah.alamin@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৪৯০৭২০৫০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-আবদুল্লাহ-আল-আমিন-ভূঁইয়া-e5f76f-6922d8e3933eb65569dfaf48)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/1aa596074e2b46bd83af3426849cee7f.jpg)

নাম

শাহীন আহমেদ সাদ

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

shahin.ahmed@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৯৫৭১১৫৭১৩

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/শাহীন-আহমেদ-সাদ-feea19-6922e1cb933eb65569e2d76f)

### কমিউনিকেশন'স

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/3c0b707016c040a284196daa5f5cb9f2.jpg)

নাম

মোহাম্মদ সফিউল আযম

পদবি

কনসালটেন্ট (কমিউনিকেশনস)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

safiul.azam@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৫৫২৩৮৬৭২৬

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোহাম্মদ-সফিউল-আযম-a5fb29-6922dd32933eb65569e13e49)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2026/0/94a4976a-a0ce-4ecb-b78d-fa5517c27c4a.jpeg)

নাম

খালেদ আরাফাত

পদবি

গ্রাফিক ডিজাইনার

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

khaled.arafat@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬৭৬-৬৫৫৮৫৮

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/খালেদ-আরাফাত-86e2e8-6922dccd933eb65569e121f2)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/84bae058d9644355b708115312911930.jpg)

নাম

সাদিয়া তাবাসসুম

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট

ইমেইল

sadia.tabassum@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৩৯-০৩৩২৪৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/সাদিয়া-তাবাসসুম-0addf5-6922dacb933eb65569e06a71)

৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/be7e8121af854217ada4fd3eca97bcd1.jpg)

নাম

নাসিফ আস সামী আহমেদ

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

nasif.oishik@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৩১৯১৯৫৫০১

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/নাসিফ-আস-সামী-আহমেদ-446e44-6922e0c2933eb65569e287b7)

### প্রকিউরমেন্ট

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2026/5/1b139252-e69b-45b5-b4b9-958ec64ff01d.jpg)

নাম

মোঃ রশিদুল মান্নাফ কবীর

পদবি

যুগ্ম প্রকল্প পরিচালক (যুগ্মসচিব), কম্পোনেন্ট- ২, ৩

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

jpd.ict@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭১২-২৫৫৭০০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-রশিদুল-মান্নাফ-কবীর-7fzbgu-6a21278bffeb882b6871280d)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/15f89b52dcc94561ae4632466c75198b.jpg)

নাম

মীর তাওসীফ-উল-হাসান

পদবি

জুনিয়র কনসালটেন্ট (প্রকিউরমেন্ট)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

tauseef.hasan@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৯১৩-৯১৬৯৮৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মীর-তাওসীফ-উল-হাসান-e86fcc-6922e023933eb65569e25a97)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/dc148890a4d543b98306f4a0867d8b59.jpg)

নাম

সাজ্জাত হোসাইন খান

পদবি

জুনিয়র কনসালটেন্ট (প্রকিউরমেন্ট)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

sazzat.hossain@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭১১-৭৩৫৭০৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/সাজ্জাত-হোসাইন-খান-e99e9b-6922df56933eb65569e214a8)

৪

নাম

মালিহা নাজনীন

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

maliha.naznin@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬৮৬-৭৬৮৮০৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মালিহা-নাজনীন-c120cf-6922dfd7933eb65569e2445b)

৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/376b92dd65f74efcb2002009aadb5cd6.jpg)

নাম

শামছুত্ত্বিরীজ রিয়াদ

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

riad.tibriz@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৩৯-৭৩১১৯৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/শামছুত্ত্বিরীজ-রিয়াদ-4422ce-6922dfce933eb65569e24112)

৬

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/aced610f58bc4ed29559644e58acff2f.jpg)

নাম

মো. সাব্বির হোসেন

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

sabbir.hossain@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৭০-০৬৬২৯০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মো-সাব্বির-হোসেন-e09d90-6922da59933eb65569e03e62)

৭

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/2848520930ca446b8f8fb0ae3f4bb623.jpg)

নাম

ইশমাম মাহমুদ

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

ishmam.mahmud@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৮৭১-০৫৯৫৬৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ইশমাম-মাহমুদ-a7babf-6922dbd4933eb65569e0cd89)

### পিপল এন্ড কালচার

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/4bc9aea8e957469192cda8cd7d4d6138.jpeg)

নাম

মোহাম্মদ আরিফুর রহমান

পদবি

কনসালটেন্ট (হিউম্যান রিসোর্সেস)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

arifur.rahman@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৩১৩-৩৪৭৯৩১

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোহাম্মদ-আরিফুর-রহমান-1593a2-6922de78933eb65569e1ad8a)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2026/4/07e81cb0-0f22-450b-a403-8e3ffa91e8db.jpeg)

নাম

জান্নাতুল ফেরদৌস সুরমা

পদবি

জুনিয়র কনসালটেন্ট (হিউম্যান রিসোর্সেস)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

jannatul.surma@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৪৫-৪৪২১৫৮

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/জান্নাতুল-ফেরদৌস-সুরমা-fc8802-6922d9ed933eb65569e01184)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/cb60c7f588b74cccb5050079629f3ba4.jpeg)

নাম

মোঃ শাহরুখ সাহিদ

পদবি

জুনিয়র কনসালটেন্ট (হিউম্যান রিসোর্সেস)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

shahrookh.shahid@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬৩৪-৪০৭০৬৬

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-শাহরুখ-সাহিদ-bf35a2-6922e02d933eb65569e25dd0)

৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/d3afb9760a5243faa81ed9a6272e88e9.png)

নাম

তাসনিমা তারান্নুম

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

tasnima.tarannum@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭২৯৬১৩৯৮০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/তাসনিমা-তারান্নুম-708bfd-6922e112933eb65569e2a061)

### টেকনোলোজি

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/c8b2ef6567a34f5d8edc8c42efbe84f0.jpg)

নাম

মোহাম্মদ মাসুদুর রহমান

পদবি

সিনিয়র কন্সাল্টেন্ট (চিফ টেকনিক্যাল এডভাইজর)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

masud.rahman@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৩০৭-৫২১০৪৬

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোহাম্মদ-মাসুদুর-রহমান-f342cc-6922d9c2933eb65569dffed6)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/f34f823428824ec3b8f879c90c3e535f.jpg)

নাম

মোঃ মেহেদী হাসান ভুঁইয়া

পদবি

কনসালটেন্ট (সলিউশন আর্কিটেক্ট)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

mehedi.hasan@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৮১৯২১০৮৫৬

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-মেহেদী-হাসান-ভুঁইয়া-d5f5c5-6922da51933eb65569e03a2e)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/c5d5962153ce4093b6c00d7920f45f37.jpg)

নাম

মোহাম্মদ ইউনূস আলী সরদার

পদবি

কনসালটেন্ট (টেকনোলজি)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

younus.ali@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৯৩৭-২৫২২৯২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোহাম্মদ-ইউনূস-আলী-সরদার-d35895-6922e1db933eb65569e2da5c)

৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/e5b1077a170f474f82adb46ecef5c15f.jpg)

নাম

আনিসুজ্জামান

পদবি

কনসালটেন্ট (ডেভঅপস ইঞ্জিনিয়ার)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

anis.zaman@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৯০৬-৯৯৪৪৮৭

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/আনিসুজ্জামান-74be8d-6922dbd4933eb65569e0cd46)

৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/0c9b60ba235a42f58efd653fdfb026a9.jpg)

নাম

মোঃ আনিছুর রহমান

পদবি

কনসালটেন্ট (সফটওয়্যার ইঞ্জিনিয়ার)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

anisur.rahman@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৯৬২-৪২৪৪৩৭

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-আনিছুর-রহমান-9c7cfb-6922ddf7933eb65569e1759f)

৬

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/0658f5c9fa004b7b860084405eb21cf8.jpeg)

নাম

মোঃ মাহমুদুল হাসান সোহাগ

পদবি

কনসালটেন্ট (ন্যাশনাল পোর্টাল)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

mahamudul.hasan@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭০০-৯৯৭৬৭৬

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-মাহমুদুল-হাসান-সোহাগ-b4374b-6922e160933eb65569e2bcb2)

৭

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/48aed89145954ce08da35f18e4ddcc19.jpg)

নাম

ফাহিম বিন মোমেন

পদবি

কনসালটেন্ট (সফটওয়্যার ইঞ্জিনিয়ার)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

fahim.momen@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬১২-৫২৪৮২৬

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ফাহিম-বিন-মোমেন-a76688-6922d8e3933eb65569dfaf2b)

৮

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/ee14d6c1453c42c999b7086d997028e6.jpg)

নাম

মাসুদ রানা

পদবি

কনসালটেন্ট (সফটওয়্যার ইঞ্জিনিয়ার)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

rana.masud@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭২২-৮৬৮৬৩৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মাসুদ-রানা-a6652f-6922dc6a933eb65569e103b3)

৯

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/f76d1ad212824b8a89e89833eded0437.jpg)

নাম

মোহাম্মদ নাজিম উদ্দীন আল মামুন

পদবি

ন্যাশনাল কনসালটেন্ট ফর ইনফ্রাস্ট্রাকচার ডেভেলপমেন্ট

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

nazimuddin.mamun@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৫৫২-৩২৯৩৮৮

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোহাম্মদ-নাজিম-উদ্দীন-আল-মামুন-6ff020-6922d99c933eb65569dff3e1)

১০

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/8465d02007974140bf3dfc84c47fb7a9.jpg)

নাম

মোঃ তানজিলুর রহমান

পদবি

সিকিউরিটি এক্সপার্ট

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

tanjilur.rahman@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭০৭-৮০০৩১৪

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-তানজিলুর-রহমান-831365-6922decc933eb65569e1d714)

১১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/f4b373c2b84b4233816b221688a962f6.jpg)

নাম

মোঃ সানাউল্লাহ

পদবি

জুনিয়র কনসালটেন্ট (সফটওয়্যার ইঞ্জিনিয়ার)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

md.sanaullah@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭১২-৬১৬০৫৭

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-সানাউল্লাহ-e5b048-6922e2ff933eb65569e305b2)

১২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/d3da82a361184b9998a2b1409803bf42.jpg)

নাম

সুদীপ্ত দে অনিক

পদবি

সিকিউরিটি ইঞ্জিনিয়ার

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

anik.sudipta@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৮৪০-০৩৬৪২৬

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/সুদীপ্ত-দে-অনিক-318a2f-6922de34933eb65569e18ff3)

১৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/a8b4a59f075b4218877634cc5306a924.jpg)

নাম

ফারজানা আক্তার

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

farzana.akter@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৮৬৯৩৪১০০৪

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ফারজানা-আক্তার-88fc77-6922db05933eb65569e07fef)

১৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/3439bbd2f87845889c9e71efd87034d8.jpg)

নাম

তাওহিদা বিনতে কবির

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

tawhida.kabir@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬২৪০৪৮৪৮৮

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/তাওহিদা-বিনতে-কবির-29d58e-6922d961933eb65569dfe7ff)

১৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/a5bc0c273ba9492ebd06fe80fae81422.jpg)

নাম

ফয়সাল আহম্মেদ তন্ময়

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

faisal.tonmoy@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৫২১২০০২৩৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ফয়সাল-আহম্মেদ-তন্ময়-c1eced-6922df9a933eb65569e22fc2)

১৬

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/36117f3f8b5b493096f52a250bf7fd05.JPG)

নাম

আরিফুর রহমান

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

rahman.arifur@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬২৬৩৭৬৭৫৪

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/আরিফুর-রহমান-168fd6-6922df75933eb65569e221a4)

১৭

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/cce5d648ec0a4e4ab7f27417c3065ec9.JPG)

নাম

মোঃ সাইদুর রহমান

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

saydur.rahman@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭০৩৬৩৯০৯১

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-সাইদুর-রহমান-759796-6922d8f1933eb65569dfb684)

১৮

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/dc11576383f3485eafd2f7385f72fc09.jpg)

নাম

মোঃ রেজওয়ানুল হক

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

razuanul.haque@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৫১৯৬৬৮৯১

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-রেজওয়ানুল-হক-91703b-6922d96b933eb65569dfea0b)

১৯

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/9e0f3d412c6c4d7b9be9635ccd7961d9.jpg)

নাম

নাইমুর রহমান

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

naimur.rahman@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৯-২১২০১১৩৮

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/নাইমুর-রহমান-d753ed-6922e1ac933eb65569e2d119)

২০

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/da640799f9f347e08a2a3059e8c0826e.jpg)

নাম

সুমাইয়া ইসলাম মীম

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

sumiya.islam@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬৩২০৫১৫০৮

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/সুমাইয়া-ইসলাম-মীম-f64fb0-6922d8cc933eb65569dfa02b)

২১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/98789ed5a1f841bb98cfdef74565b2df.jpg)

নাম

মোঃ আব্দুল মোতালেব অন্তর

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

abdul.motaleb@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭-৯৫৯৩৭৭৩৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-আব্দুল-মোতালেব-অন্তর-2f1ead-6922e099933eb65569e27c29)

২২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/6043072b387b4e7f8c3bf231541cac8c.jpg)

নাম

মোঃ সাকিব হাসান রুদ্র

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

shakib.hasan@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭১-৬৩০৭৩৪৩

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-সাকিব-হাসান-রুদ্র-9a907d-6922da2c933eb65569e02e4a)

২৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/d0e323617faa4228b0460f55942c7ce0.jpg)

নাম

মোঃ জুয়েল রানা

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

jewel.rana@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭০৫-৮৩০৬৯৩

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-জুয়েল-রানা-86e2ae-6922e1ca933eb65569e2d748)

২৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/ddecefb948114a7592feacc57ea43259.jpg)

নাম

মোঃ নূরনবি

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

nur.nobi@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৮৬-৮৯৪৭৫৪৬

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-নূরনবি-cb4965-6922d8da933eb65569dfa98d)

২৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/d7a2018f6f67452f9ef373dc8154df6b.jpg)

নাম

আয়েশা আক্তার তন্বী

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

aisha.akter@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৭৬-১৭৫৫৫২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/আয়েশা-আক্তার-তন্বী-a5096a-6922de4f933eb65569e19c27)

### ফাইন্যান্স & একাউন্টস

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/36e4a3e9f770400b8210943075f84fce.jpg)

নাম

মোঃ নাহিদ আলম

পদবি

সিনিয়র কনসালটেন্ট (এটুআই ইনোভেশন ফান্ড) (অতিরিক্ত দায়িত্ব - হেড অফ অপারেশন্স)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

nahid.alam@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৫৫০-০২০৪৪৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-নাহিদ-আলম-b7cbc4-6922d9b5933eb65569dff88e)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/68a654e9621c4942b50ec5beff205f7b.jpg)

নাম

মোঃ আতিকুল ইসলাম

পদবি

কনসালটেন্ট (ফাইন্যান্স)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

md.atiqul@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৩০৩৩৫২৩৭

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-আতিকুল-ইসলাম-af8f2a-6922de9b933eb65569e1bf24)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/01d759998bde41919e628341b09360c4.jpeg)

নাম

মোঃ জাহাঙ্গীর আলম

পদবি

ফাইন্যান্স অফিসার

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

jahanger.alam@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭১৮-৭৫৮০৮০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-জাহাঙ্গীর-আলম-62448b-6922d911933eb65569dfc4cd)

৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/e86ab0fce10343bfae18950213b18c7a.jpg)

নাম

মো: আবু হাসান

পদবি

জুনিয়র কনসালটেন্ট (ফাইন্যান্স)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

abu.hasan@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৩৪৬৬৯০৭৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মো-আবু-হাসান-912981-6922d96d933eb65569dfeaa9)

৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/d888dd4b033e4d2bb326b57aa2d5483d.jpg)

নাম

ইউনুস আলী রাকিব

পদবি

জুনিয়র কনসালটেন্ট (ফাইন্যান্স)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

rakib.younus@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৮৫০-১১৫৫৭২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ইউনুস-আলী-রাকিব-2b4c6d-6922e2ad933eb65569e2f4f5)

৬

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/09bfd505e60147ae93901d3a7202698f.jpeg)

নাম

এলা বিশ্বাস

পদবি

জুনিয়র কনসালটেন্ট (ফাইন্যান্স)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

ella.biswas@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৬৮২৬৪৫৫৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/এলা-বিশ্বাস-ae1598-6922df81933eb65569e226dc)

৭

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/f8e288b6577f41e48bdd8c4451b2393d.jpg)

নাম

মোঃ হাফিজুর রহমান

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

mrahman.hafizur@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৯২৭২৫২৫৭

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-হাফিজুর-রহমান-956b82-6922da3b933eb65569e0339d)

৮

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/522cd6686f6e4900b1c828666d642ca1.jpeg)

নাম

মোঃ আতিকুল ইসলাম

পদবি

ইয়াং প্রফেশনাল

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

atiqul.islam@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৩২৪৩৪০১৩২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-আতিকুল-ইসলাম-20ab8d-6922de21933eb65569e1873b)

### এডমিন

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/1092b096c7664767892b89efbfb9301b.jpg)

নাম

মোঃ নাহিদ আলম

পদবি

সিনিয়র কনসালটেন্ট (এটুআই ইনোভেশন ফান্ড) (অতিরিক্ত দায়িত্ব - হেড অফ অপারেশন্স)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

nahid.alam@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৫৫০-০২০৪৪৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-নাহিদ-আলম-fbcad3-6922db7c933eb65569e0a59c)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2026/1/e80c6979-df98-4a45-a92d-479185755390.jpg)

নাম

হোসাইন আহমেদ সায়মন

পদবি

কনসালটেন্ট (সফটওয়্যার ইঞ্জিনিয়ার)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

hossain.ahmed@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬৭০৯১১৭৪৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/হোসাইন-আহমেদ-সায়মন-ce3f9f-6922db5d933eb65569e09ae2)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/45d0f8d20e914ab69dd753492ad5c873.jpg)

নাম

মোহাম্মদ শাহজালাল

পদবি

জুনিয়র কনসালটেন্ট (অপারেশন্স)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

sahajalal.muhammed@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭১৩৩৮০৩১০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোহাম্মদ-শাহজালাল-d24549-6922d94e933eb65569dfe307)

৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2026/6/839cab23-634c-49be-9779-ab55e6a037c4.jpg)

নাম

আবু সালেহ

পদবি

জুনিয়র কনসালটেন্ট (এডমিন আইটি)

অফিস

এসপায়ার টু ইনোভেট (এটুআই)

ইমেইল

abu.saleh@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭১৭৭৩১১৯৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/জুনিয়র-কনসালটেন্ট-এডমিন-minjgv-6a45e06776ab4c32100a063e)

৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/e8293eb40ccc43359447cb3ae91c37e7.jpg)

নাম

মার্ক উৎস বৈদ্য

পদবি

ইয়ং প্রোফেশনাল

অফিস

এসপায়ার টু ইনোভেট

ইমেইল

mark.baidya@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬০৮-৯০২৩৩৭

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মার্ক-উৎস-বৈদ্য-6c9309-6922de15933eb65569e181ed)

৬

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/dc0ddb65058743de90a0f23bee2236a8.jpeg)

নাম

মোঃ রোমান মিয়া

পদবি

প্রোজেক্ট এসিস্ট্যান্ট

অফিস

এসপায়ার টু ইনোভেট

ইমেইল

roman.mia@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬৮৪-৯৫৪০৪৪

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-রোমান-মিয়া-71771c-6922db4a933eb65569e093d5)

৭

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2026/2/25b7f77d-c24e-41b8-90d2-2627f7cede50.jpeg)

নাম

মোঃ আলি মর্তুজা

পদবি

প্রোজেক্ট এসিস্ট্যান্ট

অফিস

এসপায়ার টু ইনোভেট

ইমেইল

ali.mortuja@a2i.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৯১১-৫৫৪৪৪০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-আলি-মর্তুজা-60fcdb-6922ded2933eb65569e1da28)

-   ১
-   পৃষ্ঠায় যান 

আর্কাইভ দেখুন প্রকাশিত দেখুন দেখছেন ১ থেকে ১৯৮ পর্যন্ত, মোট ১৯৮ এন্ট্রি

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

### এক্সেসিবিলিটি

ফন্ট বৃদ্ধি ফন্ট হ্রাস

 মনোক্রোম

 ইনভার্ট

 বড় কার্সর

 লিঙ্ক হাইলাইট

 শিরোনাম হাইলাইট

 পড়ার গাইড

রিসেট

[স্ক্রিন রিডার ডাউনলোড করুন](https://www.nvaccess.org/files/nvda/releases/2020.4/nvda_2020.4.exe)

[কন্টেন্টে চলে যান](#main-content) [এক্সেসিবিলিটি মেনুতে যান](#accessibility-card-title)