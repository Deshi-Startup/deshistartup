---
source: "a2i / Aspire to Innovate"
tier: 1
category: "Innovation program"
url: "https://a2i.gov.bd/pages/tenders"
title: "টেন্ডার (দরপত্র) | এসপায়ার টু ইনোভেট (এটুআই)"
scraped_at: "2026-07-02"
---

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

## টেন্ডার (দরপত্র)

 এডভান্সড অপশনগুলো দেখান

গ্রুপ অনুসারে কিছুই না শিরোনাম,দরপত্র নং,দরপত্রের ধরণ,প্রকাশের তারিখ

পৃষ্ঠা আইটেম ১০ ২০ ৫০ ১০০

নং

শিরোনাম

দরপত্র নং

দরপত্রের ধরণ

ফাইল সমূহ

প্রকাশের তারিখ

কার্যকলাপ

 

 

 

   

 

১

e-Tender Notice for "Annual Maintenance Contract (AMC) for Server and Storage Systems for D-Nothi, Located at the Tier-4 Data Center, Kaliakair"

1

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2026/5/d5112d64-d01c-48ad-9905-7cffa232778d.pdf "office-a2i/2026/5/d5112d64-d01c-48ad-9905-7cffa232778d.pdf")

৩০-০৬-২০২৬

[দেখুন](/pages/tenders/e-tender-notice-for-annual-maintenance-contract-amc-for-server-and-storage-systems-for-d-nothi-located-at-the-tier-4-data-center-kaliakair-z4waec-6a439802c2af96278a520fe9)

২

e-Tender Notice for "Framework agreement of Toner items for the official use of a2i Programme"

1

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2026/5/9fb30548-bbaa-4730-95a6-909034099d9e.pdf "office-a2i/2026/5/9fb30548-bbaa-4730-95a6-909034099d9e.pdf")

২৫-০৬-২০২৬

[দেখুন](/pages/tenders/e-tender-notice-for-framework-agreement-of-toner-items-for-the-official-use-of-a2i-programme-vm9rpf-6a3cdedd305a00ac84107d61)

-   ১
-   পৃষ্ঠায় যান 

আর্কাইভ দেখুন প্রকাশিত দেখুন দেখছেন ১ থেকে ২ পর্যন্ত, মোট ২ এন্ট্রি

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

### এক্সেসিবিলিটি

ফন্ট বৃদ্ধি ফন্ট হ্রাস

 মনোক্রোম

 ইনভার্ট

 বড় কার্সর

 লিঙ্ক হাইলাইট

 শিরোনাম হাইলাইট

 পড়ার গাইড

রিসেট

[স্ক্রিন রিডার ডাউনলোড করুন](https://www.nvaccess.org/files/nvda/releases/2020.4/nvda_2020.4.exe)

[কন্টেন্টে চলে যান](#main-content) [এক্সেসিবিলিটি মেনুতে যান](#accessibility-card-title)