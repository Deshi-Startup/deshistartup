---
source: "a2i / Aspire to Innovate"
tier: 1
category: "Innovation program"
url: "https://a2i.gov.bd/pages/notices"
title: "নোটিশ | এসপায়ার টু ইনোভেট (এটুআই)"
scraped_at: "2026-07-02"
---

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

## নোটিশ

 এডভান্সড অপশনগুলো দেখান

গ্রুপ অনুসারে কিছুই না শিরোনাম,প্রকাশের তারিখ

পৃষ্ঠা আইটেম ১০ ২০ ৫০ ১০০

নং

শিরোনাম

ফাইল সমূহ

ইমেজ

প্রকাশের তারিখ

কার্যকলাপ

 

   

   

 

১

এটুআই ইনোভেশন ফান্ডের আওতায় অনুষ্ঠিত প্রেগন্যান্সি মনিটরিং ইনোভেশন চ্যালেঞ্জ ২০২২ প্রতিযোগিতার একটি উদ্ভাবনী উদ্যোগের চুক্তি অকার্যকর ঘোষণা

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/6f4f5de3e207429c9fbba7d041538540.pdf "office-a2i/2024/12/6f4f5de3e207429c9fbba7d041538540.pdf")

১৬-১১-২০২৫

[দেখুন](/pages/notices/এটুআই-ইনোভেশন-ফান্ডের-আওতায়-অনুষ্ঠিত-প্রেগন্যান্সি-মনিটরিং-ff1e9f-6922dbcedbfbab28ce05c09d)

২

এটুআই ইনোভেশন ফান্ডের আওতায় অনুষ্ঠিত হেলথ চ্যালেঞ্জ ফান্ড-২০২০ প্রতিযোগিতার একটি উদ্ভাবনী উদ্যোগের চুক্তি অকার্যকর ঘোষণা

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/ecac0c2eed744bfba6c661410731450c.pdf "office-a2i/2024/12/ecac0c2eed744bfba6c661410731450c.pdf")

১৬-১১-২০২৫

[দেখুন](/pages/notices/এটুআই-ইনোভেশন-ফান্ডের-আওতায়-অনুষ্ঠিত-হেলথ-চ্যালেঞ্জ-ফান্ড-২০২০-ca5603-6922ea5cdbfbab28ce0b37b0)

৩

এটুআই ইনোভেশন ফান্ড এর আওতায় অনুষ্ঠিত স্মার্ট ডিসট্রিক্ট ইনোভেশন চ্যালেঞ্জ ২০২৩ প্রতিযোগিতার দুটি উদ্ভাবনী উদ্যোগের চুক্তি অকার্যকর ঘোষণা

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/d642c5cd5b72487299041fe816d5af74.pdf "office-a2i/2024/12/d642c5cd5b72487299041fe816d5af74.pdf")

১৬-১১-২০২৫

[দেখুন](/pages/notices/এটুআই-ইনোভেশন-ফান্ড-এর-আওতায়-অনুষ্ঠিত-স্মার্ট-ডিসট্রিক্ট-ইনোভেশন-d939fc-6922f1aedbfbab28ce0d58da)

৪

এনওসি (মোমেনা আক্তার)

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/4ffd3f31d520421ca4fbd467ca6bdc67.pdf "এনওসি (মোমেনা আক্তার)")

১০-১১-২০২৫

[দেখুন](/pages/notices/এনওসি-মোমেনা-আক্তার-1a957d-6922f38fdbfbab28ce0dea18)

৫

এনওসি (মোঃ শহীদুল ইসলাম)

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-a2i/2024/12/9a02f364df764a2baf056b61cfec206d.pdf "office-a2i/2024/12/9a02f364df764a2baf056b61cfec206d.pdf")

১৭-০৬-২০২৫

[দেখুন](/pages/notices/এনওসি-মোঃ-শহীদুল-ইসলাম-2fa1b1-6922d97fdbfbab28ce04d3f4)

-   ১
-   পৃষ্ঠায় যান 

আর্কাইভ দেখুন প্রকাশিত দেখুন দেখছেন ১ থেকে ৫ পর্যন্ত, মোট ৫ এন্ট্রি

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

### এক্সেসিবিলিটি

ফন্ট বৃদ্ধি ফন্ট হ্রাস

 মনোক্রোম

 ইনভার্ট

 বড় কার্সর

 লিঙ্ক হাইলাইট

 শিরোনাম হাইলাইট

 পড়ার গাইড

রিসেট

[স্ক্রিন রিডার ডাউনলোড করুন](https://www.nvaccess.org/files/nvda/releases/2020.4/nvda_2020.4.exe)

[কন্টেন্টে চলে যান](#main-content) [এক্সেসিবিলিটি মেনুতে যান](#accessibility-card-title)