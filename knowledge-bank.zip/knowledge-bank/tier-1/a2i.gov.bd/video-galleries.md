---
source: "a2i / Aspire to Innovate"
tier: 1
category: "Innovation program"
url: "https://a2i.gov.bd/pages/video-galleries"
title: "ইউটিউব গ্যালারি | এসপায়ার টু ইনোভেট (এটুআই)"
scraped_at: "2026-07-02"
---

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

## ইউটিউব গ্যালারি

ক্রম অনুসারে ডিফল্ট শিরোনাম

পৃষ্ঠা আইটেম ১০ ২০ ৫০ ১০০

[

১০ মাসে ১০ লক্ষ+ অনলাইন সত্যায়ন সম্পন্ন করল ই-এপোস্টিল!

](/pages/video-galleries/১০-মাসে-১০-লক্ষ-অনলাইন-সত্যায়ন-সম্পন্ন-করল-ই-এপোস্টিল-daa3e5-6922df16933eb65569e1fc23 "১০ মাসে ১০ লক্ষ+ অনলাইন সত্যায়ন সম্পন্ন করল ই-এপোস্টিল!")

[

আওয়ার অফ কোড: খেলতে খেলতে কোডিং শেখা

](/pages/video-galleries/আওয়ার-অফ-কোড-খেলতে-খেলতে-কোডিং-শেখা-39ad01-6922df37933eb65569e20a25 "আওয়ার অফ কোড: খেলতে খেলতে কোডিং শেখা")

[

আপনার প্রয়োজনীয় সরকারি সেবা পেতে মাইগভে রেজিস্ট্রেশন করুন।

](/pages/video-galleries/আপনার-প্রয়োজনীয়-সরকারি-সেবা-পেতে-মাইগভে-রেজিস্ট্রেশন-করুন-e1101a-6922df0c933eb65569e1f794 "আপনার প্রয়োজনীয় সরকারি সেবা পেতে মাইগভে রেজিস্ট্রেশন করুন।")

[

ডিসি অফিসের সেবা এখন মাইগভ থেকেই নেয়া যায়। জানেন কি?

](/pages/video-galleries/ডিসি-অফিসের-সেবা-এখন-মাইগভ-থেকেই-নেয়া-যায়-জানেন-কি-f65d06-6922df0c933eb65569e1f79b "ডিসি অফিসের সেবা এখন মাইগভ থেকেই নেয়া যায়। জানেন কি?")

[

Bangladesh is advancing AI to improve health, education, agriculture, and finance, with support from the ICT Division, UNESCO Dhaka, UNDP, and a2i

](/pages/video-galleries/bangladesh-is-advancing-ai-to-improve-health-education-agriculture-and-finance-with-support-from-the-ict-division-unesco-dhaka-undp-and-a2i-6c9ab7-6922df18933eb65569e1fd18 "Bangladesh is advancing AI to improve health, education, agriculture, and finance, with support from the ICT Division, UNESCO Dhaka, UNDP, and a2i")

[

Judicial Information Portal: Easy access to justice, transparency, and citizen empowerment.

](/pages/video-galleries/judicial-information-portal-easy-access-to-justice-transparency-and-citizen-empowerment-a5eba9-6922df41933eb65569e20e3a "Judicial Information Portal: Easy access to justice, transparency, and citizen empowerment.")

[

"The National Portal is improving with youth ideas and new technology. Stay tuned! #NationalPortal #UXDesign "

](/pages/video-galleries/the-national-portal-is-improving-with-youth-ideas-and-new-technology-stay-tuned-nationalportal-uxdesign-268d6d-6922df3b933eb65569e20bc1 "\"The National Portal is improving with youth ideas and new technology. Stay tuned! #NationalPortal #UXDesign \"")

[

With over 2,500 youths and 28 employers, the Youth Employment Fair 2025 is building inclusive futures throughout Bangladesh

](/pages/video-galleries/with-over-2-500-youths-and-28-employers-the-youth-employment-fair-2025-is-building-inclusive-futures-throughout-bangladesh-5c3ee8-6922df23933eb65569e201df "With over 2,500 youths and 28 employers, the Youth Employment Fair 2025 is building inclusive futures throughout Bangladesh")

-   ১
-   পৃষ্ঠায় যান 

আর্কাইভ দেখুন প্রকাশিত দেখুন দেখছেন ১ থেকে ৮ পর্যন্ত, মোট ৮ এন্ট্রি

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

### এক্সেসিবিলিটি

ফন্ট বৃদ্ধি ফন্ট হ্রাস

 মনোক্রোম

 ইনভার্ট

 বড় কার্সর

 লিঙ্ক হাইলাইট

 শিরোনাম হাইলাইট

 পড়ার গাইড

রিসেট

[স্ক্রিন রিডার ডাউনলোড করুন](https://www.nvaccess.org/files/nvda/releases/2020.4/nvda_2020.4.exe)

[কন্টেন্টে চলে যান](#main-content) [এক্সেসিবিলিটি মেনুতে যান](#accessibility-card-title)