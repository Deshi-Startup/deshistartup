---
source: "VAT Online"
tier: 1
category: "VAT portal"
url: "https://vat.gov.bd"
title: "VAT Online Services"
scraped_at: "2026-07-02"
---

eVAT system is currently down for maintenance

From 02nd-July-2026 to 03rd-July-2026.

We apologise for any inconveniences  
while we make improvements to our eVAT system.

কারিগরী রক্ষণাবেক্ষণের কারণে ইভ্যাট সিস্টেম ব্যবহারে

০২ জুলাই ২০২৬ ইং হতে ০৩ জুলাই ২০২৬ ইং তারিখে সাময়িকভাবে সমস্যার সম্মুখীন হবেন।

ইভ্যাট সিস্টেমের উন্নতিকল্পে সম্মানিত করদাতাদের সাময়িক অসুবিধার জন্য আমরা আন্তরিক ভাবে দুঃখিত।

![](./img/maintenance.png)