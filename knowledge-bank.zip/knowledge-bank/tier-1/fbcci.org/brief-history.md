---
source: "FBCCI"
tier: 1
category: "Chamber"
url: "https://fbcci.org/web/contents/brief-history"
title: "Brief History"
scraped_at: "2026-07-02"
---

### Brief History

-   [Home](https://fbcci.org)
-   /
-   About FBCCI
-   /
-   FBCCI
-   /
-   Brief History