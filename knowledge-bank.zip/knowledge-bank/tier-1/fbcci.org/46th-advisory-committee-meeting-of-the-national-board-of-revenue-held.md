---
source: "FBCCI"
tier: 1
category: "Chamber"
url: "https://fbcci.org/web/news/46th-advisory-committee-meeting-of-the-national-board-of-revenue-held"
title: "FBCCI | 46th Advisory Committee meeting of the National Board of Revenue held"
scraped_at: "2026-07-02"
---

### News Details

-   [Home](https://fbcci.org)
-   /
-   Media
-   /
-   [Current News](https://fbcci.org/web/current-news)
-   /
-   46th Advisory Committee meeting of the National Board of Revenue held