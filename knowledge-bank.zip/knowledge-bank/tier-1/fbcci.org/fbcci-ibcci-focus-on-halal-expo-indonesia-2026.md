---
source: "FBCCI"
tier: 1
category: "Chamber"
url: "https://fbcci.org/web/news/fbcci-ibcci-focus-on-halal-expo-indonesia-2026"
title: "FBCCI | FBCCI, IBCCI Focus on Halal Expo Indonesia 2026"
scraped_at: "2026-07-02"
---

### News Details

-   [Home](https://fbcci.org)
-   /
-   Media
-   /
-   [Current News](https://fbcci.org/web/current-news)
-   /
-   FBCCI, IBCCI Focus on Halal Expo Indonesia 2026