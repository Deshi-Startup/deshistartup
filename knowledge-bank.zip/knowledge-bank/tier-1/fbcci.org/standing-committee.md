---
source: "FBCCI"
tier: 1
category: "Chamber"
url: "https://fbcci.org/web/contents/standing-committee"
title: "Standing Committee"
scraped_at: "2026-07-02"
---

### Standing Committee

-   [Home](https://fbcci.org)
-   /
-   Division
-   /
-   Standing Committee