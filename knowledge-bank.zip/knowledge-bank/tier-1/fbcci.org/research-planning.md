---
source: "FBCCI"
tier: 1
category: "Chamber"
url: "https://fbcci.org/web/contents/research-planning"
title: "Research and Planning"
scraped_at: "2026-07-02"
---

### Research and Planning

-   [Home](https://fbcci.org)
-   /
-   Division
-   /
-   Research and Planning