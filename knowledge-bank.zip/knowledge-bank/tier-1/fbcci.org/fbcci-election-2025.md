---
source: "FBCCI"
tier: 1
category: "Chamber"
url: "https://fbcci.org/web/contents/fbcci-election-2025"
title: "FBCCI Election 2025"
scraped_at: "2026-07-02"
---

### FBCCI Election 2025

-   [Home](https://fbcci.org)
-   /
-   Division
-   /
-   FBCCI Election 2025