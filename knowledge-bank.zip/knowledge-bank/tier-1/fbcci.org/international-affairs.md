---
source: "FBCCI"
tier: 1
category: "Chamber"
url: "https://fbcci.org/web/contents/international-affairs"
title: "International Affairs"
scraped_at: "2026-07-02"
---

### International Affairs

-   [Home](https://fbcci.org)
-   /
-   Division
-   /
-   International Affairs