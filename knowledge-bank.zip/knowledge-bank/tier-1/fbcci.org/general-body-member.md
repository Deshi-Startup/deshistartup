---
source: "FBCCI"
tier: 1
category: "Chamber"
url: "https://fbcci.org/web/contents/general-body-member"
title: "General Body Member"
scraped_at: "2026-07-02"
---

### General Body Member

-   [Home](https://fbcci.org)
-   /
-   Division
-   /
-   General Body Member