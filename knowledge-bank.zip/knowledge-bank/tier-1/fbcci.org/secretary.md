---
source: "FBCCI"
tier: 1
category: "Chamber"
url: "https://fbcci.org/web/secretary"
title: "FBCCI | Secretariats"
scraped_at: "2026-07-02"
---

### Secretariats

-   [Home](https://fbcci.org)
-   /
-   About FBCCI
-   /
-   FBCCI
-   /
-   Secretariats