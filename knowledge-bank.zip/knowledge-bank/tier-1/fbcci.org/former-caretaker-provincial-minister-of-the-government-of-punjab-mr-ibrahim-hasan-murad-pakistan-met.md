---
source: "FBCCI"
tier: 1
category: "Chamber"
url: "https://fbcci.org/web/news/former-caretaker-provincial-minister-of-the-government-of-punjab-mr-ibrahim-hasan-murad-pakistan-met-fbcci-secretary-general-mr-md-alamgir"
title: "FBCCI | Former Caretaker Provincial Minister of the Government of Punjab Mr. Ibrahim Hasan Murad Pakistan met FBCCI Secretary General Mr. Md. Alamgir"
scraped_at: "2026-07-02"
---

### News Details

-   [Home](https://fbcci.org)
-   /
-   Media
-   /
-   [Current News](https://fbcci.org/web/current-news)
-   /
-   Former Caretaker Provincial Minister of the Government of Punjab Mr. Ibrahim Has ...