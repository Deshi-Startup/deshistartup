---
source: "FBCCI"
tier: 1
category: "Chamber"
url: "https://fbcci.org/web/service/trade-and-finance-activities"
title: "Trade and Finance Activities"
scraped_at: "2026-07-02"
---

### What we do

-   [Home](https://fbcci.org)
-   /
-   About FBCCI
-   /
-   FBCCI
-   /
-   What we do
-   /
-   Trade and Finance Activities