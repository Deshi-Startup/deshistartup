---
source: "FBCCI"
tier: 1
category: "Chamber"
url: "https://fbcci.org/web/service/exchange-of-business-delegation"
title: "Exchange of business Delegation"
scraped_at: "2026-07-02"
---

### What we do

-   [Home](https://fbcci.org)
-   /
-   About FBCCI
-   /
-   FBCCI
-   /
-   What we do
-   /
-   Exchange of business Delegation