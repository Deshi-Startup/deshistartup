---
source: "FBCCI"
tier: 1
category: "Chamber"
url: "https://fbcci.org/"
title: "FBCCI"
scraped_at: "2026-07-02"
---

Accelerating the Trillion Dollar Journey

-   [](https://www.facebook.com/fbcci.official)
-   [](https://twitter.com/fbccibd)
-   [](https://www.linkedin.com/company/fbcci/)
-   [](https://www.instagram.com/fbccibd)
-   [](https://www.youtube.com/@fbccitv1493)
-   [Useful Links](https://fbcci.org/web/important/important-link)

[![logo](https://fbcci.org/public/storage/upload/conf/230625112346-2103logo.png)](https://fbcci.org)

-   [](https://www.facebook.com/fbcci.official)
-   [](https://twitter.com/fbccibd)
-   [](https://www.linkedin.com/company/fbcci/)
-   [](https://www.instagram.com/fbccibd)
-   [](https://www.youtube.com/@fbccitv1493)

[![FBCC-logo](https://fbcci.org/public/storage/upload/conf/230626102847-15065.jpeg)](https://fbcci.org)

Accelerating the Trillion Dollar Journey

 ![search](https://fbcci.org/public/images/search.png)

-   [Home](https://fbcci.org)
-   [About FBCCI](javascript:void\(0\))
    -   [FBCCI](javascript:void\(0\))
        -   [Brief History](https://fbcci.org/web/contents/brief-history)
            
        -   [What we do](https://fbcci.org/web/service)
            
        -   [Former Presidents](https://fbcci.org/web/former/Former-president)
            
        -   [Former Senior Vice Presidents](https://fbcci.org/web/former/Former-senior-vice-president)
            
        -   [Former Vice Presidents](https://fbcci.org/web/former/Former-vice-president)
            
        -   [Advisors](https://fbcci.org/web/advisor?Advisors)
            
        -   [Safety Council Officials](https://fbcci.org/web/safety-council)
            
    -   [Board of Directors](https://fbcci.org/web/contents/directors)
        
    -   [FBCCI Arbitration Tribunal](https://fbcci.org/web/contents/fbcci-arbitration-tribunal)
        
    -   [General Body Member](https://fbcci.org/web/contents/general-body-member)
        
-   [Secretariat](javascript:void\(0\))
    -   [Wings](javascript:void\(0\))
        -   [General Affairs](https://fbcci.org/web/contents/general-affairs)
            
        -   [Legal & Membership](https://fbcci.org/web/contents/membership-legal-affairs-division)
            
        -   [International Affairs](https://fbcci.org/web/contents/international-affairs)
            
        -   [Research and Planning](https://fbcci.org/web/contents/research-planning)
            
        -   [Public Relation (PR) & Communication](https://fbcci.org/web/contents/public-relation-%28pr%29-communication)
            
        -   [Trade Facilitation and Policy Advocacy](https://fbcci.org/web/contents/trade-facilitation-policy-advocacy)
            
        -   [Information Technology (IT)](https://fbcci.org/web/contents/information-technology-%28it%29)
            
        -   [Accounts and Finance](https://fbcci.org/web/contents/accounts-audits)
            
        -   [Standing Committee](https://fbcci.org/web/contents/standing-committee)
            
        -   [Safety Council](https://fbcci.org/web/contents/division-safety-council)
            
        -   [Price Monitoring](https://fbcci.org/web/contents/fbcci-market-price-monitoring-cell)
            
        -   [Protocol](https://fbcci.org/web/contents/protocol1)
            
    -   [Secretariat Officials](https://fbcci.org/web/secretary)
        
-   [Committees](javascript:void\(0\))
    -   [Standing Committees](javascript:void\(0\))
        -   [Standard Operating Procedure](https://fbcci.org/web/contents/standard-operating-procedure)
            
        -   [List of Standing Committees](https://fbcci.org/web/standing-committee)
            
        -   [Expression of Interest](https://fbcci.org/web/standing-committee-eoi-form)
            
        -   [Recommendation](https://fbcci.org/web/contents/recommendations)
            
    -   [Board Committees](https://fbcci.org/web/contents/board-committee)
        
-   [Media](javascript:void\(0\))
    -   [Events](https://fbcci.org/web/events)
        
    -   [Current News](https://fbcci.org/web/current-news)
        
    -   [Press Kit](https://fbcci.org/web/press-kit)
        
    -   [Press Release](https://fbcci.org/web/press-release)
        
    -   [Photo Gallery](https://fbcci.org/web/album/photos?photo-gallery)
        
    -   [Video Gallery](https://fbcci.org/web/album/videos?video-gallery)
        
    -   [Media Report](https://fbcci.org/web/media-report?media-report)
        
-   [Notice](javascript:void\(0\))
    -   [Govt Notice](https://fbcci.org/web/govt-notice)
        
    -   [FBCCI Notice](https://fbcci.org/web/fbcci-notice)
        
    -   [Safety Council Notice](https://fbcci.org/web/safety-council-notice)
        
-   [Resources](javascript:void\(0\))
    -   [Publications](https://fbcci.org/web/resource/publications)
        
    -   [Magazine](https://fbcci.org/web/resource/magazines)
        
    -   [FBCCI Rules & regulations](https://fbcci.org/web/resource/fbcci-rules-and-regulations)
        
    -   [Annual Reports](https://fbcci.org/web/resource/annual-reports)
        
    -   [Govt. Polices & SRO's](https://fbcci.org/web/resource/govt-police-sro-and-gazette)
        
    -   [Keynote Papers](https://fbcci.org/web/resource/keynote-paper)
        
    -   [Important links](https://fbcci.org/web/important/important-link)
        
    -   [Acts/Laws/Gazzette/Circulars](https://fbcci.org/web/resource/acts-laws)
        
-   [FBCCI Election](javascript:void\(0\))
    -   [FBCCI Election 2025](https://fbcci.org/web/contents/fbcci-election-2025)
        

![slider-image](https://fbcci.org/public/storage/upload/slider/260430043310-7858.png)

## [46th Advisory Committee meeting of the National Board of Revenue held](https://fbcci.org/web/news/46th-advisory-committee-meeting-of-the-national-board-of-revenue-held)

The 46th Advisory Committee meeting of the National Board of Revenue (NBR) was held on April 29, 2026 at Pan Pacific Sonargaon Dhaka. The meeting was jointly organized by NBR and FBCCI, focusing on key discussions for the upcoming National Budget FY 2026&ndash;2027. Mr. Amir Khosru Mahmud Chowdhury MP, Honourable... [Read More](https://fbcci.org/web/news/46th-advisory-committee-meeting-of-the-national-board-of-revenue-held)

![slider-image](https://fbcci.org/public/storage/upload/slider/260210072204-7349.png)

## [FBCCI Reviews Market Situation Ahead of Ramadan](https://fbcci.org/web/news/fbcci-reviews-market-situation-ahead-of-ramadan)

The Federation of Bangladesh Chambers of Commerce and Industry (FBCCI) organized a view exchange meeting on the current situations of import, stock, supply and pricing of essential commodities ahead of Ramadan, held at FBCCI office in Motijheel, Dhaka on February 09, 2026. Business leaders from different chambers and associations, representatives... [Read More](https://fbcci.org/web/news/fbcci-reviews-market-situation-ahead-of-ramadan)

![slider-image](https://fbcci.org/public/storage/upload/slider/260402063645-2754.png)

## [FBCCI Proposes Policy Continuity and Revenue Reforms in Pre-Budget Meeting](https://fbcci.org/web/news/fbcci-proposes-policy-continuity-and-revenue-reforms-in-pre-budget-meeting)

A comprehensive set of recommendations aimed at expanding trade and bolstering investor confidence was formally presented by the Federation of Bangladesh Chambers of Commerce and Industry (FBCCI) for the upcoming National Budget for FY 2026-27. During a pre-budget discussion held on 12 March 2026 at the FBCCI&rsquo;s Motijheel office, the... [Read More](https://fbcci.org/web/news/fbcci-proposes-policy-continuity-and-revenue-reforms-in-pre-budget-meeting)

![slider-image](https://fbcci.org/public/storage/upload/slider/260119070519-7733.png)

## [FBCCI: Empowering the Future of Women in Business](https://fbcci.org/web/news/fbcci-empowering-the-future-of-women-in-business)

In a significant move toward fostering an inclusive economic landscape, the Federation of Bangladesh Chambers of Commerce and Industry (FBCCI) convened a high-level consultative meeting on January 12, 2026. Held at the FBCCI office in Motijheel, Dhaka, the session focused on the critical themes of capacity building and skill development,... [Read More](https://fbcci.org/web/news/fbcci-empowering-the-future-of-women-in-business)

![slider-image](https://fbcci.org/public/storage/upload/slider/260217110414-3362.png)

## FBCCI Extends Heartiest Felicitations to Prime Minister Tarique Rahman

On behalf of the country&rsquo;s business community, the Federation of Bangladesh Chambers of Commerce and Industry (FBCCI) offers its heartiest congratulations to Mr. Tarique Rahman, Chairman of the Bangladesh Nationalist Party (BNP), on his historic appointment as the Prime Minister of Bangladesh. FBCCI wished the new leadership every success in...

![Introduction to the FBCCI](https://fbcci.org/public/storage/upload/content/240912102701-6825.png)

[

](https://www.youtube.com/watch?v=9OycaSqkJ7Y)

##### 50+

Introduction to the FBCCI

#### Introduction to the FBCCI

The Federation of Bangladesh Chambers of Commerce and Industry (FBCCI) is the apex trade organization of Bangladesh playing a pivotal role in consultative and advisory capacity, safeguarding the interest of...

![Introduction to the FBCCI](https://fbcci.org/public/images/m.png)

#### Our Mission

Chamber 4.0 focused on sustainability and more efficient activities that would be more participative. As fourth generation leaders of umbrella chamber aligned with 4RI, we engage with business communication of...

![Introduction to the FBCCI](https://fbcci.org/public/images/m.png)

#### Our Vision

To be the center of excellence in policy Advocacy and all matter relevant to trade and investment facilitation from CMSME to the largest sector of Bangladesh.

[Read More](https://fbcci.org/web/contents/about-us)

![animate-shape](https://fbcci.org/public/images/animate-shape.png) ![animate-shape](https://fbcci.org/public/images/animate-shape.png)

![](https://fbcci.org/public/storage/upload/home/120.jpeg)

## Md. Abdur Rahim Khan

###### Administrator, FBCCI

Mr. Md. Abdur Rahim Khan, Additional Secretary, Ministry of Commerce has been appointed as the administrator of the Federation of Bangladesh Chambers of Commerce and Industry (FBCCI). The post was vacant for around 2 months since Mr. Md. Hafizur Rahman, Ex Administrator vacated the post on September 10, 2025.

Mr. Md. Abdur Rahim Khan is working as head of the...

[Read More](https://fbcci.org/web/contents/about-president?track=home)

#### FBCCI 50-year Celebration

![Business-Summit](https://fbcci.org/public/images/bs-logo.png)

Bangladesh Business Summit 2023, scheduled for March 11 & 12, 2023, is an international trade and investment promotion event being organized by Bangladesh’s apex business body Federation of Bangladesh Chambers...

[Explore More](https://bdbusinesssummit.com/)

![Business-Summit](https://fbcci.org/public/images/fa.png)

FBCCI is going to celebrate its 50 years anniversary this year. On the occasion of the Golden Jubilee, FBCCI will organize Bangladesh Business Summit, Best of Bangladesh Expo and other...

[Explore More](https://fbccibusinessaward.com/)

![](https://fbcci.org/public/storage/upload/content/newbd.png)

## Bangladesh Country Profile

Bangladesh is a South Asian country with a population of about 168 million people. It is one of the most densely populated countries in the world. The capital and largest city is Dhaka. The official language is Bengali and the majority of the population is Muslim. Bangladesh has made significant progress in recent decades, reducing poverty and improving health and education. The country is a lower-middle-income country with a growing economy. The main industries are ready-made garments, textiles, chemical fertilizers, jute and jute goods, tea processing, pharmaceuticals, paper and newsprint, sugar, cement, leather goods, food, fish, and poultry.The literacy rate in Bangladesh is 75.2%, which is a significant increase from the literacy rate of 51.8% in 1981. However, the literacy rate for males is higher than the literacy rate for females. The government is taking steps to address this gender gap. Overall, Bangladesh is a developing country with a bright future. It has made significant progress in recent decades and is on track to achieve its development...

[Read More](https://fbcci.org/web/contents/bangladesh-country-profile)

#### Latest News

![Former Caretaker Provincial Minister of the Government of Punjab Mr. Ibrahim Hasan Murad Pakistan met FBCCI Secretary General Mr. Md. Alamgir](https://fbcci.org/public/storage/upload/news/resize_509X280/260702065723-6839.jpeg)

01 Jul

##### [Former Caretaker Provincial Minister of the Government of Punjab Mr. Ibrahim Hasan Murad Pakistan met FBCCI Secretary General Mr. Md. Alamgir](https://fbcci.org/web/news/former-caretaker-provincial-minister-of-the-government-of-punjab-mr-ibrahim-hasan-murad-pakistan-met-fbcci-secretary-general-mr-md-alamgir)

![FBCCI, IBCCI Focus on Halal Expo Indonesia 2026](https://fbcci.org/public/storage/upload/news/resize_509X280/260524090857-7645.jpeg)

21 May

##### [FBCCI, IBCCI Focus on Halal Expo Indonesia 2026](https://fbcci.org/web/news/fbcci-ibcci-focus-on-halal-expo-indonesia-2026)

![Mandi Bahauddin Trade Delegation Explores New Commercial Horizons in Bangladesh](https://fbcci.org/public/storage/upload/news/resize_509X280/260521052114-5891.jpeg)

12 May

##### [Mandi Bahauddin Trade Delegation Explores New Commercial Horizons in Bangladesh](https://fbcci.org/web/news/mandi-bahauddin-trade-delegation-explores-new-commercial-horizons-in-bangladesh)

[View all news](https://fbcci.org/web/current-news)

#### What We Do

![FBCC-Service](https://fbcci.org/images/service/1.png)

##### [Trade and Finance Activities](https://fbcci.org/web/service/trade-and-finance-activities)

Along with coordinating and promoting the interest of its members- Chambers of Commerce, Trade, and Industrial Association, FBCCI also plays...

[Read More](https://fbcci.org/web/service/trade-and-finance-activities)

1

![FBCC-Service](https://fbcci.org/images/service/2.png)

##### [Policy Advocacy](https://fbcci.org/web/service/policy-advocacy)

FBCCI regularly conducts advocacy with the government on different fiscal, monetary and other policy issues for enabling ease of doing...

[Read More](https://fbcci.org/web/service/policy-advocacy)

2

![FBCC-Service](https://fbcci.org/images/service/3.png)

##### [CSR Activity](https://fbcci.org/web/service/csr-activity)

FBCCI takes part in different Corporate Social Responsibilities in order to enhance the social and environmental aspects of the country....

[Read More](https://fbcci.org/web/service/csr-activity)

3

![FBCC-Service](https://fbcci.org/images/service/4.png)

##### [Research & Planning](https://fbcci.org/web/service/research-innovation-center)

FBCCI collects statistical and additional necessary data to aid the trade and industry of the country in regard to development...

[Read More](https://fbcci.org/web/service/research-innovation-center)

4

![FBCC-Service](https://fbcci.org/images/service/5.png)

##### [Arbitration](https://fbcci.org/web/service/arbitration)

FBCCI provides assistance to the businessmen all over the country to settle their domestic and international disputes at a minimum...

[Read More](https://fbcci.org/web/service/arbitration)

5

![FBCC-Service](https://fbcci.org/images/service/6.png)

##### [Exchange of business Delegation](https://fbcci.org/web/service/exchange-of-business-delegation)

It is one of the crucial duties of FBCCI to maintain the incoming and outgoing delegations along with arranging all...

[Read More](https://fbcci.org/web/service/exchange-of-business-delegation)

6

![FBCC-Service](https://fbcci.org/images/service/7.png)

##### [Networking with strategic partners...](https://fbcci.org/web/service/networking-with-strategic-partners-counterparts)

FBCCI maintains close liaison with the foreign National Chambers of Commerce and other Trade and Industrial Associations while initiating bilateral...

[Read More](https://fbcci.org/web/service/networking-with-strategic-partners-counterparts)

7

![FBCC-Service](https://fbcci.org/images/service/8.png)

##### [Seminar / Symposiums](https://fbcci.org/web/service/seminar-symposiums)

FBCCI discusses and shares views on the crucial matters relevant to and affecting the national economy in various government forums...

[Read More](https://fbcci.org/web/service/seminar-symposiums)

8

### 90

Chambers

### 429

Association

### 19

Joint Chambers

### 0

G.B Members

#### Upcoming Events

[View all events](https://fbcci.org/web/up-coming-events)

![No Event](https://fbcci.org/public/images/no-event-image.jpg)

[View all event](https://fbcci.org/web/events)

##### Upcoming Events

×

#### Our Latest Events

![FBCCI Proposes Policy Continuity and Revenue Reforms in Pre-Budget Meeting](https://fbcci.org/public/storage/upload/events/resize_856X480/260402092710-2063.jpeg)

-   12 Mar, 2026

##### [FBCCI Proposes Policy Continuity and Revenue Reforms in Pre-Budget Meeting](https://fbcci.org/web/event/fbcci-proposes-policy-continuity-and-revenue-reforms-in-pre-budget-meeting)

[Read More](https://fbcci.org/web/event/fbcci-proposes-policy-continuity-and-revenue-reforms-in-pre-budget-meeting)

![FBCCI: Empowering the Future of Women in Business](https://fbcci.org/public/storage/upload/events/resize_856X480/260202053319-1934.jpeg)

-   12 Jan, 2026

##### [FBCCI: Empowering the Future of Women in Business](https://fbcci.org/web/event/charge-handover-takeover-ceremony)

[Read More](https://fbcci.org/web/event/charge-handover-takeover-ceremony)

![FBCCI Hosts Pivotal Seminar Focused on Advancing the Healthcare Sector](https://fbcci.org/public/storage/upload/events/resize_856X480/260402061722-9786.jpeg)

-   25 Nov, 2025

##### [FBCCI Hosts Pivotal Seminar Focused on Advancing the Healthcare Sector](https://fbcci.org/web/event/fbcci-hosts-pivotal-seminar-focused-on-advancing-the-healthcare-sector1)

Entrepreneurs and experts emphasized timely policies and simplified licensing processes...

[Read More](https://fbcci.org/web/event/fbcci-hosts-pivotal-seminar-focused-on-advancing-the-healthcare-sector1)

[View all event](https://fbcci.org/web/events)

#### Photo and Video Gallery

-   All
-   Photos
-   Videos

[

![gallery-image](<https://fbcci.org/public/storage/upload/album/260622081915-2184আমরা শোকাহত.jpeg>)

#### আমরা শোকাহত



](https://fbcci.org/web/album/photo/amra-sokaht)

[

![gallery-image](<https://fbcci.org/public/storage/upload/album/260622045242-2463We Mourn.jpeg>)

#### We Mourn



](https://fbcci.org/web/album/photo/we-mourn)

[

![gallery-image](https://fbcci.org/public/storage/upload/album/260430105131-4877Capture2.PNG)

#### Highlights from the FBCCI-NBR joint session in National Dailies



](https://fbcci.org/web/album/photo/highlights-from-the-fbcci-nbr-joint-session-in-national-dailies)

[

![gallery-image](<https://fbcci.org/public/storage/upload/album/260430103258-841545 \(2\).jpeg>)

#### 46th Advisory Committee meeting



](https://fbcci.org/web/album/photo/46th-advisory-committee-meeting)

[

![gallery-image](https://fbcci.org/public/storage/upload/album/260423083211-3486Mourn.jpeg)

#### FBCCI Mourns



](https://fbcci.org/web/album/photo/fbcci-mourns1)

[

![gallery-image](https://fbcci.org/public/storage/upload/album/260419095052-4666secretary.jpeg)

#### FBCCI Mourns



](https://fbcci.org/web/album/photo/fbcci-mourns)

[

![gallery-image](<https://fbcci.org/public/storage/upload/album/260622081915-2184আমরা শোকাহত.jpeg>)

#### আমরা শোকাহত



](https://fbcci.org/web/album/photo/amra-sokaht)

[

![gallery-image](<https://fbcci.org/public/storage/upload/album/260622045242-2463We Mourn.jpeg>)

#### We Mourn



](https://fbcci.org/web/album/photo/we-mourn)

[

![gallery-image](https://fbcci.org/public/storage/upload/album/260430105131-4877Capture2.PNG)

#### Highlights from the FBCCI-NBR joint session in National Dailies



](https://fbcci.org/web/album/photo/highlights-from-the-fbcci-nbr-joint-session-in-national-dailies)

[

![gallery-image](<https://fbcci.org/public/storage/upload/album/260430103258-841545 \(2\).jpeg>)

#### 46th Advisory Committee meeting



](https://fbcci.org/web/album/photo/46th-advisory-committee-meeting)

[

![gallery-image](https://fbcci.org/public/storage/upload/album/260423083211-3486Mourn.jpeg)

#### FBCCI Mourns



](https://fbcci.org/web/album/photo/fbcci-mourns1)

[

![gallery-image](https://fbcci.org/public/storage/upload/album/260419095052-4666secretary.jpeg)

#### FBCCI Mourns



](https://fbcci.org/web/album/photo/fbcci-mourns)

[

![gallery-image](<https://fbcci.org/public/storage/upload/album/260301070047-2767Late PM khaleda.jpeg>)

#### FBCCI Commemorates Legacy of Begum Khaleda Zia



](https://fbcci.org/web/galleries/video/fbcci-commemorates-legacy-of-begum-khaleda-zia)

[

![gallery-image](https://fbcci.org/public/storage/upload/album/240914050308-7086fbccilogo.jpeg)

#### FBCCI Delegation in a Courtesy Meeting with the Then Prime Minister



](https://fbcci.org/web/galleries/video/fbcci-leaders-paid-courtesy-call-on-hpm-sheikh-hasina1)

[

![gallery-image](https://fbcci.org/public/storage/upload/album/230724065513-6031.png)

#### Business Conference on Building Smart Bangladesh

Business Conference on Building Smart Bangladesh | Smart Bangladesh| FBCCI



](https://fbcci.org/web/galleries/video/business-conference-on-building-smart-bangladesh)

[

![gallery-image](https://fbcci.org/public/storage/upload/album/230705065331-2337.png)

#### Business Excellence Award 2023 Gala Event



](https://fbcci.org/web/galleries/video/business-excellence-award-2023-gala-event)

[

![gallery-image](<https://fbcci.org/public/storage/upload/album/260202083351-1686fbcci team.jpeg>)

#### Annual General Meeting of the FBCCI (2020-2021 & 2021-2022 Session)



](https://fbcci.org/web/galleries/video/annual-general-meeting-of-the-fbcci-2020-2021-2021-2022-session)

[

![gallery-image](https://fbcci.org/public/storage/upload/album/230705054653-4892.png)

#### বাজেটে প্রত্যাশা ২০২৩-২৪



](https://fbcci.org/web/galleries/video/bajete-prtzasa-2023-24)