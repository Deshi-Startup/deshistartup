---
source: "FBCCI"
tier: 1
category: "Chamber"
url: "https://fbcci.org/web/standing-committee-eoi-form"
title: "FBCCI | Standing Committee EOI Form"
scraped_at: "2026-07-02"
---

### Expression of Interest

-   [Home](https://fbcci.org)
-   /
-   Committees
-   /
-   Standing Committees
-   /
-   Expression of Interest