---
source: "ICT Division"
tier: 1
category: "ICT policy"
url: "https://ictd.gov.bd/pages/notices"
title: "নোটিশ | তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ"
scraped_at: "2026-07-02"
---

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

## নোটিশ

 এডভান্সড অপশনগুলো দেখান

গ্রুপ অনুসারে কিছুই না শিরোনাম,প্রকাশের তারিখ

পৃষ্ঠা আইটেম ১০ ২০ ৫০ ১০০

নং

শিরোনাম

ফাইল সমূহ

ইমেজ

প্রকাশের তারিখ

কার্যকলাপ

 

   

   

 

১

অফিস আদেশ-৪৩৪ (দায়িত্ব বণ্টন)

০১-০৭-২০২৬

[দেখুন](/pages/notices/অফিস-আদেশ-৪৩৪-দায়িত্ব-বণ্টন-7684e55b-6a4494eb28c42c6f052ef841)

[রেফারেন্স](/pages/office-orders/6a4494eb28c42c6f052ef83f)

২

e-Tender Notice for "Annual Maintenance Contract (AMC) for Server and Storage Systems for D-Nothi, Located at the Tier-4 Data Center, Kaliakair"

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/6/808008d9-e4ba-4c85-9d02-5db162dcd806.pdf "office-ictd/2026/6/808008d9-e4ba-4c85-9d02-5db162dcd806.pdf")

০১-০৭-২০২৬

[দেখুন](/pages/notices/e-tender-notice-for-annual-maintenance-contract-amc-for-server-and-storage-systems-for-d-nothi-located-at-the-tier-4-data-center-kaliakair-1n1cyn-6a44942dd3ddcff4605a04d7)

৩

প্রজ্ঞাপন (জনাব আল-আমিন, ব্যক্তিগত কর্মকর্তা, তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ)

২৯-০৬-২০২৬

[দেখুন](/pages/notices/প্রজ্ঞাপন-জনাব-আল-আমিন-ব্যক্তিগত-কর্মকর্তা-তথ্য-ও-যোগাযোগ-প্রযুক্তি-বিভাগ-e6ee6fd7-6a41f4c6c46c177d110645a8)

[রেফারেন্স](/pages/go-ultimates/6a41f4c6c46c177d110645a6)

৪

Request for Expressions of Interest (REoI) for Selection of Individual Consultants for 2 Consultant positions

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/5/dea6f03c-4ab9-4772-81af-e68408b200fc.pdf "office-ictd/2026/5/dea6f03c-4ab9-4772-81af-e68408b200fc.pdf")

২৮-০৬-২০২৬

[দেখুন](/pages/notices/request-for-expressions-of-interest-reoi-for-selection-of-individual-consultants-for-2-consultant-positions-pynb2w-6a40b598a306397897d96901)

৫

e-Tender Notice for "Framework agreement of Toner items for the official use of a2i Programme"

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/5/9f945d84-fcf0-43ec-9518-f3b11535d089.pdf "office-ictd/2026/5/9f945d84-fcf0-43ec-9518-f3b11535d089.pdf")

২৫-০৬-২০২৬

[দেখুন](/pages/notices/e-tender-notice-for-framework-agreement-of-toner-items-for-the-official-use-of-a2i-programme-nbwkyn-6a3ce835ead8618d35d52df9)

৬

জুন ২০২৬ মাসের মাসিক সমন্বয় সভা

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/5/4774f42e-cf12-4d0b-977c-e96f196a7357.pdf "office-ictd/2026/5/4774f42e-cf12-4d0b-977c-e96f196a7357.pdf")

২৪-০৬-২০২৬

[দেখুন](/pages/notices/জুন-২০২৬-মাসের-মাসিক-সমন্বয়-সভা-fkeee4-6a3c9a33ead8618d35d4e793)

৭

অফিস আদেশ-৪০৯ (অবমুক্তি, জনাব মোঃ এরফানুল হক চৌধুরী (১৮৩৪৮), উপপরিচালক , তথ্য ও যোগাযোগ প্রযুক্তি অধিদপ্তর

২১-০৬-২০২৬

[দেখুন](/pages/notices/অফিস-আদেশ-৪০৯-অবমুক্তি-জনাব-মোঃ-এরফানল-হক-চৌধুরী-১৮৩৪৮-উপপরিচালক-তথ্য-ও-যোগাযোগ-প্রযুক্তি-অধিদপ্তর-01847464-6a378064d6fff31fe5bce8c0)

[রেফারেন্স](/pages/office-orders/6a378064d6fff31fe5bce8be)

৮

অফিস আদেশ-৩৭২ (GPMS-টিম লিডার)

০২-০৬-২০২৬

[দেখুন](/pages/notices/অফিস-আদেশ-৩৭২-gpms-টিম-লিডার-bc37309e-6a1e9c4b356c14ea93162f37)

[রেফারেন্স](/pages/office-orders/6a1e9c4b356c14ea93162f35)

৯

অফিস আদেশ-৩৬৮ (দায়িত্ব বণ্টন)

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/5/f07db407-b141-493c-8368-acab78c3225f.pdf "office-ictd/2026/5/f07db407-b141-493c-8368-acab78c3225f.pdf")

০২-০৬-২০২৬

[দেখুন](/pages/notices/অফিস-আদেশ-৩৬৮-দায়িত্ব-বণ্টন-t9llqm-6a1e9bb04b0cb0ed96f89ec6)

১০

ভারপ্রাপ্ত সচিব পদে যোগদান।

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/5/e9a9eb30-d0a0-4438-86bd-3d5bd0589ba0.pdf "office-ictd/2026/5/e9a9eb30-d0a0-4438-86bd-3d5bd0589ba0.pdf")

০১-০৬-২০২৬

[দেখুন](/pages/notices/ভারপ্রাপ্ত-সচিব-পদে-যোগদান-pfb7wj-6a1d4e32977edbd1f13433b8)

-   ১
-   ২
-   ৩
-   ৪
-   ...
-   ৩১৫
-   **পরবর্তী** 🡲
-   পৃষ্ঠায় যান 

আর্কাইভ দেখুন প্রকাশিত দেখুন দেখছেন ১ থেকে ১০ পর্যন্ত, মোট ৩১৪১ এন্ট্রি

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

### এক্সেসিবিলিটি

ফন্ট বৃদ্ধি ফন্ট হ্রাস

 মনোক্রোম

 ইনভার্ট

 বড় কার্সর

 লিঙ্ক হাইলাইট

 শিরোনাম হাইলাইট

 পড়ার গাইড

রিসেট

[স্ক্রিন রিডার ডাউনলোড করুন](https://www.nvaccess.org/files/nvda/releases/2020.4/nvda_2020.4.exe)

[কন্টেন্টে চলে যান](#main-content) [এক্সেসিবিলিটি মেনুতে যান](#accessibility-card-title)