---
source: "ICT Division"
tier: 1
category: "ICT policy"
url: "https://ictd.gov.bd/pages/publications"
title: "প্রকাশনাসমূহ | তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ"
scraped_at: "2026-07-02"
---

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

## প্রকাশনাসমূহ

 এডভান্সড অপশনগুলো দেখান

গ্রুপ অনুসারে কিছুই না শিরোনাম,প্রকাশের তারিখ

পৃষ্ঠা আইটেম ১০ ২০ ৫০ ১০০

নং

শিরোনাম

কভার ছবি

সংযুক্তি ফাইল সমূহ

প্রকাশের তারিখ

কার্যকলাপ

 

   

   

 

১

জুলাই স্মারক ২০২৫-অগ্রগতি আর অর্জনের এক বছর

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/0/bc0885f1-0047-44db-9a47-4972c5e3cd07.pdf "office-ictd/2026/0/bc0885f1-0047-44db-9a47-4972c5e3cd07.pdf")

২১-০১-২০২৬

[দেখুন](/pages/publications/জুলাই-স্মারক-২০২৫-অগ্রগতি-আর-অর্জনের-এক-বছর-pjarth-6970cdff16af4e9291af3275)

২

Impact Assessment Of Learning and Earning Development Project (LEDP)

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/3f64896b11d94f4b895c9be7f6844355.pdf "office-ictd/2024/12/3f64896b11d94f4b895c9be7f6844355.pdf")

২৯-০৪-২০২৪

[দেখুন](/pages/publications/impact-assessment-of-learning-and-earning-development-project-ledp-e765ad-69414b2235ce18e1c059ac7f)

৩

Bangladesh Cyber Threat Landscape 2022

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/d44ccecf47684819a7387961caf7b251.pdf "office-ictd/2024/12/d44ccecf47684819a7387961caf7b251.pdf")

৩০-০৩-২০২৩

[দেখুন](/pages/publications/bangladesh-cyber-threat-landscape-2022-6e257b-69414b2235ce18e1c059ac7c)

৪

e-Government Master Plan for Digital Bangladesh Final

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/4bf83fadc8a94ff0b7511c0e1124ac62.pdf "office-ictd/2024/12/4bf83fadc8a94ff0b7511c0e1124ac62.pdf")

০৫-০৮-২০১৯

[দেখুন](/pages/publications/e-government-master-plan-for-digital-bangladesh-final-e6ce21-69414b2235ce18e1c059ac7e)

-   ১
-   পৃষ্ঠায় যান 

আর্কাইভ দেখুন প্রকাশিত দেখুন দেখছেন ১ থেকে ৪ পর্যন্ত, মোট ৪ এন্ট্রি

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

### এক্সেসিবিলিটি

ফন্ট বৃদ্ধি ফন্ট হ্রাস

 মনোক্রোম

 ইনভার্ট

 বড় কার্সর

 লিঙ্ক হাইলাইট

 শিরোনাম হাইলাইট

 পড়ার গাইড

রিসেট

[স্ক্রিন রিডার ডাউনলোড করুন](https://www.nvaccess.org/files/nvda/releases/2020.4/nvda_2020.4.exe)

[কন্টেন্টে চলে যান](#main-content) [এক্সেসিবিলিটি মেনুতে যান](#accessibility-card-title)