---
source: "ICT Division"
tier: 1
category: "ICT policy"
url: "https://ictd.gov.bd/"
title: "হোম | তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ"
scraped_at: "2026-07-02"
---

![জর্জিয়ার তিবিলিসিতে বাংলাদেশের ডাক, টেলিযোগাযোগ ও তথ্যপ্রযুক্তি মন্ত্রী ফকির মাহবুব আনাম কম্বোডিয়ার ডাক ও টেলিযোগাযোগ মন্ত্রী এইচ.ই. চিয়া ভানদেথ (H.E. Chea Vandeth)-এর সঙ্গে দ্বিপাক্ষিক বৈঠক করেন।](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/5/2c0063ef-efec-4d1e-9def-475487cea7ef.jpg)

জর্জিয়ার তিবিলিসিতে বাংলাদেশের ডাক, টেলিযোগাযোগ ও তথ্যপ্রযুক্তি মন্ত্রী ফকির মাহবুব আনাম কম্বোডিয়ার ডাক ও টেলিযোগাযোগ মন্ত্রী এইচ.ই. চিয়া ভানদেথ (H.E. Chea Vandeth)-এর সঙ্গে দ্বিপাক্ষিক বৈঠক করেন।

![জর্জিয়ার তিবিলিসিতে বাংলাদেশের ডাক, টেলিযোগাযোগ ও তথ্য প্রযুক্তি মন্ত্রী ফকির মাহবুব আনাম কাজাখস্তানের 'আস্তানা সিভিল সার্ভিস হাব' (Astana Civil Service Hub)-এর চেয়ারম্যান আলিখান বাইমেনভ (Alikhan Baimenov) এর সাথে দ্বিপাক্ষিক বৈঠক করেন।](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/5/33732328-5651-4d0d-bf48-2f2e6eef0eb0.jpg)

জর্জিয়ার তিবিলিসিতে বাংলাদেশের ডাক, টেলিযোগাযোগ ও তথ্য প্রযুক্তি মন্ত্রী ফকির মাহবুব আনাম কাজাখস্তানের 'আস্তানা সিভিল সার্ভিস হাব' (Astana Civil Service Hub)-এর চেয়ারম্যান আলিখান বাইমেনভ (Alikhan Baimenov) এর সাথে দ্বিপাক্ষিক বৈঠক করেন।

![জর্জিয়ার তিবিলিসিতে বাংলাদেশের ডাক, টেলিযোগাযোগ ও তথ্য প্রযুক্তি মন্ত্রী ফকির মাহবুব আনাম আজারবাইজানের এএসএএন ইনোভেশনস সেন্টারের (ASAN Innovations Centre) নির্বাহী পরিচালক ভুসাল রুস্তমভ (Vusal Rustamov) এর সাথে দ্বিপাক্ষিক বৈঠক করেন।](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/5/4e6d137e-1ecf-4360-bb93-9b3c72f702b9.jpg)

জর্জিয়ার তিবিলিসিতে বাংলাদেশের ডাক, টেলিযোগাযোগ ও তথ্য প্রযুক্তি মন্ত্রী ফকির মাহবুব আনাম আজারবাইজানের এএসএএন ইনোভেশনস সেন্টারের (ASAN Innovations Centre) নির্বাহী পরিচালক ভুসাল রুস্তমভ (Vusal Rustamov) এর সাথে দ্বিপাক্ষিক বৈঠক করেন।

![”প্রযুক্তিদক্ষ তরুণরাই গড়বে সমৃদ্ধ বাংলাদেশ” — মন্ত্রী ফকির মাহবুব আনাম](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/5/54a2e0df-12bc-4c07-bd5f-28086a3a52cf.jpg)

”প্রযুক্তিদক্ষ তরুণরাই গড়বে সমৃদ্ধ বাংলাদেশ” — মন্ত্রী ফকির মাহবুব আনাম

![রাজধানীর আগারগাঁওস্থ বাংলাদেশ কম্পিউটার কাউন্সিল (বিসিসি) অডিটোরিয়ামে জাতীয় হাইস্কুল প্রোগ্রামিং প্রতিযোগিতা ২০২৬-এর চূড়ান্ত পর্ব উপলক্ষে সংবাদ সম্মেলন](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/5/def839e6-4a58-474d-ab54-015431c317c5.jpg)

রাজধানীর আগারগাঁওস্থ বাংলাদেশ কম্পিউটার কাউন্সিল (বিসিসি) অডিটোরিয়ামে জাতীয় হাইস্কুল প্রোগ্রামিং প্রতিযোগিতা ২০২৬-এর চূড়ান্ত পর্ব উপলক্ষে সংবাদ সম্মেলন

![নবযোগদানকৃত ভারপ্রাপ্ত সচিব মহোদয়ের সাথে মতবিনিময়](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/5/3dfb80af-1c5d-49cf-8bbe-644cb98ea7ad.jpeg)

নবযোগদানকৃত ভারপ্রাপ্ত সচিব মহোদয়ের সাথে মতবিনিময়

![মধুপুর উপজেলা স্বাস্থ্য কমপ্লেক্স পরিদর্শন](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/5/0cc39cd6-56eb-4c7a-afc8-b44d3d5a5c94.jpg)

মধুপুর উপজেলা স্বাস্থ্য কমপ্লেক্স পরিদর্শন

![টাঙ্গাইলের মধুপুর উপজেলা বিএনপির উদ্যোগে আয়োজিত শহীদ রাষ্ট্রপতি জিয়াউর রহমানের ৪৫তম শাহাদাত বার্ষিকী উপলক্ষ্যে আয়োজিত দোয়া মাহফিলে অংশগ্রহণ](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/5/32d17197-40ab-43e4-aca0-69608063e8e2.jpg)

টাঙ্গাইলের মধুপুর উপজেলা বিএনপির উদ্যোগে আয়োজিত শহীদ রাষ্ট্রপতি জিয়াউর রহমানের ৪৫তম শাহাদাত বার্ষিকী উপলক্ষ্যে আয়োজিত দোয়া মাহফিলে অংশগ্রহণ

![মে ২০২৬ মাসের এডিপি পর্যালোচনা সভা](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/5/bede7d72-fd08-4e21-985b-96b7ab07baa7.jpg)

মে ২০২৬ মাসের এডিপি পর্যালোচনা সভা

![হযরত শাহজালাল আন্তর্জাতিক বিমানবন্দরে ফ্রি ওয়াইফাই সেবা উদ্বোধন](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/4/6136455b-b824-4b1b-9f1b-82432bb5195f.jpeg)

হযরত শাহজালাল আন্তর্জাতিক বিমানবন্দরে ফ্রি ওয়াইফাই সেবা উদ্বোধন

❮ ❯

  

![জর্জিয়ার তিবিলিসিতে বাংলাদেশের ডাক, টেলিযোগাযোগ ও তথ্যপ্রযুক্তি মন্ত্রী ফকির মাহবুব আনাম কম্বোডিয়ার ডাক ও টেলিযোগাযোগ মন্ত্রী এইচ.ই. চিয়া ভানদেথ (H.E. Chea Vandeth)-এর সঙ্গে দ্বিপাক্ষিক বৈঠক করেন।](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/5/2c0063ef-efec-4d1e-9def-475487cea7ef.jpg) ![জর্জিয়ার তিবিলিসিতে বাংলাদেশের ডাক, টেলিযোগাযোগ ও তথ্য প্রযুক্তি মন্ত্রী ফকির মাহবুব আনাম কাজাখস্তানের 'আস্তানা সিভিল সার্ভিস হাব' (Astana Civil Service Hub)-এর চেয়ারম্যান আলিখান বাইমেনভ (Alikhan Baimenov) এর সাথে দ্বিপাক্ষিক বৈঠক করেন।](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/5/33732328-5651-4d0d-bf48-2f2e6eef0eb0.jpg) ![জর্জিয়ার তিবিলিসিতে বাংলাদেশের ডাক, টেলিযোগাযোগ ও তথ্য প্রযুক্তি মন্ত্রী ফকির মাহবুব আনাম আজারবাইজানের এএসএএন ইনোভেশনস সেন্টারের (ASAN Innovations Centre) নির্বাহী পরিচালক ভুসাল রুস্তমভ (Vusal Rustamov) এর সাথে দ্বিপাক্ষিক বৈঠক করেন।](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/5/4e6d137e-1ecf-4360-bb93-9b3c72f702b9.jpg) ![”প্রযুক্তিদক্ষ তরুণরাই গড়বে সমৃদ্ধ বাংলাদেশ” — মন্ত্রী ফকির মাহবুব আনাম](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/5/54a2e0df-12bc-4c07-bd5f-28086a3a52cf.jpg) ![রাজধানীর আগারগাঁওস্থ বাংলাদেশ কম্পিউটার কাউন্সিল (বিসিসি) অডিটোরিয়ামে জাতীয় হাইস্কুল প্রোগ্রামিং প্রতিযোগিতা ২০২৬-এর চূড়ান্ত পর্ব উপলক্ষে সংবাদ সম্মেলন](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/5/def839e6-4a58-474d-ab54-015431c317c5.jpg) ![নবযোগদানকৃত ভারপ্রাপ্ত সচিব মহোদয়ের সাথে মতবিনিময়](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/5/3dfb80af-1c5d-49cf-8bbe-644cb98ea7ad.jpeg) ![মধুপুর উপজেলা স্বাস্থ্য কমপ্লেক্স পরিদর্শন](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/5/0cc39cd6-56eb-4c7a-afc8-b44d3d5a5c94.jpg) ![টাঙ্গাইলের মধুপুর উপজেলা বিএনপির উদ্যোগে আয়োজিত শহীদ রাষ্ট্রপতি জিয়াউর রহমানের ৪৫তম শাহাদাত বার্ষিকী উপলক্ষ্যে আয়োজিত দোয়া মাহফিলে অংশগ্রহণ](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/5/32d17197-40ab-43e4-aca0-69608063e8e2.jpg) ![মে ২০২৬ মাসের এডিপি পর্যালোচনা সভা](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/5/bede7d72-fd08-4e21-985b-96b7ab07baa7.jpg) ![হযরত শাহজালাল আন্তর্জাতিক বিমানবন্দরে ফ্রি ওয়াইফাই সেবা উদ্বোধন](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/4/6136455b-b824-4b1b-9f1b-82432bb5195f.jpeg)

🡸 🡺

নোটিশ বোর্ড

-   [
    
    অফিস আদেশ-৪৩৪ (দায়িত্ব বণ্টন)
    
    ০১-০৭-২০২৬ **নতুন** **অফিস আদেশ**
    
    ](/pages/office-orders/6a4494eb28c42c6f052ef83f)
-   [
    
    e-Tender Notice for "Annual Maintenance Contract (AMC) for Server and Storage Systems for D-Nothi, Located at the Tier-4 Data Center, Kaliakair"
    
    ০১-০৭-২০২৬ **নতুন** **সাধারণ**
    
    ](/pages/notices/e-tender-notice-for-annual-maintenance-contract-amc-for-server-and-storage-systems-for-d-nothi-located-at-the-tier-4-data-center-kaliakair-1n1cyn-6a44942dd3ddcff4605a04d7)
-   [
    
    প্রজ্ঞাপন (জনাব আল-আমিন, ব্যক্তিগত কর্মকর্তা, তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ)
    
    ২৯-০৬-২০২৬ **নতুন** **বিভিন্ন আদেশ**
    
    ](/pages/go-ultimates/6a41f4c6c46c177d110645a6)

[সকল নোটিশ দেখুন](/pages/notices)

খবর

[হযরত শাহজালাল আন্তর্জাতিক বিমানবন্দরে ফ্রি ওয়াইফাই সেবা উদ্বোধন](/pages/news/হযরত-শাহজালাল-আন্তর্জাতিক-বিমানবন্দরে-ফ্রি-ওয়াইফাই-সেবা-উদ্বোধন-2odqra-6a0a8e33f284771b36b14382) [বিশ্ব টেলিযোগাযোগ ও তথ্য সংঘ দিবস ২০২৬ উদযাপন](/pages/news/বিশ্ব-টেলিযোগাযোগ-ও-তথ্য-সংঘ-দিবস-২০২৬-উদযাপন-b7j6qs-6a0a8bff5d40ccedfd8e2455) [রাজধানীর ওসমানী স্মৃতি মিলনায়তনে জেলা প্রশাসক সম্মেলন ২০২৬ এর তৃতীয় অধিবেশনে বক্তব্য রাখেন ডাক, টেলিযোগাযোগ ও তথ্য প্রযুক্তি মন্ত্রণালয় এবং বিজ্ঞান ও প্রযুক্তি মন্ত্রণালয়ের মন্ত্রী ফকির মাহবুব আনাম ।](/pages/news/রাজধানীর-ওসমানী-স্মৃতি-মিলনায়তনে-জেলা-প্রশাসক-সম্মেলন-২০২৬-এর-তৃতীয়-অধিবেশনে-বক্তব্য-রাখেন-ডাক-টেলিযোগাযোগ-ও-তথ্য-প্রযুক্তি-মন্ত্রণালয়-এবং-বিজ্ঞান-ও-প্রযুক্তি-মন্ত্রণালয়ের-মন্ত্রী-ফকির-মাহবুব-আনাম--bz3m9j-69fac031a9b39d45e9d75517) [ডাক, টেলিযোগাযোগ ও তথ্যপ্রযুক্তি এবং বিজ্ঞান ও প্রযুক্তি মন্ত্রী ফকির মাহবুব আনাম টাঙ্গাইলের শহীদ মারুফ স্টেডিয়াম পরিদর্শন করেন।](/pages/news/ডাক-টেলিযোগাযোগ-ও-তথ্যপ্রযুক্তি-এবং-বিজ্ঞান-ও-প্রযুক্তি-মন্ত্রী-ফকির-মাহবুব-আনাম-টাঙ্গাইলের-শহীদ-মারুফ-স্টেডিয়াম-পরিদর্শন-করেন-4zda8j-69dd18482bea4766e9c8513f) [কক্সবাজার রেলওয়ে স্টেশন প্রাঙ্গণে মন্ত্রী এবং উপদেষ্টার গাছের চারা রোপণ](/pages/news/কক্সবাজার-রেলওয়ে-স্টেশন-প্রাঙ্গণে-মন্ত্রী-এবং-উপদেষ্টার-গাছের-চারা-রোপণ-am6qy7-69dc73d890a32ce7bcff3812)

[সকল](/pages/news/)

সেবা সমূহ

[সব দেখুন](/pages/service-boxes)

# আমাদের বিষয়ে

![আমাদের বিষয়ে](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/2c01445e8387410b83f69dfbd2c30a46.png)

-   [ভিশন ও মিশন](/pages/static-pages/69414b2535ce18e1c059aeca "ভিশন ও মিশন")
-   [সাংগঠনিক কাঠামো](/pages/static-pages/69414b2535ce18e1c059ae22 "সাংগঠনিক কাঠামো")
-   [কর্মকর্তা/কর্মচারী](/pages/officers "কর্মকর্তা/কর্মচারী")
-   [কর্মবন্টন](/pages/work-distributions?filters=%7B%22wing%22%3A%2269414a4d35ce18e1c059a87d%22%7D "কর্মবন্টন")

# বিজ্ঞপ্তি/আদেশ/পরিপত্র

![বিজ্ঞপ্তি/আদেশ/পরিপত্র](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/6b22571d60494a2e831f198cd7026958.png)

-   [প্রজ্ঞাপন/পরিপত্র](/pages/go-ultimates?filters=%7B%22order%22%3A%20%2269414a4c35ce18e1c059a822%22%7D "প্রজ্ঞাপন/পরিপত্র")
-   [অফিস আদেশ/বিদেশ ভ্রমণের জিও/পাসপোর্ট অনাপত্তিপত্র](/pages/static-pages/69414b2535ce18e1c059aec7 "অফিস আদেশ/বিদেশ ভ্রমণের জিও/পাসপোর্ট অনাপত্তিপত্র")
-   [সংবাদ বিজ্ঞপ্তি](/pages/press-releases "সংবাদ বিজ্ঞপ্তি")
-   [দরপত্র/নিয়োগ বিজ্ঞপ্তি](/pages/static-pages/69414b2535ce18e1c059ae89 "দরপত্র/নিয়োগ বিজ্ঞপ্তি")

# নীতিমালা ও প্রকাশনা

![নীতিমালা ও প্রকাশনা](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/143823adee99439c9933b58f412032b6.png)

-   [নীতিমালা](/pages/policies "নীতিমালা")
-   [আইন ও বিধি/নির্দেশিকা ও কৌশলপত্র](/pages/static-pages/69414b2535ce18e1c059aeae "আইন ও বিধি/নির্দেশিকা ও কৌশলপত্র")
-   [বার্ষিক প্রতিবেদন](/pages/annual-reports "বার্ষিক প্রতিবেদন")
-   [বিভিন্ন প্রকাশনা ও প্রতিবেদন](/pages/publications "বিভিন্ন প্রকাশনা ও প্রতিবেদন")

# নাগরিক ই-সেবাসমূহ

![নাগরিক ই-সেবাসমূহ](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/76c8e59a8ef649d384763dffcf822270.png)

-   [উদ্ভাবনীমুলক কাজে অনুদান](http://ims.ictd.gov.bd/ "উদ্ভাবনীমুলক কাজে অনুদান")
-   [ফেলোশিপ ও বৃত্তি](http://ims.ictd.gov.bd/ "ফেলোশিপ ও বৃত্তি")
-   [হাইটেক পার্ক ওয়ান স্টপ সার্ভিস](https://ossbhtpa.gov.bd/ "হাইটেক পার্ক ওয়ান স্টপ সার্ভিস")
-   [অন্যান্য ই-সেবা](https://www.nagoriksheba.gov.bd/ "অন্যান্য ই-সেবা")

# সেবা প্রদান প্রতিশ্রুতি (সিটিজেন্‌স চার্টার)

![সেবা প্রদান প্রতিশ্রুতি (সিটিজেন্‌স চার্টার)](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/991a08df4bc74227b6289b9c581d7567.png)

-   [সেবা প্রদান প্রতিশ্রুতি](/pages/office-citizen-charters/69414b0435ce18e1c059a909 "সেবা প্রদান প্রতিশ্রুতি ")
-   [ফোকাল পয়েন্ট/পরিবীক্ষণ কমিটি](/pages/static-pages/69414b2535ce18e1c059ae87 "ফোকাল পয়েন্ট/পরিবীক্ষণ কমিটি")
-   [কর্মপরিকল্পনা, পরিবীক্ষণ ও মূল্যায়ন প্রতিবেদন](/pages/reports?filters=%7B%22reports_type%22%3A%20%2269414a4d35ce18e1c059a874%22%7D "কর্মপরিকল্পনা, পরিবীক্ষণ ও মূল্যায়ন প্রতিবেদন")
-   [আইন/বিধি/নীতিমালা/পরিপত্র/প্রজ্ঞাপন/পরিপত্র](/pages/reports?filters=%7B%22reports_type%22%3A%20%2269414a4d35ce18e1c059a875%22%7D "আইন/বিধি/নীতিমালা/পরিপত্র/প্রজ্ঞাপন/পরিপত্র")

# সরকারি কর্মসম্পাদন পরিবীক্ষণ পদ্ধতি

![সরকারি কর্মসম্পাদন পরিবীক্ষণ পদ্ধতি](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/7bf84d127d3841c5ab5f4154039c9dac.png)

-   [নির্দেশিকা/পরিপত্র/GPMS টিম/ফোকাল পয়েন্ট](/pages/static-pages/69414b2535ce18e1c059ae91 "নির্দেশিকা/পরিপত্র/GPMS টিম/ফোকাল পয়েন্ট")
-   [GPMS ও ফলাফল](/pages/reports?filters=%7B%22reports_type%22%3A%20%2269414a4d35ce18e1c059a845%22%7D "GPMS ও ফলাফল")
-   [পরিবীক্ষণ ও মূল্যায়ন প্রতিবেদন](/pages/reports?filters=%7B%22reports_type%22%3A%20%2269414a4d35ce18e1c059a878%22%7D "পরিবীক্ষণ ও মূল্যায়ন প্রতিবেদন")
-   [GPMS সফটওয়্যার লিংক](http://gpmsbd.cabinet.gov.bd/ "GPMS সফটওয়্যার লিংক")

# জাতীয় শুদ্ধাচার কৌশল

![জাতীয় শুদ্ধাচার কৌশল](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/9e5fc0fecdbe44f4ae1a91ad7b2be09f.png)

-   [উত্তম চর্চা কর্মপরিকল্পনা সফটওয়্যার লিংক](https://nis.cabinet.gov.bd/login "উত্তম চর্চা কর্মপরিকল্পনা সফটওয়্যার লিংক")
-   [নৈতিকতা কমিটি ও ফোকাল পয়েন্ট](/pages/static-pages/69414b2535ce18e1c059ae02 "নৈতিকতা কমিটি ও ফোকাল পয়েন্ট ")
-   [পরিবীক্ষণ/মূল্যায়ন প্রতিবেদন](/pages/reports?filters=%7B%22reports_type%22%3A%20%2269414a4d35ce18e1c059a841%22%7D "পরিবীক্ষণ/মূল্যায়ন প্রতিবেদন")
-   [আইন/বিধি/ নীতিমালা/নির্দেশিকা/পরিপত্র/প্রজ্ঞাপন/কর্মপরিকল্পনা](/pages/reports?filters=%7B%22reports_type%22%3A%20%2269414a4d35ce18e1c059a864%22%7D "আইন/বিধি/ নীতিমালা/নির্দেশিকা/পরিপত্র/প্রজ্ঞাপন/কর্মপরিকল্পনা")

# অভিযোগ প্রতিকার ব্যবস্থাপনা

![অভিযোগ প্রতিকার ব্যবস্থাপনা](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/850c2871d1c040c181e5b774aafb1d50.png)

-   [অনিক ও আপিল কর্মকর্তা](/pages/static-pages/69414b2535ce18e1c059ae45 "অনিক ও আপিল কর্মকর্তা ")
-   [কর্মপরিকল্পনা, পরিবীক্ষণ ও মূল্যায়ন প্রতিবেদন](/pages/reports?filters=%7B%22reports_type%22%3A%20%2269414a4d35ce18e1c059a85b%22%7D "কর্মপরিকল্পনা, পরিবীক্ষণ ও মূল্যায়ন প্রতিবেদন")
-   [অভিযোগ দাখিল (অনলাইন)](http://www.grs.gov.bd/ "অভিযোগ দাখিল (অনলাইন)")
-   [আইন/বিধি/নীতিমালা/পরিপত্র/প্রজ্ঞাপন/নির্দেশিকা](/pages/reports?filters=%7B%22reports_type%22%3A%20%2269414a4d35ce18e1c059a876%22%7D "আইন/বিধি/নীতিমালা/পরিপত্র/প্রজ্ঞাপন/নির্দেশিকা")

# তথ্য অধিকার

![তথ্য অধিকার](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/3101033d43fc415197fb4f2c42dfea75.png)

-   [দায়িত্বপ্রাপ্ত কর্মকর্তা ও আপীল কর্তৃপক্ষ](/views/info-officers "দায়িত্বপ্রাপ্ত কর্মকর্তা ও আপীল কর্তৃপক্ষ ")
-   [আবেদন ও আপিল ফরম](/pages/static-pages/69414b2535ce18e1c059ae7b "আবেদন ও আপিল ফরম")
-   [স্বপ্রণোদিতভাবে প্রকাশযোগ্য তথ্যসমূহ/বাস্তবায়ন অগ্রগতি প্রতিবেদন](/pages/static-pages/69414b2435ce18e1c059adc1 "স্বপ্রণোদিতভাবে প্রকাশযোগ্য তথ্যসমূহ/বাস্তবায়ন অগ্রগতি প্রতিবেদন")
-   [আইন/বিধি/কর্মপরিকল্পনা/প্রতিবেদন/নীতিমালা/পরিপত্র/নির্দেশিকা/প্রজ্ঞাপন](/pages/reports?filters=%7B%22reports_type%22%3A%20%2269414a4d35ce18e1c059a877%22%7D "আইন/বিধি/কর্মপরিকল্পনা/প্রতিবেদন/নীতিমালা/পরিপত্র/নির্দেশিকা/প্রজ্ঞাপন ")

# উদ্ভাবনী কার্যক্রম

![উদ্ভাবনী কার্যক্রম](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/e0e945748a9448fe9e8535a819f2feac.png)

-   [ইনোভেশন টিম](/pages/innovation-corners?filters=%7B%22innovation_corner_type%22%3A%20%2269414a4c35ce18e1c059a7fa%22%7D "ইনোভেশন টিম")
-   [ইনোভেশন আইডিয়া](/pages/innovation-corners?filters=%7B%22innovation_corner_type%22%3A%20%2269414a4c35ce18e1c059a81c%22%7D "ইনোভেশন আইডিয়া")
-   [ইনোভেশন কর্মপরিকল্পনা/প্রকাশনা](/pages/innovation-corners?filters=%7B%22innovation_corner_type%22%3A%20%2269414a4c35ce18e1c059a7fb%22%7D "ইনোভেশন কর্মপরিকল্পনা/প্রকাশনা")
-   [পাইলটিং প্রকল্পের তালিকা](/pages/innovation-corners/69414b4335ce18e1c059aef1 "পাইলটিং প্রকল্পের তালিকা")

# সেবা সহজিকরণ

![সেবা সহজিকরণ](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/a21bb5aa6c004d1099960226f1daca25.png)

-   [প্রজ্ঞাপন/পরিপত্র/নীতিমালা/প্রকাশনা](/pages/static-pages/69414b2435ce18e1c059adcc "প্রজ্ঞাপন/পরিপত্র/নীতিমালা/প্রকাশনা")
-   [বাস্তবায়িত ডিজিটাল সেবার তথ্য](/pages/static-pages/69414b2535ce18e1c059ae28 "বাস্তবায়িত ডিজিটাল সেবার তথ্য")
-   [সেবা সহজিকরণের দৃষ্টান্ত](/pages/static-pages/69414b2535ce18e1c059ae1e "সেবা সহজিকরণের দৃষ্টান্ত")
-   [সহজিকৃত সেবার তালিকা](/pages/sps-datas/69414b2235ce18e1c059ac80 "সহজিকৃত সেবার তালিকা")

# বাজেট ও প্রকল্পসমূহ

![বাজেট ও প্রকল্পসমূহ](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/c30e8fc0f7b5400492d7465c2ec8df27.png)

-   [বার্ষিক ক্রয় পরিকল্পনা](/pages/static-pages/69414b2535ce18e1c059ae65 "বার্ষিক ক্রয় পরিকল্পনা ")
-   [বাজেট ও এমটিবিএফ বাজেট](/pages/static-pages/69414b2535ce18e1c059ae10 "বাজেট ও এমটিবিএফ বাজেট")
-   [বাজেট প্রতিবেদন/অফিস আদেশ](/pages/static-pages/69414b2435ce18e1c059add4 "বাজেট প্রতিবেদন/অফিস আদেশ")
-   [গুরুত্বপূর্ণ সমাপ্ত প্রকল্পসমূহ](/pages/static-pages/69414b2535ce18e1c059ae08 "গুরুত্বপূর্ণ সমাপ্ত প্রকল্পসমূহ")

# এসডিজি ও উন্নয়ন কর্মপরিকল্পনা

![এসডিজি ও উন্নয়ন কর্মপরিকল্পনা](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/4dc1a42dbdcd44f582130fc6f4577fe7.png)

-   [মন্ত্রণালয়/বিভাগের এসডিজি](/pages/static-pages/69414b2435ce18e1c059adc8 "মন্ত্রণালয়/বিভাগের এসডিজি")
-   [এসডিজি ফোকাল পয়েন্ট/বিকল্প ফোকাল পয়েন্ট](/pages/static-pages/69414b2435ce18e1c059adc8 "এসডিজি ফোকাল পয়েন্ট/বিকল্প ফোকাল পয়েন্ট")
-   [এসডিজি জাতীয় ডকুমেন্ট](/pages/static-pages/69414b2535ce18e1c059aeb7 "এসডিজি জাতীয় ডকুমেন্ট")
-   [পঞ্চবার্ষিকী পরিকল্পনা ও প্রতিবেদন](/pages/publications/69414b2235ce18e1c059ac8b "পঞ্চবার্ষিকী পরিকল্পনা ও প্রতিবেদন")

# জাতীয় আইসিটি নীতিমালা ২০১৮

![জাতীয় আইসিটি নীতিমালা ২০১৮](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/a16e2f4e90ae403d828fddd36cc009f1.JPG)

-   [জাতীয় আইসিটি নীতিমালা ২০১৮](/pages/static-pages/69414b2535ce18e1c059aeaf "জাতীয় আইসিটি নীতিমালা ২০১৮")
-   [মন্ত্রণালয়/বিভাগভিত্তিক কর্মপরিকল্পনা](/pages/static-pages/69414b2535ce18e1c059ae43 "মন্ত্রণালয়/বিভাগভিত্তিক কর্মপরিকল্পনা")
-   [অফিস আদেশ, প্রজ্ঞাপন](/pages/static-pages/69414b2535ce18e1c059aebb "অফিস আদেশ, প্রজ্ঞাপন")
-   [ফোকাল পয়েন্ট](/pages/static-pages/69414b2535ce18e1c059ae12 "ফোকাল পয়েন্ট")

# বিবিধ

![বিবিধ](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/f1d2aff943d44df7919dcd022f0c398f.png)

-   [বিভিন্ন ফরম](/pages/static-pages/69414b2435ce18e1c059adbc "বিভিন্ন ফরম")
-   [উত্তম চর্চা](/pages/static-pages/69414b2435ce18e1c059adf0 "উত্তম চর্চা")
-   [আইসিটি সম্পর্কিত অর্জিত পুরস্কার](/pages/static-pages/69414b2435ce18e1c059addb "আইসিটি সম্পর্কিত অর্জিত পুরস্কার ")
-   [বিভিন্ন কমিটি](/pages/committees "বিভিন্ন কমিটি")

সকল সেবাসমূহ দেখুন সংক্ষিপ্ত

### বন্যার সময় কি করণীয়

### এক্সেসিবিলিটি

ফন্ট বৃদ্ধি ফন্ট হ্রাস

 মনোক্রোম

 ইনভার্ট

 বড় কার্সর

 লিঙ্ক হাইলাইট

 শিরোনাম হাইলাইট

 পড়ার গাইড

রিসেট

[স্ক্রিন রিডার ডাউনলোড করুন](https://www.nvaccess.org/files/nvda/releases/2020.4/nvda_2020.4.exe)

[কন্টেন্টে চলে যান](#main-content) [এক্সেসিবিলিটি মেনুতে যান](#accessibility-card-title)

# 

মাননীয় মন্ত্রী

![minister](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/3/a4b04fd5-ca63-4567-aace-5e3ba6e776dd.jpeg)

**

ফকির মাহবুব আনাম, এমপি

**মাননীয় মন্ত্রী**

Faqir Mahbub Anam, MP

Hon’ble Minister, Ministry of Post and Telecommunication, ICT Division and Ministry of Science and Technology, Bangladesh

Faqir Mahbub Anam is a prominent Bangladeshi politician and a senior leader of Bangladesh Nationalist Party (BNP). He is an elected Member of Parliament (MP) from the Tangail-1 (Madhupur-Dhonbari) Constituency in the 2026 national parliamentary elections. He was appointed as the Minister for Post and Telecommunication, ICT Division and Ministry of Science and Technology of the government of the People’s Republic of Bangladesh on 17th February 2026. Within his party, he serves as the ex. Acting President, B.N.P. Greater Tangail District and as Executive Member of BNP’s Central Committee.

Born on 5 March 1953 in Tangail, Bangladesh, Mr. Anam pursued higher education at the University of Dhaka, earning a Bachelor of Science degree before advancing to the United Kingdom for specialized studies in Automobile Engineering at Willesden College of Technology, London, in 1979. His international academic exposure laid the foundation for a global outlook that would later influence his entrepreneurial journey

**Family and Personal Life**

Mr. Anam comes from a respected family background with longstanding involvement in business and public service. He is married to Dr. Reshma Anam, MBBS, FCGP, MPH. His family includes internationally educated professionals based in the United States, the United Kingdom, and Canada, reflecting a strong tradition of education and global engagement.

-   **Son:** Faqir Riasat Saleqin Anam – Graduate in Economics, Boston University, USA
    
-   **Son:** Raad Sharrar Anam – Graduate in politics, Brandeis University, USA; Master’s, University of Reading, UK
    
-   **Daughter-in-Law:** Graduate, University of Toronto, Canada
    

**Notable Relatives:**

-   Late Afaz Uddin Faqir – Former MNA, Former MP, Former Vice Chairman of BNP; Recipient of Sitara-e-Quaid-e-Azam (S.Q.A.)
    
-   Late Lokman Hossen Faqir – Founder Chairman, Jatiyatabadi Samajik Sangskritik Sangstha (JASAS); Former Cultural Secretary, BNP; Recipient of Ekushey Padak
    

He is the visionary business leader with over 40 years of executive leadership across fisheries, agro-industry, garments, renewable energy, leisure infrastructure, and international trade. Proven track record in board governance, export expansion, industry representation, and institutional leadership. Recipient of the Prime Minister’s Gold Medal (1998) for excellence in hatchery operations. Extensive global exposure across North America, Europe, Asia, and Australia.

Recognized for strategic growth leaders hip, policy advocacy, industry association leadership, and multi-sector investment management.

Faqir Mahbub Anam is a distinguished Bangladeshi entrepreneur, industrialist, and board-level executive whose business leadership spans more than four decades. With diversified involvement in fisheries, aquaculture, garments, agro-industry, renewable energy, marine enterprises, tea, and jute exports, he has played a meaningful role in shaping Bangladesh’s private-sector growth and export development.

.

**Early Industrial Leadership and Expansion**

Mr. Anam began his business career in the early 1980s, entering the fisheries and marine export sector at a time when Bangladesh’s seafood industry was expanding into international markets. As Managing Director of Shimizu Specialized Fishing Pvt. Ltd. (since 1982), he contributed to the development of organized shrimp and fish exports, helping position Bangladeshi seafood in competitive global markets.

From 1982 to 2004, he led shrimp and fish export operations, establishing strong commercial networks in North America, Europe, and Asia. Recognizing the importance of sustainability and value-chain development, he expanded into hatchery operations in 1995. His hatchery enterprise earned national recognition when it was awarded the Prime Minister’s Gold Medal in 1998 for being the best hatchery in the country—an acknowledgment of excellence in quality, innovation, and industry contribution.

**Diversification into Garments and Manufacturing**

During the 1990s, Mr. Anam diversified into the ready-made garments sector, serving as Chairman of Vase Apparels Ltd. and leading export operations from 1993 to 2007. His involvement aligned with Bangladesh’s rapid emergence as a global garment exporter. He also chaired Vase Paper Products Ltd., contributing to manufacturing and industrial expansion beyond textiles.

Through these ventures, he gained extensive experience in export compliance, international buyer relations, workforce management, and industrial operations at scale.

**Agro-Industry, Energy, and Contemporary Leadership**

In subsequent years, Mr. Anam expanded his business portfolio into agro-processing, renewable energy initiatives, and diversified trading. He currently serves as:

-   Chairman, Sun N’ Sands Amusement Park Pvt. Ltd.
    
-   Managing Director, Anam Agro Products Ltd.
    
-   Managing Partner, Shimizu Hatchery & Nursery (Shrimp)
    
-   Managing Partner, Anam Green Fuel Energy Resource
    
-   Managing Partner, Anam Eastern Traders
    

His leadership reflects a continued commitment to sustainable enterprise development, agricultural modernization, and energy diversification.

**National Trade and Policy Engagement**

Beyond entrepreneurship, Mr. Anam has been actively engaged in national trade bodies and policy forums. He served as Co-Chairman of the Standing Committee on Human Resource Development & Employment at the Federation of Bangladesh Chambers of Commerce & Industry, the apex trade organization of the country. In this role, he contributed to discussions on workforce development, industrial competitiveness, and employment policy.

He also held similar leadership responsibilities at the Bangladesh Garment Manufacturers & Exporters Association, supporting the development of human capital within Bangladesh’s garment sector.

Earlier in his career, he served as Secretary General of the Bangladesh Marine Fisheries Association (BMFA), where he represented sectoral interests and contributed to strengthening the marine export industry.

**Institutional and Social Leadership**

Mr. Anam’s leadership extends beyond commercial enterprises. He served as:

-   Director (Former), National Tea Company (NTC)
    
-   Chairman (Former), Tangail Red Crescent Society
    
-   Vice-Chairman (Former), Mohammedan Sporting Club
    

Through these roles, he supported institutional governance, social service initiatives, and community engagement efforts.

**Club Memberships**

-   Gulshan Club Ltd.
    
-   Chittagong Club Ltd.
    
-   Bhatiary Golf Club
    
-   Kurmitola Golf Club Ltd.
    
-   Dhaka Club Ltd. (ex)
    
-   Uttara Club Ltd. (ex)
    
-   Navy Club (ctg)
    
-   Baridhara Diplomatic Club (founder Member)
    

**International Exposure**

Over the decades, Mr. Anam has traveled extensively across the United States, United Kingdom, Canada, Europe, Southeast Asia, East Asia, Australia, and the Middle East. This international exposure has enriched his understanding of global trade dynamics, cross-cultural business practices, and evolving market standards.

**Legacy and Continuing Contribution**

Throughout his career, Faqir Mahbub Anam has demonstrated resilience, adaptability, and strategic foresight. From pioneering shrimp exports and hatchery development to contributing to garment manufacturing, agro-industry, and renewable energy ventures, his leadership mirrors the evolution of Bangladesh’s private sector over the last four decades.

With sustained engagement in trade bodies, industrial enterprises, and social institutions, he continues to contribute to economic development, entrepreneurship, and governance in Bangladesh.

**[বিস্তারিত](/pages/office-heads/মাননীয়-মন্ত্রী-loxkkh-6996c10ff365cabf42e17376)

# 

মাননীয় উপদেষ্টা

![minister](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/2/a6f65553-32a8-4138-94dc-6b621ca36c1f.jpeg)

**

জনাব রেহান আসিফ আসাদ

**মাননীয় প্রধানমন্ত্রীর ডাক, টেলিযোগাযোগ ও তথ্যপ্রযুক্তি বিষয়ক উপদেষ্টা (প্রতিমন্ত্রী পদমর্যাদা)**

**[বিস্তারিত](/pages/office-heads/মাননীয়-প্রধানমন্ত্রীর-ডাক-টেলিযোগাযোগ-ও-তথ্যপ্রযুক্তি-বিষয়ক-উপদেষ্টা-প্রতিমন্ত্রী-পদমর্যাদা-b8ptoc-69c8c48b4e6074befaa63a90)

# 

সচিব

![minister](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/5/cc79a445-8693-460a-b109-d91320beff8a.png)

**

জনাব মোঃ মামুনুর রশীদ ভূঞা

**ভারপ্রাপ্ত সচিব**

**[বিস্তারিত](/pages/office-heads/সচিব-996546-69414b04a31054345f0fcc7d)

# [সরকারি অফিসের নতুন ওয়েবসাইটের আবেদন](https://pms.portal.gov.bd/office/outauth_new_office)

[![](/site-assets/images/service_link_1.jpg)](https://edirectory.portal.gov.bd/)

[![](/site-assets/images/service_link_5.jpg)](https://www.mygov.bd/)

[![](/site-assets/images/service_link_3.gif)](#)

# অভ্যন্তরীণ ই-সেবাসমূহ

-   [ওয়েব মেইল](http://mail.ictd.gov.bd)
-   [বৃত্তি ও আইসিটি উদ্ভাবনী অনুদান অনলাইন আবেদন](/pages/static-pages/69414b2535ce18e1c059aec6)
-   [ন্যাশনাল এন্টারপ্রাইজ আর্কিটেকচার](http://nea.bcc.gov.bd/)
-   [CIRT](https://www.cirt.gov.bd/)
-   [অনলাইন নিয়োগ সিস্টেম](https://erecruitment.bcc.gov.bd/exam/?lang=bn)
-   [ওয়ান স্টপ সার্ভিস (বাংলাদেশ হাইটেক পার্ক কর্তৃপক্ষ)](https://ossbhtpa.gov.bd/)

[সকল](/pages/internal-eservices)

 [![](/site-assets/images/service_link_1.jpg)](https://edirectory.portal.gov.bd/)[![](/site-assets/images/service_link_2.gif) ](https://www.mygov.bd/)[![](/site-assets/images/service_link_3.gif)](#)

[কেন্দ্রীয় ই-সেবাসমূহ](https://bangladesh.gov.bd/site/view/all_eservices_in_bangladesh/)

# গুরুত্বপূর্ণ লিঙ্ক

-   [রাষ্ট্রপতির কার্যালয়](http://www.bangabhaban.gov.bd/)
-   [প্রধানমন্ত্রীর কার্যালয়](https://pmo.gov.bd/)
-   [মন্ত্রিপরিষদ বিভাগ](http://www.cabinet.gov.bd/)
-   [বাংলাদেশ কর্মচারী কল্যাণ বোর্ড](http://www.bkkb.gov.bd)
-   [এনএসডিএ](http://www.nsda.gov.bd/)
-   [জাতীয় পোর্টাল](http://bangladesh.gov.bd/)
-   [মুক্তপাঠ](http://www.muktopaath.gov.bd/)

[সকল](/pages/external-links)

### ওয়েবসাইট দর্শনার্থী \[০৬.১১.২০১৯ তারিখ থেকে কার্যকর\]

[Free-Hit-Counters.net](https://free-hit-counters.net/)

[![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2025/11/67014dc8-1eb0-48e6-9be9-634d632e9979.jpg)](https://ictd.gov.bd/sites/default/files/files/ictd.portal.gov.bd/files/f071a55e_9356_44ed_ba33_461288ec14bd/FAQ%20on%20Electronic%20Toll%20Collection%20%28ETC%29%20System.pdf)

### জরুরি যোগাযোগ

[সরকারি তথ্য ও সেবা **৩৩৩**](https://bangladesh.gov.bd/site/page/aaebba14-f52a-4a3d-98fd-a3f8b911d3d9) [জরুরি সেবা **৯৯৯**](https://bangladesh.gov.bd/site/page/aaebba14-f52a-4a3d-98fd-a3f8b911d3d9) [ফায়ার সার্ভিস হটলাইন **১০২**](https://bangladesh.gov.bd/site/page/aaebba14-f52a-4a3d-98fd-a3f8b911d3d9)

সকল সেবা দেখুন সংক্ষিপ্ত

### ডেঙ্গু প্রতিরোধে করণীয়

[![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/b20b284df49c46daa7c81e9758789f6e.jpg)](https://bangladesh.gov.bd/site/page/91530698-c795-4542-88f2-5da1870bd50c)

###### জাতীয় সঙ্গীত

# সামাজিক যোগাযোগ

[](https://www.facebook.com/ictdivisionbd "facebook")