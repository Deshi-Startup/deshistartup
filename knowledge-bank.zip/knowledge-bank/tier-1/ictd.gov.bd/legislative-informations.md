---
source: "ICT Division"
tier: 1
category: "ICT policy"
url: "https://ictd.gov.bd/pages/legislative-informations"
title: "বিধানিক তথ্যাবলী | তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ"
scraped_at: "2026-07-02"
---

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

## বিধানিক তথ্যাবলী

 এডভান্সড অপশনগুলো দেখান

গ্রুপ অনুসারে কিছুই না শিরোনাম,প্রকাশের তারিখ

পৃষ্ঠা আইটেম ১০ ২০ ৫০ ১০০

নং

শিরোনাম

পিডিএফ সংযুক্তি

ডক সংযুক্তি

প্রকাশের তারিখ

কার্যকলাপ

 

   

   

 

১

বেসরকারী হাই-টেক পার্ক ঘোষণা সংক্রান্ত গাইডলাইন-২০২৪

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/782165ddfd4d4ba1924798114c08688b.pdf "office-ictd/2024/12/782165ddfd4d4ba1924798114c08688b.pdf")

২০-০৩-২০২৪

[দেখুন](/pages/legislative-informations/বেসরকারী-হাই-টেক-পার্ক-ঘোষণা-সংক্রান্ত-গাইডলাইন-২০২৪-9c4338-69414b22c4774958d7b556aa)

২

ডিজিটাল ফরেনসিক গাইডলাইন, ২০২৩

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/e3d6c1bd366944afbf06ff1cb198a12e.pdf "ডিজিটাল ফরেনসিক গাইডলাইন, ২০২৩")

১৯-০৭-২০২৩

[দেখুন](/pages/legislative-informations/ডিজিটাল-ফরেনসিক-গাইডলাইন-২০২৩-029b4a-69414b22c4774958d7b556a3)

৩

GUIDELINES FOR VENTURE CAPITAL FUND MANAGEMENT UNDER iDEA PROJECT (REVISED)

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/ddc7d33385b84d25ad95662e85ae3447.pdf "office-ictd/2024/12/ddc7d33385b84d25ad95662e85ae3447.pdf")

২০-০৯-২০২২

[দেখুন](/pages/legislative-informations/guidelines-for-venture-capital-fund-management-under-idea-project-revised-8f1622-69414b22c4774958d7b556a5)

৪

ক্ষুদ্র ও মাঝারি শিল্প প্রতিষ্ঠান (এসএমই) অনুদান প্রদান সম্পর্কিত গাইডলাইন-২০২২'

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/a84fe9efe04647ddb507ff57e626c817.pdf "ক্ষুদ্র ও মাঝারি শিল্প প্রতিষ্ঠান (এসএমই) অনুদান প্রদান সম্পর্কিত গাইডলাইন-২০২২'")

২০-০৯-২০২২

[দেখুন](/pages/legislative-informations/ক্ষুদ্র-ও-মাঝারি-শিল্প-প্রতিষ্ঠান-এসএমই-অনুদান-প্রদান-সম্পর্কিত-7d8d50-69414b22c4774958d7b5569b)

৫

'তথ্য ও যোগাযোগ প্রযুক্তি (তদন্ত পরিচালনা) বিধিমালা, ২০২২'

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/aae02ff450884003869d87a3e96513c3.pdf "office-ictd/2024/12/aae02ff450884003869d87a3e96513c3.pdf")

১২-০৯-২০২২

[দেখুন](/pages/legislative-informations/তথ্য-ও-যোগাযোগ-প্রযুক্তি-তদন্ত-পরিচালনা-বিধিমালা-২০২২-de944f-69414b22c4774958d7b556a0)

৬

Government of Bangladesh Information Security Manual

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/cd12f6d7d8584804a28c6c72f35798db.pdf "Government of Bangladesh Information Security Manual")

২১-০৮-২০২২

[দেখুন](/pages/legislative-informations/government-of-bangladesh-information-security-manual-6e8aec-69414b22c4774958d7b5569f)

৭

গুরুত্বপূর্ণ তথ্য পরিকাঠামোর ডিজিটাল নিরাপত্তা সুরক্ষা গাইডলাইন ২০২২

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/c882160cd6344d0782e98ed0a4352d01.pdf "office-ictd/2024/12/c882160cd6344d0782e98ed0a4352d01.pdf")

১১-০৮-২০২২

[দেখুন](/pages/legislative-informations/গুরুত্বপূর্ণ-তথ্য-পরিকাঠামোর-ডিজিটাল-নিরাপত্তা-সুরক্ষা-e71f7d-69414b22c4774958d7b556a7)

৮

গবেষণা গাইডলাইন ২০২২

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/d4ba8fc8c6054861a3e2867342e68338.pdf "office-ictd/2024/12/d4ba8fc8c6054861a3e2867342e68338.pdf")

১১-০৫-২০২২

[দেখুন](/pages/legislative-informations/গবেষণা-গাইডলাইন-২০২২-76cc14-69414b22c4774958d7b556b1)

৯

মেইড ইন বাংলাদেশ-আইসিটি ইন্ডাস্ট্রি স্ট্রাটেজি ২০২২

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/a70c712e0b47439ab6a78065f9b6ba4c.pdf "office-ictd/2024/12/a70c712e0b47439ab6a78065f9b6ba4c.pdf")

১৩-০২-২০২২

[দেখুন](/pages/legislative-informations/মেইড-ইন-বাংলাদেশ-আইসিটি-ইন্ডাস্ট্রি-স্ট্রাটেজি-২০২২-b624b7-69414b22c4774958d7b556a2)

১০

'৩৩৩-সংক্রান্ত নির্দেশিকা ২০২১'

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/e18e6bb258904226add57d11fea9ae7e.pdf "office-ictd/2024/12/e18e6bb258904226add57d11fea9ae7e.pdf")

২১-০৫-২০২১

[দেখুন](/pages/legislative-informations/৩৩৩-সংক্রান্ত-নির্দেশিকা-২০২১-d3eb8e-69414b22c4774958d7b556b2)

-   ১
-   ২
-   ৩
-   **পরবর্তী** 🡲
-   পৃষ্ঠায় যান 

আর্কাইভ দেখুন প্রকাশিত দেখুন দেখছেন ১ থেকে ১০ পর্যন্ত, মোট ২৯ এন্ট্রি

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

### এক্সেসিবিলিটি

ফন্ট বৃদ্ধি ফন্ট হ্রাস

 মনোক্রোম

 ইনভার্ট

 বড় কার্সর

 লিঙ্ক হাইলাইট

 শিরোনাম হাইলাইট

 পড়ার গাইড

রিসেট

[স্ক্রিন রিডার ডাউনলোড করুন](https://www.nvaccess.org/files/nvda/releases/2020.4/nvda_2020.4.exe)

[কন্টেন্টে চলে যান](#main-content) [এক্সেসিবিলিটি মেনুতে যান](#accessibility-card-title)