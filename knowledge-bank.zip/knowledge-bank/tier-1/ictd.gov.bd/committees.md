---
source: "ICT Division"
tier: 1
category: "ICT policy"
url: "https://ictd.gov.bd/pages/committees"
title: "কমিটি | তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ"
scraped_at: "2026-07-02"
---

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

## কমিটি

 এডভান্সড অপশনগুলো দেখান

গ্রুপ অনুসারে কিছুই না কমিটির নাম,কমিটি টাইপ

পৃষ্ঠা আইটেম ১০ ২০ ৫০ ১০০

নং

কমিটির নাম

কমিটি গঠনের তারিখ

ফাইল

কমিটি টাইপ

কার্যকলাপ

 

   

   

 

১

National Steering Committee to lead, guide, and oversee implementation of the Artificial Intelligence (AI) Readiness Assessment

০১-১২-২০২৪ ০৬:০০ am

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/615a3f19aa254055995bd8c10dc3b296.pdf "office-ictd/2024/12/615a3f19aa254055995bd8c10dc3b296.pdf")

[দেখুন](/pages/committees/national-steering-committee-to-lead-guide-and-oversee-implementation-of-the-artificial-intelligence-ai-readiness-assessment-439253-69414b5fa31054345f0fd252)

২

বোর্ড অব গভর্নরস (বাংলাদেশ হাই-টেক পার্ক কর্তৃপক্ষ)

১৪-০৯-২০১৪ ০৬:০০ am

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/8f0ce77046a947a5bcdd481b0ad21aea.pdf "office-ictd/2024/12/8f0ce77046a947a5bcdd481b0ad21aea.pdf")

[দেখুন](/pages/committees/বোর্ড-অব-গভর্নরস-বাংলাদেশ-হাই-টেক-পার্ক-কর্তৃপক্ষ-a3eaae-69414b5fa31054345f0fd253)

৩

জাতীয় তথ্য ও যোগাযোগ প্রযুক্তি নীতিমালা ২০১৮ এর কর্মপরিকল্পনার করণীয় বিষয়সমূহের তদারকি ও সমন্বয় সাধনের নিমিত্ত কমিটি

১২-০৬-২০১৯ ০৬:০০ am

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/7ca8621aea4a40b29d2d24d497f47fb8.pdf "office-ictd/2024/12/7ca8621aea4a40b29d2d24d497f47fb8.pdf")

[দেখুন](/pages/committees/জাতীয়-তথ্য-ও-যোগাযোগ-প্রযুক্তি-নীতিমালা-২০১৮-এর-কর্মপরিকল্পনার-cf2a2f-69414b5fa31054345f0fd251)

৪

জাতীয় তথ্য ও যোগাযোগ প্রযুক্তি নীতিমালা ২০১৮ এর আওতায় গৃহীত কর্মপরিকল্পনাসমূহের বাস্তবায়ন, পরিবীক্ষণ ও মূল্যায়ন কমিটি

০২-০৯-২০১৯ ০৬:০০ am

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/ac7687ba67f947918820751688620f67.pdf "office-ictd/2024/12/ac7687ba67f947918820751688620f67.pdf")

[দেখুন](/pages/committees/জাতীয়-তথ্য-ও-যোগাযোগ-প্রযুক্তি-নীতিমালা-২০১৮-এর-আওতায়-গৃহীত-a13745-69414b5fa31054345f0fd250)

-   ১
-   পৃষ্ঠায় যান 

আর্কাইভ দেখুন প্রকাশিত দেখুন দেখছেন ১ থেকে ৪ পর্যন্ত, মোট ৪ এন্ট্রি

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

### এক্সেসিবিলিটি

ফন্ট বৃদ্ধি ফন্ট হ্রাস

 মনোক্রোম

 ইনভার্ট

 বড় কার্সর

 লিঙ্ক হাইলাইট

 শিরোনাম হাইলাইট

 পড়ার গাইড

রিসেট

[স্ক্রিন রিডার ডাউনলোড করুন](https://www.nvaccess.org/files/nvda/releases/2020.4/nvda_2020.4.exe)

[কন্টেন্টে চলে যান](#main-content) [এক্সেসিবিলিটি মেনুতে যান](#accessibility-card-title)