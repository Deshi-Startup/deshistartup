---
source: "ICT Division"
tier: 1
category: "ICT policy"
url: "https://ictd.gov.bd/pages/news/%E0%A6%A1%E0%A6%BE%E0%A6%95-%E0%A6%9F%E0%A7%87%E0%A6%B2%E0%A6%BF%E0%A6%AF%E0%A7%8B%E0%A6%97%E0%A6%BE%E0%A6%AF%E0%A7%8B%E0%A6%97-%E0%A6%93-%E0%A6%A4%E0%A6%A5%E0%A7%8D%E0%A6%AF%E0%A6%AA%E0%A7%8D%E0%A6%B0%E0%A6%AF%E0%A7%81%E0%A6%95%E0%A7%8D%E0%A6%A4%E0%A6%BF-%E0%A6%8F%E0%A6%AC%E0%A6%82-%E0%A6%AC%E0%A6%BF%E0%A6%9C%E0%A7%8D%E0%A6%9E%E0%A6%BE%E0%A6%A8-%E0%A6%93-%E0%A6%AA%E0%A7%8D%E0%A6%B0%E0%A6%AF%E0%A7%81%E0%A6%95%E0%A7%8D%E0%A6%A4%E0%A6%BF-%E0%A6%AE%E0%A6%A8%E0%A7%8D%E0%A6%A4%E0%A7%8D%E0%A6%B0%E0%A7%80-%E0%A6%AB%E0%A6%95%E0%A6%BF%E0%A6%B0-%E0%A6%AE%E0%A6%BE%E0%A6%B9%E0%A6%AC%E0%A7%81%E0%A6%AC-%E0%A6%86%E0%A6%A8%E0%A6%BE%E0%A6%AE-%E0%A6%9F%E0%A6%BE%E0%A6%99%E0%A7%8D%E0%A6%97%E0%A6%BE%E0%A6%87%E0%A6%B2%E0%A7%87%E0%A6%B0-%E0%A6%B6%E0%A6%B9%E0%A7%80%E0%A6%A6-%E0%A6%AE%E0%A6%BE%E0%A6%B0%E0%A7%81%E0%A6%AB-%E0%A6%B8%E0%A7%8D%E0%A6%9F%E0%A7%87%E0%A6%A1%E0%A6%BF%E0%A7%9F%E0%A6%BE%E0%A6%AE-%E0%A6%AA%E0%A6%B0%E0%A6%BF%E0%A6%A6%E0%A6%B0%E0%A7%8D%E0%A6%B6%E0%A6%A8-%E0%A6%95%E0%A6%B0%E0%A7%87%E0%A6%A8-4zda8j-69dd18482bea4766e9c8513f"
title: "ডাক, টেলিযোগাযোগ ও তথ্যপ্রযুক্তি এবং বিজ্ঞান ও প্রযুক্তি মন্ত্রী ফকির মাহবুব আনাম টাঙ্গাইলের শহীদ মারুফ স্টেডিয়াম পরিদর্শন করেন। | খবর | তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ"
scraped_at: "2026-07-02"
---

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

কনটেন্টটি শেষ হাল-নাগাদ করা হয়েছে: সোমবার, ১৩ এপ্রিল, ২০২৬ এ ১০:২২ PM

## ডাক, টেলিযোগাযোগ ও তথ্যপ্রযুক্তি এবং বিজ্ঞান ও প্রযুক্তি মন্ত্রী ফকির মাহবুব আনাম টাঙ্গাইলের শহীদ মারুফ স্টেডিয়াম পরিদর্শন করেন।

কন্টেন্ট: খবর প্রকাশের তারিখ: ১৩-০৪-২০২৬ আর্কাইভ তারিখ: ৩১-১২-২০২৬

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/3/5c71c9a9-27ee-4d0d-b024-90f98cf56652.jpg)

ফাইল ১[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/3/5c71c9a9-27ee-4d0d-b024-90f98cf56652.jpg "Click here to download")

ফাইল ২[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/3/a0eac5b5-a854-4920-93cb-7eb47830f57f.jpg "Click here to download")

ফাইল ৩[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/3/df4fc220-446e-4798-afdd-03ba3be4878f.jpg "Click here to download")

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/3/5c71c9a9-27ee-4d0d-b024-90f98cf56652.jpg) ![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/3/a0eac5b5-a854-4920-93cb-7eb47830f57f.jpg) ![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/3/df4fc220-446e-4798-afdd-03ba3be4878f.jpg)

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

### এক্সেসিবিলিটি

ফন্ট বৃদ্ধি ফন্ট হ্রাস

 মনোক্রোম

 ইনভার্ট

 বড় কার্সর

 লিঙ্ক হাইলাইট

 শিরোনাম হাইলাইট

 পড়ার গাইড

রিসেট

[স্ক্রিন রিডার ডাউনলোড করুন](https://www.nvaccess.org/files/nvda/releases/2020.4/nvda_2020.4.exe)

[কন্টেন্টে চলে যান](#main-content) [এক্সেসিবিলিটি মেনুতে যান](#accessibility-card-title)