---
source: "ICT Division"
tier: 1
category: "ICT policy"
url: "https://ictd.gov.bd/pages/officers"
title: "কর্মকর্তাবৃন্দ | তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ"
scraped_at: "2026-07-02"
---

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

## কর্মকর্তাবৃন্দ

Designation

(সকল) যুগ্ম সচিব সিনিয়র সহকারী সচিব

ক্যাটাগরি ভিত্তিক কর্মকর্তাবৃন্দ

(সকল) মাননীয় মন্ত্রীর দপ্তর মাননীয় উপদেষ্টার দপ্তর সচিবের দপ্তর প্রশাসন অনুবিভাগ বাজেট ও নিরীক্ষা অনুবিভাগ পরিকল্পনা ও উন্নয়ন অনুবিভাগ আইসিটি প্রমোশন ও গবেষণা অনুবিভাগ অর্গানাইজেশনাল সাপোর্ট অনুবিভাগ ডিজিটাল গভর্নেন্স ও সিকিউরিটি অনুবিভাগ আইন ও পলিসি অনুবিভাগ রিফর্ম ম্যানেজমেন্ট ও পলিসি রিসার্চ ইউনিট প্রশাসনিক কর্মকর্তা ও ব্যক্তিগত কর্মকর্তা কর্মচারীবৃন্দ

ক্রম অনুসারে ডিফল্ট শিরোনাম,পদবি / পোস্ট,ইমেইল,ফোন (অফিস),ইন্টারকম,ফ্যাক্স

পৃষ্ঠা আইটেম ১০ ২০ ৫০ ১০০ ২৫০

### মাননীয় মন্ত্রীর দপ্তর

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/3/2a4473cd-aca3-479b-905c-81e981bf86c7.jpeg)

নাম

ফকির মাহবুব আনাম, এমপি

পদবি

মাননীয় মন্ত্রী

অফিস

ডাক, টেলিযোগাযোগ ও তথ্যপ্রযুক্তি মন্ত্রণালয়

ইমেইল

minister@moptit.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪০৩৮

ইন্টারকম

১০২

কক্ষ নম্বর

মোবাইল

ফ্যাক্স

+৮৮-০২-৮১৮১০৩৮

ভিকার্ড ডাউনলোড করুন   •   [জীবন বৃত্তান্ত](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/1/61a4c4f6-0f35-4b6f-831e-43652f9518bd.pdf)   •   [দেখুন](/pages/officers/ফয়েজ-আহমদ-তৈয়্যব-24bfd8-69414b04a31054345f0fcc97)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/1/0fa717a2-0b4e-450d-9d04-6a20e36ec9bb.jpg)

নাম

মোহাম্মদ মোকলেছুর রহমান (১৬৫২৩)

পদবি

উপসচিব (মন্ত্রীর একান্ত সচিব), অতিরিক্ত দায়িত্ব

অফিস

ডাক, টেলিযোগাযোগ ও তথ্যপ্রযুক্তি মন্ত্রণালয়

ইমেইল

pstominister@moptit.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪০৩৯

ইন্টারকম

১১৪

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭১৬১৭০৬৫৬

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/আ-স-ম-জামশেদ-খোন্দকার-2476dc-69414b04a31054345f0fcc98)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/1/9b95e789-e75c-4152-ab78-88cfda28198e.jpeg)

নাম

মুহম্মদ জসীম উদ্দিন

পদবি

তথ্য ও জনসংযোগ কর্মকর্তা

অফিস

ডাক, টেলিযোগাযোগ ও তথ্যপ্রযুক্তি মন্ত্রণালয়

ইমেইল

promoptit@gmail.com

ফোন (অফিস)

+৮৮০ ২-৫৫০০৬৯০২

ইন্টারকম

১৪২

কক্ষ নম্বর

মোবাইল

+৮৮-০১৫৫০১৫৩২৫১

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মুহম্মদ-জসীম-উদ্দিন-986d09-69414b04a31054345f0fcc9d)

৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/1/bc284789-daed-4786-beb0-85af25a5ca4a.jpeg)

নাম

মোঃ শরীফুল ইসলাম

পদবি

মাননীয় মন্ত্রীর সহকারী একান্ত সচিব

অফিস

ডাক, টেলিযোগাযোগ ও তথ্যপ্রযুক্তি মন্ত্রণালয়

ইমেইল

mahmudulhasansharif4741@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭২৬৮৭৪৭৪১

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোহাম্মদ-নাহিদুল-করিম-14a627-69414b04a31054345f0fcc9c)

৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/3/94e8aa4a-2fc6-4c44-b69a-771772f66c7e.jpg)

নাম

মো: সফিকুল ইসলাম

পদবি

মাননীয় মন্ত্রীর ব্যক্তিগত কর্মকর্তা

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

sofiqul.islam@ictd.gov.bd

ফোন (অফিস)

ইন্টারকম

১০৭

কক্ষ নম্বর

মোবাইল

+৮৮-০১৬৮২৯৫৩৭৩৭

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মো-সফিকুল-ইসলাম-3a2105-69414b06a31054345f0fce09)

৬

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/d289a27bf0344f9c832cc2a38eb75581.jpeg)

নাম

মুহাম্মদ নাঈম হুসাইন

পদবি

অফিস সহকারী-কাম-কম্পিউটার মুদ্রাক্ষরিক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

mohammadnaimictd@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৫৭৫১৩৭১৬৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মুহাম্মদ-নাঈম-হুসাইন-7a99b4-69414b04a31054345f0fccc3)

### মাননীয় উপদেষ্টার দপ্তর

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/3/37172721-3dd7-41d1-b97b-f0eccfcabdd5.jpeg)

নাম

জনাব রেহান আসিফ আসাদ

পদবি

মাননীয় উপদেষ্টা (প্রতিমন্ত্রী পদমর্যাদা)

অফিস

মাননীয় প্রধানমন্ত্রীর ডাক, টেলিযোগাযোগ ও তথ্যপ্রযুক্তি বিষয়ক উপদেষ্টা

ইমেইল

rehan.asad@ictd.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/জনাব-রেহান-আসিফ-আসাদ-tl1l8a-69d35d262ddf64102bc5029f)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/3/6d709575-b762-4474-955c-f6ddb806cfc5.JPG)

নাম

মোহাম্মদ সালেক মূহিদ

পদবি

মাননীয় উপদেষ্টার একান্ত সচিব

অফিস

ডাক, টেলিযোগাযোগ ও তথ্যপ্রযুক্তি মন্ত্রণালয়

ইমেইল

shalekmuhid@ictd.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোহাম্মদ-সালেক-মূহিদ-goc9h0-69d5d5b208aced688835b32b)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/eb09ffb8c0b44c6c8f3a332127ac8b2d.jpg)

নাম

আহম্মেদ আলী

পদবি

প্রশাসনিক কর্মকর্তা (মাননীয় উপদেষ্টার দপ্তর)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

ahmmed.ali@ictd.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭১০৭৯৫৭৬৮

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/আহম্মেদ-আলী-2bc66b-69414b06a31054345f0fce05)

৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/3afcbf527a0a469080e1f1037e1451ff.jpg)

নাম

মোঃ সাব্বির হোসেন

পদবি

কম্পিউটার অপারেটর

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

sabbir.ictd@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৬২৫৪৩৭০৪৩

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-সাব্বির-হোসেন-ac2cd0-69414b04a31054345f0fcca1)

### সচিবের দপ্তর

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/5/23afb271-0c40-4170-b22f-57924c6fffee.png)

নাম

মোঃ মামুনুর রশীদ ভূঞা (৬৪৯২)

পদবি

ভারপ্রাপ্ত সচিব

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

secretary@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪০৩১

ইন্টারকম

১০৩

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭০৮৫০১৩১৩

ফ্যাক্স

+৮৮-০২-৪১০২৪০০৬

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-মামুনুর-রশীদ-ভূঞা-৬৪৯২-cd5981-69414b05a31054345f0fcd2c)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/2/9b8e3625-2c19-4cdb-a4e4-78b6e0afac85.jpg)

নাম

মো: রকিবুল হাসান (১৭৯৪৬)

পদবি

সচিবের একান্ত সচিব (সিনিয়র সহকারী সচিব)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

pstosecretary@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪০১৩

ইন্টারকম

১২৪

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭১৯৪২২৫৪৬

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মুসতাহসিন-তাসমিম-রহমান-অনিদ্র-১৮৬০৬-c616d0-69414b05a31054345f0fcccf)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/106887a51a9748bba37671b19184a927.jpg)

নাম

মোঃ আব্দুর রহিম

পদবি

ব্যক্তিগত কর্মকর্তা

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

abdur.rahim@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪০৩১

ইন্টারকম

১৪৩

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭২২৫৭৫৯৭০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-আব্দুর-রহিম-fb4a3d-69414b06a31054345f0fcde3)

### প্রশাসন অনুবিভাগ

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/5/6f0cd425-7e70-4c3f-832c-f319c6681d1e.jpg)

নাম

ড. মোহাম্মদ আজিজুল হক, এনডিসি (১৫২২১)

পদবি

যুগ্মসচিব (অতিরিক্ত দায়িত্ব, প্রশাসন অনুবিভাগ)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

admin.wing@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪০২২

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৯১০৮০৭৭৪৩

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ড-মোহাম্মদ-আজিজুল-হক-এনডিসি-১৫২২১-xqn9oy-6a1e54e66985b94712de4da7)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/f221cd7a57fd4dedba301b8784efc517.jpg)

নাম

মোহাম্মদ সাইফুল হাসান (১৫৭০১)

পদবি

যুগ্মসচিব (প্রশাসন অধিশাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

admin.br@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪০১০

ইন্টারকম

১২৩

কক্ষ নম্বর

মোবাইল

+৮৮-০১৮৩৩৬৭৬৭৭৭

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোহাম্মদ-সাইফুল-হাসান-১৫৭০১-9ae0c5-69414b05a31054345f0fcd86)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/4de10eb179e243ee9080c874f15a41d5.jpg)

নাম

মোঃ শাহিদুজ্জামান (১৫৭৪৪)

পদবি

উপসচিব (লজিস্টিক সেবা অধিশাখা, অতিরিক্ত দায়িত্ব)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

ls.br@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪০২৭

ইন্টারকম

১২৯

কক্ষ নম্বর

মোবাইল

+৮৮০-১৭১৪০৮২৭৬৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-শাহিদুজ্জামান-১৫৭৪৪-28f532-69414b05a31054345f0fcd8a)

৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/789bd4032dad4a9488201ca8b8aff191.jpg)

নাম

মো: পূবন আখতার (২০৬৩৪)

পদবি

সিনিয়র সহকারী সচিব (জাতীয় সংসদ ও আন্তঃমন্ত্রণালয় শাখা এবং কাউন্সিল অফিসার)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

npi.sec@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪৯৪৭

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৮৬১৯৬৪০০১

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মো-পূবন-আখতার-২০৬৩৪-5f6785-69414b05a31054345f0fcd90)

৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/1/a912ffff-304e-4ad5-93cd-4aa773d3d17c.jpg)

নাম

মো: রকিবুল হাসান (১৭৯৪৬)

পদবি

সিনিয়র সহকারী সচিব (লজিস্টিক সেবা-২ শাখা )

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

ls2.sec@ictd.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭১৯৪২২৫৪৬

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মো-রকিবুল-হাসান-১৭৯৪৬-0bb584-69414b05a31054345f0fcd92)

৬

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/3/af114b04-48aa-43cd-acfe-3efc5a503a30.jpeg)

নাম

সায়েম ইমরান (১৯১৪৮)

পদবি

সিনিয়র সহকারী সচিব (প্রশাসন শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

admin.sec@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪০২৬

ইন্টারকম

১৪৬

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭৭৫৬৬৪৮৪১

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/আবদুল্লাহ-আল-মামুন-১৬২৪৬-9df7b5-69414b05a31054345f0fcd8c)

৭

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/36d83433fb6240079179080343257823.jpeg)

নাম

জাহিদা খাতুন (১১৬০৭)

পদবি

সহকারী সচিব (লাইব্রেরি ও গবেষণা শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

lr.sec@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪০২৪

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৬১২৩৯৬৩৬০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/জাহিদা-খাতুন-১১৬০৭-fd8f4b-69414b06a31054345f0fcdd3)

৮

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/e1b4c20a96fa4f019b2b2d8e39636b92.jpg)

নাম

মোঃ নিজামুল আলম (১১৬১০)

পদবি

সহকারী সচিব (লজিস্টিক সেবা-১ শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

ls1.sec@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৫৮০৫

ইন্টারকম

১৬৫

কক্ষ নম্বর

মোবাইল

+৮৮-০১৫৫৩৩৯১৩২৪

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-নিজামুল-আলম-১১৬১০-cab267-69414b06a31054345f0fcdd9)

### বাজেট ও নিরীক্ষা অনুবিভাগ

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2025/11/9236e4a8-f70b-4586-b9d0-37449bdc50a3.jpg)

নাম

ড. মোহাম্মদ আজিজুল হক, এনডিসি (১৫২২১)

পদবি

যুগ্মসচিব (বাজেট ও নিরীক্ষা অনুবিভাগ)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

ba.wing@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪০৪৩

ইন্টারকম

১১২

কক্ষ নম্বর

মোবাইল

+৮৮-০১৯১০৮০৭৭৪৩

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোহাম্মদ-আনোয়ার-উদ্দিন-২০৩২৩-5b3af7-69414b05a31054345f0fcd2a)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/91a1d714dfef411da54817c1b6a5a254.jpg)

নাম

এস এম শফিক (১৫৫৮৭)

পদবি

উপসচিব (বাজেট এবং নিরীক্ষা অধিশাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

ba.br@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪০৩৫

ইন্টারকম

১৯১

কক্ষ নম্বর

মোবাইল

+৮৮০১৯১৫৮৪৯৩১৪

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/এস-এম-শফিক-১৫৫৮৭-9cc995-69414b05a31054345f0fcd3f)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/b4051f8f6a33444cb63788b997280f36.jpg)

নাম

এস এম শফিক (১৫৫৮৭)

পদবি

উপসচিব (রাজস্ব বাজেট শাখা, অতিরিক্ত দায়িত্ব)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

rb.sec@ictd.gov.bd

ফোন (অফিস)

+৮৮-২২৩৩১৪৮২৮

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৯১৫৮৪৯৩১৪

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/এস-এম-শফিক-১৫৫৮৭-95eeb0-69414b05a31054345f0fcd7a)

৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/f6dd259d083e4e5c91d6bd985673ad74.jpg)

নাম

সাদিয়া আফরোজ (২০৬৪৭)

পদবি

সিনিয়র সহকারী সচিব (উন্নয়ন বাজেট শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

db.sec@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪০৪০

ইন্টারকম

১৩৪

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭১৫৭৯০০৯৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/সাদিয়া-আফরোজ-২০৬৪৭-0ee690-69414b05a31054345f0fcd8e)

৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/0379d2d4712d4c5e8c65d9ba209a6702.jpg)

নাম

মোঃ জাহিদুল ইসলাম

পদবি

হিসাবরক্ষণ কর্মকর্তা ও ডিডিও (হিসাব ও নিরীক্ষা শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

aa.sec@ictd.gov.bd

ফোন (অফিস)

+৮৮ ০২ ৪১০২৪০৩০

ইন্টারকম

১৪০

কক্ষ নম্বর

মোবাইল

০১৭২৩-১৩৯৩৫৮

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-জাহিদুল-ইসলাম-db1b40-69414b06a31054345f0fcdcd)

### পরিকল্পনা ও উন্নয়ন অনুবিভাগ

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/0/f4f1ba6e-454f-43f1-a340-4db9f16eafc5.jpeg)

নাম

মুর্তুজা জুলকার নাঈন নোমান (২০৪০৩)

পদবি

যুগ্মসচিব

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

pd.wing@ictd.gov.bd

ফোন (অফিস)

ইন্টারকম

১১৭

কক্ষ নম্বর

মোবাইল

+৮৮-০ ১৭১২৬৩৩০৯৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-মজিবর-রহমান-১৫৪৪৪-6955ff17e778cc2f4e2f3d72)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/20feae29b73348baa304ece3e6d73e0b.jpeg)

নাম

মোঃ আশরাফুল মমিন খান (১৫৭১৯)

পদবি

যুগ্মসচিব (পরিকল্পনা অধিশাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

plan.br@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪০৩৭

ইন্টারকম

১৩৫

কক্ষ নম্বর

মোবাইল

+৮৮ ০১৯১১০৩৬৯০৪

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-আশরাফুল-মমিন-খান-১৫৭১৯-e0b3d6-69414b05a31054345f0fcd38)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/20a56e8686e144e9a6e754db6ea19e3f.PNG)

নাম

এএসএম লোকমান (৮১০৩)

পদবি

উপসচিব (উন্নয়ন, পরিবীক্ষণ ও সমন্বয় অধিশাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

dmc.br@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪০৩৬

ইন্টারকম

১২২

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭১১৩৬০৭৬৭

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/এএসএম-লোকমান-৮১০৩-e83cb4-69414b05a31054345f0fcd3d)

৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/77dd3e1cf04943ff997ccd487392eec6.png)

নাম

ফাতেমা তুল জান্নাত (১৫৮৬৮)

পদবি

উপসচিব (পরিকল্পনা-২ শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

plan2.sec@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪০২৫

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭১১৪৭৪১৭৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ফাতেমা-তুল-জান্নাত-১৫৮৬৮-015a7a-69414b05a31054345f0fcd5f)

৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/ca0102b3366143798d1131f0ada07371.jpg)

নাম

আবদুল্লাহ আল মামুন (১৬২৪৬)

পদবি

উপসচিব (পরিকল্পনা-৩ শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

plan3.sec@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪৯৪৭

ইন্টারকম

১৮৮

কক্ষ নম্বর

মোবাইল

+৮৮-০১৩১৯৮৭১৫৯০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/আবদুল্লাহ-আল-মামুন-১৬২৪৬-c5a5b7-69414b05a31054345f0fcd61)

৬

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/cb04dc34fc5d415d9df2b54f93799e6f.jpg)

নাম

সাদিয়া আফরোজ (২০৬৪৭)

পদবি

সিনিয়র সহকারী সচিব (পরিকল্পনা-১ শাখা, অতিরিক্ত দায়িত্ব)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

plan1.sec@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪০৪০

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭১৫৭৯০০৯৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/সাদিয়া-আফরোজ-২০৬৪৭-770ece-69414b05a31054345f0fcd65)

৭

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/2ef1ebe0694d4abb80a0c6266b0b953a.jpg)

নাম

আফিয়া সুলতানা কেয়া (১৭৭৭৩)

পদবি

সিনিয়র সহকারী সচিব (সমন্বয় শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

sf.sec@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪০৪৫

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭৮৩০৪৩৩৩৪

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/আফিয়া-সুলতানা-কেয়া-১৭৭৭৩-ab8388-69414b06a31054345f0fcdb9)

৮

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/1bc8759eb822479984c10ad96a425daf.jpg)

নাম

নূর জাহান (১১৬০৯)

পদবি

সহকারী সচিব (পরিবীক্ষণ ও মূল্যায়ন-২ শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

me2.sec@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪০২৪

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮- ০১৭১২৯৬০৬৩৬

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/নূর-জাহান-১১৬০৯-886e59-69414b06a31054345f0fcdd7)

৯

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/bbcb0d4822de44c99dc98e3f6db93eca.png)

নাম

শামীম আহম্মেদ (১১৮৩৬)

পদবি

সহকারী সচিব (পরিবীক্ষণ ও মূল্যায়ন শাখা-১)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

me1.sec@ictd.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭১০৮৫৫৯৬৮

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/শামীম-আহম্মেদ-১১৮৩৬-8ba725-69414b06a31054345f0fcddb)

### আইসিটি প্রমোশন ও গবেষণা অনুবিভাগ

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/f63a791c65f94a8da62a4b7f29cd18ad.jpg)

নাম

ড. মো: তৈয়বুর রহমান (২০৩৬২)

পদবি

যুগ্মসচিব (আইসিটি প্রমোশন ও গবেষণা অনুবিভাগ)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

ipr.wing@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪০৪১

ইন্টারকম

১৩০

কক্ষ নম্বর

মোবাইল

+৮৮-০১৫৫০১৫০৬৮৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ড-মো-তৈয়বুর-রহমান-২০৩৬২-620dca-69414b05a31054345f0fccd5)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/2fba00ab2c2e47eaba27fe3fca4183ca.jpeg)

নাম

মোঃ সিদ্দিকুর রহমান তালুকদার (৮২৫৯)

পদবি

উপসচিব (আইসিটি প্রমোশন অধিশাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

ip.br@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪০৪৫

ইন্টারকম

১৩১

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭২১১৩০০৫২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-সিদ্দিকুর-রহমান-তালুকদার-৮২৫৯-76ccd1-69414b05a31054345f0fcd59)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2025/11/3f137b2e-4eb2-4699-9148-d24d4b866115.jpg)

নাম

সুরাইয়া জাহান (১৬২৬৬)

পদবি

উপসচিব (কর্মসম্পাদন ও কৌশল শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

pstrg.sec@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪০৯৭

ইন্টারকম

১৩২

কক্ষ নম্বর

মোবাইল

+৮৮০১৭১১৯৮২৫৭১

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/সুরাইয়া-জাহান-১৬২৬৬-35879f-69414b05a31054345f0fcd69)

৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/2c261afde8224b5f96728a5c625b5f31.png)

নাম

জুয়েল ভৌমিক (২০৬৬৭)

পদবি

সিনিয়র সহকারী সচিব (আন্তর্জাতিক বিষয়াবলী শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

ia.sec@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪০৫২

ইন্টারকম

১৯৩

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭১৩৪১১৬২৭

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/জুয়েল-ভৌমিক-২০৬৬৭-প্রশিক্ষণে-ab5642-69414b06a31054345f0fcdbb)

৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/9e6b2b0f099c4cec991712feb3594cfc.png)

নাম

স্বজল মোল্লা (১৮০৫১)

পদবি

সিনিয়র সহকারী সচিব (বৃত্তি ও ফেলোশিপ শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

sf.sec@ictd.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭২৩৫৫৫০২৬

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/স্বজল-মোল্লা-১৮০৫১-523efd-69414b06a31054345f0fcdbd)

৬

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/1/b8063404-bea5-485f-bdfe-803bcde8641c.jpg)

নাম

জগৎবন্ধু মন্ডল (১৮২৩১)

পদবি

সিনিয়র সহকারী সচিব (উদ্ভাবনী ও বিশেষ অনুদান শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

isg.sec@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪০৩৫

ইন্টারকম

১৩৪

কক্ষ নম্বর

মোবাইল

+৮৮-০১৯২১৯১৮৪৮২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/জগৎবন্ধু-মন্ডল-১৮২৩১-39618c-69414b06a31054345f0fcdbf)

### অর্গানাইজেশনাল সাপোর্ট অনুবিভাগ

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/f560fb9029eb493e99fdc563c60163d4.jpg)

নাম

মোহাম্মদ আনোয়ার উদ্দিন (২০৩২৩)

পদবি

অতিরিক্ত সচিব (অর্গানাইজেশনাল সাপোর্ট অনুবিভাগ)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

os.wing@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪০৩৩

ইন্টারকম

১৪৪

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭৪৫৮২১৫৫৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোহাম্মদ-আনোয়ার-উদ্দিন-২০৩২৩-49f765-69414b05a31054345f0fccfd)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/3bc3e5fc934b48ea86e15b084691586b.png)

নাম

ড. মো: আনোয়ার হোসেন (৮৩১৬)

পদবি

উপসচিব (সংস্থা-১ শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

os1.sec@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪০৪৭

ইন্টারকম

১১৮

কক্ষ নম্বর

মোবাইল

+৮৮ ০১৭৩১১৭৯৭৮৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ড-মো-আনোয়ার-হোসেন-৮৩১৬-af9135-69414b05a31054345f0fcd74)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/a258834064df4ddf92f068facbf92b3e.png)

নাম

আরেফিন আখতার নূর (১৬৭৬৭)

পদবি

সিনিয়র সহকারী সচিব (সংস্থা-২ শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

os2.sec@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪০২৫

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭২৩৬০৯৯৯২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/আরেফিন-আখতার-নূর-১৬৭৬৭-f6bd8a-69414b05a31054345f0fcd9c)

৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/4/e8dd08c5-a388-4b07-bc85-73b8f79b44bc.jpeg)

নাম

সৈয়দা শমসাদ বেগম (১৭৫৫০)

পদবি

সিনিয়র সহকারী সচিব (সংস্থা-৩ শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

os3.sec@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪৯৪৭

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮ ০১৭৫২৩১১০৯৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ড-মো-আনোয়ার-হোসেন-৮৩১৬-4f7f17-69414b05a31054345f0fcd78)

### ডিজিটাল গভর্নেন্স ও সিকিউরিটি অনুবিভাগ

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/02a1f237e3124a71af6d4ece8dc6feaf.jpg)

নাম

মো: মজিবর রহমান (১৫৪৪৪)

পদবি

যুগ্মসচিব (ডিজিটাল গভর্নেন্স ও সিকিউরিটি অনুবিভাগ)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

dgs.wing@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪০৪২

ইন্টারকম

১৯০

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭১১৪৪৫৮০৩

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মো-মজিবর-রহমান-১৫৪৪৪-37cdd6-69414b05a31054345f0fcd1e)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/37818118abe84027a87058a67f35b89b.jpg)

নাম

মোঃ ইকবাল হোসেন (৮০৩৬)

পদবি

উপসচিব (ডিজিটাল কো-অর্ডিনেশন এন্ড কো-অপারেশন অধিশাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

dcc.br@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪০৪৫

ইন্টারকম

১৮৬

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭১২৬১১৩০৩

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-ইকবাল-হোসেন-৮০৩৬-c92d88-69414b05a31054345f0fcd34)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/5dc1b2acca6e45dc99966b188245eb24.jpg)

নাম

মোঃ নবীর উদ্দীন

পদবি

সিনিয়র সিস্টেম এনালিস্ট (ডিজিটাল গভর্নেন্স ও ইমপ্লিমেন্টেশন অধিশাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

nobir@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪০৫৬

ইন্টারকম

১৯৯

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭১৭১৭৮০৩০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-নবীর-উদ্দীন-498b7f-69414b05a31054345f0fcd9e)

৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/f573a79482f9465e819268a7baca2f9c.jpg)

নাম

মোহাম্মদ আনোয়ার হোসেন

পদবি

সিনিয়র মেইন্টেনেন্স ইঞ্জিনিয়ার (ডিজিটাল সিকিউরিটি ও অপারেশন অধিশাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

anwar@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪০৫৪

ইন্টারকম

১৪১

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭১০৯০৪০৯৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোহাম্মদ-আনোয়ার-হোসেন-9487b6-69414b05a31054345f0fcda0)

৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/5e7206bacb714d8282cdf96bcf6508cd.jpg)

নাম

মোঃ শরিফুল ইসলাম

পদবি

সিস্টেম এনালিস্ট (ডিজিটাল গভর্নেন্স শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

shariful@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪০৫৩

ইন্টারকম

১৩৮

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭২১৭১৬০৫৩

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [জীবন বৃত্তান্ত](#)   •   [দেখুন](/pages/officers/মোঃ-শরিফুল-ইসলাম-869d8c-69414b06a31054345f0fcdb8)

৬

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/113f1e7633d94fa4a69487586471f15b.jpg)

নাম

মুঃ মেসবাহুল আলম

পদবি

সিনিয়র প্রোগ্রামার (ডিজিটাল সিকিউরিটি মনিটরিং ও অপারেশন শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

mesbah@ictd.gov.bd

ফোন (অফিস)

০২-৪১০২৪০৫৫

ইন্টারকম

১৩৯

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭১৯৫৩৩০৬২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মুঃ-মেসবাহুল-আলম-27bd31-69414b06a31054345f0fcdc1)

৭

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/cae7bc4566704cf3b2b8e190f6f542cd.jpg)

নাম

মোঃ নাজমুল হক খন্দকার

পদবি

সহকারী সিস্টেম এনালিস্ট (ই-সার্ভিস ইমপ্লিমেন্টেশন শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

nazmul@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪০৫৭

ইন্টারকম

১৩৭

কক্ষ নম্বর

মোবাইল

+৮৮০ ১৭৩৯-২০৮৮৬৪

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-নাজমুল-হক-খন্দকার-58d8c4-69414b06a31054345f0fcdc3)

৮

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/0/78e0e174-b16e-4153-859d-f95dc98ecbb3.jpg)

নাম

মিঠুন চক্রবর্ত্তী

পদবি

রক্ষণাবেক্ষণ প্রকৌশলী (ডিজিটাল সিকিউরিটি ও স্ট্যান্ডার্ড শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

mithun.me@ictd.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭৩৮১৪৫৬৪৩

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মিঠুন-চক্রবর্ত্তী-69561671f17d00d4fc1f7c1a)

৯

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/3/9706dcac-6f52-4703-9be0-5fefe1b1f979.png)

নাম

মোঃ সাজ্জাত হোসেন

পদবি

সহকারী প্রোগ্রামার ( ডিজিটাল কো-অপারেশন শাখা ও ডিজিটাল কো-অর্ডিনেশন শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

shazzed@ictd.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৯৮৯২৩৭৪২৮

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-সাজ্জাত-হোসেন-6c121d-69414b06a31054345f0fcdc5)

### আইন ও পলিসি অনুবিভাগ

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/5/3b5c71a0-4e77-4e02-8774-0868c17f5c18.jpg)

নাম

অনুপম বড়ুয়া (৬৭৬৭)

পদবি

যুগ্মসচিব (আইন ও পলিসি অনুবিভাগ)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

lp.wing@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪০৪১

ইন্টারকম

১৩০

কক্ষ নম্বর

মোবাইল

+৮৮-০১৮৪২৭৭৩৩৫২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোহাম্মদ-গোলাম-কিবরিয়া-১৫৪৩৮-754055-69414b05a31054345f0fcd09)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/99156fa9fc74469c924bfb3a1c7f9e54.jpg)

নাম

মোঃ আবদুল হান্নান (৮২৩১)

পদবি

উপসচিব (পলিসি অধিশাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

policy.br@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪০৫০

ইন্টারকম

১২৮

কক্ষ নম্বর

মোবাইল

+৮৮-০১৫৫০১৫১৩৩৬

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-আবদুল-হান্নান-৮২৩১-d2c37d-69414b05a31054345f0fcd4c)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/29fc77951a9a4e079b4e341a600d37da.jpg)

নাম

মোহাম্মদ আমিনুল ইসলাম খান (১৫৫২৬)

পদবি

উপসচিব

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

law.br@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪০৫১

ইন্টারকম

কক্ষ নম্বর

১৮৯

মোবাইল

+৮৮-০১৭১২৬৪৯০১০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোহাম্মদ-আমিনুল-ইসলাম-খান-১৫৫২৬-e294d4-69414b05a31054345f0fcd88)

৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/5/b3bbeb04-9fd9-42e2-be2c-3dfcb24b8d0f.jpg)

নাম

আরাফাত মোহাম্মদ নোমান (১৮০৬৯)

পদবি

সিনিয়র সহকারী সচিব (আইন ও বিধি প্রণয়ন শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

lrf.sec@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪০৪৪

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭২২৮৭৮১০২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/আরাফাত-মোহাম্মদ-নোমান-১৮০৬৯-6e8179-69414b05a31054345f0fcd98)

৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/9a46e905c9ab44b0866b241c17e40a09.jpg)

নাম

ফারহানা ইয়াসমিন (১৮১৬৭)

পদবি

সিনিয়র সহকারী সচিব (লিগ্যাল শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

legs.sec@ictd.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭৩৩৭৭০০৯৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ফারহানা-ইয়াসমিন-১৮১৬৭-ca2a91-69414b05a31054345f0fcd9a)

৬

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/6/578c7326-33d9-428b-8893-811cd6e4e60c.jpeg)

নাম

মোহাম্মদ মোজাহেরুল হক (১৮৯৮৮)

পদবি

সিনিয়র সহকারী সচিব (পলিসি বাস্তবায়ন শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

pi.sec@ictd.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮০১৫৫৯২৪৪১৫৭

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/শামীম-আহম্মেদ-১১৮৩৬-2ae289-69414b06a31054345f0fcdcf)

৭

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/ff293d0d35bd411fb3fcb7749473b013.jpg)

নাম

শাহানারা খানম (১১৪২৬)

পদবি

সিনিয়র সহকারী সচিব (পলিসি শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

policy.sec@ictd.gov.bd

ফোন (অফিস)

+৮৮-০২-৪১০২৪০৯৭

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৬৮০২৪৬৭৫৬

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/শাহানারা-খানম-১১৪২৬-bc9c81-69414b06a31054345f0fcdcb)

### রিফর্ম ম্যানেজমেন্ট ও পলিসি রিসার্চ ইউনিট

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/0/5288da68-27ed-4bd0-9beb-fbbefdcea1c2.jpeg)

নাম

মুর্তুজা জুলকার নাঈন নোমান (২০৪০৩)

পদবি

যুগ্মসচিব (রিফর্ম ম্যানেজমেন্ট ও পলিসি রিসার্চ ইউনিট)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

rmps@ictd.gov.bd

ফোন (অফিস)

ইন্টারকম

১১৭

কক্ষ নম্বর

মোবাইল

+৮৮-০ ১৭১২৬৩৩০৯৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মুর্তুজা-জুলকার-নাঈন-নোমান-২০৪০৩-e68f5a-69414b05a31054345f0fcd6b)

### প্রশাসনিক কর্মকর্তা ও ব্যক্তিগত কর্মকর্তা

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/07ce3a433b1f4681aa9cd3c64d6ad5a6.jpg)

নাম

জি.এম. জাহাঙ্গীর হোসেন

পদবি

ব্যক্তিগত কর্মকর্তা (প্রশাসন অনুবিভাগ এবং পরিকল্পনা ও উন্নয়ন অনুবিভাগ)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

jahangir@ictd.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৮৪১৫০৪০৬৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/জি-এম-জাহাঙ্গীর-হোসেন-d6b26e-69414b06a31054345f0fcde5)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/202fceaaa68f40189fd7bb53cef2d28c.jpg)

নাম

তাছলিমা আক্তার

পদবি

ব্যক্তিগত কর্মকর্তা (অর্গানাইজেশনাল সাপোর্ট অনুবিভাগ)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

taslima.akter@ictd.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৯২১২১৫৮০০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/তাছলিমা-আক্তার-040b9f-69414b06a31054345f0fcde7)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/e7921a248da44bfbb2e0e65c02530ff6.jpg)

নাম

মোঃ হানিফ

পদবি

প্রশাসনিক কর্মকর্তা (পলিসি প্রণয়ন শাখা এবং পলিসি বাস্তবায়ন শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

md.hanif@ictd.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৮১৬৭২০১৭২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-হানিফ-0e8120-69414b06a31054345f0fcde9)

৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/83191602074c4bcc837c9ebcd4ffe7d2.jpg)

নাম

মোঃ শরিফুল ইসলাম

পদবি

প্রশাসনিক কর্মকর্তা (প্রশাসন শাখা ও প্রশাসন অধিশাখা )

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

shoriful.islam@ictd.gov.bd

ফোন (অফিস)

০২-৪১০২৪০৩২

ইন্টারকম

১৪৬

কক্ষ নম্বর

মোবাইল

+৮৮-০১৯২২২৭৫৬৫৪

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-শরিফুল-ইসলাম-d35cf2-69414b06a31054345f0fcdeb)

৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/abdfeb77f0a94208883bea0df75aaeff.jpg)

নাম

চায়না আক্তার

পদবি

প্রশাসনিক কর্মকর্তা (সংস্থা-৩ শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

china.aktar@ictd.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৯২৩ ৪১০৭১১

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/চায়না-আক্তার-f50d65-69414b06a31054345f0fcded)

৬

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/a2b9a47a429c4f07acbec0396c5965fe.PNG)

নাম

মোঃ নুর হোসেন পারভেজ

পদবি

প্রশাসনিক কর্মকর্তা (আইন ও বিধি প্রণয়ন শাখা এবং লিগ্যাল শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

nur.parvez@ictd.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৮২৩২১০২৬২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-নুর-হোসেন-পারভেজ-1ca2a4-69414b06a31054345f0fcdef)

৭

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/d857eec408c342cf9458a54977a87007.jpg)

নাম

ভোলানাথ ত্রিপুরা

পদবি

প্রশাসনিক কর্মকর্তা (পরিকল্পনা অধিশাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

bholanath@ictd.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৫৫৬৭৭৪২১৩

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ভোলানাথ-ত্রিপুরা-a6ed06-69414b06a31054345f0fcdf1)

৮

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/cc23e319f4fe420a887c2e6cdf8535b4.jpg)

নাম

মোঃ রাশেদুর রহমান

পদবি

প্রশাসনিক কর্মকর্তা (সংস্থা-২ শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

rrahman.ict2200@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭১২০৪৬৫২৪

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-রাশেদুর-রহমান-af9e9d-69414b06a31054345f0fcdf3)

৯

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/a6064524e1a8413da1ad7ee665940454.jpg)

নাম

মোহাম্মদ শফিকুল ইসলাম খান

পদবি

ব্যক্তিগত কর্মকর্তা (আইন ও পলিসি অনুবিভাগ)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

sofiq.khan@ictd.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৫৩৬১০০৩৩৭

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোহাম্মদ-শফিকুল-ইসলাম-খান-9341e9-69414b06a31054345f0fcdf5)

১০

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/b714af615a32457ea1b8269b1f290615.jpg)

নাম

জাহিদ আল সিদ্দিকী

পদবি

ব্যক্তিগত কর্মকর্তা (পরিবীক্ষণ ও মূল্যায়ন ১ ও ২ শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

zahid.siddique@ictd.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭৭১৬১২৬৩১

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/জাহিদ-আল-সিদ্দিকী-19332f-69414b06a31054345f0fcdf7)

১১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/06e44253ec5f43a9acf772bcdfa7403e.gif)

নাম

মোঃ মিনহাজ হোসেন

পদবি

প্রশাসনিক কর্মকর্তা (সমন্বয় শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

minhaj.hossain@ictd.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭৬০৪০৭১৮৭

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-মিনহাজ-হোসেন-dd1b54-69414b06a31054345f0fcdf8)

১২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/7b9d598c14814ba5af385e1dfa39ac14.jpg)

নাম

নুছরাত জাহান

পদবি

প্রশাসনিক কর্মকর্তা (কর্মসম্পাদন ও কৌশল শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

nusrat.jahan@ictd.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭০১৭৯৯৫৪১

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/নুছরাত-জাহান-115783-69414b06a31054345f0fcdfb)

১৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/6ece0cd265e64bbda320efdb0d14cf68.jpg)

নাম

ইসরাত অনামিকা

পদবি

প্রশাসনিক কর্মকর্তা (পরিকল্পনা-৩ শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

israt.anamica@ictd.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৫১৫২৯৮৫৬২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ইসরাত-অনামিকা-0defba-69414b06a31054345f0fcdfd)

১৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/3/f8534427-7fd4-400c-a325-c0499df7a88a.jpeg)

নাম

নাজনীন সুলতানা

পদবি

প্রশাসনিক কর্মকর্তা (আইসিটি প্রমোশন ও ব্রান্ডিং শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

najnin.sultana@ictd.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৮২৩২৮৪৪৫৮

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/নাজনীন-সুলতানা-0a1e00-69414b06a31054345f0fcdff)

১৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/5/22f1e5d7-6e57-49a0-98f9-7aba12e061b7.jpeg)

নাম

ফখর উদ্দীন আহমেদ

পদবি

প্রশাসনিক কর্মকর্তা (আন্তর্জাতিক বিষয়াবলী শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

fakar.ahamed@ictd.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৬৭০৬৮৮৬৬৮

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ফখর-উদ্দীন-আহমেদ-6b5916-69414b06a31054345f0fce01)

১৬

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/6c884de05623499ea7f0c59aceea11ff.jpg)

নাম

ফরিদা আক্তার মিষ্টি

পদবি

প্রশাসনিক কর্মকর্তা (উদ্ভাবনী ও বিশেষ অনুদান শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

farida.misty@ictd.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৬৮৪৯১৩২২৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ফরিদা-আক্তার-মিষ্টি-59f5cd-69414b06a31054345f0fce03)

১৭

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/0acb5746db6f4644a50470fa0de906aa.jpg)

নাম

মো: হযরত আলী

পদবি

প্রশাসনিক কর্মকর্তা (জাতীয় সংসদ ও আন্তঃমন্ত্রণালয় শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

hazrat.ali@ictd.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭৪৩৯৫৮৬৪৪

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মো-হযরত-আলী-519836-69414b04a31054345f0fccba)

১৮

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/22d3bd49774d4ed99fcddb2a66525046.jpg)

নাম

ছানোয়ার হোসেন

পদবি

ব্যক্তিগত কর্মকর্তা (আইসিটি প্রমোশন ও গবেষণা অনুবিভাগ)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

sanowar.hossen@ictd.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭১৯৭৮৭৩৬৬

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ছানোয়ার-হোসেন-1801c2-69414b06a31054345f0fce07)

১৯

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/dfecdcf2b56d4bc5b6c5751424c7f6b0.jpg)

নাম

মোঃ শহিদুল ইসলাম

পদবি

ব্যক্তিগত কর্মকর্তা (বাজেট ও নিরীক্ষা অনুবিভাগ)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

shahidul.ictd84@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৪৩২৫৯৫৫৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-শহিদুল-ইসলাম-3e2f85-69414b06a31054345f0fce0b)

২০

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/7258690b58534271ab432304915dfed8.jpg)

নাম

মোছাঃ সেলিনা খাতুন

পদবি

প্রশাসনিক কর্মকর্তা (রাজস্ব বাজেট শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

k.selina993@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭৭৭৩৩২৭২৭

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/সেলিনা-খাতুন-b6139b-69414b06a31054345f0fce0c)

২১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/d01e54a146c0440bb1abb46c65b04b9b.jpg)

নাম

মোছাঃ এ্যামিলী খাতুন

পদবি

ব্যক্তিগত কর্মকর্তা

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

amelikhatun0402@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭৬৮১৪৮০৯৭

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোছাঃ-এ্যামিলী-খাতুন-5385aa-69414b06a31054345f0fce0e)

২২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/3a998a96e749497d91322603d92c05e6.jpeg)

নাম

প্রভা মন্ডল

পদবি

ব্যক্তিগত কর্মকর্তা (ডিজিটাল গভর্নেন্স ও সিকিউরিটি অনুবিভাগ)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

provamandal666@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭৬৬৫৪৬৬৬০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/প্রভা-মন্ডল-192c57-69414b06a31054345f0fce10)

২৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/9115e5e3fa5b459ea5e949452ab7ea0f.jpg)

নাম

হামিদ খান

পদবি

প্রশাসনিক কর্মকর্তা (পরিকল্পনা-২ শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

hamidkhan28101996@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৯১৭৫৮৭৪৪

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/হামিদ-খান-dae21b-69414b06a31054345f0fce12)

২৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/5de50a6453064ade823c7e5890f35aeb.jpg)

নাম

শারমিন খাতুন

পদবি

প্রশাসনিক কর্মকর্তা (উন্নয়ন বাজেট শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

sarmin.khatun6680@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭২৩৭৮৬৬৮০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/শারমিন-খাতুন-a94088-69414b06a31054345f0fce14)

২৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/e7a8c92f83704934a644d483e7b8dd05.jpg)

নাম

বিউটি আক্তার

পদবি

প্রশাসনিক কর্মকর্তা (পরিকল্পনা-১ শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

beauty.akter.ria@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৯৪৮ ৬০৬৩৬৮

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/বিউটি-আক্তার-d1432d-69414b06a31054345f0fce16)

২৬

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/7d61bfb7e0a84bbead41e3613bdf1df3.jpg)

নাম

ছৈয়দ বিল্লাল হোসেন

পদবি

প্রশাসনিক কর্মকর্তা (সংস্থা-১ শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

rieadbdc@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৯২০২১৭৪৮০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ছৈয়দ-বিল্লাল-হোসেন-2aaf47-69414b06a31054345f0fce18)

২৭

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/ddd049c6c90344fbbe4e3b994f869f62.jpg)

নাম

আখি আক্তার

পদবি

প্রশাসনিক কর্মকর্তা (কর্মসম্পাদন ও কৌশল শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

akhihayder2000@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬৭৫৬০০৫৭১

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/আখি-আক্তার-5245f8-69414b06a31054345f0fce1a)

২৮

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/cba66441f1aa4afbb00d3c575f1c50c7.jpg)

নাম

ইসতিয়াক আহমেদ

পদবি

প্রশাসনিক কর্মকর্তা ( লজিস্টিক সেবা-২ শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

iamistiaqueahmed@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৫০১১৫৭৪৪

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ইসতিয়াক-আহমেদ-322139-69414b06a31054345f0fce1c)

২৯

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/8bba8bf995ca4a6486d28fcd57c9a1cd.jpeg)

নাম

নজরুল ইসলাম

পদবি

ব্যক্তিগত কর্মকর্তা (মানবসম্পদ উন্নয়ন অধিশাখা এবং বৃত্তি ও ফেলোশিপ শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

nazrulinfo89@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬৮১৭৫৩০৯১

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/নজরুল-ইসলাম-88f04b-69414b06a31054345f0fce1e)

৩০

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/51a622dd99a04728a4e0d382e38b5bce.jpg)

নাম

মোঃ সাহাব উদ্দিন

পদবি

ব্যক্তিগত কর্মকর্তা (লজিস্টিক সেবা-১ শাখা এবং লজিস্টিক সেবা অধিশাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

shahab.uddin@ictd.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৮১২৬১৬০৩৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-সাহাব-উদ্দিন-fa7b43-69414b06a31054345f0fce20)

৩১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/0/0df6c08d-52fb-428a-8cb8-6ab69dd70658.jpeg)

নাম

মল্লিক মনিরুল ইসলাম

পদবি

সহকারী হিসাবরক্ষণ কর্মকর্তা (হিসাব ও নিরীক্ষা শাখা)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

mmikanta@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৯১১৪৬৮৩৭৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মল্লিক-মনিরুল-ইসলাম-e58d02-69414b06a31054345f0fce22)

৩২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/aa2d752e4ddd440e85f1cc4164577bc1.jpg)

নাম

মোছাঃ কামরুন নাহার

পদবি

ব্যক্তিগত কর্মকর্তা

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

kamrunictd@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭৪৪৪২৪২৮১

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোছাঃ-কামরুন-নাহার-b27da3-69414b04a31054345f0fccae)

### কর্মচারীবৃন্দ

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/1/95dfadec-9c3b-4dd6-8c5b-ceda441bc307.jpeg)

নাম

মোঃ বুলবুল ইসলাম

পদবি

হিসাবরক্ষক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

mdbulbulislam81@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৯১২২৮২৯৪৮

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-বুলবুল-ইসলাম-92b0a9-69414b04a31054345f0fcca6)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/ea1687033f1a47a6a8492a6fa3a5c2b9.jpg)

নাম

মোহাম্মদ নূরুল ইসলাম

পদবি

কম্পিউটার অপারেটর (সংযুক্ত)

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

nurulmng@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭২০৯৩৯৩১৭

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোহাম্মদ-নূরুল-ইসলাম-bab735-69414b04a31054345f0fcc9e)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/d1ccb45338234db09cdf6ffdeaa762b5.jpeg)

নাম

শামীমা আক্তার

পদবি

কম্পিউটার অপারেটর

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

shamima.mitu023@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৬৮৪১৩৮৭৫১

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/শামীমা-আক্তার-68e219-69414b04a31054345f0fcca0)

৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/c358339e4e014a329c7e81660c9a1824.jpg)

নাম

সোহেল রানা

পদবি

কম্পিউটার অপারেটর

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

sohelranabubt40@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৯১৫০২০৫৭৮

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/সোহেল-রানা-6637db-69414b04a31054345f0fcca4)

৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/1332147d21e5458aaeba9aae4847f064.jpg)

নাম

মোঃ মাজহারুল ইসলাম

পদবি

কম্পিউটার অপারেটর

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

mazharul642@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৫২১২১৪৩৫৬

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-মাজহারুল-ইসলাম-6daf2a-69414b04a31054345f0fcca5)

৬

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/99b79ab40a4446de87204d7ba2ce5ed5.jpg)

নাম

শাহিনা আক্তার

পদবি

অফিস সহকারী-কাম-কম্পিউটার মুদ্রাক্ষরিক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

shahinaictd@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭৭৯২৯২৭৫১

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/শাহিনা-আক্তার-fabcef-69414b04a31054345f0fccaa)

৭

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/148babaddda04528917f4596aafccc75.jpg)

নাম

আল-আমিন

পদবি

অফিস সহকারী-কাম-কম্পিউটার মুদ্রাক্ষরিক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

alamin.ictd85@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৯১৪১০৬৩২০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/আল-আমিন-171244-69414b04a31054345f0fccaf)

৮

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/3a2f92939c9c40f29b4533d3fde68642.jpg)

নাম

মোঃ মোবাইদুল ইসলাম

পদবি

অফিস সহকারী-কাম-কম্পিউটার মুদ্রাক্ষরিক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

mobaydul.ictd@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৬৮৩৬৬৬৭৫১

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-মোবাইদুল-ইসলাম-51f0eb-69414b04a31054345f0fccb1)

৯

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/f2225a220ea44cfd8370a7cc2d293e2c.jpg)

নাম

আপন চন্দ্র পাল

পদবি

অফিস সহকারী-কাম-কম্পিউটার মুদ্রাক্ষরিক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

apanchandrapaul@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৬২৯১৪৩২১৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/আপন-চন্দ্র-পাল-d631a1-69414b04a31054345f0fccb2)

১০

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/61130f276b2d45d18c2ebc70e4b8a38d.jpg)

নাম

মোঃ শামসুদ্দোহা

পদবি

অফিস সহকারী-কাম-কম্পিউটার মুদ্রাক্ষরিক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

samsuddohaictd@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭১৯৫৮৪০৯৬

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-শামসুদ্দোহা-ea2f63-69414b04a31054345f0fccb3)

১১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/bdaad6dcc7ae4234808308fe1cdf2230.jpg)

নাম

মোঃ সাইফুল ইসলাম

পদবি

অফিস সহকারী-কাম-কম্পিউটার মুদ্রাক্ষরিক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

saifulislam.ictd@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৬৭৩৪৯৫৪১৪

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-সাইফুল-ইসলাম-b4bc58-69414b04a31054345f0fccb4)

১২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/8d0fd3419c7042dcb5557989e5c2375c.jpg)

নাম

ফরমান আলী

পদবি

অফিস সহকারী-কাম-কম্পিউটার মুদ্রাক্ষরিক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

formanictd@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭৬৪৪৫২৩৬২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ফরমান-আলী-f13c63-69414b04a31054345f0fccb5)

১৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/0818cc5429b84da8ad568d4f05369286.jpg)

নাম

মেহেদী হাসান রিমন

পদবি

অফিস সহকারী-কাম-কম্পিউটার মুদ্রাক্ষরিক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

mehediremon513@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭৯৫৮৮৩০৪৩

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মেহেদী-হাসান-রিমন-1bece3-69414b04a31054345f0fccb6)

১৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/687b64d3977f4998945ff1dff744f193.jpeg)

নাম

মোঃ মিঠুল ইসলাম

পদবি

অফিস সহকারী-কাম-কম্পিউটার মুদ্রাক্ষরিক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

mithulislam62@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৫৩৩৩১২৮০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-মিঠুল-ইসলাম-8d4bb8-69414b04a31054345f0fccb8)

১৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/7d3eaf13adc34760951a3cae0ff01b9b.jpg)

নাম

সুমন মিয়া

পদবি

অফিস সহকারী-কাম-কম্পিউটার মুদ্রাক্ষরিক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

monisafa008@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭৩০২১০৮৮৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/সুমন-মিয়া-3574f3-69414b04a31054345f0fccbd)

১৬

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/62bdf4f9eb3a42c2b319499bba668343.jpg)

নাম

মারিয়া সুলতানা মিমি

পদবি

অফিস সহকারী-কাম-কম্পিউটার মুদ্রাক্ষরিক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

mimisultana244@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭৭১৮৩১১৬৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মারিয়া-সুলতানা-মিমি-2f2291-69414b04a31054345f0fccb9)

১৭

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/ddafb3e0d1794c09ab3880d7cb332ece.jpg)

নাম

মো: ইকবাল হোসেন

পদবি

অফিস সহকারী-কাম-কম্পিউটার মুদ্রাক্ষরিক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

iqbal.hossainictd@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭৫০৭০৪৩৪৩

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মো-ইকবাল-হোসেন-73df53-69414b04a31054345f0fccbc)

১৮

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/b52eaadf70f84e5882c88aec6fb07619.jpg)

নাম

আমেনা আক্তার

পদবি

অফিস সহকারী-কাম-কম্পিউটার মুদ্রাক্ষরিক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

amenaictd@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৯২১৮৭৬৯৩০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/আমেনা-আক্তার-333051-69414b04a31054345f0fccbe)

১৯

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/064a5af69f854da195f74ba6c1fc318a.jpg)

নাম

আফরিন শাহ্‌রিয়া প্রিয়াংকা

পদবি

অফিস সহকারী-কাম-কম্পিউটার মুদ্রাক্ষরিক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

shahria007ictd@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৮৪৯৬১৪২৮

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/আফরিন-শাহ্-রিয়া-প্রিয়াংকা-e7ea76-69414b04a31054345f0fccbf)

২০

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/331cad4268da441093e6755eaf0a383a.jpg)

নাম

শেখ জহিরুল ইসলাম

পদবি

অফিস সহকারী কাম-কম্পিউটার মুদ্রাক্ষরিক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

zohirulislam812@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬৮৪৩১৪৫১৩

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/শেখ-জহিরুল-ইসলাম-6cbc9d-69414b04a31054345f0fccc0)

২১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/9f1e56b053e346c0bb3d217ac6b851b9.png)

নাম

মোঃ জাকের হোসেন

পদবি

অফিস সহকারী কাম-কম্পিউটার মুদ্রাক্ষরিক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

hossainjaker5@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৮৩২১০৩৯১৪

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-জাকের-হোসেন-d8043c-69414b04a31054345f0fccc1)

২২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/5f3c2317a9f04fb3960f17e8e37ae04b.jpeg)

নাম

জাকের আলম

পদবি

অফিস সহকারী কাম-কম্পিউটার মুদ্রাক্ষরিক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

jakeralamparves@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৮২৫৪৬৭৪২৩

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/জাকের-আলম-b4a98e-69414b04a31054345f0fccc2)

২৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/27271ff1fabd4025af05d7b489891570.jpeg)

নাম

দিনা আক্তার

পদবি

অফিস সহকারী-কাম-কম্পিউটার মুদ্রাক্ষরিক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

dinaakter7666@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৯২৭৮১৫৬৩৭

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/দিনা-আক্তার-416808-69414b04a31054345f0fccc4)

২৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/1b4f5f7df5b04bd4a059d311910bf661.jpg)

নাম

মো: আবু সাইদ

পদবি

ক্যাশ সরকার

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭৮৯৬৪৫১৩৭

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মো-আবু-সাইদ-b533d8-69414b04a31054345f0fccc5)

২৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/6b07d46610cf4e9581cc98acf59a1633.jpg)

নাম

এ, এস, এম জহিরুল হক চৌধুরী

পদবি

ডেসপাচ রাইডার

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৯৮১৩৬১৬৩৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/এ-এস-এম-জহিরুল-হক-চৌধুরী-7f8d11-69414b04a31054345f0fccc6)

২৬

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/f5793dfe372247ae9048e812de6b0099.jpg)

নাম

মো: আব্দুস সাত্তার

পদবি

অফিস সহায়ক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৯২৬৯১৯৮৬৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মো-আব্দুস-সাত্তার-8ad4b7-69414b04a31054345f0fccc7)

২৭

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/48fbd3b69d294120bdb07d1c9bdf8878.jpg)

নাম

মোঃ মোক্তার হোসেন নয়ন

পদবি

অফিস সহায়ক

অফিস

ইমেইল

mmhnayan@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬৮৯৭৩৭২১৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-মোক্তার-হোসেন-নয়ন-0e9972-69414b05a31054345f0fccc9)

২৮

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/5f4ecc5fe7a94a69b2ada43e5e63ef0d.jpg)

নাম

মোঃ মাহাবুব হাসান

পদবি

অফিস সহায়ক

অফিস

ইমেইল

mahbub2arman@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬৮৪৩৯২০৫৪

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-মাহাবুব-হাসান-3b145c-69414b05a31054345f0fcccd)

২৯

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/026a6668a32b40a594f01bc03caf6ba4.jpg)

নাম

পলাশ

পদবি

অফিস সহায়ক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

polashhasan754@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৯১৮৭২১৭৫৪

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/পলাশ-7afa3f-69414b05a31054345f0fccd1)

৩০

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/1dd0c566be7a47a6a3eab2dade42bdb8.jpg)

নাম

মো: মোজাম্মেল

পদবি

অফিস সহায়ক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

mojammal99@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৪৩৭৫২৬৪৬

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মো-মোজাম্মেল-b2c7f4-69414b05a31054345f0fccd2)

৩১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/3f32c63923034ca696bf7858e1391e5b.jpg)

নাম

রাবেয়া খাতুন

পদবি

অফিস সহায়ক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

rabeyakhatun14144@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬৮৬৩০৩৫৩১

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/রাবেয়া-খাতুন-7a9a17-69414b05a31054345f0fccda)

৩২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/1411fbaa8efe4176997a6432cb2f1535.jpg)

নাম

মোঃ আল আমিন

পদবি

অফিস সহায়ক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

md.al.amin58518@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭৩৮৬৩৬৭৬০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-আল-আমিন-80e6f8-69414b05a31054345f0fccdc)

৩৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/a2eef2a3fcad4d6cb18bb62a69f1b657.jpg)

নাম

কায়সারুন নেছা

পদবি

অফিস সহায়ক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

mitalimala19@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭২৮৫৮৪৮০৪

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/কায়সারুন-নেছা-fd64d7-69414b05a31054345f0fccdd)

৩৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/efc84441514e41ac922b923a4dbc62cc.jpg)

নাম

মোঃ রাশিদুল ইসলাম

পদবি

অফিস সহায়ক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

mdrasidulislam290@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭৩৮০৩৫৩০০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-রাশিদুল-ইসলাম-cd65c4-69414b05a31054345f0fccdf)

৩৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/d52c1dbf306349ae9619bf51f5b08444.jpg)

নাম

শ্রী বিশ্বনাথ চন্দ্র শীল

পদবি

অফিস সহায়ক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

bishajitray25@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৮৫৯৯১৯৯০২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/শ্রী-বিশ্বনাথ-চন্দ্র-শীল-060f75-69414b05a31054345f0fcce2)

৩৬

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/155c4662c9524fc4b8a28562bc8b6d97.jpg)

নাম

মোঃ আব্দুল্লাহ আল মামুন

পদবি

অফিস সহায়ক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

mamun050593@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭৮২৫২৪৯৫৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-আব্দুল্লাহ-আল-মামুন-9b3b56-69414b05a31054345f0fcce3)

৩৭

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/5b1ffe85de884d5ea8f03c7118cd58ba.jpg)

নাম

মাহফুজা আক্তার তামান্না

পদবি

অফিস সহায়ক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

mahfuzatamanna1995@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৯৮৮৪৭৯৮৬৪

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মাহফুজা-আক্তার-তামান্না-150c9b-69414b05a31054345f0fcce4)

৩৮

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/388fed2d5fd1431799694b9475c7c3d2.jpg)

নাম

মোছাঃ আইরিন আক্তার আঁখি

পদবি

অফিস সহায়ক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

airinakterakhi789@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭৪৪৬৪৭৫৩০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোছাঃ-আইরিন-আক্তার-আঁখি-470676-69414b05a31054345f0fcce6)

৩৯

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/330280db24664c48b8cbf755f67badff.jpg)

নাম

মোঃ সোহেল রানা

পদবি

অফিস সহায়ক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

sohelranamd0806@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৯১৬৬২৫৭২৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-সোহেল-রানা-fddf5e-69414b05a31054345f0fcce7)

৪০

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/6314f972c08c42469372b149e9006909.jpg)

নাম

মোঃ জিহাদ হাসান চৌধুরী

পদবি

অফিস সহায়ক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

cmjihad7721@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭৩৭৮৬৮০১৪

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-জিহাদ-হাসান-চৌধুরী-23f9d1-69414b05a31054345f0fcce8)

৪১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/4a4bb889f59947a6b01473d2f9af8607.jpg)

নাম

ইকবাল হোসেন

পদবি

অফিস সহায়ক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

iqbalemon2019@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৬৮০৬৭৫৫০০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ইকবাল-হোসেন-03cc1f-69414b05a31054345f0fccea)

৪২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/8b5c3af4379945eeb6880a42e61da2cb.jpg)

নাম

ইশতিয়াক আহমেদ

পদবি

অফিস সহায়ক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

ishtiaqueahmed@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৩০৫২৫৭৭৬০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ইশতিয়াক-আহমেদ-4717f5-69414b05a31054345f0fccee)

৪৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/70a16248d2c64c319d4a3a20c3672208.jpeg)

নাম

রফিক সরকার

পদবি

অফিস সহায়ক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

rafiqsarkarm@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৩২৫১৮০২৫৬

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/রফিক-সরকার-0403fb-69414b05a31054345f0fccf2)

৪৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/9d876aa5dd0f4e21aa942f35a0a0777c.jpeg)

নাম

প্রকাশ বাড়ৈ

পদবি

অফিস সহায়ক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

prakashbarai2121@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৫৭৫৬৩৮৮৮১

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/প্রকাশ-বাড়ৈ-70f9d6-69414b05a31054345f0fccf7)

৪৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/e56c1384be9345d3a995a007c3264813.jpg)

নাম

কানিজ ফাতেমা

পদবি

অফিস সহায়ক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

kanizfatemaictd@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৫৬৯১৫০৬৫০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/কানিজ-ফাতেমা-57de44-69414b05a31054345f0fccf9)

৪৬

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/5f77cbe9f53444cdbe1e73468d035202.jpeg)

নাম

মো:সাইফুল ইসলাম

পদবি

অফিস সহায়ক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

mdsifulislamptk@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭২৮১৫৪৫৭১

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মো-সাইফুল-ইসলাম-2042ff-69414b05a31054345f0fccfb)

৪৭

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/8dcb18550f8d40b3a0dad0c6e036d65c.jpeg)

নাম

মোঃ সজিব হোসেন

পদবি

অফিস সহায়ক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

sazibhossen68@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭২৩৬৭২৩৪৮

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-সজিব-হোসেন-f34a7d-69414b05a31054345f0fcd03)

৪৮

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/b5242c440d6e48e1ba7ddaabdc33b6ed.jpeg)

নাম

মোঃ বিপুল হোসেন

পদবি

অফিস সহায়ক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

mdbipul496911@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮০১৮২১ ৮১৫১৪৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-বিপুল-হোসেন-8a6b9b-69414b05a31054345f0fcd07)

৪৯

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/d98627cec3ad4b17bc65460abb3ec537.jpeg)

নাম

মো: সৈকত সরকার

পদবি

অফিস সহায়ক

অফিস

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

ইমেইল

saikatsarker353@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৮৩০৫১৬৩৬২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মো-সৈকত-সরকার-fe15d4-69414b05a31054345f0fcd0b)

-   ১
-   পৃষ্ঠায় যান 

আর্কাইভ দেখুন প্রকাশিত দেখুন দেখছেন ১ থেকে ১৪৩ পর্যন্ত, মোট ১৪৩ এন্ট্রি

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

### এক্সেসিবিলিটি

ফন্ট বৃদ্ধি ফন্ট হ্রাস

 মনোক্রোম

 ইনভার্ট

 বড় কার্সর

 লিঙ্ক হাইলাইট

 শিরোনাম হাইলাইট

 পড়ার গাইড

রিসেট

[স্ক্রিন রিডার ডাউনলোড করুন](https://www.nvaccess.org/files/nvda/releases/2020.4/nvda_2020.4.exe)

[কন্টেন্টে চলে যান](#main-content) [এক্সেসিবিলিটি মেনুতে যান](#accessibility-card-title)