---
source: "ICT Division"
tier: 1
category: "ICT policy"
url: "https://ictd.gov.bd/pages/annual-reports"
title: "বার্ষিক প্রতিবেদন | তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ"
scraped_at: "2026-07-02"
---

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

## বার্ষিক প্রতিবেদন

 এডভান্সড অপশনগুলো দেখান

গ্রুপ অনুসারে কিছুই না শিরোনাম,প্রকাশের তারিখ

পৃষ্ঠা আইটেম ১০ ২০ ৫০ ১০০

নং

শিরোনাম

ফাইল সমূহ

প্রকাশের তারিখ

কার্যকলাপ

 

   

 

১

জুলাই স্মারক ২০২৫ -অগ্রগতি আর অর্জনের এক বছর

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/0/6a74f004-d7c3-4ff3-a684-70a2689fe7b0.pdf "office-ictd/2026/0/6a74f004-d7c3-4ff3-a684-70a2689fe7b0.pdf")

২১-০১-২০২৬

[দেখুন](/pages/annual-reports/জুলাই-স্মারক-২০২৫-অগ্রগতি-আর-অর্জনের-এক-বছর-qjf7ga-6970cf510c6e193a6486cad3)

২

বার্ষিক প্রতিবেদন ২০২২-২০২৩

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/e743671eeb8d4889b6cb45489f849538.pdf "office-ictd/2024/12/e743671eeb8d4889b6cb45489f849538.pdf")

১৫-১০-২০২৩

[দেখুন](/pages/annual-reports/বার্ষিক-প্রতিবেদন-২০২২-২০২৩-dbf0d3-69414b43c4774958d7b56500)

৩

বার্ষিক প্রতিবেদন ২০২১-২০২২

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/f0d9111a71904783b7b051ac805ab492.pdf "office-ictd/2024/12/f0d9111a71904783b7b051ac805ab492.pdf")

০৪-১০-২০২২

[দেখুন](/pages/annual-reports/বার্ষিক-প্রতিবেদন-২০২১-২০২২-238cc3-69414b43c4774958d7b5651d)

৪

বার্ষিক প্রতিবেদন ২০২০-২০২১

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/d790127ef34b4c54807cbc159bee6e54.pdf "বার্ষিক প্রতিবেদন ২০২০-২০২১")

১৪-১০-২০২১

[দেখুন](/pages/annual-reports/বার্ষিক-প্রতিবেদন-২০২০-২০২১-005032-69414b43c4774958d7b56525)

৫

বার্ষিক প্রতিবেদন ২০১৯-২০২০

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/8f7812460ed1421d9df72071101e796d.pdf "office-ictd/2024/12/8f7812460ed1421d9df72071101e796d.pdf")

১৫-১২-২০২০

[দেখুন](/pages/annual-reports/বার্ষিক-প্রতিবেদন-২০১৯-২০২০-695a7c-69414b43c4774958d7b56522)

৬

বার্ষিক প্রতিবেদন ২০১৮-২০১৯

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/9730b40f115f4d05b686d63f5bd61bad.pdf "বার্ষিক প্রতিবেদন ২০১৮-২০১৯")

১৫-১০-২০১৯

[দেখুন](/pages/annual-reports/বার্ষিক-প্রতিবেদন-২০১৮-২০১৯-86f8a1-69414b43c4774958d7b56528)

৭

বার্ষিক প্রতিবেদন ২০১৭-২০১৮ (চূড়ান্ত ও খসড়া ভার্সন)

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/ed0eac86c5ea4163a2b2524032145c3d.pdf "বার্ষিক প্রতিবেদন ২০১৭-২০১৮")[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/e2d2ccabc105408db3fff33e020466f1.pdf "office-ictd/2024/12/e2d2ccabc105408db3fff33e020466f1.pdf")

১৫-১০-২০১৮

[দেখুন](/pages/annual-reports/বার্ষিক-প্রতিবেদন-২০১৭-২০১৮-চূড়ান্ত-ও-খসড়া-ভার্সন-5101c6-69414b43c4774958d7b56512)

৮

বার্ষিক প্রতিবেদন ২০১৬-২০১৭

[](# "বার্ষিক প্রতিবেদন ২০১৬-২০১৭")

০৪-০৭-২০১৮

[দেখুন](/pages/annual-reports/বার্ষিক-প্রতিবেদন-২০১৬-২০১৭-904fa3-69414b43c4774958d7b5652d)

৯

বার্ষিক প্রতিবেদন ২০১৬-২০১৭

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/312bf1140b494ab38414849a3798e8ab.pdf "office-ictd/2024/12/312bf1140b494ab38414849a3798e8ab.pdf")

০৯-০১-২০১৮

[দেখুন](/pages/annual-reports/বার্ষিক-প্রতিবেদন-২০১৬-২০১৭-568f30-69414b43c4774958d7b56508)

১০

বার্ষিক প্রতিবেদন ২০১৫-২০১৬

০৮-০১-২০১৮

[দেখুন](/pages/annual-reports/বার্ষিক-প্রতিবেদন-২০১৫-২০১৬-bce1fe-69414b43c4774958d7b5651a)

-   ১
-   ২
-   **পরবর্তী** 🡲
-   পৃষ্ঠায় যান 

আর্কাইভ দেখুন প্রকাশিত দেখুন দেখছেন ১ থেকে ১০ পর্যন্ত, মোট ১৬ এন্ট্রি

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

### এক্সেসিবিলিটি

ফন্ট বৃদ্ধি ফন্ট হ্রাস

 মনোক্রোম

 ইনভার্ট

 বড় কার্সর

 লিঙ্ক হাইলাইট

 শিরোনাম হাইলাইট

 পড়ার গাইড

রিসেট

[স্ক্রিন রিডার ডাউনলোড করুন](https://www.nvaccess.org/files/nvda/releases/2020.4/nvda_2020.4.exe)

[কন্টেন্টে চলে যান](#main-content) [এক্সেসিবিলিটি মেনুতে যান](#accessibility-card-title)