---
source: "ICT Division"
tier: 1
category: "ICT policy"
url: "https://ictd.gov.bd/pages/policies"
title: "নীতিমালা | তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ"
scraped_at: "2026-07-02"
---

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

## নীতিমালা

 এডভান্সড অপশনগুলো দেখান

গ্রুপ অনুসারে কিছুই না শিরোনাম,ট্যাগ,স্মারক নম্বর,প্রকাশের তারিখ

পৃষ্ঠা আইটেম ১০ ২০ ৫০ ১০০

নং

শিরোনাম

ট্যাগ

স্মারক নম্বর

ফাইল সমূহ

প্রকাশের তারিখ

কার্যকলাপ

 

 

 

   

 

১

User’s Policy for National Data Center, Bangladesh Computer Council

 

 

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/3cd0d2a74f0445449c713f4276642123.pdf "User’s Policy for National Data Center, Bangladesh Computer Council")

২৯-১০-২০২০

[দেখুন](/pages/policies/user-s-policy-for-national-data-center-bangladesh-computer-council-fc7a84-69414b0435ce18e1c059a928)

২

জাতীয় ডিজিটাল কমার্স নীতিমালা-২০১৮

 

 

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/03b62f024267470e8fd28f17a178edca.pdf "জাতীয় ডিজিটাল কমার্স নীতিমালা-২০১৮")

৩০-০১-২০১৯

[দেখুন](/pages/policies/জাতীয়-ডিজিটাল-কমার্স-নীতিমালা-২০১৮-6d8394-69414b0435ce18e1c059a920)

৩

জাতীয় তথ্য ও যোগাযোগ প্রযুক্তি নীতিমালা ২০১৮

 

 

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/eb9b7aa9bd9b4f02aec947d1ddcd1e46.pdf "জাতীয় তথ্য ও যোগাযোগ প্রযুক্তি নীতিমালা ২০১৮")

১৫-১২-২০১৮

[দেখুন](/pages/policies/জাতীয়-তথ্য-ও-যোগাযোগ-প্রযুক্তি-নীতিমালা-২০১৮-aa91ef-69414b0435ce18e1c059a90c)

৪

সরকারি ই-মেইল নীতিমালা ২০১৮

 

 

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/e7e05582eb2142b58e15487345547bfc.pdf "সরকারি ই-মেইল নীতিমালা ২০১৮")

২২-০৫-২০১৮

[দেখুন](/pages/policies/সরকারি-ই-মেইল-নীতিমালা-২০১৮-0ac57d-69414b0435ce18e1c059a924)

৫

তথ্য ও যোগাযোগ প্রযুক্তি খাতে গবেষণার জন্য ফেলোশিপ ও বৃত্তি প্রদান এবং উদ্ভাবনীমূলক কাজের জন্যে অনুদান প্রদান সম্পর্কিত (সংশোধিত) নীতিমালা-২০১৬

 

 

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/c1e19121aa5940fca24a7de08955b988.pdf "ICT Fellowship and Donation Policy")

০৪-০৪-২০১৭

[দেখুন](/pages/policies/তথ্য-ও-যোগাযোগ-প্রযুক্তি-খাতে-গবেষণার-জন্য-ফেলোশিপ-ও-বৃত্তি-10fc6c-69414b0435ce18e1c059a92e)

৬

জাতীয় তথ্য ও যোগাযোগ প্রযুক্তি নীতিমালা-২০১৫

 

 

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/ce13f0e1cb87463184a0b74d0a391e42.pdf "office-ictd/2024/12/ce13f0e1cb87463184a0b74d0a391e42.pdf")

০৫-০৮-২০১৫

[দেখুন](/pages/policies/জাতীয়-তথ্য-ও-যোগাযোগ-প্রযুক্তি-নীতিমালা-২০১৫-c3e0cc-69414b0435ce18e1c059a92c)

৭

জাতীয় তথ্য ও যোগাযোগ প্রযুক্তি নীতিমালা-২০০৯

 

 

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/b270553a80004ed2b4888864fd536023.pdf "office-ictd/2024/12/b270553a80004ed2b4888864fd536023.pdf")

০৪-০৮-২০১৫

[দেখুন](/pages/policies/জাতীয়-তথ্য-ও-যোগাযোগ-প্রযুক্তি-নীতিমালা-২০০৯-8621fc-69414b0435ce18e1c059a90e)

৮

National ICT Policy 2009 (Revised)

 

 

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/5510354d2f4e4042bc4a1c52366160e4.pdf "National ICT Policy 2009 (Revised)")

১৪-০৯-২০১৪

[দেখুন](/pages/policies/national-ict-policy-2009-revised-ad3ba9-69414b0435ce18e1c059a922)

-   ১
-   পৃষ্ঠায় যান 

আর্কাইভ দেখুন প্রকাশিত দেখুন দেখছেন ১ থেকে ৮ পর্যন্ত, মোট ৮ এন্ট্রি

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

### এক্সেসিবিলিটি

ফন্ট বৃদ্ধি ফন্ট হ্রাস

 মনোক্রোম

 ইনভার্ট

 বড় কার্সর

 লিঙ্ক হাইলাইট

 শিরোনাম হাইলাইট

 পড়ার গাইড

রিসেট

[স্ক্রিন রিডার ডাউনলোড করুন](https://www.nvaccess.org/files/nvda/releases/2020.4/nvda_2020.4.exe)

[কন্টেন্টে চলে যান](#main-content) [এক্সেসিবিলিটি মেনুতে যান](#accessibility-card-title)