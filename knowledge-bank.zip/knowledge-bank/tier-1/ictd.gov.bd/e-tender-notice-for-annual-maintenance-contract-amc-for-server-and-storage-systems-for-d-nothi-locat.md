---
source: "ICT Division"
tier: 1
category: "ICT policy"
url: "https://ictd.gov.bd/pages/notices/e-tender-notice-for-annual-maintenance-contract-amc-for-server-and-storage-systems-for-d-nothi-located-at-the-tier-4-data-center-kaliakair-1n1cyn-6a44942dd3ddcff4605a04d7"
title: "E Tender Notice For \"Annual Maintenance Contract (Amc) For Server And Storage Systems For D Nothi, Located At The Tier 4 Data Center, Kaliakair\" | নোটিশ | তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ"
scraped_at: "2026-07-02"
---

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

কনটেন্টটি শেষ হাল-নাগাদ করা হয়েছে: বুধবার, ১ জুলাই, ২০২৬ এ ১০:১৪ AM

## e-Tender Notice for "Annual Maintenance Contract (AMC) for Server and Storage Systems for D-Nothi, Located at the Tier-4 Data Center, Kaliakair"

কন্টেন্ট: নোটিশ প্রকাশের তারিখ: ০১-০৭-২০২৬ আর্কাইভ তারিখ: ১৬-০৭-২০২৬

ফাইল ১[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/6/808008d9-e4ba-4c85-9d02-5db162dcd806.pdf "Click here to download")

### ফাইল প্রিভিউ ওয়েব ব্রাউজারে সমর্থিত নয়

ফাইল ১

[ডাউনলোড করুন](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/6/808008d9-e4ba-4c85-9d02-5db162dcd806.pdf "Click here to download")

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

### এক্সেসিবিলিটি

ফন্ট বৃদ্ধি ফন্ট হ্রাস

 মনোক্রোম

 ইনভার্ট

 বড় কার্সর

 লিঙ্ক হাইলাইট

 শিরোনাম হাইলাইট

 পড়ার গাইড

রিসেট

[স্ক্রিন রিডার ডাউনলোড করুন](https://www.nvaccess.org/files/nvda/releases/2020.4/nvda_2020.4.exe)

[কন্টেন্টে চলে যান](#main-content) [এক্সেসিবিলিটি মেনুতে যান](#accessibility-card-title)