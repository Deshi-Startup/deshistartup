---
source: "ICT Division"
tier: 1
category: "ICT policy"
url: "https://ictd.gov.bd/pages/news/%E0%A6%B9%E0%A6%AF%E0%A6%B0%E0%A6%A4-%E0%A6%B6%E0%A6%BE%E0%A6%B9%E0%A6%9C%E0%A6%BE%E0%A6%B2%E0%A6%BE%E0%A6%B2-%E0%A6%86%E0%A6%A8%E0%A7%8D%E0%A6%A4%E0%A6%B0%E0%A7%8D%E0%A6%9C%E0%A6%BE%E0%A6%A4%E0%A6%BF%E0%A6%95-%E0%A6%AC%E0%A6%BF%E0%A6%AE%E0%A6%BE%E0%A6%A8%E0%A6%AC%E0%A6%A8%E0%A7%8D%E0%A6%A6%E0%A6%B0%E0%A7%87-%E0%A6%AB%E0%A7%8D%E0%A6%B0%E0%A6%BF-%E0%A6%93%E0%A7%9F%E0%A6%BE%E0%A6%87%E0%A6%AB%E0%A6%BE%E0%A6%87-%E0%A6%B8%E0%A7%87%E0%A6%AC%E0%A6%BE-%E0%A6%89%E0%A6%A6%E0%A7%8D%E0%A6%AC%E0%A7%8B%E0%A6%A7%E0%A6%A8-2odqra-6a0a8e33f284771b36b14382"
title: "হযরত শাহজালাল আন্তর্জাতিক বিমানবন্দরে ফ্রি ওয়াইফাই সেবা উদ্বোধন | খবর | তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ"
scraped_at: "2026-07-02"
---

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

কনটেন্টটি শেষ হাল-নাগাদ করা হয়েছে: সোমবার, ১৮ মে, ২০২৬ এ ০৯:৫৭ AM

## হযরত শাহজালাল আন্তর্জাতিক বিমানবন্দরে ফ্রি ওয়াইফাই সেবা উদ্বোধন

কন্টেন্ট: খবর প্রকাশের তারিখ: ১৮-০৫-২০২৬ আর্কাইভ তারিখ: ৩১-১২-২০২৬

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/4/1a1b5e74-b469-4c37-9fe9-9e4c7cdfc990.jpeg)

ফাইল ১[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/4/1a1b5e74-b469-4c37-9fe9-9e4c7cdfc990.jpeg "Click here to download")

ফাইল ২[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/4/69b2e9b2-d30e-4f64-b5bc-37cb308007f4.jpeg "Click here to download")

ফাইল ৩[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/4/e5b8a6da-57a1-4944-a8d8-0e9c6af51a31.jpeg "Click here to download")

ফাইল ৪[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/4/07e419a0-b54e-419d-90cd-40af41f81e21.jpeg "Click here to download")

ফাইল ৫[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/4/689d23fd-178e-45fa-a98b-6165a2e773e3.jpeg "Click here to download")

ফাইল ৬[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/4/e4dfd464-f278-4b7c-ba3b-4fe1b89cf26a.jpeg "Click here to download")

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/4/1a1b5e74-b469-4c37-9fe9-9e4c7cdfc990.jpeg) ![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/4/69b2e9b2-d30e-4f64-b5bc-37cb308007f4.jpeg) ![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/4/e5b8a6da-57a1-4944-a8d8-0e9c6af51a31.jpeg) ![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/4/07e419a0-b54e-419d-90cd-40af41f81e21.jpeg) ![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/4/689d23fd-178e-45fa-a98b-6165a2e773e3.jpeg) ![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/4/e4dfd464-f278-4b7c-ba3b-4fe1b89cf26a.jpeg)

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

### এক্সেসিবিলিটি

ফন্ট বৃদ্ধি ফন্ট হ্রাস

 মনোক্রোম

 ইনভার্ট

 বড় কার্সর

 লিঙ্ক হাইলাইট

 শিরোনাম হাইলাইট

 পড়ার গাইড

রিসেট

[স্ক্রিন রিডার ডাউনলোড করুন](https://www.nvaccess.org/files/nvda/releases/2020.4/nvda_2020.4.exe)

[কন্টেন্টে চলে যান](#main-content) [এক্সেসিবিলিটি মেনুতে যান](#accessibility-card-title)