---
source: "ICT Division"
tier: 1
category: "ICT policy"
url: "https://ictd.gov.bd/pages/go-ultimates?filters=%7B%22order%22%3A%20%2269414a4c35ce18e1c059a822%22%7D"
title: "বিভিন্ন আদেশ | তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ"
scraped_at: "2026-07-02"
---

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

## বিভিন্ন আদেশ

বিভিন্ন আদেশ টাইপ

(সকল) কমিটি-টিম ফোকাল পয়েন্ট অনাপত্তি অথবা এনওসি পরিপত্র-প্রজ্ঞাপন বদলী অথবা নিয়োগ আদেশ বহিঃ বাংলাদেশ ছুটি বিদেশ ভ্রমণের জি.ও পাসপোর্ট অনাপত্তি

 এডভান্সড অপশনগুলো দেখান

গ্রুপ অনুসারে কিছুই না শিরোনাম,ইস্যু নম্বর,প্রকাশের তারিখ

পৃষ্ঠা আইটেম ১০ ২০ ৫০ ১০০

নং

শিরোনাম

ইস্যু নম্বর

ফাইল সমূহ

প্রকাশের তারিখ

কার্যকলাপ

 

 

   

 

১

প্রজ্ঞাপন (জনাব আল-আমিন, ব্যক্তিগত কর্মকর্তা, তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ)

৪২৯

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/5/80fd3c9a-9d9c-4236-9af9-4e1b0f60aa5c.pdf "office-ictd/2026/5/80fd3c9a-9d9c-4236-9af9-4e1b0f60aa5c.pdf")

২৯-০৬-২০২৬

[দেখুন](/pages/go-ultimates/প্রজ্ঞাপন-জনাব-আল-আমিন-ব্যক্তিগত-কর্মকর্তা-তথ্য-ও-যোগাযোগ-প্রযুক্তি-বিভাগ-hyvp7v-6a41f4c6c46c177d110645a6)

২

প্রজ্ঞাপন (জনাব মোছাঃ কামরুন নাহার, ব্যক্তিগত কর্মকর্তা, তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ)

৩৪০

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/4/8ecf2b37-fe25-44c0-aa01-9ccf2363491d.pdf "office-ictd/2026/4/8ecf2b37-fe25-44c0-aa01-9ccf2363491d.pdf")

১৭-০৫-২০২৬

[দেখুন](/pages/go-ultimates/প্রজ্ঞাপন-জনাব-মোছাঃ-কামরুন-নাহার-ব্যক্তিগত-কর্মকর্তা-তথ্য-ও-যোগাযোগ-প্রযুক্তি-বিভাগ-vrx2o5-6a096ed6fa5a21e711e52b88)

৩

ডাক অধিদপ্তরকে (Critical Information Infrastructure-CII) হিসেবে ঘোষণা

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/3/e5dde919-d23a-4815-a630-ee54f82e881b.pdf "office-ictd/2026/3/e5dde919-d23a-4815-a630-ee54f82e881b.pdf")

২৯-০৪-২০২৬

[দেখুন](/pages/go-ultimates/ডাক-অধিদপ্তরকে-critical-information-infrastructure-cii-হিসেবে-ঘোষণা-rx9yp5-69f1a966dc5c085e99760a8c)

৪

প্রজ্ঞাপন (স্মারক-১৫, জাতীয় সাইবার সুরক্ষা এজেন্সির শাখা কার্যালয়ের দায়িত্ব প্রদান)

১৫

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/1/08e85b36-f3e9-45d5-9a6e-2866f6409aa2.pdf "office-ictd/2026/1/08e85b36-f3e9-45d5-9a6e-2866f6409aa2.pdf")

০৩-০২-২০২৬

[দেখুন](/pages/go-ultimates/প্রজ্ঞাপন-স্মারক-১৫-জাতীয়-সাইবার-সুরক্ষা-এজেন্সির-শাখা-কার্যালয়ের-দায়িত্ব-প্রদান-nxtxa2-69840c364e60a6191b561c55)

৫

প্রজ্ঞাপন (সহকারী প্রোগ্রামার হিসেবে নিয়োগ, সিসিএ কার্যালয়)

১১

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/0/61c63ade-88e7-4a70-bc76-cbfcf1198f6e.pdf "office-ictd/2026/0/61c63ade-88e7-4a70-bc76-cbfcf1198f6e.pdf")

২৫-০১-২০২৬

[দেখুন](/pages/go-ultimates/প্রজ্ঞাপন-সহকারী-প্রোগ্রামার-হিসেবে-নিয়োগ-সিসিএ-কার্যালয়-ibcpq9-6975b0318c3f7fde7ba4e3f9)

৬

প্রজ্ঞাপন (জনাব এস এম ইমরান, সহকারী প্রোগ্রামার, তথ্য ও যোগাযোগ প্রযুক্তি অধিদপ্তর)

০২

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/0/67eb18a1-053f-40f8-970d-a520529db7fd.pdf "office-ictd/2026/0/67eb18a1-053f-40f8-970d-a520529db7fd.pdf")

১৫-০১-২০২৬

[দেখুন](/pages/go-ultimates/প্রজ্ঞাপন-জনাব-এস-এম-ইমরান-সহকারী-প্রোগ্রামার-তথ্য-ও-যোগাযোগ-প্রযুক্তি-অধিদপ্তর-8f1qik-696899d2e48846e6fbba13ee)

৭

প্রজ্ঞাপন (জনাব কাজী আরফিনা ওয়াহিদ, সহকারী প্রোগ্রামার, আইসিটি অধিদপ্তর)

১১৪

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/dc4a0a57ffbf4ce99c3789fb405b5b1b.pdf "office-ictd/2024/12/dc4a0a57ffbf4ce99c3789fb405b5b1b.pdf")

১৮-১২-২০২৫

[দেখুন](/pages/go-ultimates/প্রজ্ঞাপন-জনাব-কাজী-আরফিনা-ওয়াহিদ-সহকারী-প্রোগ্রামার-আইসিটি-e2f25d-6944392bc4774958d7b5756d)

৮

প্রজ্ঞাপন (মোহাম্মদ মিজানুর রহমান, সহকারী প্রোগ্রামার, আইসিটি অধিদপ্তর)

১১১

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/56939be7ebf24ebb99033ac22e9af1b5.pdf "office-ictd/2024/12/56939be7ebf24ebb99033ac22e9af1b5.pdf")

১৮-১২-২০২৫

[দেখুন](/pages/go-ultimates/প্রজ্ঞাপন-মোহাম্মদ-মিজানুর-রহমান-সহকারী-প্রোগ্রামার-আইসিটি-12ff11-6944392bc4774958d7b5756e)

৯

প্রজ্ঞাপন (জনাব মিঠুন চক্রবর্ত্তী, রক্ষণাবেক্ষণ প্রকৌশলী, তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ)

১৩২৩

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/8da8ae29ff12455398daeda2e1050c8d.pdf "office-ictd/2024/12/8da8ae29ff12455398daeda2e1050c8d.pdf")

১৭-১২-২০২৫

[দেখুন](/pages/go-ultimates/প্রজ্ঞাপন-জনাব-মিঠুন-চক্রবর্ত্তী-রক্ষণাবেক্ষণ-প্রকৌশলী-তথ্য-ও-22a958-6944392bc4774958d7b5756f)

১০

প্রজ্ঞাপন (জনাব মো: সাজ্জাত হোসেন, সহকারী প্রোগ্রামার হিসেবে নিয়োগ)

১২৫৭

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/15f849e9376c4cceb061612d05d72abe.pdf "office-ictd/2024/12/15f849e9376c4cceb061612d05d72abe.pdf")

০৪-১২-২০২৫

[দেখুন](/pages/go-ultimates/প্রজ্ঞাপন-জনাব-মো-সাজ্জাত-হোসেন-সহকারী-প্রোগ্রামার-হিসেবে-নিয়োগ-60f672-69414b4ac4774958d7b568e2)

-   ১
-   ২
-   ৩
-   ৪
-   ...
-   ১০
-   **পরবর্তী** 🡲
-   পৃষ্ঠায় যান 

আর্কাইভ দেখুন প্রকাশিত দেখুন দেখছেন ১ থেকে ১০ পর্যন্ত, মোট ১০০ এন্ট্রি

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

### এক্সেসিবিলিটি

ফন্ট বৃদ্ধি ফন্ট হ্রাস

 মনোক্রোম

 ইনভার্ট

 বড় কার্সর

 লিঙ্ক হাইলাইট

 শিরোনাম হাইলাইট

 পড়ার গাইড

রিসেট

[স্ক্রিন রিডার ডাউনলোড করুন](https://www.nvaccess.org/files/nvda/releases/2020.4/nvda_2020.4.exe)

[কন্টেন্টে চলে যান](#main-content) [এক্সেসিবিলিটি মেনুতে যান](#accessibility-card-title)