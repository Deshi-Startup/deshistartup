---
source: "ICT Division"
tier: 1
category: "ICT policy"
url: "https://ictd.gov.bd/views/info-officers"
title: "তথ্য কর্মকর্তা | তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ"
scraped_at: "2026-07-02"
---

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

## দায়িত্বপ্রাপ্ত কর্মকর্তাগন

### দায়িত্বপ্রাপ্ত কর্মকর্তা

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/2ef1ebe0694d4abb80a0c6266b0b953a.jpg)

নাম:

আফিয়া সুলতানা কেয়া (১৭৭৭৩)

পদবি:

সিনিয়র সহকারী সচিব (সমন্বয় শাখা)

ফোন:

+৮৮-০২-৪১০২৪০৪৫

মোবাইল:

+৮৮-০১৭৮৩০৪৩৩৩৪

ইমেইল:

sf.sec@ictd.gov.bd

ঠিকানা :

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

### বিকল্প দায়িত্বপ্রাপ্ত কর্মকর্তা

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/113f1e7633d94fa4a69487586471f15b.jpg)

নাম:

মুঃ মেসবাহুল আলম

পদবি:

সিনিয়র প্রোগ্রামার (ডিজিটাল সিকিউরিটি মনিটরিং ও অপারেশন শাখা)

ফোন:

০২-৪১০২৪০৫৫

মোবাইল:

+৮৮-০১৭১৯৫৩৩০৬২

ইমেইল:

mesbah@ictd.gov.bd

ঠিকানা :

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

### আপীল কর্তৃপক্ষ

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/5/23afb271-0c40-4170-b22f-57924c6fffee.png)

নাম:

মোঃ মামুনুর রশীদ ভূঞা (৬৪৯২)

পদবি:

ভারপ্রাপ্ত সচিব

ফোন:

+৮৮-০২-৪১০২৪০৩১

মোবাইল:

+৮৮-০১৭০৮৫০১৩১৩

ইমেইল:

secretary@ictd.gov.bd

ঠিকানা :

তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

### এক্সেসিবিলিটি

ফন্ট বৃদ্ধি ফন্ট হ্রাস

 মনোক্রোম

 ইনভার্ট

 বড় কার্সর

 লিঙ্ক হাইলাইট

 শিরোনাম হাইলাইট

 পড়ার গাইড

রিসেট

[স্ক্রিন রিডার ডাউনলোড করুন](https://www.nvaccess.org/files/nvda/releases/2020.4/nvda_2020.4.exe)

[কন্টেন্টে চলে যান](#main-content) [এক্সেসিবিলিটি মেনুতে যান](#accessibility-card-title)