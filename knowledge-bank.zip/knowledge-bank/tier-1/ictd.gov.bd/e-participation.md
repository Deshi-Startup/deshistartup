---
source: "ICT Division"
tier: 1
category: "ICT policy"
url: "https://ictd.gov.bd/views/e-participation"
title: "ডিজিটাল অংশগ্রহণ | তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ"
scraped_at: "2026-07-02"
---

সিটিজেন স্পেস

মস্তিষ্কের ব্যায়াম

![Test](https://e-participation.gov.bd/storage/uploads/posts/2opDtEa8FNIYF0v9v80Jga6XBvwm3w4HvXaMcxbi.jpg)

### Test

[বিস্তারিত](https://e-participation.gov.bd/posts/view-opinion-forum/601)