---
source: "ICT Division"
tier: 1
category: "ICT policy"
url: "https://ictd.gov.bd/pages/laws"
title: "আইন | তথ্য ও যোগাযোগ প্রযুক্তি বিভাগ"
scraped_at: "2026-07-02"
---

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

## আইন

 এডভান্সড অপশনগুলো দেখান

গ্রুপ অনুসারে কিছুই না শিরোনাম,আইনের নং,গেজেট নং,ট্যাগ,স্মারক নম্বর,প্রকাশের তারিখ

পৃষ্ঠা আইটেম ১০ ২০ ৫০ ১০০

নং

শিরোনাম

আইনের নং

গেজেট নং

ট্যাগ

স্মারক নম্বর

ফাইল সমূহ

সংশোধন ফাইল সমূহ

প্রকাশের তারিখ

কার্যকলাপ

 

 

 

 

 

   

   

 

১

জাতীয় উপাত্ত ব্যবস্থাপনা আইন, ২০২৬

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/3/ab68f686-1ba9-4c04-85ad-83f0982f7b4e.pdf "office-ictd/2026/3/ab68f686-1ba9-4c04-85ad-83f0982f7b4e.pdf")

১৫-০৪-২০২৬

[দেখুন](/pages/laws/জাতীয়-উপাত্ত-ব্যবস্থাপনা-আইন-২০২৬-ll5kfu-69df5c5f51af25eb91b58cf3)

২

সাইবার সুরক্ষা আইন, ২০২৬

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/3/31737fbf-7a0b-4437-b479-a20cd0e06e69.pdf "office-ictd/2026/3/31737fbf-7a0b-4437-b479-a20cd0e06e69.pdf")

১৫-০৪-২০২৬

[দেখুন](/pages/laws/সাইবার-সুরক্ষা-আইন-২০২৬-fid714-69df5c15db601f2f93b4757d)

৩

ব্যক্তিগত উপাত্ত সুরক্ষা আইন, ২০২৬

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2026/3/1c355c6a-cc9c-42a0-b07f-e0876b89dc9d.pdf "office-ictd/2026/3/1c355c6a-cc9c-42a0-b07f-e0876b89dc9d.pdf")

১৫-০৪-২০২৬

[দেখুন](/pages/laws/ব্যক্তিগত-উপাত্ত-সুরক্ষা-আইন-২০২৬-70is1t-69df5ba2210b1799cc640412)

৪

বাংলাদেশ হাই-টেক পার্ক কর্তৃপক্ষ এর কর্মচারী চাকরি প্রবিধানমালা, ২০২৫

 

 

 

 

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/4cc881fe3aa349e78258b7b02ddfadbb.pdf "office-ictd/2024/12/4cc881fe3aa349e78258b7b02ddfadbb.pdf")

০৮-১০-২০২৫

[দেখুন](/pages/laws/বাংলাদেশ-হাই-টেক-পার্ক-কর্তৃপক্ষ-এর-কর্মচারী-চাকরি-প্রবিধানমালা-d3c5cb-69414b2335ce18e1c059aca5)

৫

ইলেক্ট্রনিক স্বাক্ষর সার্টিফিকেট প্রদানকারী কর্তৃপক্ষের নিয়ন্ত্রক এর কার্যালয়ের (কর্মচারী) নিয়োগ বিধিমালা ২০২৫

 

 

 

 

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/d4f8e8e7036f43f79f0ddc8e9318ab77.pdf "office-ictd/2024/12/d4f8e8e7036f43f79f0ddc8e9318ab77.pdf")

২২-০১-২০২৫

[দেখুন](/pages/laws/ইলেক্ট্রনিক-স্বাক্ষর-সার্টিফিকেট-প্রদানকারী-কর্তৃপক্ষের-9ba80a-69414b2235ce18e1c059ac94)

৬

এজেন্সি টু ইনোভেট (এটুআই) (তহবিল পরিচালনা ও ব্যবস্থাপনা) বিধিমালা, ২০২৪

 

 

 

 

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/d4ba4707e9cd4090bfa8aa09a2fd3fe9.pdf "office-ictd/2024/12/d4ba4707e9cd4090bfa8aa09a2fd3fe9.pdf")

২৪-১০-২০২৪

[দেখুন](/pages/laws/এজেন্সি-টু-ইনোভেট-এটুআই-তহবিল-পরিচালনা-ও-ব্যবস্থাপনা-বিধিমালা-b3c27e-69414b2235ce18e1c059ac90)

৭

এজেন্সি টু ইনোভেট (এটুআই) আইন ২০২৩

 

 

 

 

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/b4c47d5274c2425cad27dd2d491ac4e2.pdf "এজেন্সি টু ইনোভেট (এটুআই) আইন ২০২৩")

১১-০৭-২০২৩

[দেখুন](/pages/laws/এজেন্সি-টু-ইনোভেট-এটুআই-আইন-২০২৩-c9370b-69414b2335ce18e1c059aca9)

৮

'তথ্য ও যোগাযোগ প্রযুক্তি (তদন্ত পরিচালনা) বিধিমালা, ২০২২'

 

 

 

 

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/909e682e4de645b8a9699f002c67c377.pdf "'তথ্য ও যোগাযোগ প্রযুক্তি (তদন্ত পরিচালনা) বিধিমালা, ২০২২'")

১২-০৯-২০২২

[দেখুন](/pages/laws/তথ্য-ও-যোগাযোগ-প্রযুক্তি-তদন্ত-পরিচালনা-বিধিমালা-২০২২-98cc8d-69414b2335ce18e1c059aca0)

৯

ওয়ান স্টপ সার্ভিস (বাংলাদেশ হাই-টেক পার্ক কর্তৃপক্ষ) বিধিমালা, ২০১৯

 

 

 

 

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/bedadce80e25463fa746b9595c64ec64.pdf "ওয়ান স্টপ সার্ভিস (বাংলাদেশ হাই-টেক পার্ক কর্তৃপক্ষ) বিধিমালা, ২০১৯")

২২-০৭-২০১৯

[দেখুন](/pages/laws/ওয়ান-স্টপ-সার্ভিস-বাংলাদেশ-হাই-টেক-পার্ক-কর্তৃপক্ষ-বিধিমালা-২০১৯-9e4feb-69414b2335ce18e1c059acaf)

১০

ওয়ান স্টপ সার্ভিস, ২০১৮

১০

 

 

 

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-ictd/2024/12/0cee7f61096a458f93143992a755cdd7.pdf "ওয়ান স্টপ সার্ভিস, ২০১৮")

১২-০২-২০১৮

[দেখুন](/pages/laws/ওয়ান-স্টপ-সার্ভিস-২০১৮-84ef27-69414b2335ce18e1c059acc8)

-   ১
-   ২
-   ৩
-   **পরবর্তী** 🡲
-   পৃষ্ঠায় যান 

আর্কাইভ দেখুন প্রকাশিত দেখুন দেখছেন ১ থেকে ১০ পর্যন্ত, মোট ২১ এন্ট্রি

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

### এক্সেসিবিলিটি

ফন্ট বৃদ্ধি ফন্ট হ্রাস

 মনোক্রোম

 ইনভার্ট

 বড় কার্সর

 লিঙ্ক হাইলাইট

 শিরোনাম হাইলাইট

 পড়ার গাইড

রিসেট

[স্ক্রিন রিডার ডাউনলোড করুন](https://www.nvaccess.org/files/nvda/releases/2020.4/nvda_2020.4.exe)

[কন্টেন্টে চলে যান](#main-content) [এক্সেসিবিলিটি মেনুতে যান](#accessibility-card-title)