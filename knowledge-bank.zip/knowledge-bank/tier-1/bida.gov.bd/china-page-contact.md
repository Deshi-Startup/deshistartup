---
source: "Bangladesh Investment Development Authority (BIDA)"
tier: 1
category: "Government / regulator"
url: "https://bida.gov.bd/china-page-contact"
title: "China Page Contact"
scraped_at: "2026-07-02"
---

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/686cf7286136ad1eee6ed377_Layer_1%20\(1\).svg)](/china)

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/686cf7286136ad1eee6ed377_Layer_1%20\(1\).svg)](/china)

[首页](/china)[投资机遇](#)[资源中心](https://investbangladesh.gov.bd/resources)[关于BIDA](/china-page-about-bida) [联系我们](/china-page-contact)

[English](/)[B2B商务对接](https://irms.bida.gov.bd/matchmaking)

# 联系我们

## 总公司

总理办公室

Biniyog Bhaban, E-6/B, Agargaon,  
Sher-e-Bangla Nagar, Dhaka-1207

[+880-2-44826795-99](tel:+880-2-44826795-99)

[info@bida.gov.bd](mailto:info@bida.gov.bd)

### 给我们留言

支持上传文件：PDF、文档、图片、演示文稿或电子表格。单个文件最大10 MB。

上传文件

Uploading...

fileuploaded.jpg

Upload failed. Max size for files is 10 MB.

谢谢！我们已收到您的投稿！

糟糕！提交表单时出错了。  

#### BOOK AN APPOINTMENT

##### SERVICE

New Business Opportunities

Registration & Approvals

Regulatory Facilitation

Visa & Work Permit Support

Aftercare

Policy & Sectoral Guidance

##### REQUESTED DATE

##### REQUESTED TIME

**Thank you!**  
Your appointment request has been submitted.  
If approved, a confirmation email will be sent to you.

Oops! Something went wrong while submitting the form.