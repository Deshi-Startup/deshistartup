---
source: "Bangladesh Investment Development Authority (BIDA)"
tier: 1
category: "Government / regulator"
url: "https://bida.gov.bd/faq"
title: "BIDA FAQ | Answers to Investment, Visa, Tax & Business Setup Queries"
scraped_at: "2026-07-02"
---

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/686cf7286136ad1eee6ed377_Layer_1%20\(1\).svg)](/)

[中文](/china)[BIDA OSS](/services#one-stop-services)[

Matchmakin

](https://uat-irms.oss.net.bd/matchmaking)

![bida search icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678cd4d48720bb0edd6ad500_Group%2055.svg)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/68945f6c4818ae3dc291a664_Layer_1.svg)![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![search](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6788a1c48788ea23e00ed88c_Group%2055%20\(1\).webp)

![humbergur](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678896a2d5b4ac64ddac5e2a_Group%2096%20\(3\).webp)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

-   [home](/)

-   [OPPORTUNITIES](/opportunities)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [Services](/services)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [RESOURCES](/resources)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [ABOUT BIDA](/about-bida)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [NOTICE](/notices)

[BIDA OSS](https://www.investbangladesh.gov.bd/services#one-stop-service)[中文](/china)[

MATCHMAKING

](https://uat-irms.oss.net.bd/matchmaking)

# FREQUENTLY ASKED QUESTIONS

[DOWNLOAD ALL FAQ](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/68b5669bec0d2d0e60c0dff1_Frequently%20Asked%20Questions%20\(BIDA\).pdf)

## Q: What are the services of BIDA?

Bangladesh Investment Development Authority (BIDA) is the apex investment promotion agency of the Government of Bangladesh under the Chief Adviser's Office. We deliver investment services to promote and facilitate the entry and growth of private businesses in Bangladesh and advocate business-friendly policies.

**Our services**

1.  Pre-investment counseling
2.  Registration and approval of private industrial projects
3.  Approval of branch/liaison/representative/project offices
4.  Visa recommendations and work permits for foreign nationals
5.  Approval of agreement for remitting royalty/franchise fee/technical knowledge fee/technical assistance fee/technical know-how fee
6.  Facilitation of import of capital machinery and raw material
7.  Approval of the foreign loan and supplier credit
8.  Aftercare

### Q: What are the Investment Promotion Agencies (IPAs) of Bangladesh?

-   **Bangladesh Investment Development Authority (BIDA):** For all domestic and foreign investments in Bangladesh outside economic zones, export processing zones and hi-tech parks. Their website is [https://bida.gov.bd](https://www.investbangladesh.gov.bd/)
-   **Bangladesh Economic Zones Authority (BEZA):** For domestic and foreign industries located in economic zones. Their website is [https://www.beza.gov.bd/](https://www.beza.gov.bd/)
-   **Public Private Partnership Authority (PPPA):** For supporting line ministries to identify, develop, procure and finance PPP projects. Their website is [https://www.pppo.gov.bd/](https://www.pppo.gov.bd/)
-   **Bangladesh Export Processing Zones Authority (BEPZA):** For domestic and foreign export-oriented industries located at export processing zones. Their website is [https://www.bepza.gov.bd/](https://www.bepza.gov.bd/)
-   **Bangladesh Hi-Tech Park Authority (BHTPA):** For domestic and foreign high-tech industries in hi-tech and software parks. Their website is [https://www.bhtpa.gov.bd/](https://bhtpa.gov.bd/)

#### Q: Who can register with BIDA?

-   Domestic Investment Projects
-   100% Foreign Investment Projects
-   Joint Venture Entities
-   Branch, Liaison, Representative, Project, and other offices

**Important Notes:**

-   This excludes companies located in BEZA, BEPZA, BHTPA, and BSCIC.
-   Both manufacturing and service industries can register with BIDA.
-   BIDA registration is not a requirement for commercial and trading activities.

#### Q:Why should investors register their businesses with BIDA?

**BIDA-registered businesses are eligible for:**

-   Access to financial and non-financial incentives declared by the government
-   Get business licenses and approvals from BIDA and other regulators, facilitation and aftercare services of BIDA

#### Q: What is the online One-Stop Service Portal of BIDA?

BIDA established its online One-Stop Service Portal - better known as BIDA OSS, as per the One-Stop Service Act, 2018. It is the country's first interoperable platform providing end-to-end digitized investor services of BIDA and other regulators in Bangladesh. Soon, all investor services in Bangladesh will be integrated with BIDA OSS.

BIDA services are online, e-payment enabled, and time-bound as per OSS Rules, 2020:

-   Access e-payment-enabled services
-   Back-end approval processes are carried out electronically to ensure service quality
-   Submit service request and get time-bound results
-   Application status is monitored through dashboards
-   Track all communication and service request status
-   Real-time user feedback enabled

BIDA OSS: One place for all our investor services. Doing Business in Bangladesh is easy!

Visit BIDA's One-Stop Service portal [https://bidaquickserv.org](https://bidaquickserv.org/)

#### Q: What are the types of services currently available on BIDA OSS?

BIDA is streamlining, digitizing and integrating all G2B services with BIDA OSS.

-   Industrial Project Registration
-   Permission for Branch/ Liaison/ Representative/ Project Office
-   Visa Recommendation
-   Work Permit
-   Visa on Arrival
-   Recommendation for Import Registration Certificate
-   Name Clearance
-   Online Bank Account Opening
-   Trade License
-   E-TIN (Tax Identification Number)
-   Country of Origin Issuance
-   New Electricity Connection
-   Water Supply (Industry)
-   E-mutation of Land
-   No Objection Certificate (NOC) from Fire Service
-   Security Clearance
-   Land Use Clearance
-   Construction Permit
-   No Objection Certificate (NOC) for Large/ Specialized Project
-   Site Clearance
-   Environment Clearance Certificate
-   Environmental Impact Assessment (EIA) Approval
-   Terms of Reference (TOR) Approval
-   Zero Discharge Approval

See the full list of service providers and services on BIDA OSS. [https://bida.gov.bd/oss-services](https://www.investbangladesh.gov.bd#oss-services)

#### Q: How do I get started on BIDA OSS?

-   Create OSS ID
-   Log in to OSS
-   Provide basic information to create profile
-   Select service
-   Fill-up and submit application
-   Submit fee, if applicable
-   Check progress with tracking ID
-   Get real-time notifications
-   Approval of application
-   Get approval delivered to your inbox

The same process is followed for domestic, 100% foreign, and joint venture businesses. Registrations are also issued by BIDA divisional offices, which follow the same online process.

#### Q: What are the priority sectors for investment in Bangladesh?

**Export Diversification Sectors**

-   Agribusiness and Food Processing
-   Ready-made Garments
-   Manmade Fiber
-   Apparel Accessories and Packaging
-   Pharmaceuticals
-   Plastics
-   Jute and Jute Products
-   Leather and Leather Goods
-   Light Engineering
-   Shipbuilding
-   Furniture
-   Home Textile
-   Active Pharmaceutical Ingredients
-   Automobile Manufacturing and Repair Services
-   Logistics

\*As per the Industrial Policy 2022

**Priority Sectors**

-   Manpower Export
-   Tourism
-   Environment-friendly Ship Recycling
-   Hospital and Clinic
-   Seed
-   Medical Equipment and Devices
-   Herbal Medicine
-   Hi-Tech Industries
-   Agro-machineries
-   Tea
-   Cosmetics and Toiletries
-   Logistics
-   Home Textile
-   Cement
-   Wind Energy
-   Rice Bran Oil Manufacturing
-   LED, CFL Bulb Manufacturing

\*As per the Industrial Policy 2022

#### Q: How do I incorporate a company?

1.  Apply for Name Clearance to the Registrar of Joint Stock Companies and Firms (RJSC&F) through BIDA OSS. The foreign companies need to pay BDT 230 including VAT to get the name clearance. However, local company name clearance will be validated at the time of incorporation
2.  Open a temporary bank account to deposit capital equal to shareholding position and collect encashment certificate from the bank 
3.  Rent office space in any commercial area 
4.  Prepare Article of Association (AoA) and Memorandum of Association (MoA), Form IX, Form I, Subscription Page, and submit to BIDA OSS for incorporation 
5.  Pay registration fees along with stamp duty 
6.  When RJSC&F approves the application, the applicant will get Incorporation Certificate, MoA, AoA and Form XII 
7.  Register with Income Tax Authority and collect E-TIN 
8.  Register for Trade License 
9.  Obtain VAT Registration 

\*If a company engages in export and import, Export and Import Registration Certificates are required."

#### Q: How do I set up a Branch/ Liaison/ Representative/ Project Office in Bangladesh?

-   Log in to BIDA OSS
-   Get approval of BIDA through BIDA OSS. Upload necessary documents and later submit them physically at BIDA (Initial approval for 3 years).
-   Rent an office space.
-   Open a bank account in Bangladesh and an amount of foreign exchange equivalent to US$ 50,000 or more must be brought within 2 months from the date of getting approval from BIDA.
-   Notify Bangladesh Bank under Section 18B of the Foreign Exchange Regulation Act, 1947 within 30 (thirty) days of obtaining permission from BIDA via the bank of the office.
-   Obtain a Tax Identification Number (TIN) Certificate.
-   Apply to RJSC&F within 30 days from receiving permission from BIDA for certificate of filing as per Section 379 of the Companies Act, 1994.
-   Obtain a Trade License.
-   Obtain VAT Registration (E-BIN) from National Board of Revenue (NBR).

\*If a Branch Office is engaged in export and import, Export and Import Registration Certificates are required.

\*Find checklist of required documents [https://bida.webflow.io/commercial-offices](https://www.investbangladesh.gov.bd/commercial-offices)

#### Q: How do I apply for a trade license in Bangladesh?

-   Trade licenses are issued by the local government, i.e. by the City Corporation, Paurashava and Union Parishad.
-   The trade licensing services of Dhaka North City Corporation, South City Corporation, and Chattogram City Corporation are available on BIDA OSS.

**For trade license services available on BIDA OSS:**

01\. Sign up on BIDA OSS

02\. Fill-up the prescribed form

03\. Submit necessary documents

04\. Submit Fees

05\. Get a trade license online

**For trade license services outside of BIDA OSS:**

01\. Get the proper form from the proper office\*

02\. Get No Objection Certificate (NOC) from the local Ward Commissioner or Chairman

03\. Submit application with supporting documentation and signboard fees to City Corporation, Paurashava and Union Parishad Offices

04\. Await enquiry by the licensing supervisor

05\. Pay necessary fee and collect trade license

\*The application form is available on the websites of local government offices.

#### Q: How do I get a Tax Identification Number (TIN) for a company/ foreign commercial offices?

TIN registration service of the National Board of Revenue (NBR) is available on BIDA OSS.

-   Sign in to BIDA OSS
-   Select TIN Certificate
-   Fill-up the prescribed form
-   Upload Trade License, BIDA registration letter, Company Incorporation Certificate, Copy of Memorandum of Association and Articles of Association, photograph of Managing Director, Bank Solvency Certificate
-   Submit application
-   Receive certificate online in 3 days, if all documents are duly submitted

#### Q: How do I get a Tax Identification Number (TIN) for foreign employees?

TIN registration service of the National Board of Revenue (NBR) is available on BIDA OSS.

1.  Sign in to BIDA OSS
2.  Select TIN Certificate
3.  Fill-up the prescribed form
4.  Need an active phone number
5.  Upload required documents  
    -   Academic Certificate/Birth Certificate
    -   Passport info page
    -   Passport visa page
    -   Appointment letter of the service contract
    -   Work permit
    -   Memorandum of company
6.  Submit application
7.  Receive certificate online in 3 days, if all documents are duly submitted

#### Q: How do I get a VAT registration for industry?

1.  Sign in to BIDA OSS
2.  Upload required documents

-   Trade License
-   TIN Certificate
-   Import Registration Certificate/Export Registration Certificate (if any)
-   List of all sales shops; sales centers, full address, equipment, machinery, fittings, product features and     amendment of the products manufactured
-   RJSC&F Incorporation number (if any)
-   Deed of Agreement
-   Bank Statement
-   BIDA Registration Letter
-   Memorandum of Association (MOA) and Articles of Association (AoA)
-   List of invoice and stored product

3\.  Get VAT Registration Certificate Online

#### Q: How do I get BIDA's recommendation for Import Permit (IP)?

Import Permit is necessary for foreign investor who wants to import capital machinery without opening a Letter of Credit (LC) in Bangladesh. The value of the capital machinery is considered equity investment.

-   Sign in to BIDA OSS
-   Select recommendation for IP
-   Fill-up the prescribed form
-   Upload required documents
-   Submit application
-   Receive IP recommendation in 3 days, if all documents are duly submitted

\*Checklist of required documents:

[Import Permission (Capital machineries)](https://www.investbangladesh.gov.bd/foreign-joint-venture-projects#import-permission)

#### Q: How do I get an ad-hoc Import Registration Certificate (IRC) recommendation?

1\. New industries are provided IRC on ad hoc basis based on BIDA recommendation.

-   Sign in on BIDA OSS
-   Select ad hoc IRC recommendation
-   Fill- up prescribed form
-   Upload required documents
-   If the report is approved by BIDA, the applicant will be notified by SMS and email
-   The applicant will log in BIDA OSS for payment of fees
-   If required documents are duly submitted, the applicant will get the certificate

\*Checklist of required documents:

-   [Domestic Projects](https://www.investbangladesh.gov.bd/domestic-projects)
-   [Foreign & Joint Venture Projects](https://www.investbangladesh.gov.bd/foreign-joint-venture-projects)

#### Q: How do I get 2nd ad hoc, 3rd ad hoc and regular Import Registration Certificate (IRC) recommendation?

1.  Sign in on BIDA OSS
2.  Select 2nd ad hoc, 3rd ad hoc and regular IRC recommendation

-   Fill-up the prescribed form
-   Upload required documents
-   Submit application
-   BIDA's assigned official will inspect factory and submit report
-   If the report is positive, BIDA will notify the applicant and send the recommendation through OSS for and 2nd/ 3rd ad hoc or regular IRC to the Chief Controller of Imports & Exports (CCI&E)

\*The next step is to apply for IRC from CCI&E through BIDA OSS.

\*Checklist of required documents:

-   [Domestic Projects](https://www.investbangladesh.gov.bd/domestic-projects)
-   [Foreign & Joint Venture Projects](https://www.investbangladesh.gov.bd/foreign-joint-venture-projects)

#### Q: How do I get 2nd ad hoc, 3rd ad hoc and regular Import Registration Certificate (IRC) from CCI&E?

1.  Sign in on BIDA OSS
2.  Select Import Registration Certificate (IRC)
3.  Fill-up the prescribed form
4.  Upload required documents
5.  Submit fee
6.  CCI&E will issue digital IRC

\*BIDA will send a letter recommending regularization of ad hoc IRC to CCI&E if 70% of the entitled import value mentioned in ad hoc IRC is utilized. Otherwise the company will apply for 2nd/3rd ad hoc.

#### Q: How do I get an Environmental Clearance Certificate?

Before setting up a factory in Bangladesh, an investor must secure an Environment Clearance Certificate from the Department of Environment (DOE)

1\. Apply through BIDA OSS

2\. Upload the documents

-   A Feasibility Study Report for the proposed industrial unit or project
-   Initial Environmental Examination (IEE) for the proposed industrial unit or project
-   The process flow diagram, Layout Plan (showing location of Effluent Treatment Plant), and design
-   An Environmental Management Plan (EMP) and a Report for the existing industrial unit or project
-   An Impact Assessment Report for the proposed industrial unit or project
-   No Objection Certificate (NOC) from the local authority
-   Outline of the relocation, and rehabilitation plan
-   An Emergency plan on pollution minimization and adverse environmental impact
-   Other necessary information (if required)

3\. Submit application along with the supporting documents through BIDA OSS to the DOE

4\. Verification of application and supporting documents by DOE

5\. An Inspection Officer from DOE will further inspect after verification of all the documents

6\. A meeting will be held by Environmental Clearance Committee (only for Orange-B and Red Category)

7\. Decision will be taken at the meeting by the Environmental Clearance Committee

8\. After all the above steps are completed, if DOE is satisfied then it shall issue an Environmental Clearance Certificate

**ECC Categories**

-   Green
-   Orange (Orange 'A' & Orange 'B')
-   Red

#### Q: How do I get a Fire License?

Fire License is another obligatory permit required by all factories, according to the Fire Prevention and Fire Fighting Act, 2003. The permit is issued by the Department of Fire Service & Civil Defense (FSCD).

1.  Log in to BIDA OSS
2.  Apply for No Objection Certificate
3.  Upload required documents

-   Attested Copy of the Trade License of the company
-   Attested Copy of Company Incorporation Certificate
-   Attested Copy of Memorandum of Association and Articles of Association
-   Copy of Financial/Bank Solvency Certificate of the establishment
-   Tax Identification Number (TIN)
-   Valuation Certificate from relevant Municipality or City Corporation
-   A NOC from a local representative (If Plastic Industry)
-   Deed of Agreement with rental receipt
-   A Clearance Certificate from the FSCD
-   Layout plans of the establishment/factory/building authorized by RAJUK or City Corporation
-   Completely filled-in additional form (In the case of garments factories)  
    4\. Submit the application along with the supporting documents  
    5\. An Inspection Officer from FSCD will inspect the factory  
    6\. After inspection is completed, a Demand Note will be issued stating the amount of fee that needs to be paid by the applicant  
    7\. If there is any points of violation, then a specific time will be given to address these issues to the applicant  
    8\. Later, the factory will be re-inspected to check if the flagged violations have been addressed  
    9\. After all the above steps are completed, if FSDC is satisfied that the factory fulfills the requirements of fire safety, it shall issue a Fire License to the applicant  
    10\. Obtain the Fire License Certificate online  
    ‍

#### Q: What types of projects are eligible for tax exemption facilities?

1.  Newly established industrial undertakings
2.  Newly established physical infrastructures
3.  Public Private Partnership (PPP) projects
4.  Private sector power generation companies (excluding coal-based power generation)
5.  Businesses of software development and Information Technology-Enabled Services (ITES)  
    -   Technology park established in High-Tech Park
    -   Investment in ICT Sector
    -   Investment in Light Engineering Sector

#### Q: What are the fiscal incentives that can be enjoyed by investors registered with BIDA?

1.  Newly-established companies are eligible for the following incentives\*:  
    a. Corporate Income Tax (CIT) exemption (holiday and rebate) based on the type of business and on the geographical location of the undertaking  
    b. Bonded Warehouse facility  
    c. Reduced total tax incidence

\*Incentives are subject to change as per the Finance Act and Statutory Regulatory Orders.

#### Q: What are the other incentives enjoyed by BIDA-registered industries?

**Import duty exemption**

-   1% on capital machinery/ spares for export-oriented industries and allowed to import spare parts free of duty for up to 10% of the machinery value every two years
-   3% on capital machinery/ spares for other industries
-   Exemption of VAT for import of capital machinery/ spares

**Accelerated depreciation**

-   Allowed for newly established industrial undertakings in lieu of tax exemption on factory, machinery/ plant; 50% for the 1st year, 30% for the 2nd year, and 20% for the 3rd year
-   Initial depreciation allowance is also available on machinery/ plant

**Other tax exemptions**

-   On royalty, franchise, technical knowledge/ know-how/ assistance fees for foreign entities (up to a certain level as decided by National Board of Revenue (NBR))
-   On personal income tax up to three years for foreign technicians employed in BEZA and High-Tech industries

Companies located in economic zones and export processing zones are entitled to different sets of incentive packages of tax exemption.

#### Q: What is the procedure for outward remittances of dividend/profits for foreign companies/joint venture companies, etc.?

1.  **Dividends/Profits:**  
    -   Dividend/profit income (both final and interim) can be remitted through an authorized dealer of non-resident shareholders.
    -   Remittable dividends/profits can be credited to foreign currency accounts maintained by the non-resident shareholders.

#### Q: How do I get the Double Taxation Treaties (DTT) benefits?

**1\. Submit application manually to the International Taxation Wing of NBR with the following documents:**

-   E-TIN
-   Incorporation Certificate
-   MoA and AoA
-   Form XII
-   Copy of Dividend Declaration
-   Copy of Tax Residency
-   Copy of profit after tax for the latest income year
-   Detailed bank information through which the monetary activities will be done
-   AGM resolution regarding dividend
-   Schedule X
-   Auditor's Certificate for the amount of paid up capital by the individuals
-   Statement on mode of payment of paid up capital by individuals
-   Company's last 5 years Income Tax Certificate
-   Copy of paid dividend of last year
-   Copy of cumulative amount of dividend paid in the last year
-   Auditor's Certificate and Challan copies of dividend remitted in the previous year
-   Copy of short-term bank loan
-   Copy of DTT with Bangladesh
-   Latest financial statement

2\. Upon verification of the documents, NBR will issue a non-deduction or reduced rated deduction certificate within 30 days of application.

#### Q: What is the procedure for outward remittances of dividends/profits of Branch Offices of foreign companies?

1.  Dividends/ Profits: Branches of foreign companies, banking, and insurance institutions incorporated in Bangladesh can remit post-tax profits to the head offices through an authorized dealer.
2.  Repatriation of savings, retirement benefits, and salary of expatriate employee: Foreigners employed in Bangladesh can remit 80% of their monthly salary after deducting all admissible expenses, savings, and admissible retirement benefits through an authorized dealer.

#### Q: How do I get BIDA's approval for a long-term foreign loan?

BIDA's approval is required for foreign currency borrowing (commercial loan, buyer's and supplier's credit) to import capital goods for new projects, replacement, or expansion of the existing production facilities.

-   Apply manually to BIDA with required documents
-   A Scrutiny Committee on Foreign Loan/ Supplier's Credit verifies the application and approves the loan proposal

\*Permission is not provided for the foreign loan to be used exclusively for working capital.

List of required documents is available here: [https://bida.gov.bd/storage/app/media/pdf/Citizen-Charter-Foreign-Industry~English.pdf](https://www.investbangladesh.gov.bd/foreign-joint-venture-projects)

####  Q: How do I get a visa recommendation from BIDA?

BIDA provides recommendations for E-Visa, E1-Visa, P1-Visa and Visa on Arrival for foreign investors.

-   Sign in to BIDA OSS
-   Upload information and necessary documents as listed in BIDA OSS
-   Get approval online within 24 hours, provided that all required information and documents are duly submitted

Visa Types:

-   'P1' visa is for foreign private investors for industrial and commercial enterprises.
-   'E' visa is for the employees of private or public organizations, both foreign and local companies.
-   'E1' visa is for the persons who are engaged with machinery and software installation project inspection services.

\*Checklist of required documents: [https://bida.webflow.io/foreign-joint-venture-projects](https://www.investbangladesh.gov.bd/foreign-joint-venture-projects)  

#### Q: How do I get a work permit?

1.  The employer of the expatriate will log in to BIDA OSS for work permit\*
2.  The employer must submit the application and documents including a copy of appropriate visa within 15 days of arrival of the expatriate
3.  Pay fees for work permit
4.  Get the work permit

\*Checklist of required documents:

[https://bidaquickserv.org](https://www.investbangladesh.gov.bd/foreign-joint-venture-projects)

#### BOOK AN APPOINTMENT

##### SERVICE

New Business Opportunities

Registration & Approvals

Regulatory Facilitation

Visa & Work Permit Support

Aftercare

Policy & Sectoral Guidance

##### REQUESTED DATE

##### REQUESTED TIME

**Thank you!**  
Your appointment request has been submitted.  
If approved, a confirmation email will be sent to you.

Oops! Something went wrong while submitting the form.