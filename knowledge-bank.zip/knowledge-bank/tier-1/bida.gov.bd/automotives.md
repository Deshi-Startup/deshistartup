---
source: "Bangladesh Investment Development Authority (BIDA)"
tier: 1
category: "Government / regulator"
url: "https://bida.gov.bd/china-sector/automotives"
title: "Automotives"
scraped_at: "2026-07-02"
---

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/686cf7286136ad1eee6ed377_Layer_1%20\(1\).svg)](/china)

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/686cf7286136ad1eee6ed377_Layer_1%20\(1\).svg)](/china)

[首页](/china)[投资机遇](#)[资源中心](https://investbangladesh.gov.bd/resources)[关于BIDA](/china-page-about-bida) [联系我们](/china-page-contact)

[English](/)[B2B商务对接](https://irms.bida.gov.bd/matchmaking)

**驱动下一代出行转型**

# **电动汽车与汽车产业**

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3b7c5ab20cb4ab3cbc2b5b_ChatGPT%20Image%20Jun%2024%2C%202026%2C%2010_52_48%20AM.png)

600万+

 已安装太阳能家庭系统

5%

乘用车市场年增长率

20亿美元+

2030年市场机遇

零关税

电动汽车充电器、充电站、电池组件及原材料进口关税为零

## 概览

孟加拉国汽车与电动汽车产业是一个正在兴起的制造业机遇，受到长期国内市场潜力、电动两轮车和三轮车需求上升，以及日益支持电动汽车普及和本地生产的政策方向所推动。

‍

目前，孟加拉国大部分乘用车和汽车零部件依赖进口，这为经济型乘用车、电动两轮车和三轮车、电池电芯、电动汽车零部件及相关制造领域的本地化提供了更大空间。主要车辆进口来源包括日本、中国、印度、泰国和韩国，反映出孟加拉国与区域汽车供应链的连接不断加深。

‍

当前机会领域包括电动两轮车制造及电池相关生态系统；受益于相较CBU整车进口的关税优势和不断扩大的中产消费市场的CKD乘用车组装；与基础设施和物流增长相关的商用车组装；覆盖城市地区和高速公路走廊的电动汽车充电基础设施；以及汽车零部件本地化，包括电池、控制器、线束、制动系统和发动机组件。

‍

早期充电基础设施发展、针对电动汽车和混合动力车型的优惠关税待遇，以及不断增长的电动汽车进口需求，正在增强该行业的投资吸引力。拟议的2026—27财年预算进一步支持这一方向，进口电动汽车的关税税负拟从93%降至64%至80%，本地制造的电动汽车和插电式混合动力汽车整体税负拟从89%降至约33%。

‍

对投资者而言，孟加拉国提供了一个服务不断增长的国内出行市场的平台，同时也为电动汽车、零部件、电池及配套基础设施发展本地制造能力提供了空间。

‍

‍

## 增长驱动因素

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a323f7bce8defae19fa0f52_68330c2b5e73bf3f5e1847ce_Group%20173%20\(1\).svg)

### 市场规模

庞大人口和不断扩大的中产消费群体，正在提升对经济型两轮车、乘用车和商用出行解决方案的需求。

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3a215d2d100f91b35580e1_ev-charge.png)

### 电动化动能

电动两轮车、三轮车和商用电动汽车需求增长，正在创造组装、电池和充电基础设施领域的投资机遇。

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3a22f71b910755f7202ef1_lll.png)

### 本地组装

CKD和SKD组装相较于CBU整车进口具有关税优势，使本地制造更具商业吸引力。

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a323f5fec85e3dca2a557e7_682c51d814d4da2279365798_Agro%20Icon-01.svg)

### 政策支持

电动汽车普及、本地零部件生产、充电基础设施和电池生态系统发展，正获得越来越多政策支持。

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3664c5b3793215d696f05d_icon%202nd.png)

### 工业能力

不断发展的轻工工程基础、经济区和工业园区，为汽车零部件和组件制造提供了基础。

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3641072e061ee276968985_4.svg)

### 战略互联

道路、港口、铁路和区域通道投资，正在改善物流、分销和供应链可靠性。

### POLICIES & INCENTIVES

-   Reduced duty for CKD/SKD vehicle assembly compared to CBU imports (Source: NBR Customs Tariff FY2024-25).

-   Preferential tariff for electric vehicles and EV components (Source: NBR Budget SRO 2024-25).
-   Policy encouragement for EV adoption, progressive localization, local parts production, charging infrastructure, and battery-related ecosystem development (including recycling) (Source: Ministry of Industries)

#### RELEVANT BODIES

-   Bangladesh Automobiles Assemblers and Manufacturers Association (BAAMA)
-   Ministry / Agency Relevance
-   Ministry of Industries
-   Bangladesh Road Transport Authority (BRTA)
-   National Board of Revenue (NBR)
-   Bangladesh Standards and Testing Institution (BSTI)
-   Power Division
-   Bangladesh Energy Regulatory Commission (BERC)
-   Sustainable and Renewable Energy Development Authority (SREDA)
-   Bangladesh Investment Development Authority (BIDA)
-   Bangladesh Economic Zones Authority (BEZA)
-   Bangladesh Export Processing Zones Authority (BEPZA)
-   Bangladesh Hi-Tech Park Authority (BHTPA)

## **BIDA Sector Focal**

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a32478a7ceaf9d84ab0abdf_Untitled%20design%20\(4\).png)](#)

Sheikh Rasibul Islam  

Deputy Director

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a324c4edc4295c73da1d547_wechat_red_icon.png)[+8801712595962](#)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[dd.is3@bida.gov.bd](mailto:dd.is3@bida.gov.bd)

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a32478a7ceaf9d84ab0abdf_Untitled%20design%20\(4\).png)](#)

Mobarok Hossain

Assistant Director

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a324c4edc4295c73da1d547_wechat_red_icon.png)[+8801779197057](#)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.cl6@bida.gov.bd](mailto:ad.cl6@bida.gov.bd)

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a32478a7ceaf9d84ab0abdf_Untitled%20design%20\(4\).png)](#)

Sheikh Rasibul Islam  

Deputy Director

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a324c4edc4295c73da1d547_wechat_red_icon.png)[+8801712595962](#)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[dd.is3@bida.gov.bd](mailto:dd.is3@bida.gov.bd)

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a32478a7ceaf9d84ab0abdf_Untitled%20design%20\(4\).png)](#)

Mobarok Hossain

Assistant Director

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a324c4edc4295c73da1d547_wechat_red_icon.png)[+8801779197057](#)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.cl6@bida.gov.bd](mailto:ad.cl6@bida.gov.bd)