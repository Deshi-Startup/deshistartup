---
source: "Bangladesh Investment Development Authority (BIDA)"
tier: 1
category: "Government / regulator"
url: "https://bida.gov.bd/aftercare"
title: "BIDA | Investment Growth & Business Expansion Support"
scraped_at: "2026-07-02"
---

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/686cf7286136ad1eee6ed377_Layer_1%20\(1\).svg)](/)

[中文](/china)[BIDA OSS](/services#one-stop-services)[

Matchmakin

](https://uat-irms.oss.net.bd/matchmaking)

![bida search icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678cd4d48720bb0edd6ad500_Group%2055.svg)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/68945f6c4818ae3dc291a664_Layer_1.svg)![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![search](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6788a1c48788ea23e00ed88c_Group%2055%20\(1\).webp)

![humbergur](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678896a2d5b4ac64ddac5e2a_Group%2096%20\(3\).webp)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

-   [home](/)

-   [OPPORTUNITIES](/opportunities)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [Services](/services)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [RESOURCES](/resources)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [ABOUT BIDA](/about-bida)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [NOTICE](/notices)

[BIDA OSS](https://www.investbangladesh.gov.bd/services#one-stop-service)[中文](/china)[

MATCHMAKING

](https://uat-irms.oss.net.bd/matchmaking)

# Post-Investment Support

Supporting investors beyond entry

Post-Investment Support refers to the support extended to investors after initial entry and registration, covering facilitation, approvals, and issue resolution throughout the operational lifecycle of a project. BIDA provides Post-Investment Support services to ensure the smooth functioning, expansion, and retention of investments.  
  
These services are available to foreign and domestic industries, as well as Branch, Liaison, and Representative Offices registered with BIDA. Eligible entities may seek assistance with the services listed below.

Post-Investment Support Services

No

01

Services

Trade license

Responsible organization

-   City corporation
-   Union Parishad
-   Municipality

02

-   Name Clearance
-   Certificate of Incorporation
-   Certificate of Commencement of Business
-   Approval of Articles of Association
-   Approval of Memorandum of Association
-   Transfer of Share
-   Amendment of Memorandum/Articles of Companies and Firms
-   Change of Director
-   Authorized capital increase

Office of the Registrar of Joint Stock Companies and Firms

03

-   Land purchase deed/Lease Agreement Registration/Binding Deal/Registration of Power of Attorney
-   Supply copy of Registered Deed

Directorate of Registration & Sub Registry Office

04

Land mutation

Concerned Upazila Land Office

05

Issuance of different categories of visas recommended by BIDA

-   Embassies of Bangladesh
-   Ministry of Foreign Affairs

06

E-Visa extension

-   Expiry of E1 visa
-   Extension of PI visa
-   Extension of A3 visa

Department of Immigration and Passports, Ministry of Home Affairs

07

-   Visa extension with class change (subject to receipt of security clearance/Special Branch (SB) report/recommendation by BIDA)

Security Services Division, Ministry of Home Affairs

-   Submission of Special Branch (SB) report for visa
-   Submission of SB report for Security Clearance

Special Branch, Bangladesh Police

-   Submission of NSI report for Security Clearance

National Security Intelligence (NSI)

-   Issuance of Security Clearance for Visa/Work Permit Renewal (subject to receipt of report)

Ministry of Home Affairs

08  

-   Issuance of Industrial Import Registration Certificate (IRC)
-   Permission for sample import/export
-   Controlled products import (subject to receipt of BIDA’s recommendation)

Office of the Chief Controller of Imports and Exports

09

Land Acquisition

-   BIDA
-   Deputy Commissioner’s Office
-   Ministry of Land

10

Green

Environmental

Orange-A

Environmental

Positional

Orange-B

Environmental

Positional

Red

Environmental

Department of Environment

11  

Green

Environmental

Orange-A

Environmental

Positional

Orange-B

Environmental

Positional

Red

Environmental

Department of Environment

12

Land use clearance

Special project clearance

On-site inspection

Building construction approval

Living use certificate

-   Capital Development Authority
-   Chittagong Development Authority
-   City Corporation
-   Municipality
-   Union Parishad

13

Technical investigation and survey work completed

Load allotment

Demand note issue

Deposit of money

Meter supply and electricity connection

-   Department of Power
-   Distribution companies

14

Gas connection

-   Department of Energy and Mineral Resources
-   Gas Distribution Companies

15

Water connection and sewerage

-   Water Supply and Sewerage Authority (WASA)
-   City Corporations Municipalities

16

Telephone and internet connection

Bangladesh Telecommunication Company Limited (BTCL)

17

Approval of Fire Safety Plan

Fire Safety License Approval (with final inspection)

Renewal of fire safety license

Department of Fire Service and Civil Defense

18

Issuance  of explosives license

Renewal of explosives license

Department of Explosives

19

Licensing

Approval of factory machine layout plan

License renewal and amendment

Department of Inspection for Factories and Establishments (DIFE)

20

No objection certificate for Boiler Import

Boiler registration and issuance of certificate

Renewal of Boiler certificate (with inspection)

Change of ownership (name/address)

Office of the Chief Inspector of Boilers

21

TIN  registration

VAT registration

Business  Identification  Number (BIN)

Bond License

Customs clearance

Deduction of duty/tax

Utilization Permit (UP)

National  Board of Revenue

22

Certificate of Origin

Export Promotion Bureau

Chamber of Commerce

23

Utilization declaration

Bangladesh Garment Manufacturers and Exporters Association (BGMEA)

24

Issuance of Mark License (with inspection)

-   Bangladesh Standards and Testing Institution
-   Ministry of Industries

25

Permission  to  take  Foreign  Currency  Term  Loan (FTCL) from Off-Shore  Banking  Unit  (OBU) by private industrialproject registered with BIDA  
  
To  inform  matters  relating  to  the  issue/transfer of shares  in  favor  of  non-resident  to  resident,  resident to  non-resident  and  non-resident  to  non-resident  in unlisted companies on the stock exchange  
  
Profit and dividend return  
  
Permission to send consultancy fees outside general authority  
  
Proceeds  from  sale  of shares  held  by  a  non-resident in an    unlisted  company  on  the stock exchange to a resident and the return of the remaining money abroad in proportion to the company's liquidation

Bangladesh Bank

How to make an application

-   Write application to Executive Chairman of BIDA with attention to Executive Member, Strategic Investment (Use company letterhead)
-   Attach copy of company’s registration issued by BIDA
-   Attach copy of application made to avail investor service from concerned organization
-   Attach any previous letter on same subject (if any)
-   Attach any document relevant to the application
-   Email to [dir.rifi@bida.gov.bd](mailto:investmentaftercare@bida.gov.bd) (For Foreign Iddustry), [dir.rifc@bida.gov.bd](mailto:dir.aftercare@bida.gov.bd) (For local indutry) OR send the application to Director, director (deputy secreatry),Registration,Foreign industry or director Registration local industry-1 Unit at BIDA Head Office:  E - 6/8, Sher-e Bangla Nagar, Dhaka -1207.

Resources

-   [Investment Aftercare Procedure](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685c0b8e068ffe8ae0b4e924_Investment%20Guide%20for%20Bangladesh-compressed-compressed_11zon%20\(1\).pdf)

#### BOOK AN APPOINTMENT

##### SERVICE

New Business Opportunities

Registration & Approvals

Regulatory Facilitation

Visa & Work Permit Support

Aftercare

Policy & Sectoral Guidance

##### REQUESTED DATE

##### REQUESTED TIME

**Thank you!**  
Your appointment request has been submitted.  
If approved, a confirmation email will be sent to you.

Oops! Something went wrong while submitting the form.