---
source: "Bangladesh Investment Development Authority (BIDA)"
tier: 1
category: "Government / regulator"
url: "https://bida.gov.bd/sector-desks"
title: "BIDA | Sector Desks"
scraped_at: "2026-07-02"
---

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/686cf7286136ad1eee6ed377_Layer_1%20\(1\).svg)](/)

[中文](/china)[BIDA OSS](/services#one-stop-services)[

Matchmakin

](https://uat-irms.oss.net.bd/matchmaking)

![bida search icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678cd4d48720bb0edd6ad500_Group%2055.svg)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/68945f6c4818ae3dc291a664_Layer_1.svg)![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![search](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6788a1c48788ea23e00ed88c_Group%2055%20\(1\).webp)

![humbergur](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678896a2d5b4ac64ddac5e2a_Group%2096%20\(3\).webp)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

-   [home](/)

-   [OPPORTUNITIES](/opportunities)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [Services](/services)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [RESOURCES](/resources)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [ABOUT BIDA](/about-bida)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [NOTICE](/notices)

[BIDA OSS](https://www.investbangladesh.gov.bd/services#one-stop-service)[中文](/china)[

MATCHMAKING

](https://uat-irms.oss.net.bd/matchmaking)

# Sector desks  

## Dedicated Investor Support, by Sector  

# BIDA sector DESKS FOR INVESTOR SUPPORT

##### Connect with BIDA’s sector desk officers for sector-specific investor  
support and facilitation services in Bangladesh

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a0d454ba6d2af0b8939f64e_Adobe%20Express%20-%20file.png)

### Logistics

-   Lead: Tajmahal Begum
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801917677419](https://wa.me/8801917677419)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[dir.is1@bida.gov.bd](mailto:dir.is1@bida.gov.bd)
    
    Sheikh Rasibul Islam
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801712595962](https://wa.me/8801712595962)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[rasibul20@gmail.com](mailto:rasibul20@gmail.com)
    
    Mahfuzul Islam
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801521407944](https://wa.me/8801521407944)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.is1@bida.gov.bd](mailto:ad.is1@bida.gov.bd)
    

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69fc23d2a712031c17fd585b_10.png)

### Heavy Industries & Light Engineering

-   Lead: Tajmahal Begum
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801917677419](https://wa.me/8801917677419)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[dir.is1@bida.gov.bd](mailto:dir.is1@bida.gov.bd)
    
    Sheikh Rasibul Islam
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801712595962](https://wa.me/8801712595962)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[rasibul20@gmail.com](mailto:rasibul20@gmail.com)
    
    Mahfuzul Islam
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801521407944](https://wa.me/8801521407944)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.is1@bida.gov.bd](mailto:ad.is1@bida.gov.bd)
    

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69f2da4fc751bf60352871ef_Service%20Industry%20\(Financial%2C%20Fintech%20%26%20Hospitality\).png)

### Financial Services, Fintech & Hospitality

-   Lead: Dr. Md. Houmyoun Kabir Khan
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801919859881](https://wa.me/8801919859881)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[dir.siu@bida.gov.bd](mailto:dir.is1@bida.gov.bd)
    
    Sheikh Rasibul Islam
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801712595962](https://wa.me/8801712595962)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[rasibul20@gmail.com](mailto:rasibul20@gmail.com)
    
    Hridi Rahman
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801621132528](https://wa.me/8801621132528)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.ips2@bida.gov.bd](mailto:ad.ips2@bida.gov.bd)
    

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69fc23d27e2051ec53799409_11.png)

### Automotive & Electric Vehicles

-   Lead: Tajmahal Begum
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801917677419](https://wa.me/8801917677419)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[dir.is1@bida.gov.bd](mailto:dir.is1@bida.gov.bd)
    
    Jannatul Ferdousy
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801323586003](https://wa.me/8801323586003)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.oss@bida.gov.bd](mailto:ad.oss@bida.gov.bd)
    
    SM Rafio Morshed
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801671160070](https://wa.me/8801671160070)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.is7@bida.gov.bd](mailto:ad.is7@bida.gov.bd)
    

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69f2da4f6c1f690910e0d9a4_Agriculture%20%26%20Food%20Processing.png)

### Agribusiness & Food Processing

-   Lead: Sunil Kumar Adhikary
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801550151283](https://wa.me/8801550151283)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[dir.ossrr@bida.gov.bd](mailto:dir.ossrr@bida.gov.bd)
    
    Sheikh Rasibul Islam
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801712595962](https://wa.me/8801712595962)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[rasibul20@gmail.com](mailto:rasibul20@gmail.com)
    
    Ashraful Alam Lincoln
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801911403009](https://wa.me/8801911403009)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.ips5@bida.gov.bd](mailto:ad.hrd@bida.gov.bd)
    

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69fc23d2689eca36673d3d4b_12.png)

### Renewable Energy

-   Lead: Tajmahal Begum
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801917677419](https://wa.me/8801917677419)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[dir.is1@bida.gov.bd](mailto:dir.is1@bida.gov.bd)
    
    Sheikh Rasibul Islam
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801712595962](https://wa.me/8801712595962)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[rasibul20@gmail.com](mailto:rasibul20@gmail.com)
    
    Mobarok Hossain
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801779197057](https://wa.me/8801779197057)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.cl6@bida.gov.bd](mailto:ad.cl6@bida.gov.bd)
    

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69fc23d2107e323bc7803a9c_13.png)

### FMCG

-   Lead: Tajmahal Begum
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801917677419](https://wa.me/8801917677419)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[dir.is1@bida.gov.bd](mailto:dir.is1@bida.gov.bd)
    
    Sheikh Rasibul Islam
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801712595962](https://wa.me/8801712595962)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[rasibul20@gmail.com](mailto:rasibul20@gmail.com)
    
    Mobarok Hossain
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801779197057](https://wa.me/8801779197057)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.cl6@bida.gov.bd](mailto:ad.cl6@bida.gov.bd)
    

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69fc23d26a99d11bc727bc61_14.png)

### IT & ITes

-   Lead: Tajmahal Begum
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801917677419](https://wa.me/8801917677419)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[dir.is1@bida.gov.bd](mailto:dir.is1@bida.gov.bd)
    
    Atik Sarker
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801914594512](https://wa.me/8801914594512)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[dd.rifiwp@bida.gov.bd](mailto:dd.rifiwp@bida.gov.bd)
    
    Mahfuzul Islam
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801521407944](https://wa.me/8801521407944)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.is8@bida.gov.bd](mailto:ad.is8@bida.gov.bd)
    

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69fc2e90d743546352ca757c_Pharmaceuticals%20%26%20Healthcare%20\(1\).png)

### Electronics

-   Lead: Tajmahal Begum
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801917677419](https://wa.me/8801917677419)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[dir.is1@bida.gov.bd](mailto:dir.is1@bida.gov.bd)
    
    Atik Sarker
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801914594512](https://wa.me/8801914594512)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[dd.rifiwp@bida.gov.bd](mailto:dd.rifiwp@bida.gov.bd)
    
    Mahfuzul Islam
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801521407944](https://wa.me/8801521407944)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.is8@bida.gov.bd](mailto:ad.is8@bida.gov.bd)
    

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69fc23d2678316b5a87d86e1_15.png)

### Textiles & Apparel

-   Lead: Tajmahal Begum
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801917677419](https://wa.me/8801917677419)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[dir.is1@bida.gov.bd](mailto:dir.is1@bida.gov.bd)
    
    Faizur Rabbi
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801711082417](https://wa.me/8801711082417)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[rabbeefaizur@gmail.com](mailto:rabbeefaizur@gmail.com)
    
    SM Rafio Morshed
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801671160070](https://wa.me/8801671160070)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.ips6@bida.gov.bd](mailto:ad.ips6@bida.gov.bd)
    
    Ashraful Alam Lincoln
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801911403009](https://wa.me/8801911403009)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.ips5@bida.gov.bd](mailto:ad.hrd@bida.gov.bd)
    

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69fc23d2208045b340dbda32_16.png)

### Leather & Footwear

-   Lead: Tajmahal Begum
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801917677419](https://wa.me/8801917677419)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[dir.is1@bida.gov.bd](mailto:dir.is1@bida.gov.bd)
    
    Faizur Rabbi
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801711082417](https://wa.me/8801711082417)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[rabbeefaizur@gmail.com](mailto:rabbeefaizur@gmail.com)
    
    SM Rafio Morshed
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801671160070](https://wa.me/8801671160070)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.ips6@bida.gov.bd](mailto:ad.hrd@bida.gov.bd)
    
    Ashraful Alam Lincoln
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801911403009](https://wa.me/8801911403009)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.ips5@bida.gov.bd](mailto:ad.hrd@bida.gov.bd)
    

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69fc23d284943f23a7e62bff_17.png)

### Health & Pharma

-   Lead: Dr. Md. Houmyoun  
    Kabir Khan
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801919859881](https://wa.me/8801919859881)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[dir.siu@bida.gov.bd](mailto:dir.is1@bida.gov.bd)
    
    Sheikh Rasibul Islam
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801712595962](https://wa.me/8801712595962)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[rasibul20@gmail.com](mailto:rasibul20@gmail.com)
    
    Hridi Rahman
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801621132528](https://wa.me/8801621132528)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.ips2@bida.gov.bd](mailto:ad.ips2@bida.gov.bd)
    
    Md Rashedur Rahman
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801521487446](https://wa.me/8801521487446)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.is2@bida.gov.bd](mailto:ad.is2@bida.gov.bd)
    

![BIDA Online One Stop Service Portal](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6857d01a4b0cc9c2995ee763_Logo%20Icon-26.svg)

## BIDA INVESTMENT  
MATCHMAKING PORTAL

CONNECTING INVESTORS & INVESTEES  
DIRECTLY AND TRANSPARENTLY

-   INVESTEES CAN REGISTER AND SHOWCASES INVESTMENT-REDY PROJECTS
-   INVESTORS GAIN DIRECT ACCESS TO SECTOR-WISE PROJECT PORTFOLIO
-   DIRECT AND TRANSPARENT ENGAGEMENT WITHOUT INTERMEDIARES

[LOG IN](https://irms.bida.gov.bd/matchmaking)[GET help](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6937f6d77307f50fe568395f_B2B%20MATCHMAKING_BIDA_%20USER%20GUIDE%20\(1\).pdf)

-   INVESTEES CAN REGISTER AND SHOWCASE INVESTMENT-READY PROJECTS
-   INVESTORS GAIN DIRECT ACCESS TO SECTOR-WISE PROJECT PORTFOLIO
-   DIRECT AND TRANSPARENT ENGAGEMENT WITHOUT INTERMEDIARIES