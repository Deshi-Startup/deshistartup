---
source: "Bangladesh Investment Development Authority (BIDA)"
tier: 1
category: "Government / regulator"
url: "https://bida.gov.bd/country-desks"
title: "BIDA | Country Desks"
scraped_at: "2026-07-02"
---

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/686cf7286136ad1eee6ed377_Layer_1%20\(1\).svg)](/)

[中文](/china)[BIDA OSS](/services#one-stop-services)[

Matchmakin

](https://uat-irms.oss.net.bd/matchmaking)

![bida search icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678cd4d48720bb0edd6ad500_Group%2055.svg)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/68945f6c4818ae3dc291a664_Layer_1.svg)![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![search](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6788a1c48788ea23e00ed88c_Group%2055%20\(1\).webp)

![humbergur](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678896a2d5b4ac64ddac5e2a_Group%2096%20\(3\).webp)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

-   [home](/)

-   [OPPORTUNITIES](/opportunities)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [Services](/services)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [RESOURCES](/resources)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [ABOUT BIDA](/about-bida)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [NOTICE](/notices)

[BIDA OSS](https://www.investbangladesh.gov.bd/services#one-stop-service)[中文](/china)[

MATCHMAKING

](https://uat-irms.oss.net.bd/matchmaking)

# Country Desks  

## Dedicated investor support, by market  

# BIDA COUNTRY DESKS FOR INVESTOR SUPPORT

##### Connect with BIDA’s dedicated country desk officers for investor  
support and facilitation services in Bangladesh

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69f19297170da7347377a56a_usa.png)

### USA

-   Lead: Md. Sirajul Islam Khan
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801711952685](https://wa.me/8801711952685)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[research@bida.gov.bd](mailto:research@bida.gov.bd)
    
    Md. Anwar Uj Jaman
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801727233257](https://wa.me/8801727233257)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[pstoec@bida.gov.bd](mailto:pstoec@bida.gov.bd)
    
    Rabiul Islam
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801703901427](https://wa.me/8801703901427)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.hrd@bida.gov.bd](mailto:ad.hrd@bida.gov.bd)
    

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69f194ac4e6189fa38755f1a_china.png)

### China

-   Lead: Shah Nusrat Jahan
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801671046464](https://wa.me/8801671046464)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[dir.cl2@bida.gov.bd](mailto:dir.cl2@bida.gov.bd)
    
    Sikdar Didarul
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801919955096](https://wa.me/8801919955096)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.cl2@bida.gov.bd](mailto:ad.cl2@bida.gov.bd)
    
    Mobarok Hossain
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801779197057](https://wa.me/8801779197057)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.cl6@bida.gov.bd](mailto:ad.cl6@bida.gov.bd)
    

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69f194fa1d816f3d727b8909_turkey.png)

### Turkey

-   Lead: Shah Nusrat Jahan
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801671046464](https://wa.me/8801671046464)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[dir.cl2@bida.gov.bd](mailto:dir.cl2@bida.gov.bd)
    
    Sikdar Didarul
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801919955096](https://wa.me/8801919955096)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.cl2@bida.gov.bd](mailto:ad.cl2@bida.gov.bd)
    
    Hridi Rahman
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801621132528](https://wa.me/8801621132528)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.ips2@bida.gov.bd](mailto:ad.ips2@bida.gov.bd)
    

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69f19553cb252912b83a90eb_europe.png)

### Europe

-   Lead: Mst. Shamima Akter
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801732123408](https://wa.me/8801732123408)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[dir.rifi@bida.gov.bd](mailto:dir.rifi@bida.gov.bd)
    
    Sikdar Didarul
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801919955096](https://wa.me/8801919955096)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.cl2@bida.gov.bd](mailto:ad.cl2@bida.gov.bd)
    
    Mobarok Hossain
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801779197057](https://wa.me/8801779197057)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.cl6@bida.gov.bd](mailto:ad.cl6@bida.gov.bd)
    
    SM Rafio Morshed
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801671160070](https://wa.me/8801671160070)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.cl6@bida.gov.bd](mailto:ad.hrd@bida.gov.bd)
    

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69f196200940e35dcd1b50c8_south-korea.png)

### south korea

-   Lead: Shah Nusrat Jahan
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801671046464](https://wa.me/8801671046464)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[dir.cl2@bida.gov.bd](mailto:dir.cl2@bida.gov.bd)
    
    Atik Sarker
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801914594512](https://wa.me/8801914594512)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[dd.rifiwp@bida.gov.bd](mailto:dd.rifiwp@bida.gov.bd)
    
    Md. Rashedur Rahman
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801521487446](https://wa.me/8801521487446)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.cl4@bida.gov.bd](mailto:ad.cl4@bida.gov.bd)
    
    Yasuyuki Murahashi
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801713040634](https://wa.me/8801713040634)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[y.murahashi.bida@gmail.com](mailto:y.murahashi.bida@gmail.com)
    

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69f19618c01abb5dcee0aed6_japan.png)

### Japan

-   Lead: Shah Nusrat Jahan
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801671046464](https://wa.me/8801671046464)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[dir.cl2@bida.gov.bd](mailto:dir.cl2@bida.gov.bd)
    
    Atik Sarker
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801914594512](https://wa.me/8801914594512)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[dd.rifiwp@bida.gov.bd](mailto:dd.rifiwp@bida.gov.bd)
    
    Md. Rashedur Rahman
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801521487446](https://wa.me/8801521487446)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.cl4@bida.gov.bd](mailto:ad.cl4@bida.gov.bd)
    
    Yasuyuki Murahashi
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801713040634](https://wa.me/8801713040634)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[y.murahashi.bida@gmail.com](mailto:y.murahashi.bida@gmail.com)
    

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69f196f93eea15eaa78a9c50_taiwan.png)

### Taiwan, china

-   Lead: Shah Nusrat Jahan
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801671046464](https://wa.me/8801671046464)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[dir.cl2@bida.gov.bd](mailto:dir.cl2@bida.gov.bd)
    
    Sikdar Didarul
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801919955096](https://wa.me/8801919955096)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.cl2@bida.gov.bd](mailto:ad.cl2@bida.gov.bd)
    
    Mobarok Hossain
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801779197057](https://wa.me/8801779197057)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.cl6@bida.gov.bd](mailto:ad.cl6@bida.gov.bd)
    

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69f19751b50540d0264f7c31_hong-kong.png)

### Hong kong sar, china

-   Lead: Shah Nusrat Jahan
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801671046464](https://wa.me/8801671046464)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[dir.cl2@bida.gov.bd](mailto:dir.cl2@bida.gov.bd)
    
    Sikdar Didarul
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801919955096](https://wa.me/8801919955096)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.cl2@bida.gov.bd](mailto:ad.cl2@bida.gov.bd)
    
    Mobarok Hossain
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801779197057](https://wa.me/8801779197057)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.cl6@bida.gov.bd](mailto:ad.cl6@bida.gov.bd)
    

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69f197a22ae5f849ba42f120_canada.png)

### canada

-   Lead: Md. Sirajul Islam Khan
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801711952685](https://wa.me/8801711952685)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[research@bida.gov.bd](mailto:research@bida.gov.bd)
    
    Md. Anwar Uj Jaman
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801727233257](https://wa.me/8801727233257)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[pstoec@bida.gov.bd](mailto:pstoec@bida.gov.bd)
    
    Rabiul Islam
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801703901427](https://wa.me/8801703901427)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.hrd@bida.gov.bd](mailto:ad.hrd@bida.gov.bd)
    

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef1ef17ccccfdc6945c342_south%20america.png)

### South America

-   Lead: Mst. Shamima Akter
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801732123408](https://wa.me/8801732123408)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[dir.rifi@bida.gov.bd](mailto:dir.rifi@bida.gov.bd)
    
    Abu Mohammad Nurul Hayat Totul
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801703901427](https://wa.me/8801703901427)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[dd.ossrr@bida.gov.bd](mailto:dd.ossrr@bida.gov.bd)
    
    Md. Rashedur Rahman
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801521487446](https://wa.me/8801521487446)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.cl4@bida.gov.bd](mailto:ad.cl4@bida.gov.bd)
    

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef1e09a49256d4b4dec19d_south%20asia.png)

### South Asia

-   Lead: Mst. Shamima Akter
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801732123408](https://wa.me/8801732123408)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[dir.rifi@bida.gov.bd](mailto:dir.rifi@bida.gov.bd)
    
    Abu Mohammad Nurul Hayat Totul
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801703901427](https://wa.me/8801703901427)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[dd.ossrr@bida.gov.bd](mailto:dd.ossrr@bida.gov.bd)
    
    Mahfuzul Islam
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801521407944](https://wa.me/8801521407944)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.cl3@bida.gov.bd](mailto:ad.cl3@bida.gov.bd)
    

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef1e1093a5e4fe760565f1_southeast%20asia.png)

### Southeast Asia

-   Lead: Mst. Shamima Akter
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801732123408](https://wa.me/8801732123408)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[dir.rifi@bida.gov.bd](mailto:dir.rifi@bida.gov.bd)
    
    Abu Mohammad Nurul Hayat Totul
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801703901427](https://wa.me/8801703901427)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[dd.ossrr@bida.gov.bd](mailto:dd.ossrr@bida.gov.bd)
    
    Mahfuzul Islam
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801521407944](https://wa.me/8801521407944)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.cl3@bida.gov.bd](mailto:ad.cl3@bida.gov.bd)
    

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef1e7d7efdb753474acd79_middle%20east.png)

### Middle East

-   Lead: Md.Sirajul Islam Khan
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801711952685](https://wa.me/8801711952685)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[research@bida.gov.bd](mailto:research@bida.gov.bd)
    
    Sikder Didarul
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801919955096‬](https://wa.me/8801919955096‬)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.cl2@bida.gov.bd](mailto:ad.cl2@bida.gov.bd)
    
    Md. Rabiul Islam
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801521407944](https://wa.me/8801521407944)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.hrd@bida.gov.bd](mailto:ad.hrd@bida.gov.bd)
    

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef1ebb3ddce46c62e2249e_africa.png)

### Africa

-   Lead: Mst. Shamima Akter
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801732123408](https://wa.me/8801732123408)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[dir.rifi@bida.gov.bd](mailto:dir.rifi@bida.gov.bd)
    
    Abu Mohammad Nurul Hayat Totul
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801703901427](https://wa.me/8801703901427)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[dd.ossrr@bida.gov.bd](mailto:dd.ossrr@bida.gov.bd)
    
    Md. Rashedur Rahman
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801521487446](https://wa.me/8801521487446)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.cl4@bida.gov.bd](mailto:ad.cl4@bida.gov.bd)
    

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a0e78cf370e2414bb6cc3a2_Gemini_Generated_Image_9xbm2y9xbm2y9xbm.png)

### Non-Resident  
Bangladeshis (nrb)

-   Lead: Md.Sirajul Islam Khan
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801711952685](https://wa.me/8801711952685)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[research@bida.gov.bd](mailto:research@bida.gov.bd)
    
    Abu Mohammad Nurul Hayat Totul
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801703901427](https://wa.me/8801703901427)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[dd.ossrr@bida.gov.bd](mailto:dd.ossrr@bida.gov.bd)
    
    Ashraful Alam Lincoln
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801911403009](https://wa.me/8801911403009)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.ips5@bida.gov.bd](mailto:ad.ips5@bida.gov.bd)
    

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a0e79a5122aa70291126f12_nbrr.png)

### Multilaterals

-   Lead: Md.Sirajul Islam Khan
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801711952685](https://wa.me/8801711952685)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[dir.rifi@bida.gov.bd](mailto:research@bida.gov.bd)
    
    Abu Mohammad Nurul Hayat Totul
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801703901427](https://wa.me/8801703901427)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[dd.ossrr@bida.gov.bd](mailto:dd.ossrr@bida.gov.bd)
    
    Ashraful Alam Lincoln
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)[+8801911403009](https://wa.me/8801911403009)
    
    ![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.ips5@bida.gov.bd](mailto:ad.hrd@bida.gov.bd)
    

![BIDA Online One Stop Service Portal](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6857d01a4b0cc9c2995ee763_Logo%20Icon-26.svg)

## BIDA INVESTMENT  
MATCHMAKING PORTAL

CONNECTING INVESTORS & INVESTEES  
DIRECTLY AND TRANSPARENTLY

-   INVESTEES CAN REGISTER AND SHOWCASES INVESTMENT-REDY PROJECTS
-   INVESTORS GAIN DIRECT ACCESS TO SECTOR-WISE PROJECT PORTFOLIO
-   DIRECT AND TRANSPARENT ENGAGEMENT WITHOUT INTERMEDIARES

[LOG IN](https://irms.bida.gov.bd/matchmaking)[GET help](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6937f6d77307f50fe568395f_B2B%20MATCHMAKING_BIDA_%20USER%20GUIDE%20\(1\).pdf)

-   INVESTEES CAN REGISTER AND SHOWCASE INVESTMENT-READY PROJECTS
-   INVESTORS GAIN DIRECT ACCESS TO SECTOR-WISE PROJECT PORTFOLIO
-   DIRECT AND TRANSPARENT ENGAGEMENT WITHOUT INTERMEDIARIES