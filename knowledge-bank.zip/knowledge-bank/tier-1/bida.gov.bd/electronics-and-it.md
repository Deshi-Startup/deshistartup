---
source: "Bangladesh Investment Development Authority (BIDA)"
tier: 1
category: "Government / regulator"
url: "https://bida.gov.bd/china-sector/electronics-and-it"
title: "Electronics and IT"
scraped_at: "2026-07-02"
---

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/686cf7286136ad1eee6ed377_Layer_1%20\(1\).svg)](/china)

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/686cf7286136ad1eee6ed377_Layer_1%20\(1\).svg)](/china)

[首页](/china)[投资机遇](#)[资源中心](https://investbangladesh.gov.bd/resources)[关于BIDA](/china-page-about-bida) [联系我们](/china-page-contact)

[English](/)[B2B商务对接](https://irms.bida.gov.bd/matchmaking)

# **电子产品与信息技术**

**青春、连接与代码交汇之地**

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3b7ccbf2f30a0b3818ca78_WhatsApp%20Image%202026-06-24%20at%2012.42.47%20PM.jpeg)

**全球第9位**

移动连接总量全球排名

**21亿美元**

2025年IT服务市场规模

**65万+**

注册自由职业者

**4500+**

IT与软件公司

## 概览

孟加拉国电子产品与信息技术行业正成为数字服务、技术赋能型出口和电子产品制造的高潜力平台。该行业受到快速互联互通、年轻数字劳动力、国内技术产品需求上升，以及政府日益重视将孟加拉国建设成为具有竞争力的区域技术与制造业枢纽等因素支撑。

‍

孟加拉国拥有超过1.3亿互联网用户，60%的家庭拥有智能手机，是亚洲数字连接程度较高的前沿市场之一。孟加拉国也是全球自由职业IT人才的重要来源地之一，拥有大量年轻、熟悉技术的专业人才，活跃于软件开发、IT赋能服务、人工智能、网络安全、UI/UX、移动应用和嵌入式系统等领域。

‍

国内IT服务市场正在快速扩张，预计到2025年收入将达到21.1亿美元，其中IT外包是主要增长板块。2025年至2029年期间，该市场预计将以11.8%的年复合增长率增长，到2029年达到32.9亿美元。这反映出企业IT应用不断增加，也体现了孟加拉国作为具有竞争力的外包目的地的地位正在提升。

‍

在数字服务之外，孟加拉国也正将电子产品和消费电子制造作为更广泛技术路线图的重要组成部分。优先领域包括手机、电脑和数字设备、消费电子产品、CCTV摄像头、智能卡，以及芯片设计、测试和封装等半导体相关活动和配套技术产品。

‍

该行业还受到国家在互联互通、数字公共基础设施、数据中心、人工智能和电子产品制造等领域优先方向的支持。对投资者而言，孟加拉国提供了一个将数字人才、不断增长的国内需求、具有竞争力的生产条件，以及IT服务和电子产品制造领域新兴政策支持相结合的投资机会。

‍

投资机会领域包括消费电子产品、电脑、手机及数字设备的电子产品组装；芯片设计、测试和封装等半导体活动；涵盖软件开发、网络安全、人工智能、UI/UX和移动应用的IT服务；包括数据中心、连接平台和云服务在内的数字基础设施；以及IT外包和业务流程服务等外包与BPO。

‍

## **增长驱动因素**

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a323f5f036d5fa8d0dfe883_68330b8ce0bc0c286a0deaff_Group%20298.svg)

### 加速连接普及

Starlink的进入预计将改变孟加拉国的连接格局，特别是将高速互联网扩展至服务不足地区，并为数字服务、电子商务、教育科技、智慧农业和农村科技基础设施释放新机遇。

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a323f7bce8defae19fa0f52_68330c2b5e73bf3f5e1847ce_Group%20173%20\(1\).svg)

### 外国投资增长

40多家公司目前以合资企业或全外资离岸开发中心形式运营，推动孟加拉国进一步融入全球科技供应链。

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a362fd1454e67492a61cd19_6834462c85b3e4cae9a09ba4_Vector%20\(15\).svg)

### 先进解决方案

孟加拉国企业提供包括生物识别身份系统、自动化许可平台和全球后端基础设施在内的高端服务，同时在人工智能与机器学习、物联网和嵌入式系统、AR/VR以及定制企业软件等领域具备新兴能力。

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a325513036d5fa8d0eefa1b_text.svg)

### 全球出口扩张

350多家孟加拉国IT企业目前向80多个国家出口服务，2022财年出口收入超过5亿美元。主要市场包括美国、英国、芬兰、瑞典、丹麦、澳大利亚、德国、荷兰、新加坡、日本和印度。

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a323f5fec85e3dca2a557e7_682c51d814d4da2279365798_Agro%20Icon-01.svg)

### 政策支持

出口现金补贴、税收假期和专门的高科技园区，为数字企业和外国投资者提供有利的发展环境。

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3a149e76be3e47eb2657d6_20b281a2-5f21-4093-a3f1-9d5e273d345f.jpg)

### 电子产品制造

消费电子产品、数字设备、手机、电脑和技术产品需求增长，正在为本地组装、组件生产和出口导向型制造创造机遇。

### POLICIES & INCENTIVES

-   6% export subsidy for software, ITES, and hardware (Applicable until 31 December 2025; [FEPD Circular No. 28](https://www.bb.org.bd/mediaroom/circulars/fepd/jul102025fepd28.pdf)).

-   Tax Holiday Period: 100% for first 7 years, 70% for 8 to 10 years for business established within Hi-Tech park (Applicable until 30 June 2035; [S.R.O. 245-Law/Income Tax-39/2024](https://nbr.gov.bd/uploads/sros/54914_81934.pdf))
-   0.3% to 2% export subsidy for product and market diversification for companies in high-tech parks. (Applicable until 31 December 2025; [FEPD Circular No. 28](https://www.bb.org.bd/mediaroom/circulars/fepd/jul102025fepd28.pdf)).

-   Exempted Corporate Income Tax (CIT) for first 10 years for manufacturing motherboard, casing, UPS, speaker, sound system, power supply, USB cable, CCTV, pendrive having more than 30% value addition (Applicable until 30 June 2030; [S.R.O. No. 163-Law/Income Tax/2021](https://nbr.gov.bd/uploads/sros/SRO_on-163_ICT_Products.pdf))

-   5% VAT on locally produced and software customization services ([S.R.O. No. 154-Law/VAT/2023](https://nbr.gov.bd/uploads/sros/VATSRO-154.pdf))

-   All income generated from IT Enable (ITES) is tax-exempt, having income received through banking channel (Applicable until 30 June 2027; [As per 6th Schedule of ITA 2023](http://bdlaws.minlaw.gov.bd/upload/act/2025-07-08-10-29-18-%E0%A6%86%E0%A7%9F%E0%A6%95%E0%A6%B0-%E0%A6%86%E0%A6%87%E0%A6%A8,-%E0%A7%A8%E0%A7%A6%E0%A7%A8%E0%A7%A9-\(%E0%A7%A8%E0%A7%A6%E0%A7%A8%E0%A7%A9-%E0%A6%B8%E0%A6%A8%E0%A7%87%E0%A6%B0-%E0%A7%A7%E0%A7%A8-%E0%A6%A8%E0%A6%82-%E0%A6%86%E0%A6%87%E0%A6%A8\).pdf))

#### RELEVANT BODIES

-   Information and Communication Technology (ICT) Division
-   Bangladesh Hi-Tech Park Authority
-   Bangladesh Telecommunication Regulatory Commission (BTRC)
-   Bangladesh Association of Software and Information Services (BASIS)
-   Bangladesh Computer Council (BCC)
-   Bangladesh Association of Call Center & Outsourcing (BACCO)
-   Ecommerce Association of Bangladesh (e-CAB)

## **BIDA Sector Focal**

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a32478a7ceaf9d84ab0abdf_Untitled%20design%20\(4\).png)](#)

Sheikh Rasibul Islam  

Deputy Director

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a324c4edc4295c73da1d547_wechat_red_icon.png)[+8801712595962](#)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[dd.is3@bida.gov.bd](mailto:dd.is3@bida.gov.bd)

Atik Sarker  

Deputy Director

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a324c4edc4295c73da1d547_wechat_red_icon.png)[+8801914594512](#)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[dd.rifiwp@bida.gov.bd](mailto:rabbeefaizur@gmail.com)

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a32478a7ceaf9d84ab0abdf_Untitled%20design%20\(4\).png)](#)

Mahfuzul Islam

Assistant Director

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a324c4edc4295c73da1d547_wechat_red_icon.png)[+8801521407944](#)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.is1@bida.gov.bd](mailto:ad.cl6@bida.gov.bd)

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a32478a7ceaf9d84ab0abdf_Untitled%20design%20\(4\).png)](#)

Faizur Rabbi  

Deputy Director

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a324c4edc4295c73da1d547_wechat_red_icon.png)[+8801711082417](#)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[rabbeefaizur@gmail.com](mailto:rabbeefaizur@gmail.com)

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a32478a7ceaf9d84ab0abdf_Untitled%20design%20\(4\).png)](#)

SM Rafio Morshed

Assistant Director

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a324c4edc4295c73da1d547_wechat_red_icon.png)[+8801671160070](#)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)[ad.ips6@bida.gov.bd](mailto:ad.cl6@bida.gov.bd)