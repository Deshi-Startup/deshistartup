---
source: "Bangladesh Investment Development Authority (BIDA)"
tier: 1
category: "Government / regulator"
url: "https://bida.gov.bd/services"
title: "BIDA | Explore Investment Opportunities in Bangladesh"
scraped_at: "2026-07-02"
---

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/686cf7286136ad1eee6ed377_Layer_1%20\(1\).svg)](/)

[中文](/china)[BIDA OSS](/services#one-stop-services)[

Matchmakin

](https://uat-irms.oss.net.bd/matchmaking)

![bida search icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678cd4d48720bb0edd6ad500_Group%2055.svg)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/68945f6c4818ae3dc291a664_Layer_1.svg)![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![search](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6788a1c48788ea23e00ed88c_Group%2055%20\(1\).webp)

![humbergur](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678896a2d5b4ac64ddac5e2a_Group%2096%20\(3\).webp)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

-   [home](/)

-   [OPPORTUNITIES](/opportunities)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [Services](/services)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [RESOURCES](/resources)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [ABOUT BIDA](/about-bida)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [NOTICE](/notices)

[BIDA OSS](https://www.investbangladesh.gov.bd/services#one-stop-service)[中文](/china)[

MATCHMAKING

](https://uat-irms.oss.net.bd/matchmaking)

# SERVICES THAT BIDA OFFERS

## BIDA SERVICES

[

![Commercial Offices](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67adda965a443b49335894fa_pexels-sliceisop-2529179%201.webp)

### COMMERCIAL OFFICES



](/commercial-offices)[

![Domestic Projects](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67adda9595dd0587fa959d73_pexels-sliceisop-2529179%202.webp)

### DOMESTIC PROJECTS



](/domestic-projects)[

![Foreign & JV Projects](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67adda96fb80533bfb9d7f49_pexels-sliceisop-2529179%203.webp)

### FOREIGN & JV PROJECTS



](/foreign-joint-venture-projects)[

![Aftercare](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67adda936ad1a860af2c9c37_pexels-sliceisop-2529179%204.webp)

### Post-Investment Support



](/aftercare)

## Starting a Business in Bangladesh

![Starting a Business in Bangladesh](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/68540ad8862b0a8e4b4d171e_Group%20393.webp)

## Investor Relationship Management System (IRMS)

Enhancing investor services through interconnected databases, direct communication, digital archiving, electronic monitoring, and a unified databank

[EXPLORE IRMS](#)

COMING SOON

-   Investors profile management
-   Documents Archiving Management
-   Feedback/Queries Management
-   e-Monitoring of Industrial Projects
-   Contact Management System (CMS)
-   Dynamic Reporting module

## country and sector desks in bangladesh

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69fc675a387b2f72a2062b99_Untitled%20design%20\(16\).png)](https://investbangladesh.gov.bd/country-desk)[

Country Desks

](/country-desks)

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69fc62842e224e8cfc041b88_Untitled%20design%20\(9\).png)](https://investbangladesh.gov.bd/sector-desks)[

Sector Desks

](/sector-desks)

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69fc675a387b2f72a2062b99_Untitled%20design%20\(16\).png)](https://investbangladesh.gov.bd/country-desk)[

Country Desks

](/country-desks)

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69fc62842e224e8cfc041b88_Untitled%20design%20\(9\).png)](https://investbangladesh.gov.bd/sector-desks)[

Sector Desks

](/sector-desks)

![BIDA Online One Stop Service Portal](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/683feca7fc0d9eb0783c12cc_Group%20299.svg)

## BIDA ONLINE ONE STOP SERVICE (OSS) PORTAL

ACCESS TIME-BOUND AND TRANSPARENT INVESTOR SERVICES OF DIFFERENT ORGANIZATIONS ALL IN ONE PLACE

[LOG IN](https://bidaquickserv.org/login)[CREATE ACCOUNT](https://osspid.org/user/create)

-   Access e-payment enabled services
-   Submit service request and get time-bound results
-   Track all communication and service request status
-   Back-end approval processes carried out electronically to ensure quality of service
-   Application status monitored through dashboards
-   Real-time user feedback enabled

#### BOOK AN APPOINTMENT

##### SERVICE

New Business Opportunities

Registration & Approvals

Regulatory Facilitation

Visa & Work Permit Support

Aftercare

Policy & Sectoral Guidance

##### REQUESTED DATE

##### REQUESTED TIME

**Thank you!**  
Your appointment request has been submitted.  
If approved, a confirmation email will be sent to you.

Oops! Something went wrong while submitting the form.