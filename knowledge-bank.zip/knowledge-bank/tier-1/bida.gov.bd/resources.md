---
source: "Bangladesh Investment Development Authority (BIDA)"
tier: 1
category: "Government / regulator"
url: "https://bida.gov.bd/resources"
title: "BIDA Resources – Investment Publications & Reports Bangladesh"
scraped_at: "2026-07-02"
---

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/686cf7286136ad1eee6ed377_Layer_1%20\(1\).svg)](/)

[中文](/china)[BIDA OSS](/services#one-stop-services)[

Matchmakin

](https://uat-irms.oss.net.bd/matchmaking)

![bida search icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678cd4d48720bb0edd6ad500_Group%2055.svg)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/68945f6c4818ae3dc291a664_Layer_1.svg)![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![search](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6788a1c48788ea23e00ed88c_Group%2055%20\(1\).webp)

![humbergur](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678896a2d5b4ac64ddac5e2a_Group%2096%20\(3\).webp)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

-   [home](/)

-   [OPPORTUNITIES](/opportunities)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [Services](/services)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [RESOURCES](/resources)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [ABOUT BIDA](/about-bida)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [NOTICE](/notices)

[BIDA OSS](https://www.investbangladesh.gov.bd/services#one-stop-service)[中文](/china)[

MATCHMAKING

](https://uat-irms.oss.net.bd/matchmaking)

# OUR   
RESOURCES

## PUBLICATIONS

[

### INVESTMENT HANDBOOKS

Comprehensive guides to investment opportunities and workforce insights in Bangladesh.



](/publications/investment-handbooks)

[

### SECTOR PROFILES

In-depth analyses of key industries, sustainability initiatives, and market potential.



](/publications/sector-profiles)

[

### Branding, Presentations & Others

Explore curated investment decks and reference materials for investors and partners.



](/publications/branding-presentations-others)

[

### STUDY REPORTS

Research-backed insights on global trade, export destinations, and industry competitiveness.



](/publications/study-reports)

[

### BIDA NEWSLETTERS

Stay informed with updates on policies, incentives, and investment benefits.



](/publications/bida-newsletters)

[

### ANNUAl REPORTS

Key economic trends, investment performance, and market growth analysis.



](/publications/annual-reports)

## PRESS RELEASE

![MIDA, JICA Host Seminar on Investment Potential in Bangladesh’s Fisheries and Marine Economy](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6a4261680203043f5e6b5f44_WhatsApp%20Image%202026-06-29%20at%205.17.05%20PM.jpeg)

Jun 29, 2026

MIDA, JICA Host Seminar on Investment Potential in Bangladesh’s Fisheries and Marine Economy

[

READ MORE

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](/press-release/mida-jica-host-seminar-on-investment-potential-in-bangladeshs-fisheries-and-marine-economy)

![Prime Minister Tarique Rahman Leads BIDA’s ‘Invest Bangladesh’ Seminar in Beijing as Key Bangladesh–China Investment Agreements Are Signed ](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6a3cf06c4126f672bda29f71_WhatsApp%20Image%202026-06-25%20at%203.00.25%20PM.jpeg)

Jun 25, 2026

Prime Minister Tarique Rahman Leads BIDA’s ‘Invest Bangladesh’ Seminar in Beijing as Key Bangladesh–China Investment Agreements Are Signed

[

READ MORE

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](/press-release/prime-minister-tarique-rahman-leads-bidas-invest-bangladesh-seminar-in-beijing-as-key-bangladesh-china-investment-agreements-are-signed)

![Bangladesh Net FDI Inflows Rise 39.36% in 2025](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6a05707cc28cab0827db7da5_Bangladesh%20Net%20FDI%20Rises%2039.36%25%20in%202025%20-%20English.jpg)

May 14, 2026

Bangladesh Net FDI Inflows Rise 39.36% in 2025

[

READ MORE

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](/press-release/bangladesh-net-fdi-inflows-rise-39-36-in-2025)

![BIDA’s Royalty Payment Service Now Fully Digital, Approval Time Falls from Two Months to Seven Days](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69fc65d88167589e9990c627_WhatsApp%20Image%202026-05-07%20at%204.07.47%20PM.jpeg)

May 6, 2026

BIDA’s Royalty Payment Service Now Fully Digital, Approval Time Falls from Two Months to Seven Days

[

READ MORE

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](/press-release/bidas-royalty-payment-service-now-fully-digital-approval-time-falls-from-two-months-to-seven-days)

[MORE PRESS RELEASE](/press-release)

## BIDA EVENTS

![Bangladesh Investment Summit](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/68b31ac789706f211fcff9b2_4th%20STATE%20OF%20INVESTMENT%20CLIMATE%20-%20BANGLADESH.jpg)

UpComing: 27 August 2025

4th STATE OF INVESTMENT CLIMATE - BANGLADESH

[Register here](https://tinyurl.com/bd3798vp)

[

SEE EVENT RECORDING

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://www.youtube.com/watch?v=hpL_QiSXLnk)

![Investment Climate ](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/68aaea5d1a7c61842094014c_Investment%20Climate%20Bangladesh.webp)

Join the 4th State of Investment Climate webinar, featuring Muhammad Fouzul Kabir Khan,  
Hon. Adviser to the ministries of Power, Energy & Mineral Resources, Road Transport & Bridges, and Railways. In this candid fireside chat with Ashik Chowdhury, Executive Chairman of the Bangladesh Investment Development Authority (BIDA), the Adviser will share insights on Bangladesh’s evolving energy strategy, infrastructure upgrades, and logistics reforms—key enablers of the country's investment momentum.  

The Adviser will also take questions from participants.  

![calendar Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/68aaf27fd0b649b2fe53040e_calendar.svg)

27 August 2025  

![Clock Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/68aaf27fbb98b19f06842835_circular-alarm-clock-tool.svg)

4:00 PM BST (GMT+6)

**Register:**

[https://zoom.us/webinar/register/WN\_RScrN21ZT-C0pzP0QUrPvQ](https://zoom.us/webinar/register/WN_RScrN21ZT-C0pzP0QUrPvQ)

**Got a question? Ask here:**

[https://forms.gle/YWVVenTSnU6sPEHYA](https://forms.gle/YWVVenTSnU6sPEHYA)

![Close Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/68aaf82ed0b649b2fe53cee3_cancel.svg)

![Bangladesh Investment Summit](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67c54151975a193baae29db4_Testimonial-01%20\(19\).webp)

07 - 10 April 2025  |  Dhaka

BANGLADESH INVESTMENT SUMMIT 2025

[

FIND OUT MORE

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](/bangladesh-investment-summit-2025)

![China Bangladesh conference on investment and trade](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6857b2d884ecb97b86ac6d76_Testimonial-01%20-%202025-06-22T133751.291.webp)

01 JUNE 2025  |  Dhaka

CHINA-BANGLADESH CONFERENCE ON INVESTMENT & TRADE

[

FIND OUT MORE

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](/a-new-milestone-in-china-bangladesh-economic-partnership)

![Investment Climate Bangladesh](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/68b31e0434824293b0cc3301_3RD%20State%20of%20Investment%20Climate%20-%20Bangladesh.jpg)

06 MAY 2025

3RD State of Investment Climate - Bangladesh

[

SEE EVENT RECORDING

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://www.youtube.com/watch?v=1L8UVXTbPfY)

![Investment Climate Bangladesh](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/68b31e8dbe6ce066ad2cd5a7_2nd%20State%20of%20Investment%20Climate%20-%20Bangladesh.jpg)

 02 December 2024

2nd State of Investment Climate - Bangladesh

[

SEE EVENT RECORDING

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://www.youtube.com/watch?v=DgE1meXZGM0)

![Investment Climate Bangladesh](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/68b31efbbe6ce066ad2ce1af_1ST%20STATE%20OF%20INVESTMENT%20CLIMATE%20-%C2%A0BANGLADESH.jpg)

 30 October 2024

1ST STATE OF INVESTMENT CLIMATE - BANGLADESH

[

SEE EVENT RECORDING

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://www.youtube.com/watch?v=ZlW_hbXu0Kc)

## Key Investor Contacts

Designated focal points across key ministries, departments, and agencies for investor facilitation. Officials marked with (\*) are colocated at the BIDA Head Office in Dhaka.

Institution Name

Name & Designation

Mobile Number

Email

Office of the Registrar of Joint Stock Companies and Firms

Muhammed Shafiqul Islam

Deputy Registrar

+8801712194960

deputy-registrar7@roc.gov.bd

Department of Environment

Md. Shamsuzzaman Sarkar

Deputy Director (EIA)

+8801716861848

zaman320@gmail.com

Dhaka Chamber of Commerce & Industry

Dr. A. K.M. Asaduzzaman Patowary

Acting Secretary General

0247122986,

+8801622731900

asaduzzaman@dhakachamber.com

Bangladesh Rural Electrification Board

Md. Shahidul Islam

Additional Chief Engineer (Operation, Maintenance & Distribution)

+8801918863274

acepndreb@gmail.com

West Zone Power Distribution Company Ltd.

Md. Mosarraf Hossen

Executive Engineer (System Analyst)

+8801700709716

xen.ict@wzpdce.gov.bd

Department of Fire Service and Civil Defence

Md. Ali Azam

Assistant Director

+8801717116787

maliazam.fscd@gmail.com

Directorate of Registration

Md. Mahfuzur Rahman Khan

Inspector of Registry Offices (IRO) (Khulna Division)

+8801715091155

mahfuzsr68@gmail.com

Dhaka WASA

Md. Iyar Khan

Executive Engineer

+8801670505379

engr.ykhan@gmail.com

Jalalabad Gas Transmission & Distribution System Ltd.

Biplob Kumar Bishwas

Deputy General Manager

+8801715575395

dgmplanning@gtdsl.gov.bd

Department of Immigration & Passports

Bilkis Afroza Siddika

Deputy Director

+8801733393309

ddvisa@passport.gov.bd

Metropolitan Chamber of Commerce & Industry

Asif Ayub

Joint Secretary General MCCI

+8801875218405

aayub.bd@gmail.com

Bangladesh Bank

1\. Md. Hasan Shahriar; Additional Director

2\. (\*) A. T. M. Ahasan Habib; Joint Director

3\. (\*) Md. Zonaid Siam; Deputy Director

+8801911064664

+8801718174343

+8801743120092

hasan.shahriar@bb.org.bd,

ahasan.habib@bb.org.bd,

zonaid.siam@bb.org.bd

Sundarban Gas Company Ltd., Khulna

Manik Uddin

Assistant Engineer (ICT)

+8801949527839

manik.uddin@sgcl.org.bd

Sonali Bank Ltd.

Md. Aminur Rahman Khan

Deputy General Manager (Govt. Accounts and Services Division) (Head Office)

+8801324417059

dgmgasd@sonalibank.com.bd

Dhaka North City Corporation

Md. Monowar Hossain

Revenue Officer (Municipal Tax)

+8801715446850

ro.tax@dncc.gov.bd

Dhaka South City Corporation

Md. Abu Tayeb Rokon

System Analyst IT Cell

+8801711781847

sa@dscc.gov.bd

Rajdhani Unnayan Kartripakkha (RAJUK)

Md. Aminur Rahman

Senior System Analyst

+8801730013926

ssa@rajukdhaka.gov.bd

Karnaphuli Gas Distribution Company Ltd.

Engr. Hasan Sohrab

Deputy General Manager/ Senior System Analyst IT Department

+8801766675209

hsohrab806@gmail.com

Export Promotion Bureau

Aninda Das

Assistant Director (Policy Planning)

+8801796662004

anindaepb@gmail.com

Office of the Chief Controller of Imports & Exports

1\. Rifat Hasan; Deputy Controller

2\. Milton Mistry; Executive Officer

+8801016139263

+8801918846727

rifattamal@gmail.com,

miltonmistry81@gmail.com

Dhaka Electric Supply Company Limited (DESCO)

1\. Md. Raihan Arefin; Executive Engineer

2\. Purnata Roy; Sub-Divisional Engineer (Electrical Works)

+8801713090600

+8801730794805

rarafin@desco.gov.bd,

purnata@desco.gov.bd

National Board of Revenue (NBR)

(\*) Md. Sanuwarul Kabir

Joint Commissioner (Customs Risk Management Commissionerate)

+8801790216519

\-

[VIEW ALL CONTACTS](#)

## Key Investor Contacts

Designated focal points across key ministries, departments, and agencies for investor facilitation. Officials marked with (\*) are colocated at the BIDA Head Office in Dhaka.

**INSTITUTION**

**Name**

**Contacts**

Office of the Registrar of Joint Stock Companies and Firms

Muhammed Shafiqul Islam  
Deputy Registrar

[+8801712194960](tel:+8801712194960)[deputy-registrar7@  
roc.gov.bd](mailto:deputy-registrar7@roc.gov.bd)

Department of Environment

Md. Shamsuzzaman Sarkar  
Deputy Director (EIA)

[+8801716861848](tel:+8801716861848)[zaman320@  
gmail.com](mailto:zaman320@gmail.com)

Dhaka Chamber of Commerce & Industry

Dr. A. K.M. Asaduzzaman Patowary  
Acting Secretary General

[+8801622731900](tel:+8801622731900)[asaduzzaman@  
dhakachamber  
.com](<mailto:asaduzzaman@ dhakachamber .com>)

Bangladesh Rural Electrification Board

Md. Shahidul Islam  
Additional Chief Engineer (Operation, Maintenance & Distribution)

[+8801918863274](tel:+8801918863274)[acepndreb@  
gmail.com](mailto:acepndreb@gmail.com)

West Zone Power Distribution Company Ltd.

Md. Mosarraf Hossen  
Executive Engineer (System Analyst)

[+8801700709716](tel:+8801700709716)[xen.ict@  
wzpdce.gov.bd](mailto:xen.ict@wzpdce.gov.bd)

Department of Fire Service and Civil Defence

Md. Ali Azam  
Assistant Director

[+8801717116787](tel:+8801717116787)[maliazam.fscd  
@gmail.com](mailto:maliazam.fscd@gmail.com)

Directorate of Registration

Md. Mahfuzur Rahman Khan  
Inspector of Registry Offices (IRO) (Khulna Division)

[+8801715091155](tel:+8801715091155)[mahfuzsr68@  
gmail.com](mailto:mahfuzsr68@gmail.com)

Dhaka WASA

Md. Iyar Khan  
Executive Engineer

[+8801670505379](tel:+8801670505379)[engr.ykhan@  
gmail.com](mailto:engr.ykhan@gmail.com)

Jalalabad Gas Transmission & Distribution System Ltd.

Biplob Kumar Bishwas  
Deputy General Manager

[+8801715575395](tel:+8801715575395)[dgmplanning@  
gtdsl.gov.bd](mailto:dgmplanning@gtdsl.gov.bd)

Department of Immigration & Passports

Bilkis Afroza Siddika  
Deputy Director

[+8801733393309](tel:+8801715575395)[ddvisa@  
passport.gov.bd](mailto:dgmplanning@gtdsl.gov.bd)

Metropolitan Chamber of Commerce & Industry

Asif Ayub  
Joint Secretary General MCCI

[+8801875218405](tel:+8801875218405)[aayub.bd@  
gmail.com](mailto:aayub.bd@gmail.com)

Bangladesh Bank

1\. Md. Hasan Shahriar; Additional Director  
2\. (\*) A. T. M. Ahasan Habib; Joint Director  
3\. (\*) Md. Zonaid Siam; Deputy Director

[+8801911064664](tel:+8801911064664)[+8801718174343](tel:+8801718174343)[+8801743120092](tel:+8801743120092)[hasan.shahriar  
@bb.org.bd,](mailto:hasan.shahriar@bb.org.bd,)[ahasan.habib  
@bb.org.bd,](mailto:ahasan.habib@bb.org.bd,)[zonaid.siam  
@bb.org.bd](mailto:zonaid.siam@bb.org.bd)

Sundarban Gas Company Ltd., Khulna

Manik Uddin  
Assistant Engineer (ICT)

[+8801949527839](tel:+8801949527839)[manik.uddin  
@sgcl.org.bd](mailto:manik.uddin@sgcl.org.bd)

Sonali Bank Ltd.

Md. Aminur Rahman Khan  
Deputy General Manager (Govt. Accounts and Services Division) (Head Office)

[+8801324417059](tel:+8801324417059)[dgmgasd@  
sonalibank.  
com.bd](mailto:dgmgasd@sonalibank.com.bd)

Dhaka North City Corporation

Md. Monowar Hossain  
Revenue Officer (Municipal Tax)

[+8801715446850](tel:+8801715446850)[ro.tax@  
dncc.gov.bd](mailto:ro.tax@dncc.gov.bd)

Dhaka South City Corporation

Md. Abu Tayeb Rokon  
System Analyst IT Cell

[+8801711781847](tel:+8801711781847)[sa@dscc.gov  
.bd](mailto:sa@dscc.gov.bd)

Rajdhani Unnayan Kartripakkha (RAJUK)

Md. Aminur Rahman  
Senior System Analyst

[+8801730013926](tel:+8801730013926)[ssa@  
rajukdhaka  
.gov.bd](mailto:ssa@rajukdhaka.gov.bd)

Karnaphuli Gas Distribution Company Ltd

Engr. Hasan Sohrab  
Deputy General Manager/ Senior System Analyst IT Department

[+8801766675209](tel:+8801766675209)[hsohrab806@  
gmail.com](mailto:ssa@rajukdhaka.gov.bd)

Export Promotion Bureau

Aninda Das  
Assistant Director (Policy Planning)

[+8801796662004](tel:+8801796662004)[anindaepb@  
gmail.com](mailto:anindaepb@gmail.com)

Office of the Chief Controller of Imports & Exports

1\. Rifat Hasan; Deputy Controller  
2\. Milton Mistry; Executive Officer

[+8801016139263](tel:+8801016139263)[+8801918846727](tel:+8801918846727)[rifattamal@  
gmail.com,](mailto:rifattamal@gmail.com)[miltonmistry81  
@gmail.com](mailto:miltonmistry81@gmail.com)

Dhaka Electric Supply Company Limited (DESCO)

1\. Md. Raihan Arefin; Executive Engineer  
2\. Purnata Roy; Sub-Divisional Engineer (Electrical Works)

[+8801713090600](tel:+8801713090600)[+8801730794805](tel:+8801730794805)[rarafin@  
desco.gov.bd,](mailto:rarafin@desco.gov.bd,)[purnata@  
desco.gov.bd](mailto:purnata@desco.gov.bd)

National Board of Revenue (NBR)

Md. Sanuwarul Kabir  
Joint Commissioner (Customs Risk  
Management Commissi-  
onerate)

[+8801790216519](tel:+8801790216519)

[VIEW ALL CONTACTS](#)

## TREATIES

Double Taxation Treaties

Bilateral Investment Treaties

Treaties with  
Investment Provisions

Investment Related Instruments

A Double Taxation Treaty (DTT) is a bilateral agreement between two countries that aims to prevent the same income from being taxed twice by allocating taxing rights and providing relief through exemptions or tax credits. It promotes cross-border trade and investment and includes provisions to prevent tax evasion and resolve disputes. Till date Bangladesh has signed DTTs with 40 countries.

-   Nepal
-   Kuwait
-   Bhutan
-   China
-   Canada
-   Vietnam
-   UK
-   USA
-   UAE
-   Turkey
-   Thailand
-   Switzerland
-   Oman
-   Czech Republic

-   Sweden
-   Sri Lanka
-   Republic of Korea
-   Singapore
-   Romania
-   Poland
-   Philippines
-   Pakistan
-   Norway
-   Netherlands
-   Myanmar
-   Mauritius
-   Morocco

-   Malaysia
-   Saudi Arabia
-   Japan
-   Italy
-   Germany
-   France
-   Denmark
-   Belgium
-   Belarus
-   Bahrain
-   Indonesia
-   India
-   Maldives

Bilateral Investment Treaties, or BITs, offer a set of guarantees to investors of either contracting party, including fair and equitable treatment, protection from expropriation, free transfer of funds, and full protection and security. So far, Bangladesh has signed BITs with 33 countries.

PARTIES

SIGNED

RATIFIED

United Kingdom

1980

1980

Germany

1981

1986

BLEU (Belgium-Luxembourg Economic Union)

1981

1987

France

1981

1987

United States of America

1986

1989

Korea (Republic of)

1986

1988

Romania

1987

1987

Turkey

2012

\-

Italy

1990

1994

Canada

1990

1990

Netherlands

1994

1995

Malaysia

1994

2003

Pakistan

1995

1997

China

1996

1997

Poland

1997

1999

Philippines

1997

1998

Indonesia

1998

1998

Japan

1998

1999

Korea (Democratic People’s Republic of)

1999

\-

Uzbekistan

2000

2001

Switzerland

2000

2001

Austria

2000

2001

Iran

2001

2001

Thailand

2002

2002

Singapore

2004

\-

Viet Nam

2005

2006

India

2009

2011

Denmark

2009

\-

United Arab Emirates

2011

2022

Belarus

2012

\-

Cambodia

2014

\-

Bahrain

2015

2016

Kuwait

2016

\-

Title

PARTIES

Signing year 

Year of entry into force

Asia-Pacific Trade Agreement (APTA)

China, Republic of Korea, Lao People's Democratic Republic, Sri Lanka

2009

\-

The South Asian Free Trade Area (SAFTA)

Afghanistan, Bangladesh, Bhutan, India, Maldives, Nepal, Pakistan and Sri Lanka

2004

2001

Bangladesh-EC Cooperation Agreement

European Union

2000

2006

OIC Investment Agreement

OIC member states

1981

1988

Bangladesh has signed 20 Investment Related Instruments including intergovernmental agreements, guidelines and principles both regional and multilateral.

Title

Year of adoption

Level

Type 

Trade-Related Aspects of Intellectual Property Rights (TRIPS)

1994

Multilateral

Intergovernmental agreements

Agreement on Trade-Related Investment Measures (TRIMS)

1994

Multilateral

Intergovernmental agreements

Islamic Corporation for the Insurance of Investment Credit

1992

Multilateral

Intergovernmental agreements

Multilateral Investment Guarantee Agency (MIGA) Convention

1985

Multilateral

Intergovernmental agreements

New York Convention

1958

Multilateral

Intergovernmental agreements

International Centre for Settlement of Investment Disputes (ICSID) Convention

1965

Multilateral

Intergovernmental agreements

Fifth Protocol to General Agreement on Trade in Services (GATS)

1997

Multilateral

Intergovernmental agreements

Fourth Protocol to GATS

1997

Multilateral

Intergovernmental agreements

GATS

1994

Multilateral

Intergovernmental agreements

UN Code of Conduct on Transnational Corporations

1983

Multilateral

Intergovernmental agreements

Doha Declaration

2001

Multilateral

Intergovernmental agreements

World Bank Investment Guidelines

1992

Multilateral

Intergovernmental agreements

International Labor Organization (ILO) Tripartite Declaration on Multinational Enterprises

2000

Multilateral

Intergovernmental agreements

ILO Tripartite Declaration on Multinational Enterprises

2006

Multilateral

Intergovernmental agreements

ILO Tripartite Declaration on Multinational Enterprises

1977

Multilateral

Intergovernmental agreements

Singapore Ministerial Declaration

1996

Multilateral

Intergovernmental agreements

UN Guiding Principles on Business and Human Rights

2011

Multilateral

Intergovernmental agreements

Permanent Sovereignty UN Resolution

1962

Multilateral

Intergovernmental agreements

New International Economic Order UN Resolution

1974

Multilateral

Intergovernmental agreements

Charter of Economic Rights and Duties of States

1974

Multilateral

Intergovernmental agreements

## ACTS & GUIDELINES

-   [Circular-Guidelines for Outward Remittance Repatriation for Payment of Royalty, Technical Knowledge/Technical Know-how Fee(s), Technical Assistance Fee(s) and Franchise Fee(s)-2020](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/686b8678920b2080ffad1d40_Circular-Guidelines%20for%20Outward%20Remittance%20Repatriation%20for%20Payment%20of%20Royalty%2C%20Techn.pdf)
-   [English Version-Guidelines for Outward Remittance Repatriation for Payment of Royalty, Technical Knowledge/Technical Know-how Fee(s), Technical Assistance Fee(s) and Franchise Fee(s)-2020](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/686b87ba5184c0729d88c8f6_2.%20English%20Version-Guidelines%20for%20Outward%20Remittance%20Repatriation%20for%20Payment%20of%20Royalty.pdf)
-   [Guidelines for providing permission for establishment of foreign commercial offices, providing visa recommendations to foreign workers and issuing work permits to foreign workers in Bangladesh-2023](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/686b8aed77532e8da9cd415f_3.%20Guidelines%20for%20providing%20permission%20for%20establishment%20of%20foreign%20commercial%20offices%2C%20.pdf)
-   [English Version-Guidelines for providing permission for establishment of foreign commercial offices, providing visa recommendations to foreign workers and issuing work permits to foreign workers in Bangladesh-2023](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69fc5a15ff0dc3be009e1c29_Guidelines%20for%20providing%20permission%20for%20establishment.pdf)
-   [Bangladesh Investment Development Authority Act, 2016](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/686b880fd3ab3045b2929a78_4.%20Bangladesh%20Investment%20Development%20Authority%20Act%2C%202016.pdf)
-   [One Stop Service Act 2018](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/686b880e77532e8da9ca54e8_5.%20One%20Stop%20Service%20Act%202018.pdf)
-   [One Stop Service Rules 2020](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/686b89ca17d329bcec9ffeba_6.%20One%20Stop%20Service%20Rules%202020%20\(1\).pdf)
-   [Foreign Private Investment (Promotion and Protection) Act 1980](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/686b8a333072215d94a962ea_7.%20Foreign%20Private%20Investment%20\(Promotion%20%26%20Protection\)%20Act%201980.pdf)

## GALLERY

## Bangladesh Investment Summit 2025

![Hon'ble Chief Adviser Professor Muhammad Yunus speaks](https://cdn.prod.website-files.com/6820331d027084bef793fadb/685cbeca27cef1c65657f76b_image%20\(43\)%20\(1\).png)

Hon'ble Chief Adviser Professor Muhammad Yunus speaks at the inauguration of the Bangladesh Investment Summit 2025 at the InterContinental Dhaka on April 9, 2025, inviting more global investment.

![The Rt. Hon. the Baroness Rosie Winterton, UK Trade Envoy to Bangladesh](https://cdn.prod.website-files.com/6820331d027084bef793fadb/685cbf23d087eb433fa4d8c8_image%20\(44\)%20\(1\).png)

The Rt. Hon. the Baroness Rosie Winterton, UK Trade Envoy to Bangladesh, speaks at the inauguration of the Bangladesh Investment Summit 2025 at the InterContinental Dhaka on April 9, 2025.

![Óscar García Maceiras, CEO of Inditex, speaks](https://cdn.prod.website-files.com/6820331d027084bef793fadb/685cbf81dafac4ea641126cb_image%20\(45\)%20\(1\).png)

Óscar García Maceiras, CEO of Inditex, speaks at the inauguration of the Bangladesh Investment Summit 2025 at the InterContinental Dhaka on April 9, 2025.

[

Next

](?b00283a2_page=2)

## China-Bangladesh Conference on Investment and Trade

![Hon’ble Chief Adviser Professor Muhammad Yunus speaks](https://cdn.prod.website-files.com/6820331d027084bef793fadb/685cc4174197073f63f96484_image%20\(57\)%20\(1\).png)

Hon’ble Chief Adviser Professor Muhammad Yunus speaks at the inauguration of the China-Bangladesh Conference on Investment and Trade in Dhaka on June 1, 2025, urging Chinese investors to explore opportunities in Bangladesh.

![H.E. Wang Wentao, China’s Minister of Commerce](https://cdn.prod.website-files.com/6820331d027084bef793fadb/685cc445be8acdbc202088ad_image%20\(58\)%20\(1\).png)

H.E. Wang Wentao, China’s Minister of Commerce, delivers a keynote speech at the China-Bangladesh Conference on Investment & Trade in Dhaka on June 1, 2025, highlighting growing economic ties.

![Investors from Bangladesh and China engage in a B2B session](https://cdn.prod.website-files.com/6820331d027084bef793fadb/685cc483e9ad5c75e137a426_image%20\(59\)%20\(1\).png)

Investors from Bangladesh and China engage in a B2B session at the China-Bangladesh Conference on Investment and Trade at BIDA office in Dhaka on June 1, 2025, fostering collaboration and economic growth.

[

Next

](?00b24de1_page=2)

[VIEW FULL GALLERY](/bida-gallery)

#### BOOK AN APPOINTMENT

##### SERVICE

New Business Opportunities

Registration & Approvals

Regulatory Facilitation

Visa & Work Permit Support

Aftercare

Policy & Sectoral Guidance

##### REQUESTED DATE

##### REQUESTED TIME

**Thank you!**  
Your appointment request has been submitted.  
If approved, a confirmation email will be sent to you.

Oops! Something went wrong while submitting the form.