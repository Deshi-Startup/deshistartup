---
source: "Bangladesh Investment Development Authority (BIDA)"
tier: 1
category: "Government / regulator"
url: "https://bida.gov.bd/publications/investment-handbooks"
title: "INVESTMENT HANDBOOKS"
scraped_at: "2026-07-02"
---

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/686cf7286136ad1eee6ed377_Layer_1%20\(1\).svg)](/)

[中文](/china)[BIDA OSS](/services#one-stop-services)[

Matchmakin

](https://uat-irms.oss.net.bd/matchmaking)

![bida search icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678cd4d48720bb0edd6ad500_Group%2055.svg)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/68945f6c4818ae3dc291a664_Layer_1.svg)![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![search](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6788a1c48788ea23e00ed88c_Group%2055%20\(1\).webp)

![humbergur](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678896a2d5b4ac64ddac5e2a_Group%2096%20\(3\).webp)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

-   [home](/)

-   [OPPORTUNITIES](/opportunities)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [Services](/services)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [RESOURCES](/resources)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [ABOUT BIDA](/about-bida)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [NOTICE](/notices)

[BIDA OSS](https://www.investbangladesh.gov.bd/services#one-stop-service)[中文](/china)[

MATCHMAKING

](https://uat-irms.oss.net.bd/matchmaking)

# INVESTMENT HANDBOOKS

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6874b2fd6b685abc62885218_BIDA-_-Tri-Fold-Brochure-_-13-07-25-Final-07-14-2025_01_33_PM.png)

## BIDA Brochure

10 July 2025

[

DOWNLOAD

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68bd37809cdf82cd18ad8abe_BIDA%20_%20Tri%20Fold%20Brochure%20_%2013-07-25%20Final.pdf)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6874b357f813f125524ebf3e_BIDA-_-Tri-Fold-Brochure-_-Chinese-Version-_-13-07-25-07-14-2025_01_35_PM.png)

## BIDA Brochure (Chinese Version)

10 July 2025

[

DOWNLOAD

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68bd36fb3dc64abacd7f5c80_BIDA%20_%20Tri%20Fold%20Brochure%20_%20Chinese%20Version%20_%2013-07-25.pdf)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68eded96a38abd530576f9c2_2025-10-14%20.png)

## BIDA Brochure (Korean Version)

10 July 2025

[

DOWNLOAD

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/68ee032d3d514f93faf6c0f3_BIDA%20_%20Tri%20Fold%20Brochure%20_%2013-07-25%20Final%20without%20_251014_120135.pdf)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/685a7289bda3fdb072635021_image%20\(37\).png)

## INVESTOR STARTER KIT

26 June 2025

[

DOWNLOAD

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68bd3eb8a7c0f75e9d544790_Investor%20Starter%20Kit.pdf)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6853c175521e4377217a4a42_Newsletter-Cover-02%20\(2\)%20\(1\).png)

## INVEST GUIDE FOR BANGLADESH

FEBRUARY 2023

[

DOWNLOAD

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68bd41d921e9c1f8a0d5d681_Investment%20Guide%20for%20Bangladesh-compressed-compressed_11zon%20\(1\).pdf)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6853c14d9912777913eaaf98_Handbook-Cover-01%20\(1\)%20\(1\).png)

## FOREIGN INVESTMENT IN BANGLADESH

7 APRIL 2025 | ISSUE 3

[

DOWNLOAD

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68bd41fb1b6b206314f641b0_Foreign-Investment-in-Bangladesh-Booklet%20\(1\).pdf)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/685a7248c5ade811aba04f4b_image%20\(36\).webp)

## INCENTIVES FOR ECONOMIC ZONES

26 June 2025

[

DOWNLOAD

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68bd3ed99c8527d4dfc7ebe4_Incentives%20for%20Economic%20Zones.pdf)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/699e778221dd2fc7c13a02f4_Key%20Information%20on%20Licensing%20Requirements.png)

## Key Information on Licensing Requirements (post BanglaBiz launch)

25 February 2026

[

DOWNLOAD

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/699d56f75f2d925ccf359d1e_Key%20Information%20on%20Licensing%20Requirements%20\(Post-BanglaBiz\).pdf)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/686b823c12848a1ede8278bc_Exit%20Options%20for%20foreign%20investors.png)

## Exit Options for foreign investors

26 June 2025

[

DOWNLOAD

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68bd3f440df74d5bdf163e67_Exit%20Options%20For%20Foreign%20Investors.pdf)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69ae98261766028024de26a9_Screenshot_1.png)

## Repatriation - Comparison of 2018 and 2020 Circulars with the 2026 Master Circular-1

09 March 2026

[

DOWNLOAD

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ae97bf8fa99baa742b9eaa_Repatriation%20-%20Comparison%20of%202018%20and%202020%20Circulars%20with%20the%202026%20Master%20Circular-1.pdf)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6a293836442339f89859e767_Setting%20Up%20a%20Foreign%20Office%2C%20Hiring%20Foreign%20Workers.png)

## Setting Up a Foreign Office, Hiring Foreign Workers & Repatriating Payments in Bangladesh

10 June 2026

[

DOWNLOAD

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a29397b9bbe69f0abfd9cb7_Setting%20Up%20a%20Foreign%20Office%2C%20Hiring%20Foreign%20Workers%20%26%20Repatriating%20Payments%20in%20Bangladesh.pdf)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6a38cb6f8f34bc16ff7e2cb0_Screenshot_1.png)

## BIDA Brochure (Chinese Version)

22 June 2026

[

DOWNLOAD

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a38cbecda8cdfb73e55422e_Chinese%20version%20brochure%20trifold%20for%20web_.pdf)

## Annual Reports

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69491a90ba889049414e57b4_Screenshot%202025-12-22%20161636.png)

21 Decemer 2025

BIDA Annual Report 2023-24 & 2024-25

[Read More >](https://drive.google.com/file/d/1f5DRUIzvVpsAQMoGrgUNi55at4e6fgxe/view?usp=sharing)

#### BOOK AN APPOINTMENT

##### SERVICE

New Business Opportunities

Registration & Approvals

Regulatory Facilitation

Visa & Work Permit Support

Aftercare

Policy & Sectoral Guidance

##### REQUESTED DATE

##### REQUESTED TIME

**Thank you!**  
Your appointment request has been submitted.  
If approved, a confirmation email will be sent to you.

Oops! Something went wrong while submitting the form.