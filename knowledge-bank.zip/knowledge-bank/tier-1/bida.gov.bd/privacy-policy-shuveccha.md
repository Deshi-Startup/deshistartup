---
source: "Bangladesh Investment Development Authority (BIDA)"
tier: 1
category: "Government / regulator"
url: "https://bida.gov.bd/privacy-policy-shuveccha"
title: "Privacy Policy of Shuveccha"
scraped_at: "2026-07-02"
---

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/686cf7286136ad1eee6ed377_Layer_1%20\(1\).svg)](/)

[中文](/china)[BIDA OSS](/services#one-stop-services)[

Matchmakin

](https://uat-irms.oss.net.bd/matchmaking)

![bida search icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678cd4d48720bb0edd6ad500_Group%2055.svg)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/68945f6c4818ae3dc291a664_Layer_1.svg)![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![search](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6788a1c48788ea23e00ed88c_Group%2055%20\(1\).webp)

![humbergur](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678896a2d5b4ac64ddac5e2a_Group%2096%20\(3\).webp)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

-   [home](/)

-   [OPPORTUNITIES](/opportunities)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [Services](/services)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [RESOURCES](/resources)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [ABOUT BIDA](/about-bida)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [NOTICE](/notices)

[BIDA OSS](https://www.investbangladesh.gov.bd/services#one-stop-service)[中文](/china)[

MATCHMAKING

](https://uat-irms.oss.net.bd/matchmaking)

# Privacy Policy of Shuveccha / শুভেচ্ছা

Shuveccha / শুভেচ্ছা

Shuveccha / শুভেচ্ছা is an internet-based application designed especially for Non-Resident Bangladeshis (NRBs) — overseas citizens of the People's Republic of Bangladesh. The App offers secure access to services, communication supported, managed and governed by the Bangladesh Investment Development Authority (BIDA).  
‍

The App is designed exclusively for NRBs and not accessible for Resident Bangladeshi nationals.

‍

1\. Information We Collect

The app collects data strictly necessary to provide its services, ensure user safety, and optimize operational performance. The type of data collected includes:

-   Authentication and Profile Data

-   User ID and Password: For secure login with two-factor authentication.
-   Profile Data: Name, National ID/Passport Number, telephone and email contact addresses, resident country, and other details provided during registration to facilitate services and verify as an NRB.

-   Service and Communication Data  
    -   Service Requests: Metadata related to sent-in service requests, questions, and transactions (request type, timestamps, status changes).
    -   Interaction Data: Metadata on interactions being performed over the App (sender/receiver ID, timestamp). Interaction data, if stored, is encrypted and held on BIDA servers.
    -   Support Interaction: Records of helpdesk data or support queries for quality control and troubleshooting purposes.
-   Location Data  
    -   Optional Location Tracking: Location data can be utilized when turned on by the user, e.g., for the purpose of authenticating eligibility for service or to provide location-based assistance. This is maintained only periodically to enable specific services.

-   Device Information  
    -   Device ID and Operating System: To ensure compatibility, security, and notification delivery.
    -   Network Information: For enhanced connectivity and resolving technical issues.

‍

-   Usage Data  
    -   App Use Data: Data on features utilized, usage frequency, and performance data are used for service optimization. These data are anonymized and aggregated where possible.

‍

2\. How We Use Information:

Information collected by the application is used for the following purposes:

-   To enable secure services: Allow access to BIDA and NRB-related services like applications, support, and communication.
-   To authenticate and secure: Verify an individual as an NRB and protect the integrity of the platform.
-   To improve service efficiency: Enhance usage habits and performance statistics to improve service provision.
-   To facilitate NRB support: Ensure appropriate coordination with related agencies to fulfill NRB needs.
-   To comply with regulatory needs: Fulfill requirements as mandated by BIDA and applicable laws of Bangladesh.

‍

3\. Data Storage and Protection:

-   Encryption: Data in transit and stored data are encrypted.
-   Secure Servers:Secure Servers:Secure Servers:Secure Servers: Secure Servers:Data are maintained on secure servers owned by or under the control of BIDA in approved data centers within Bangladesh.
-   Access Control: Access is limited to authorized BIDA personnel or designated authorities with a legitimate need, on a role-based and permissioned basis.
-   Two-Factor Authentication: Login access can be secured with two-factor authentication means.
-   Security Audits: Regular audits and assessments are conducted to prevent unauthorized access.  
    ‍

4\. Data Sharing and Disclosure

-   No Commercial Third-Party Sharing:No Commercial Third-Party Sharing:No Commercial Third-Party Sharing:No Commercial Third-Party Sharing: No Commercial Third-Party Sharing: Shuveccha / শুভেচ্ছা does not share personal data with external third parties for commercial or marketing reasons.
-   Internal Sharing (BIDA and Government Authorities): Data may be shared within BIDA and other concerned government departments strictly on a need-to-know basis for service facilitation, compliance with the law, or enforcement of policy.
-   Legal Compliance: Data can be disclosed if required by Bangladeshi law or legitimate legal processes.  
    ‍

5\. Data Retention and Deletion

-   Retention: Data will be retained as long as necessary to fulfill service demands, comply with legal demands, and preserve the integrity of the application system. Retention durations are determined by BIDA policies.
-   Deletion: Deletion of an account or data can be submitted by users through official application support interfaces. These requests shall be processed in accordance with the policies of BIDA and applicable legislation.  
    ‍

6\. User Rights

Considering the distinctive purpose of Shuveccha / শুভেচ্ছা application as an online platform for Non-Resident Bangladeshis, user rights regarding access, correction, or removal of personal information are regulated by the governing laws and existing policies. These matters are not directly handled through the App. For requests or complaints regarding data, users are requested to use the official support channels included in the App and follow proper procedures.  
‍

7\. Changes to This Privacy Policy

We may update this Privacy Policy from time to time to reflect changes in our practices or due to operational, legal, or regulatory requirements. Updates will be communicated through the App and/or BIDA’s official channels. Continued use of the App after modifications constitutes acknowledgment of the updated policy.  
‍

8\. Contact Information

For any questions or concerns regarding this Privacy Policy or the Shuveccha / শুভেচ্ছা App, please contact the designated IT or administrative department of Bangladesh Investment Development Authority (BIDA) through your official internal communication channels.

#### BOOK AN APPOINTMENT

##### SERVICE

New Business Opportunities

Registration & Approvals

Regulatory Facilitation

Visa & Work Permit Support

Aftercare

Policy & Sectoral Guidance

##### REQUESTED DATE

##### REQUESTED TIME

**Thank you!**  
Your appointment request has been submitted.  
If approved, a confirmation email will be sent to you.

Oops! Something went wrong while submitting the form.