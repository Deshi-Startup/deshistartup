---
source: "Bangladesh Investment Development Authority (BIDA)"
tier: 1
category: "Government / regulator"
url: "https://bida.gov.bd/investment-sector/renewable-energy"
title: "Renewable Energy"
scraped_at: "2026-07-02"
---

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/686cf7286136ad1eee6ed377_Layer_1%20\(1\).svg)](/)

[中文](/china)[BIDA OSS](/services#one-stop-services)[

Matchmakin

](https://uat-irms.oss.net.bd/matchmaking)

![bida search icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678cd4d48720bb0edd6ad500_Group%2055.svg)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/68945f6c4818ae3dc291a664_Layer_1.svg)![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![search](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6788a1c48788ea23e00ed88c_Group%2055%20\(1\).webp)

![humbergur](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678896a2d5b4ac64ddac5e2a_Group%2096%20\(3\).webp)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

-   [home](/)

-   [OPPORTUNITIES](/opportunities)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [Services](/services)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [RESOURCES](/resources)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [ABOUT BIDA](/about-bida)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [NOTICE](/notices)

[BIDA OSS](https://www.investbangladesh.gov.bd/services#one-stop-service)[中文](/china)[

MATCHMAKING

](https://uat-irms.oss.net.bd/matchmaking)

# Renewable Energy

Accelerating Energy Delivery for a Growing Economy

![Renewable Energy](https://cdn.prod.website-files.com/6820331d027084bef793fadb/683405f8130e81870baf8d24_Mask%20group%20\(39\).webp)

6M+

solar home systems installed

7%

annual power demand growth

20%

renewables target by 2030

10

year tax holiday for clean energy projects

## OVERVIEW

Bangladesh is positioning itself as a regional hub for renewable energy, driven by strong policy direction, growing industrial demand, and abundant natural resources. With over 27,000 MW in installed power capacity, the country is steadily increasing its renewable share, now above 5%, led by solar across both on-grid and off-grid systems. With actual peak power generation at approximately 15,000 MW, there is significant headroom for investment in efficient, scalable renewable energy solutions that can unlock grid performance and meet rising demand.

Power demand is growing at 7% annually, with peak demand projected to surpass 25,000 MW by 2030. In response, the government’s draft renewable energy policy sets ambitious goals: 20% of total power from renewables by 2030 and 30% by 2040. The roadmap includes incentives for local manufacturing, battery storage integration, competitive electricity trading, and targeted fiscal and financial support for investors.

With high solar irradiance, biomass availability, and rising energy needs, Bangladesh offers compelling opportunities in solar, biomass, and waste-to-energy. Backed by clear policy momentum and infrastructure upgrades, the country is building a future-ready platform for clean energy investment and innovation.

## Growth Drivers

![Expanding Capacity](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330b8ce0bc0c286a0deaff_Group%20298.svg)

### Expanding Capacity

Bangladesh’s renewable energy capacity stands at 1,559 MW, with solar leading the mix at 1,265 MW (81%), followed by hydro (230 MW) and wind (63 MW). The solar market is projected to reach 3.9 GW by 2030, growing at a CAGR of 38.6% (2025–2030).

![Natural Advantage](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330bb45e73bf3f5e180b0e_SEPZ%20Icon-07%20\(2\).svg)

### Natural Advantage

High solar irradiance (5 kWh/m²/day), viable wind (3–4.5 m/s), and tidal potential support diverse RE projects.

![Policy Momentum](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c51d814d4da2279365798_Agro%20Icon-01.svg)

### Policy Momentum

Solar home systems reached 6M+ users; land-efficient innovations scaling up. Strong regulatory push from BERC & SREDA providing supportive tariffs and encouraging smart energy solutions for flood-prone zones.

![Rising Investment](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330c2b5e73bf3f5e1847ce_Group%20173%20\(1\).svg)

### Rising Investment

Foreign direct investment (FDI) in the energy sector reached $3.48 billion in 2022. Transition from Independent Power Producer (IPP) model to Merchant Power Plants enables direct energy sales, unlocking competition and efficiency.

![Cost Competitiveness ](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330c7f8a10ff4014556154_SEPZ%20Icon-04%20\(1\).svg)

### Cost Competitiveness 

The Levelized Cost of Electricity (LCOE) for solar in Bangladesh ($97–135/MWh) is becoming competitive with gas ($88–116/MWh) and cheaper than coal ($110–150/MWh), with future cost reductions expected by 2030 and 2050.

![Strategic Renewable Energy Targets](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330ca78fff06041838dffb_Group%20293.svg)

### Strategic Renewable Energy Targets

Targets of achieving a 30% renewable energy share by 2040, backed by strong growth in solar, wind, tidal, and biogas projects. Opportunities like low-cost greenhouse-based agri-solar systems (€90–150/m², the cheapest in Asia) expand the country’s renewable energy diversification.

## KEY PLAYERS

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678c7258337ee533c78e5fe9_Rectangle%2041.svg)![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678c7258e1f212fceb08d288_Rectangle%2024.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330ee861e46a585365e247_Grameen%20Shakti.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330f01127062351d2b5e13_IDCOL.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330f1d75ee0747e9e3a82d_SREDA.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330f3a5b0b85b380237594_Solaric%20Global.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330f53fcdf5693b7cf5aec_Joules-Power%20Limited%201.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330f8157da67ec64657218_World%20Bank.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330f9a6c11fc882f204ae1_asian-development-bank-adb-vector-logo.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330fe3fcdf5693b7cfb504_Bangladesh_Power_Development_Board_Logo.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68331029d3238a5bc75aaa23_Rahimafrooz%20Renewable%20Energy%20Ltd.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68331042fcefa50583000dc8_LONGi.svg)

## KEY PLAYERS

![Grameen](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330ee861e46a585365e247_Grameen%20Shakti.svg)

![IDCOL](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330f01127062351d2b5e13_IDCOL.svg)

![SREDA](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330f1d75ee0747e9e3a82d_SREDA.svg)

![Solaric](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330f3a5b0b85b380237594_Solaric%20Global.svg)

![JPL](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330f53fcdf5693b7cf5aec_Joules-Power%20Limited%201.svg)

![The World Bank](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330f8157da67ec64657218_World%20Bank.svg)

![ADB](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330f9a6c11fc882f204ae1_asian-development-bank-adb-vector-logo.svg)

![Bangladesh Electric Development Borad](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330fe3fcdf5693b7cfb504_Bangladesh_Power_Development_Board_Logo.svg)

![Rahimafrooz Solar](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68331029d3238a5bc75aaa23_Rahimafrooz%20Renewable%20Energy%20Ltd.svg)

![Longi](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68331042fcefa50583000dc8_LONGi.svg)

![Grameen](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330ee861e46a585365e247_Grameen%20Shakti.svg)

![IDCOL](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330f01127062351d2b5e13_IDCOL.svg)

![SREDA](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330f1d75ee0747e9e3a82d_SREDA.svg)

![Solaric](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330f3a5b0b85b380237594_Solaric%20Global.svg)

![JPL](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330f53fcdf5693b7cf5aec_Joules-Power%20Limited%201.svg)

![The World Bank](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330f8157da67ec64657218_World%20Bank.svg)

![ADB](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330f9a6c11fc882f204ae1_asian-development-bank-adb-vector-logo.svg)

![Bangladesh Electric Development Borad](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330fe3fcdf5693b7cfb504_Bangladesh_Power_Development_Board_Logo.svg)

![Rahimafrooz Solar](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68331029d3238a5bc75aaa23_Rahimafrooz%20Renewable%20Energy%20Ltd.svg)

![Longi](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68331042fcefa50583000dc8_LONGi.svg)

![Grameen](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330ee861e46a585365e247_Grameen%20Shakti.svg)

![IDCOL](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330f01127062351d2b5e13_IDCOL.svg)

![SREDA](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330f1d75ee0747e9e3a82d_SREDA.svg)

![Solaric](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330f3a5b0b85b380237594_Solaric%20Global.svg)

![JPL](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330f53fcdf5693b7cf5aec_Joules-Power%20Limited%201.svg)

![The World Bank](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330f8157da67ec64657218_World%20Bank.svg)

![ADB](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330f9a6c11fc882f204ae1_asian-development-bank-adb-vector-logo.svg)

![Bangladesh Electric Development Borad](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330fe3fcdf5693b7cfb504_Bangladesh_Power_Development_Board_Logo.svg)

![Rahimafrooz Solar](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68331029d3238a5bc75aaa23_Rahimafrooz%20Renewable%20Energy%20Ltd.svg)

![Longi](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68331042fcefa50583000dc8_LONGi.svg)

### POLICIES & INCENTIVES

-   (10 year Exemption period) will start from the commencement of commercial production (Applicable until 30 June 2030; [S.R.O No. 400-Act/IT-54/2024](https://nbr.gov.bd/uploads/sros/15-SRO-400-2024_\(%E0%A6%A8%E0%A6%AC%E0%A6%BE%E0%A7%9F%E0%A6%A8%E0%A6%AF%E0%A7%8B%E0%A6%97%E0%A7%8D%E0%A6%AF_%E0%A6%9C%E0%A7%8D%E0%A6%AC%E0%A6%BE%E0%A6%B2%E0%A6%BE%E0%A6%A8%E0%A6%BF_%E0%A6%B8%E0%A6%82%E0%A6%B6%E0%A7%8B%E0%A6%A7%E0%A6%BF%E0%A6%A4\).pdf))
-   Customs duty maximum 5% (Applicable until 30 June 2028; [S.R.O No. 181-Act/2024/33/customs](https://nbr.gov.bd/uploads/sros/20._SRO-181-Ain-2024-33-Customs_Electricity-Manufacturer-New_.pdf))
-   VAT Exemption on Power Generation % (Applicable until 30 June 2028; [S.R.O No. 181-Act/2024/33/customs](https://nbr.gov.bd/uploads/sros/20._SRO-181-Ain-2024-33-Customs_Electricity-Manufacturer-New_.pdf))
-   Regulatory duty and others duty exempted % (Applicable until 30 June 2028; [S.R.O No. 181-Act/2024/33/customs](https://nbr.gov.bd/uploads/sros/20._SRO-181-Ain-2024-33-Customs_Electricity-Manufacturer-New_.pdf))
-   5% VAT on locally manufactured e-bike and exemption of AT and SD on imported and local raw materials (Applicable until 30 June 2030; [S.R.O No. 175-Act/2025/303-VAT](https://nbr.gov.bd/uploads/sros/VATSRO-1752.pdf))

#### RELEVANT BODIES

-   Ministry of Power, Energy and Mineral Resources (MPEMR)
-   Sustainable and Renewable Energy Development Authority (SREDA)
-   Bangladesh Power Development Board (BPDB)
-   Infrastructure Development Company Limited (IDCOL)

## **BIDA Sector Focal**

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69f98aa73cf19f0cbbaaccb2_Untitled%20design%20\(4\).png)

### Sheikh Rasibul Islam

Deputy Director

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)](https://wa.me/8801711952685)

[

+8801712595962

](https://wa.me/8801712595962)

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)](mailto:research@bida.gov.bd)

[

rasibul20@gmail.com

](https://rasibul20@gmail.com)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69f98aa73cf19f0cbbaaccb2_Untitled%20design%20\(4\).png)

### Mobarok Hossain

Assistant Director

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)](https://wa.me/8801711952685)

[

+8801779197057

](https://wa.me/8801779197057)

[EXPLORE OUR SECTOR DESKS](/sector-desks)

Sheikh Rasibul Islam

Deputy Director

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)](https://wa.me/8801711952685)

+8801712595962

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)](mailto:research@bida.gov.bd)

rasibul20@gmail.com

Mobarok Hossain

Assistant Director

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)](https://wa.me/8801711952685)

+8801779197057

![](https://cdn.prod.website-files.com/62434fa732124a0fb112aab4/62434fa732124a0e4912aadb_Chevron%20right-1.svg)

![](https://cdn.prod.website-files.com/62434fa732124a0fb112aab4/62434fa732124a7ce212aacc_Chevron%20right.svg)

## RESOURCES

No items found.

#### BOOK AN APPOINTMENT

##### SERVICE

New Business Opportunities

Registration & Approvals

Regulatory Facilitation

Visa & Work Permit Support

Aftercare

Policy & Sectoral Guidance

##### REQUESTED DATE

##### REQUESTED TIME

**Thank you!**  
Your appointment request has been submitted.  
If approved, a confirmation email will be sent to you.

Oops! Something went wrong while submitting the form.