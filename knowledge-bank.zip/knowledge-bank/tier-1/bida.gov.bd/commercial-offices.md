---
source: "Bangladesh Investment Development Authority (BIDA)"
tier: 1
category: "Government / regulator"
url: "https://bida.gov.bd/commercial-offices"
title: "Commercial Office Services | Visa, Work Permits & Liaison Office Approvals – BIDA"
scraped_at: "2026-07-02"
---

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/686cf7286136ad1eee6ed377_Layer_1%20\(1\).svg)](/)

[中文](/china)[BIDA OSS](/services#one-stop-services)[

Matchmakin

](https://uat-irms.oss.net.bd/matchmaking)

![bida search icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678cd4d48720bb0edd6ad500_Group%2055.svg)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/68945f6c4818ae3dc291a664_Layer_1.svg)![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![search](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6788a1c48788ea23e00ed88c_Group%2055%20\(1\).webp)

![humbergur](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678896a2d5b4ac64ddac5e2a_Group%2096%20\(3\).webp)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

-   [home](/)

-   [OPPORTUNITIES](/opportunities)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [Services](/services)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [RESOURCES](/resources)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [ABOUT BIDA](/about-bida)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [NOTICE](/notices)

[BIDA OSS](https://www.investbangladesh.gov.bd/services#one-stop-service)[中文](/china)[

MATCHMAKING

](https://uat-irms.oss.net.bd/matchmaking)

# COMMERCIAL OFFICES

Services for Branch, Liaison, and Representative Offices at BIDA

## SERVICES

Visa Recommendation for Commercial Offices

E-visa recommendation

Documents Needed

-   Copy of permission letter of branch/liaison/representative office OR Memorandum and Articles of Association and Certificate of Incorporation duly signed by the shareholders in case of  locally-incorporated companies
-   Board resolution for employment of foreign national(s) mentioning the name, nationality & passport  number of the expatriate(s)
-   Photograph of the expatriate
-   Copy of passport of the expatriate/employee with all arrival stamps & departure seals
-   Appointment letter/transfer order/service contract or agreement of expatriate/investors
-   Certificates of all academic qualification & professional experience for the employee(s)
-   Copy of all the advertisements for recruitment of national employees
-   Description of company activities
-   Statement of all existing local & foreign manpower with designation, salary, allowances & bonuses, nationality and the date of the first  appointment
-   Encashment certificate of inward remittance of USD 50,000 as initial establishment cost applicable to branch/liaison/representative office, locally incorporated, joint venture and 100% foreign ownership companies
-   Up-to-date income tax clearance certificate of the organization
-   Letter of authorization by company management for submission of application
-   Additional information with proper document(s) (if any)

Mode

[BIDA One Stop Service  
(OSS)](https://www.investbangladesh.gov.bd/services#bida-one-stop-service)

Fee

No fees

Time

24 hours

E1-visa recommendation

Documents Needed

-   Copy of permission letter of branch/liaison/representative office OR Memorandum and Articles of Association and Certificate of Incorporation duly signed by the shareholders in case of locally-incorporated companies
-   Board resolution for engaging the foreign national(s) 
-   Photograph of the expatriate 
-   Copy of passport of the expatriate/employee with all arrival stamps & departure seals
-   Proper service contract/agreement for seeking E1 visa recommendation 
-   Up-to-date income tax clearance certificate of the organization 
-   Certificate of all academic qualification & professional experience of the expatriate(s)
-   L/C copy of the respective service
-   Letter of authorization by company management for submission of application 
-   Additional information with proper document(s) (if any) 
-   Document/Certificate from vendor regarding the engagement of the expatriate in this task

Mode

[BIDA One Stop Service  
(OSS)](https://www.investbangladesh.gov.bd/services#bida-one-stop-service)

Fee

No fees

Time

24 hours

PI-visa recommendation

Documents Needed

-   Memorandum & Articles of Association and Certificate of Incorporation duly signed by shareholders 
-   Board resolution for engaging foreign national(s) in Bangladesh mentioning the name, nationality & passport number. Specifying the sector where the investor actually invests
-   Photograph of the investor 
-   Copy of passport of the investor with all arrival stamp & departure seals 
-   The specific activity of the company 
-   Statement of all existing local & foreign manpower with designation, salary, allowance(s) & bonus(s), nationality and date of the first appointment 
-   Encashment certificate of inward remittance of minimum USD 50,000 as initial establishment cost for locally incorporated joint-venture and 100% foreign ownership companies 
-   Up-to-date income tax clearance certificate of the organization
-   Letter of authorization signed by Management of the company for submitting the application
-   Additional information with proper documents (if any) 
-   Documents regarding the regarding the engagement of the expatriate

Mode

[BIDA One Stop Service  
(OSS)](https://www.investbangladesh.gov.bd/services#bida-one-stop-service)

Fee

No fees

Time

24 hours

Visa On-arrival recommendation

Documents Needed

-   Copy of the registration of industrial project with BIDA/Branch Office/Liaison Office/Representative Office 
-   Copy of airline ticket 
-   Copy of passport (including all the pages used so far) 
-   A letter from the organization for the Visa On Arrival mentioning the purpose of the visit
-   Additional information with proper documents (if any)

Mode

[BIDA One Stop Service  
(OSS)](https://www.investbangladesh.gov.bd/services#bida-one-stop-service)

Fee

No fees

Time

24 hours

Work permit for Commercial Offices

Work permit (new)

Documents Needed

-   Copy of permission letter for branch/liaison/representative office Memorandum & Articles of Association and Certificate of Incorporation duly signed by the shareholders in case of locally-incorporated Company 
-   Letter of Authorization by Project Director/authorized official of Project Office
-   Board resolution regarding employment of foreign national(s) including salaries, allowances, honorarium & other benefits 
-   Copy of passport with arrival stamp, E-type, E-1 visa and PI-type visa (for investors)
-   Service contract/agreement and appointment letter/ transfer order in case of employee
-   Copies of all academic qualifications & certificate of professional certificate of the employee 
-   Statement of all existing local & foreign manpower with designation, salary and allowances, nationality and date of the first appointment 
-   Up-to-date income tax clearance certificate of the company 
-   Encashment certificate of inward remittance of minimum USD 50,000 as initial establishment cost for branch/ liaison/ joint-venture and 100% foreign ownership company incorporation in Bangladesh 
-   Visa Recommendation letter of the expatriate/investor 
-   Letter of authorization signed by management of the company for submitting the application 
-   Additional information with proper documents (if any) 
-   List of local employees who will be trained up by the expatriate  

Mode

[BIDA One Stop Service  
(OSS)](https://www.investbangladesh.gov.bd/services#bida-one-stop-service)

Fee

BDT 5,000 per individual/year

Online payment through BIDA One Stop Service (OSS)

Time

16 working days

(Subject to the approval of the inter-ministerial working committee)

Work permit (amendment)

Documents Needed

-   Copy of the Office Permission 
-   Copy of the First work permit 
-   Copy of the last work permit 
-   Board resolution regarding amendment of work permit 
-   Copy of passport both old and new  
-   Other related documents such as: revised agreement/appointment letter/similar valid document 
-   Up-to-date income tax clearance certificate of the expatriate 

Mode

[BIDA One Stop Service  
(OSS)](https://www.investbangladesh.gov.bd/services#bida-one-stop-service)

Fee

BDT 1,000

Online payment through BIDA One Stop Service (OSS) or Pay Order from any bank in favor of “Bangladesh Investment Development Authority”

Time

3 days

Work permit (cancellation)

Documents Needed

-   First work permit letter and the last work permit
-   Up-to-date income tax clearance certificate for the company. 
-   Up-to-date income tax clearance certificate for the expatriate under Section-91 of Income Tax Ordinance 1984 
-   Income tax certificate of the expatriate for previous three years (if applicable) 
-   Resignation letter/transfer order 
-   Board resolution, acceptance letter/release letter 
-   Copy of passport (used part with the latest departure seal from Bangladesh) 
-   Copy of air ticket 
-   Updated List of local employees who have been trained by the expatriate

Mode

[BIDA One Stop Service  
(OSS)](https://www.investbangladesh.gov.bd/services#bida-one-stop-service)

Fee

No fees

Time

3 days

Branch/Liaison/Representative Office Permission

Opening of branch/ liaison/representative office

Documents Needed

-   Resolution by the company's Board of Directors regarding the opening of office in Bangladesh/Details of Project/Copy of Agreement with EPC Contractor in case of Project Office
-   Audited Accounts of the last financial year of the principal company
-   Proposed organogram of the office showing the posts to be occupied by both expatriates and local personnel
-   Detailed activities of the principal company 
-   Name and nationality of the Directors/owners of the principal company 
-   Memorandum and Articles of Association of the principal company 
-   Certificate of Incorporation 
-   Letter of authorization signed by company's management regarding the submission of application 
-   Additional information with proper documents (if any) 
-   Details of activities to be performed through the proposed branch/liaison/representative office in Bangladesh and future plan in industrial revolution  

NB:

-   (a) Documents shall have to be attested by the concerned Bangladesh mission/mission of the respective country in Bangladesh/ respective country’s apex business chamber
-   (b) After submitting the application, hard copies of all documents should be submitted to BIDA’s Commercial wing 

Mode

[BIDA One Stop Service  
(OSS)](https://www.investbangladesh.gov.bd/services#bida-one-stop-service)

Fee

BDT 25,000

Online payment through BIDA One Stop Service (OSS)

Time

16 working days

(subject to the approval of Inter-ministerial committee)

Extension of branch/liaison/representative office

Documents Needed

-   Notification letter of Bangladesh Bank under Section-18(B) of Foreign Exchange Regulation Act, 1947 
-   Latest Income Tax Clearance Certificate for the local office 
-   Audited accounts of last financial year of the principal company
-   Resolution by the company's Board of Directors regarding the extension/renewal of office permission 
-   Latest audit report of Bangladesh office 
-   Statement of all existing local & foreign manpower with designation, salary and allowances, nationality and date of the first appointment 
-   Up-to-date encashment certificate of inward remittance 
-   Copy of the last office permission letter 
-   Letter of authorization signed by company’s Management for submission of application
-   Additional information with proper documents (if any) 
-   Details of activities to be performed through the proposed branch/liaison/representative office in Bangladesh and future plan in industrial revolution  

NB:

-   (a) Documents must be submitted by an authorized person of the organization including the letter of authorization
-   (b) Application for renewal/extension to be submitted at least 2 months before the expiration of existing permission 

Mode

[BIDA One Stop Service  
(OSS)](https://www.investbangladesh.gov.bd/services#bida-one-stop-service)

Fee

BDT 10,000

Online payment through [BIDA One Stop Service (OSS)](https://bidaquickserv.org/)

Time

16 working days

(subject to the approval of Inter-ministerial committee) 

Closing of branch/liaison/representative office

Documents Needed

-   Copy of the public notice (to be published in any recognized national print media at least 3 (three) months prior to the closure of the foreign office in Bangladesh 
-   Copy of the office permission 
-   Board resolution by parent company regarding the office closure 
-   Up-to-date audit report 
-   Up-to-date Income Tax Clearance Certificate of the organization under Section-89 of Income Tax Ordinance 1984 
-   Up-to-date bank statement 
-   All dues settlement certificate 
-   NOC from house owner 
-   Copy of cancelation of work permit of all expatriates  
-   Declaration mentioning that all liabilities including all taxes (both organizational & individual) and other future financial dues will be borne by the parent company 
-   Additional information with proper documents (if any) 

Mode

In-person submission

Fee

No fees

Time

16 working days

(subject to the approval of Inter-ministerial committee) 

Changing the name of the branch/liaison/representative office

Documents Needed

-   Copy of the office permission 
-   Board resolution of the parent company for changing name of the branch/liaison/representative office (must be properly attested by the Bangladesh embassy/mission of the respective country in Bangladesh/respective country’s apex business chamber) 
-   Necessary document for changing the name including court decision (in case of a merger)/Certificate of Incorporation (on changing the name of the company)  
-   Up-to-date Income Tax Clearance Certificate of the organization 
-   Additional information with proper documents (if any)

Mode

In-person submission

Fee

BDT 1,000 

Pay order from any bank in favor of “Bangladesh Investment Development Authority’’   

Time

16 working days

(subject to the approval of Inter-ministerial committee) 

Changing the address of the branch/liaison/representative office

Documents Needed

-   Copy of the office permission 
-   Office rent agreement 
-   Board resolution for changing the office address 
-   Trade license (in case of locally incorporated company) 
-   Register of Joint Stock Company’s form VI (in case of locally incorporated company)       

Mode

BIDA One Stop Service 

Fee

BDT 1,000

Time

16 working days

(subject to the approval of Inter-ministerial committee) 

Waiver of conditions given in the Office Permission Letter

Documents Needed

-   Copy of office permission 
-   Board resolution regarding the waiver of conditions 
-   Justification for waiver with proper documents of proof 
-   Audit report of the branch/liaison/representative office 
-   Up-to-date Income Tax Clearance Certificate of the organization 
-   Prior approval letter(s) for waiving any condition (if any) 
-   Agreement with government/source of local income 
-   Proof of income (invoice/bill/ check etc. for providing any goods/services/works)             
-   Additional information with proper documents (if any)   

Mode

In-person submission 

Fee

BDT 1,000

Pay order from any bank in favor of “Bangladesh Investment Development Authority’’   

Time

16 working days

(subject to the approval of Inter-ministerial committee) 

Recommendation for Security Clearance

Recommendation for security clearance in case of objection(s) raised by Ministry of Home Affairs

Documents Needed

-   Application mentioning the reasons for withdrawing the objections by Ministry of Home Affairs 
-   Copy of office permission 
-   Copy of work permit 
-   Copy of the objection letter of the Ministry of Home Affairs 
-   Up-to-date income tax clearance certificate of the expatriate 
-   Up-to-date income tax clearance certificate of Office 
-   Additional information with proper documents (if any)    

Mode

In-person submission 

Fee

No fees

Time

3 days

#### BOOK AN APPOINTMENT

##### SERVICE

New Business Opportunities

Registration & Approvals

Regulatory Facilitation

Visa & Work Permit Support

Aftercare

Policy & Sectoral Guidance

##### REQUESTED DATE

##### REQUESTED TIME

**Thank you!**  
Your appointment request has been submitted.  
If approved, a confirmation email will be sent to you.

Oops! Something went wrong while submitting the form.