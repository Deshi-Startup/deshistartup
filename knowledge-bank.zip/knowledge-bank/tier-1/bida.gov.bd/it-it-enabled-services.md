---
source: "Bangladesh Investment Development Authority (BIDA)"
tier: 1
category: "Government / regulator"
url: "https://bida.gov.bd/investment-sector/it-it-enabled-services"
title: "The IT & ITES Goldmine – Bangladesh is Open for Business"
scraped_at: "2026-07-02"
---

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/686cf7286136ad1eee6ed377_Layer_1%20\(1\).svg)](/)

[中文](/china)[BIDA OSS](/services#one-stop-services)[

Matchmakin

](https://uat-irms.oss.net.bd/matchmaking)

![bida search icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678cd4d48720bb0edd6ad500_Group%2055.svg)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/68945f6c4818ae3dc291a664_Layer_1.svg)![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![search](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6788a1c48788ea23e00ed88c_Group%2055%20\(1\).webp)

![humbergur](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678896a2d5b4ac64ddac5e2a_Group%2096%20\(3\).webp)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

-   [home](/)

-   [OPPORTUNITIES](/opportunities)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [Services](/services)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [RESOURCES](/resources)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [ABOUT BIDA](/about-bida)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [NOTICE](/notices)

[BIDA OSS](https://www.investbangladesh.gov.bd/services#one-stop-service)[中文](/china)[

MATCHMAKING

](https://uat-irms.oss.net.bd/matchmaking)

# IT-ITeS

Where Youth, Connectivity & Code Converge

![IT-ITeS](https://cdn.prod.website-files.com/6820331d027084bef793fadb/683462c6198edddf1dfc1866_Mask%20group%20\(41\)%20\(1\).png)

9th

globally in total mobile connections

$2.1B

IT services market by 2025

650k+

registered freelancers

4.5k+

IT & software companies

## OVERVIEW

Bangladesh’s Information Technology and IT-Enabled Services (IT-ITeS) sector is emerging as one of South Asia’s strongest digital success stories—driven by rapid connectivity, a growing digital workforce, and increasing global demand for outsourcing. With over 130 million internet users and smartphones in 60% of households, Bangladesh is among the most digitally connected frontier markets in Asia. Bangladesh ranks among the top countries globally for freelance IT talent. A large pool of young, tech-savvy professionals continues to drive global demand for Bangladeshi freelancers in development, design, and digital services. Core areas include software development, ITES, AI, cybersecurity, UI/UX, mobile apps, and embedded systems.

The domestic IT services market is also rapidly expanding, with revenue projected to reach USD 2.11 billion by 2025, led by IT outsourcing—the dominant segment valued at USD 788 million. Between 2025 and 2029, the market is expected to grow at a CAGR of 11.8%, reaching USD 3.29 billion. This trend reflects a steady rise in corporate IT investment and Bangladesh’s appeal as a global outsourcing hub.

## Growth Drivers

![Global Export Expansion](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6834430b618a067cc431c55d_Group%20213.svg)

### Global Export Expansion

350+ Bangladeshi IT firms now export to 80+ countries, with export earnings exceeding USD 500 million in FY2022. Key markets include the US, UK, Finland, Sweden, Denmark, Australia, Germany, Netherlands, Singapore, Japan, and India.

![Foreign Investment Growth](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c60ad0d44bda929df1e3e_Group%20173.svg)

### Foreign Investment Growth

40+ companies now operate as joint ventures or fully foreign-owned offshore development centers (ODCs), expanding Bangladesh’s integration into global tech supply chains.

![Advanced Solutions](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6834462c85b3e4cae9a09ba4_Vector%20\(15\).svg)

### Advanced Solutions

Bangladeshi firms deliver high-end services including biometric ID systems, automated licensing platforms, and global backend infrastructure—alongside emerging capabilities in AI and machine learning, IoT and embedded systems, AR/VR, and custom enterprise software.

![Accelerating Access](https://cdn.prod.website-files.com/6820331d027084bef793fadb/683442507028b75d063e566f_Group%20198.svg)

### Accelerating Access

Starlink’s entry is poised to transform Bangladesh’s connectivity landscape, especially by extending high-speed internet to underserved regions—unlocking new opportunities in digital services, e-commerce, edtech, smart agriculture, and rural tech infrastructure.

![Policy Support ](https://cdn.prod.website-files.com/6820331d027084bef793fadb/683446e2dbe3f9c518a1f2b1_Group%20235.svg)

### Policy Support 

Export cash incentives, tax holidays, and dedicated hi-tech parks ensure an enabling environment for digital enterprises and foreign investors.

## KEY PLAYERS

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678c7258337ee533c78e5fe9_Rectangle%2041.svg)![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678c7258e1f212fceb08d288_Rectangle%2024.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/683450a2aa9270364942c2c6_Servicengine-Logo.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/683450b92ad904ccd97a98ad_Group%20\(4\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/683450da10d335cd71da6e30_Graphic%20People%202.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/683450ff86f45ad8c992e0d9_Therap%20\(BD\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6834511b10d335cd71da94b4_Bondstein.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6834513b23b8ec37e59decb0_Secure%20Link%20Services%20Bangladesh%20\(SELISE\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/683451595ee3138e786721f6_Taskeater%202.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68345176f55b542dcaa51a3a_Group%20238.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6834519186f45ad8c9932f33_KAZ%20Software.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/683451a983e55579a913ae6b_Golden%20Harvest%20Infotech.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/683451fcd353192b1ba9d103_Brain%20Station%2023.svg)

## KEY PLAYERS

![Servicengine](https://cdn.prod.website-files.com/6820331d027084bef793fadb/683450a2aa9270364942c2c6_Servicengine-Logo.svg)

![Bjit](https://cdn.prod.website-files.com/6820331d027084bef793fadb/683450b92ad904ccd97a98ad_Group%20\(4\).svg)

![Graphicpeople](https://cdn.prod.website-files.com/6820331d027084bef793fadb/683450da10d335cd71da6e30_Graphic%20People%202.svg)

![Therap(BD)Ltd](https://cdn.prod.website-files.com/6820331d027084bef793fadb/683450ff86f45ad8c992e0d9_Therap%20\(BD\).svg)

![bondstein](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6834511b10d335cd71da94b4_Bondstein.svg)

![Selise](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6834513b23b8ec37e59decb0_Secure%20Link%20Services%20Bangladesh%20\(SELISE\).svg)

![Taskeater](https://cdn.prod.website-files.com/6820331d027084bef793fadb/683451595ee3138e786721f6_Taskeater%202.svg)

![Cefalo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68345176f55b542dcaa51a3a_Group%20238.svg)

![KAZ Software](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6834519186f45ad8c9932f33_KAZ%20Software.svg)

![Golden Harvest](https://cdn.prod.website-files.com/6820331d027084bef793fadb/683451a983e55579a913ae6b_Golden%20Harvest%20Infotech.svg)

![Brain Station 23](https://cdn.prod.website-files.com/6820331d027084bef793fadb/683451fcd353192b1ba9d103_Brain%20Station%2023.svg)

![Servicengine](https://cdn.prod.website-files.com/6820331d027084bef793fadb/683450a2aa9270364942c2c6_Servicengine-Logo.svg)

![Bjit](https://cdn.prod.website-files.com/6820331d027084bef793fadb/683450b92ad904ccd97a98ad_Group%20\(4\).svg)

![Graphicpeople](https://cdn.prod.website-files.com/6820331d027084bef793fadb/683450da10d335cd71da6e30_Graphic%20People%202.svg)

![Therap(BD)Ltd](https://cdn.prod.website-files.com/6820331d027084bef793fadb/683450ff86f45ad8c992e0d9_Therap%20\(BD\).svg)

![bondstein](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6834511b10d335cd71da94b4_Bondstein.svg)

![Selise](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6834513b23b8ec37e59decb0_Secure%20Link%20Services%20Bangladesh%20\(SELISE\).svg)

![Taskeater](https://cdn.prod.website-files.com/6820331d027084bef793fadb/683451595ee3138e786721f6_Taskeater%202.svg)

![Cefalo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68345176f55b542dcaa51a3a_Group%20238.svg)

![KAZ Software](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6834519186f45ad8c9932f33_KAZ%20Software.svg)

![Golden Harvest](https://cdn.prod.website-files.com/6820331d027084bef793fadb/683451a983e55579a913ae6b_Golden%20Harvest%20Infotech.svg)

![Brain Station 23](https://cdn.prod.website-files.com/6820331d027084bef793fadb/683451fcd353192b1ba9d103_Brain%20Station%2023.svg)

![Servicengine](https://cdn.prod.website-files.com/6820331d027084bef793fadb/683450a2aa9270364942c2c6_Servicengine-Logo.svg)

![Bjit](https://cdn.prod.website-files.com/6820331d027084bef793fadb/683450b92ad904ccd97a98ad_Group%20\(4\).svg)

![Graphicpeople](https://cdn.prod.website-files.com/6820331d027084bef793fadb/683450da10d335cd71da6e30_Graphic%20People%202.svg)

![Therap(BD)Ltd](https://cdn.prod.website-files.com/6820331d027084bef793fadb/683450ff86f45ad8c992e0d9_Therap%20\(BD\).svg)

![bondstein](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6834511b10d335cd71da94b4_Bondstein.svg)

![Selise](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6834513b23b8ec37e59decb0_Secure%20Link%20Services%20Bangladesh%20\(SELISE\).svg)

![Taskeater](https://cdn.prod.website-files.com/6820331d027084bef793fadb/683451595ee3138e786721f6_Taskeater%202.svg)

![Cefalo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68345176f55b542dcaa51a3a_Group%20238.svg)

![KAZ Software](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6834519186f45ad8c9932f33_KAZ%20Software.svg)

![Golden Harvest](https://cdn.prod.website-files.com/6820331d027084bef793fadb/683451a983e55579a913ae6b_Golden%20Harvest%20Infotech.svg)

![Brain Station 23](https://cdn.prod.website-files.com/6820331d027084bef793fadb/683451fcd353192b1ba9d103_Brain%20Station%2023.svg)

### POLICIES & INCENTIVES

-   6% export subsidy for software, ITES, and hardware (Applicable until 31 December 2025; [FEPD Circular No. 28](https://www.bb.org.bd/mediaroom/circulars/fepd/jul102025fepd28.pdf)).
-   Tax Holiday Period: 100% for first 7 years, 70% for 8 to 10 years for business established within Hi-Tech park (Applicable until 30 June 2035; [S.R.O. 245-Law/Income Tax-39/2024](https://nbr.gov.bd/uploads/sros/54914_81934.pdf))
-   0.3% to 2% export subsidy for product and market diversification for companies in high-tech parks. (Applicable until 31 December 2025; [FEPD Circular No. 28](https://www.bb.org.bd/mediaroom/circulars/fepd/jul102025fepd28.pdf)).
-   Exempted Corporate Income Tax (CIT) for first 10 years for manufacturing motherboard, casing, UPS, speaker, sound system, power supply, USB cable, CCTV, pendrive having more than 30% value addition (Applicable until 30 June 2030; [S.R.O. No. 163-Law/Income Tax/2021](https://nbr.gov.bd/uploads/sros/SRO_on-163_ICT_Products.pdf))
-   5% VAT on locally produced and software customization services ([S.R.O. No. 154-Law/VAT/2023](https://nbr.gov.bd/uploads/sros/VATSRO-154.pdf))
-   All income generated from IT Enable (ITES) is tax-exempt, having income received through banking channel (Applicable until 30 June 2027; [As per 6th Schedule of ITA 2023)](http://bdlaws.minlaw.gov.bd/upload/act/2025-07-08-10-29-18-%E0%A6%86%E0%A7%9F%E0%A6%95%E0%A6%B0-%E0%A6%86%E0%A6%87%E0%A6%A8,-%E0%A7%A8%E0%A7%A6%E0%A7%A8%E0%A7%A9-\(%E0%A7%A8%E0%A7%A6%E0%A7%A8%E0%A7%A9-%E0%A6%B8%E0%A6%A8%E0%A7%87%E0%A6%B0-%E0%A7%A7%E0%A7%A8-%E0%A6%A8%E0%A6%82-%E0%A6%86%E0%A6%87%E0%A6%A8\).pdf)

#### RELEVANT BODIES

-   Information and Communication Technology (ICT) Division
-   Bangladesh Hi-Tech Park Authority
-   Bangladesh Telecommunication Regulatory Commission (BTRC)
-   Bangladesh Association of Software and Information Services (BASIS)
-   Bangladesh Computer Council (BCC)
-   Bangladesh Association of Call Center & Outsourcing (BACCO)
-   Ecommerce Association of Bangladesh (e-CAB)

## **BIDA Sector Focal**

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69f98aa73cf19f0cbbaaccb2_Untitled%20design%20\(4\).png)

### Atik Sarker

Deputy Director

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)](https://wa.me/8801711952685)

[

+8801914594512

](https://wa.me/8801914594512)

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)](mailto:research@bida.gov.bd)

[

dd.rifiwp@bida.gov.bd

](https://dd.rifiwp@bida.gov.bd)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69f98aa73cf19f0cbbaaccb2_Untitled%20design%20\(4\).png)

### Mahfuzul Islam

Assistant Director

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)](https://wa.me/8801711952685)

[

+8801521407944

](https://wa.me/8801521407944)

[EXPLORE OUR SECTOR DESKS](/sector-desks)

Atik Sarker

Deputy Director

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)](https://wa.me/8801711952685)

+8801914594512

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)](mailto:research@bida.gov.bd)

dd.rifiwp@bida.gov.bd

Mahfuzul Islam

Assistant Director

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)](https://wa.me/8801711952685)

+8801521407944

![](https://cdn.prod.website-files.com/62434fa732124a0fb112aab4/62434fa732124a0e4912aadb_Chevron%20right-1.svg)

![](https://cdn.prod.website-files.com/62434fa732124a0fb112aab4/62434fa732124a7ce212aacc_Chevron%20right.svg)

## RESOURCES

No items found.

#### BOOK AN APPOINTMENT

##### SERVICE

New Business Opportunities

Registration & Approvals

Regulatory Facilitation

Visa & Work Permit Support

Aftercare

Policy & Sectoral Guidance

##### REQUESTED DATE

##### REQUESTED TIME

**Thank you!**  
Your appointment request has been submitted.  
If approved, a confirmation email will be sent to you.

Oops! Something went wrong while submitting the form.