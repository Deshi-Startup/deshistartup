---
source: "Bangladesh Investment Development Authority (BIDA)"
tier: 1
category: "Government / regulator"
url: "https://bida.gov.bd/notices"
title: "BIDA Notices – NOC, Tenders & Government Orders Bangladesh"
scraped_at: "2026-07-02"
---

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/686cf7286136ad1eee6ed377_Layer_1%20\(1\).svg)](/)

[中文](/china)[BIDA OSS](/services#one-stop-services)[

Matchmakin

](https://uat-irms.oss.net.bd/matchmaking)

![bida search icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678cd4d48720bb0edd6ad500_Group%2055.svg)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/68945f6c4818ae3dc291a664_Layer_1.svg)![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![search](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6788a1c48788ea23e00ed88c_Group%2055%20\(1\).webp)

![humbergur](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678896a2d5b4ac64ddac5e2a_Group%2096%20\(3\).webp)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

-   [home](/)

-   [OPPORTUNITIES](/opportunities)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [Services](/services)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [RESOURCES](/resources)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [ABOUT BIDA](/about-bida)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [NOTICE](/notices)

[BIDA OSS](https://www.investbangladesh.gov.bd/services#one-stop-service)[中文](/china)[

MATCHMAKING

](https://uat-irms.oss.net.bd/matchmaking)

# BIDA NOTICES

## BIDA NOTICES

NOC / GO

TITLE

DATE

ACTION

-   NOC of Mr. Md. Yousuf, Investment Assistant, Bangladesh Investment Development Authority (BIDA)

Feb 26, 2026

[Download](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69a00e42b5a07db0b942cebd_NOC%20Mr.%20Md.%20Yousuf%2C%20Investment%20Assistant%2C%20Bangladesh%20Investment%20Development%20Authority%20\(BIDA\).pdf)

-   উপপরিচালক নাশিদ কায়সার রিয়াদ, পাসপোর্ট এনওসি

Jan 25, 2026

[Download](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6975c652b527500334edf569_%E0%A6%89%E0%A6%AA%E0%A6%AA%E0%A6%B0%E0%A6%BF%E0%A6%9A%E0%A6%BE%E0%A6%B2%E0%A6%95%20%E0%A6%A8%E0%A6%BE%E0%A6%B6%E0%A6%BF%E0%A6%A6%20%E0%A6%95%E0%A6%BE%E0%A7%9F%E0%A6%B8%E0%A6%BE%E0%A6%B0%20%E0%A6%B0%E0%A6%BF%E0%A7%9F%E0%A6%BE%E0%A6%A6%2C%20%E0%A6%AA%E0%A6%BE%E0%A6%B8%E0%A6%AA%E0%A7%8B%E0%A6%B0%E0%A7%8D%E0%A6%9F%20%E0%A6%8F%E0%A6%A8%E0%A6%93%E0%A6%B8%E0%A6%BF.pdf)

-   জনাব মোঃ মনিবুর রহমান, ঊর্ধ্বতন বিনিয়োগ সহকারী, বাংলাদেশ বিনিয়োগ উন্নয়ন কর্তৃপক্ষ এর পাসপোর্ট অনাপত্তি সনদ

Jan 12, 2026

[Download](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6964953a516c536fe3e986e6_CamScanner%2001-12-2026%2012.25.pdf)

-   GO for Abdur Rahaman, Driver, Bangladesh Investment Development Authority

Dec 23, 2025

[Download](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/694b64e69bf23f25ee434740_Abdur%20Rahaman%20\(Leave\).pdf)

-   জনাব সুদীপ্ত ভৌমিক দীপ, নির্বাহী চেয়ারম্যানের সহকারী একান্ত সচিব বাংলাদেশ বিনিয়োগ উন্নয়ন কর্তৃপক্ষ এর পাসপোর্ট অনাপত্তি

Nov 24, 2025

[Download](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69243995b06e917f8b00f0e9_%E0%A6%9C%E0%A6%A8%E0%A6%BE%E0%A6%AC%20%E0%A6%B8%E0%A7%81%E0%A6%A6%E0%A7%80%E0%A6%AA%E0%A7%8D%E0%A6%A4%20%E0%A6%AD%E0%A7%8C%E0%A6%AE%E0%A6%BF%E0%A6%95%20%E0%A6%A6%E0%A7%80%E0%A6%AA%2C%20%E0%A6%A8%E0%A6%BF%E0%A6%B0%E0%A7%8D%E0%A6%AC%E0%A6%BE%E0%A6%B9%E0%A7%80%20%E0%A6%9A%E0%A7%87%E0%A7%9F%E0%A6%BE%E0%A6%B0%E0%A6%AE%E0%A7%8D%E0%A6%AF%E0%A6%BE%E0%A6%A8%E0%A7%87%E0%A6%B0%20%E0%A6%B8%E0%A6%B9%E0%A6%95%E0%A6%BE%E0%A6%B0%E0%A7%80%20%E0%A6%8F%E0%A6%95%E0%A6%BE%E0%A6%A8%E0%A7%8D%E0%A6%A4%20%E0%A6%B8%E0%A6%9A%E0%A6%BF%E0%A6%AC%20%E0%A6%AC%E0%A6%BE%E0%A6%82%E0%A6%B2%E0%A6%BE%E0%A6%A6%E0%A7%87%E0%A6%B6%20%E0%A6%AC%E0%A6%BF%E0%A6%A8%E0%A6%BF%E0%A7%9F%E0%A7%8B%E0%A6%97%20%E0%A6%89%E0%A6%A8%E0%A7%8D%E0%A6%A8%E0%A7%9F%E0%A6%A8%20%E0%A6%95%E0%A6%B0%E0%A7%8D%E0%A6%A4%E0%A7%83.pdf)

-   মোছাঃ শামীমা আক্তার পরিচালক (উপসচিব), বাংলাদেশ বিনিয়োগ উন্নয়ন কর্তৃপক্ষ এর পাসপোর্ট অনাপত্তি সনদ।

Nov 19, 2025

[Download](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/691d680bfa53351d48c38594_%E0%A6%AA%E0%A6%BE%E0%A6%B8%E0%A6%AA%E0%A7%8B%E0%A6%B0%E0%A7%8D%E0%A6%9F%20%E0%A6%85%E0%A6%A8%E0%A6%BE%E0%A6%AA%E0%A6%BF%E0%A6%93%20%E0%A6%B8%E0%A6%A8%E0%A6%A6%E0%A5%A4%20%E0%A6%AE%E0%A7%8B%E0%A6%9B%E0%A6%BE_%20%E0%A6%B8%E0%A6%AE%E0%A7%80%E0%A6%AE%E0%A6%BE%20%E0%A6%86%E0%A6%95%E0%A7%8D%E0%A6%A4%E0%A6%BE%E0%A6%B0.pdf)

-   জনাব ফাতেমা বেগম ও তার ২ (দুই) পুত্রের পাসপোর্ট করার জন্য অনাপত্তি প্রদান

Nov 2, 2025

[Download](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6906f6026c5b3049ddd9434e_DOC-20251029-WA0007.\(2\).pdf)

-   বিডার অফিস সহায়ক জনাব মজিবুর রহমান এর পাসপোর্ট করার জন্য NOC

Oct 28, 2025

[Download](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6902e18cd45f9dc6cbc6e659_Document%2039.pdf)

[1](#)

...

[![arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6820149c00aa5aab285f0043_Vector%20\(14\).svg)](?d57a469b_page=2)

1 / 4

Meeting Notices

TITLE

DATE

ACTION

-   মহান বিজয় দিবস ২০২৪ যথাযোগ্য মর্যাদায় উদযাপনের লক্ষ্যে বাংলাদেশ বিনিয়োগ উন্নয়ন কর্তৃপক্ষ (বিডা) কর্তৃক গৃহীত কর্মসূচি

Dec 15, 2024

[Download](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685d5111aec7cf4c4a246c40_01%20%E0%A6%AE%E0%A6%B9%E0%A6%BE%E0%A6%A8%20%E0%A6%AC%E0%A6%BF%E0%A6%9C%E0%A6%AF%E0%A6%BC%20%E0%A6%A6%E0%A6%BF%E0%A6%AC%E0%A6%B8%20%E0%A7%A8%E0%A7%A6%E0%A7%A8%E0%A7%AA%20%E0%A6%AF%E0%A6%A5%E0%A6%BE%E0%A6%AF%E0%A7%8B%E0%A6%97%E0%A7%8D%E0%A6%AF%20%E0%A6%AE%E0%A6%B0%E0%A7%8D%E0%A6%AF%E0%A6%BE%E0%A6%A6%E0%A6%BE%E0%A6%AF%E0%A6%BC%20%E0%A6%89%E0%A6%A6%E0%A6%AF%E0%A6%BE%E0%A6%AA%E0%A6%A8%E0%A7%87%E0%A6%B0%20%E0%A6%B2%E0%A6%95%E0%A7%8D%E0%A6%B7%E0%A7%8D%E0%A6%AF%E0%A7%87%20%E0%A6%AC%E0%A6%BE%E0%A6%82%E0%A6%B2%E0%A6%BE%E0%A6%A6%E0%A7%87%E0%A6%B6%20%E0%A6%AC%E0%A6%BF%E0%A6%A8%E0%A6%BF%E0%A6%AF%E0%A6%BC%E0%A7%8B%E0%A6%97.pdf)

[1](#)

...

Other Notices

TITLE

DATE

ACTION

-   অফিস আদেশ (কর্মকর্তা পদায়নকৃত সংক্রান্ত)

Jul 2, 2026

[Download](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a46155671b7ed4bf4a34063_%E0%A6%85%E0%A6%AB%E0%A6%BF%E0%A6%B8%20%E0%A6%86%E0%A6%A6%E0%A7%87%E0%A6%B6%20\(%E0%A6%95%E0%A6%B0%E0%A7%8D%E0%A6%AE%E0%A6%95%E0%A6%B0%E0%A7%8D%E0%A6%A4%E0%A6%BE%20%E0%A6%AA%E0%A6%A6%E0%A6%BE%E0%A6%AF%E0%A6%BC%E0%A6%A8%E0%A6%95%E0%A7%83%E0%A6%A4%20%E0%A6%B8%E0%A6%82%E0%A6%95%E0%A7%8D%E0%A6%B0%E0%A6%BE%E0%A6%A8%E0%A7%8D%E0%A6%A4\).pdf)

-   Appointment letter of Md. Abdullah Al Noman

Jun 23, 2026

[Download](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3b4ff0b20cb4ab3caccc3a_WhatsApp%20Image%202026-06-23%20at%203.18.01%20PM.jpeg)

-   নির্বাহী চেয়ারম্যান মহোদয়ের সহকারী একান্ত সচিব এর যোগদানপত্র

Jun 21, 2026

[Download](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a378474a228486a7c7ca002_%E0%A6%A8%E0%A6%BF%E0%A6%B0%E0%A7%8D%E0%A6%AC%E0%A6%BE%E0%A6%B9%E0%A7%80%20%E0%A6%9A%E0%A7%87%E0%A7%9F%E0%A6%BE%E0%A6%B0%E0%A6%AE%E0%A7%8D%E0%A6%AF%E0%A6%BE%E0%A6%A8%20%E0%A6%AE%E0%A6%B9%E0%A7%8B%E0%A6%A6%E0%A7%9F%E0%A7%87%E0%A6%B0%20%E0%A6%B8%E0%A6%B9%E0%A6%95%E0%A6%BE%E0%A6%B0%E0%A7%80%20%E0%A6%8F%E0%A6%95%E0%A6%BE%E0%A6%A8%E0%A7%8D%E0%A6%A4%20%E0%A6%B8%E0%A6%9A%E0%A6%BF%E0%A6%AC%20%E0%A6%8F%E0%A6%B0%20%E0%A6%AF%E0%A7%8B%E0%A6%97%E0%A6%A6%E0%A6%BE%E0%A6%A8%E0%A6%AA%E0%A6%A4%E0%A7%8D%E0%A6%B0.pdf)

-   Notice To Formalise Work Visa or Work Permit

Jun 8, 2026

[Download](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a26ae686e6131eea8c72615_BIDA%20NOTICE-303.pdf)

-   সহকারী পরিচালক মিজ শ্রাবনী বসু এর অব্যাহতি পত্র

Jun 8, 2026

[Download](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a26457f1c846f2864a932b9_%E0%A6%B8%E0%A6%B9%E0%A6%95%E0%A6%BE%E0%A6%B0%E0%A7%80%20%E0%A6%AA%E0%A6%B0%E0%A6%BF%E0%A6%9A%E0%A6%BE%E0%A6%B2%E0%A6%95%20%E0%A6%AE%E0%A6%BF%E0%A6%9C%20%E0%A6%B6%E0%A7%8D%E0%A6%B0%E0%A6%BE%E0%A6%AC%E0%A6%A8%E0%A7%80%20%E0%A6%AC%E0%A6%B8%E0%A7%81%20%E0%A6%8F%E0%A6%B0%20%E0%A6%85%E0%A6%AC%E0%A7%8D%E0%A6%AF%E0%A6%BE%E0%A6%B9%E0%A6%A4%E0%A6%BF%20%E0%A6%AA%E0%A6%A4%E0%A7%8D%E0%A6%B0.pdf)

-   প্রস্তাবিত ইনভেস্ট বাংলাদেশ আইন, ২০২৬ এর প্রণীত খসড়ার বিষয়ে ই-মেইলঃ info@bida.gov.bd ঠিকানায় মতামত প্রদানের জন‍্য অনুরোধ করা হলো।

May 21, 2026

[Download](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a23d5ea08092d82f154a57b_Invest%20Bangladesh%20draft%20Act%20%20\(21%20May%202026\)%20v10.3.pdf)

-   Request for Expression of Interest (REOI) on “Hiring a National Consulting Firm to design and set up BIDA Overseas Office and to Recruit Consultants in Guangzhou, China”.

May 19, 2026

[Download](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a0c35db749f226928c8f325_Request%20for%20Expression%20of%20Interest%20\(REOI\).pdf)

-   Tender Notice (OTM)- Supply of Stationery Goods for BIDA

May 12, 2026

[Download](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a04271812699ebe7787b735_Tender%20Notice%20\(OTM\)-%20Supply%20of%20Stationery%20Goods%20for%20BIDA.pdf)

[1](#)

...

[![arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6820149c00aa5aab285f0043_Vector%20\(14\).svg)](?41f3f36c_page=2)

1 / 8

Result

TITLE

DATE

ACTION

-   Privacy Policy of Shuveccha / শুভেচ্ছা Shuveccha / শুভেচ্ছা Shuveccha / শুভেচ্ছা is an internet-based application designed especially for Non-Resident Bangladeshis (NRBs) — overseas citizens of the People's Republic of Bangladesh. The App offers secure access to services, communication supported, managed and governed by the Bangladesh Investment Development Authority (BIDA). The App is designed exclusively for NRBs and not accessible for Resident Bangladeshi nationals. 1. Information We Collect The app collects data strictly necessary to provide its services, ensure user safety, and optimize operational performance. The type of data collected includes: • Authentication and Profile Data o User ID and Password: For secure login with two-factor authentication. o Profile Data: Name, National ID/Passport Number, telephone and email contact addresses, resident country, and other details provided during registration to facilitate services and verify as an NRB. • Service and Communication Data o Service Requests: Metadata related to sent-in service requests, questions, and transactions (request type, timestamps, status changes). o Interaction Data: Metadata on interactions being performed over the App (sender/receiver ID, timestamp). Interaction data, if stored is encrypted and held on BIDA servers. o Support Interaction: Records of helpdesk data or support queries for quality control and troubleshooting purposes. • Location Data o Optional Location Tracking: Location data can be utilized when turned on by the user, e.g., for the purpose of authenticating eligibility for service or to provide location-based assistance. This is maintained only periodically to enable specific services. • Device Information o Device ID and Operating System: To ensure compatibility, security, and notification delivery. o Network Information: For enhanced connectivity and resolving technical issues. • Usage Data o App Use Data: Data on features utilized, usage frequency, and performance data are used for service optimization. These data are anonymized and aggregated where possible. 2. How We Use Information: Information collected by the application is used for the following purposes: • To enable secure services: Allow access to BIDA and NRB-related services like applications, support, and communication. • To authenticate and secure: Verify an individual as an NRB and protect the integrity of the platform. • To improve service efficiency: Enhance usage habits and performance statistics to improve service provision. • To facilitate NRB support: Ensure appropriate coordination with related agencies to fulfill NRB needs. • To comply with regulatory needs: Fulfill requirements as mandated by BIDA and applicable laws of Bangladesh. 3. Data Storage and Protection: • Encryption: Data in transit and stored data are encrypted. • Secure Servers: Data are maintained on secure servers owned by or under the control of BIDA in approved data centers within Bangladesh. • Access Control: Access is limited to authorized BIDA personnel or designated authorities with a legitimate need, on a role-based and permissioned basis. • Two-Factor Authentication: Login access can be secured with two-factor authentication means. • Security Audits: Regular audits and assessments are conducted to prevent unauthorized access. 4. Data Sharing and Disclosure • No Commercial Third-Party Sharing: Shuveccha / শুভেচ্ছা does not share personal data with external third parties for commercial or marketing reasons. • Internal Sharing (BIDA and Government Authorities): Data may be shared within BIDA and other concerned government departments strictly on a need-to-know basis for service facilitation, compliance with the law, or enforcement of policy. • Legal Compliance: Data can be disclosed if required by Bangladeshi law or legitimate legal processes. 5. Data Retention and Deletion • Retention: Data will be retained as long as necessary to fulfill service demands, comply with legal demands, and preserve the integrity of the application system. Retention durations are determined by BIDA policies. • Deletion: Deletion of an account or data can be submitted by users through official application support interfaces. These requests shall be processed in accordance with the policies of BIDA and applicable legislation. 6. User Rights Considering the distinctive purpose of Shuveccha / শুভেচ্ছা application as an online platform for Non-Resident Bangladeshis, user rights regarding access, correction, or removal of personal information are regulated by the governing laws and existing policies. These matters are not directly handled through the App. For requests or complaints regarding data, users are requested to use the official support channels included in the App and follow proper procedures. 7. Changes to This Privacy Policy We may update this Privacy Policy from time to time to reflect changes in our practices or due to operational, legal, or regulatory requirements. Updates will be communicated through the App and/or BIDA’s official channels. Continued use of the App after modifications constitutes acknowledgment of the updated policy. 8. Contact Information For any questions or concerns regarding this Privacy Policy or the Shuveccha / শুভেচ্ছা App, please contact the designated IT or administrative department of Bangladesh Investment Development Authority (BIDA) through your official internal communication channels.

Sep 12, 2025

[Download](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/68cba6e2bb4c5a02f9330ba5_Privacy%20Policy%20of%20Shuveccha.pdf)

[1](#)

...

Result

TITLE

DATE

ACTION

-   জনাব মোঃ নাইম হাসান খান, পিতাঃ সিরাজুল ইসলাম খান এর পাসপোর্ট করার জন্য অনাপত্তি প্রদান।

April 27, 2025

[Text Link](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685bbec5182784a6376582a1_%E0%A6%9C%E0%A6%A8%E0%A6%BE%E0%A6%AC%20%E0%A6%AE%E0%A7%8B%E0%A6%83%20%E0%A6%A8%E0%A6%BE%E0%A6%87%E0%A6%AE%20%E0%A6%B9%E0%A6%BE%E0%A6%B8%E0%A6%BE%E0%A6%A8%20%E0%A6%96%E0%A6%BE%E0%A6%A8%2C%20%E0%A6%AA%E0%A6%BF%E0%A6%A4%E0%A6%BE%E0%A6%83%20%E0%A6%B8%E0%A6%BF%E0%A6%B0%E0%A6%BE%E0%A6%9C%E0%A7%81%E0%A6%B2%20%E0%A6%87%E0%A6%B8%E0%A6%B2%E0%A6%BE%E0%A6%AE%20%E0%A6%96%E0%A6%BE%E0%A6%A8%20%E0%A6%8F%E0%A6%B0%20%E0%A6%AA%E0%A6%BE%E0%A6%B8%E0%A6%AA%E0%A7%8B%E0%A6%B0%E0%A7%8D%E0%A6%9F%20%E0%A6%95%E0%A6%B0%E0%A6%BE%E0%A6%B0%20%E0%A6%9C%E0%A6%A8%E0%A7%8D%E0%A6%AF%20%E0%A6%85%E0%A6%A8%E0%A6%BE%E0%A6%AA%E0%A6%A4%E0%A7%8D%E0%A6%A4%E0%A6%BF%20%E0%A6%AA%E0%A7%8D%E0%A6%B0%E0%A6%A6%E0%A6%BE%E0%A6%A8%E0%A5%A4.pdf)

-   বিডা'র উপপরিচালক (সিনিয়র সহকারী সচিব) জনাব নাশিদ কায়সার রিশাদ এর পাসপোর্ট অনাপত্তি সনদ।

February 9, 2025

[Text Link](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685bbed58941013b11904f07_%E0%A6%AC%E0%A6%BF%E0%A6%A1%E0%A6%BE_%E0%A6%B0%20%E0%A6%89%E0%A6%AA%E0%A6%AA%E0%A6%B0%E0%A6%BF%E0%A6%9A%E0%A6%BE%E0%A6%B2%E0%A6%95%20\(%E0%A6%B8%E0%A6%BF%E0%A6%A8%E0%A6%BF%E0%A7%9F%E0%A6%B0%20%E0%A6%B8%E0%A6%B9%E0%A6%95%E0%A6%BE%E0%A6%B0%E0%A7%80%20%E0%A6%B8%E0%A6%9A%E0%A6%BF%E0%A6%AC\)%20%E0%A6%9C%E0%A6%A8%E0%A6%BE%E0%A6%AC%20%E0%A6%A8%E0%A6%BE%E0%A6%B6%E0%A6%BF%E0%A6%A6%20%E0%A6%95%E0%A6%BE%E0%A7%9F%E0%A6%B8%E0%A6%BE%E0%A6%B0%20%E0%A6%B0%E0%A6%BF%E0%A6%B6%E0%A6%BE%E0%A6%A6%20%E0%A6%8F%E0%A6%B0%20%E0%A6%AA%E0%A6%BE%E0%A6%B8%E0%A6%AA%E0%A7%8B%E0%A6%B0%E0%A7%8D%E0%A6%9F%20%E0%A6%85%E0%A6%A8%E0%A6%BE%E0%A6%AA%E0%A6%A4%E0%A7%8D%E0%A6%A4%E0%A6%BF%20%E0%A6%B8%E0%A6%A8%E0%A6%A6%E0%A5%A4.pdf)

-   জনাব প্রণব কুমার রায়, পরিচালক (উপসচিব), বাংলাদেশ বিনিয়োগ উন্নয়ন কর্তৃপক্ষ, খুলনা এর পাসপোর্ট অনাপত্তি পত্র

January 27, 2025

[Text Link](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685d39452d6b35a5cb81c9eb_03%20%E0%A6%9C%E0%A6%A8%E0%A6%BE%E0%A6%AC%20%E0%A6%AA%E0%A7%8D%E0%A6%B0%E0%A6%A3%E0%A6%AC%20%E0%A6%95%E0%A7%81%E0%A6%AE%E0%A6%BE%E0%A6%B0%20%E0%A6%B0%E0%A6%BE%E0%A6%AF%E0%A6%BC%2C%20%E0%A6%AA%E0%A6%B0%E0%A6%BF%E0%A6%9A%E0%A6%BE%E0%A6%B2%E0%A6%95%20\(%E0%A6%89%E0%A6%AA%E0%A6%B8%E0%A6%9A%E0%A6%BF%E0%A6%AC\)%2C%20%E0%A6%AC%E0%A6%BE%E0%A6%82%E0%A6%B2%E0%A6%BE%E0%A6%A6%E0%A7%87%E0%A6%B6%20%E0%A6%AC%E0%A6%BF%E0%A6%A8%E0%A6%BF%E0%A6%AF%E0%A6%BC%E0%A7%8B%E0%A6%97%20%E0%A6%89%E0%A6%A8%E0%A7%8D%E0%A6%A8%E0%A6%AF%E0%A6%BC%E0%A6%A8%20%E0%A6%95%E0%A6%B0%E0%A7%8D%E0%A6%A4%E0%A7%83%E0%A6%AA%E0%A6%95%E0%A7%8D%E0%A6%B7.pdf)

[1](#)

...

[![arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6820149c00aa5aab285f0043_Vector%20\(14\).svg)](?925e8948_page=2)

1 / 29

Result

TITLE

DATE

ACTION

-   জনাব মোঃ নাইম হাসান খান, পিতাঃ সিরাজুল ইসলাম খান এর পাসপোর্ট করার জন্য অনাপত্তি প্রদান।

April 27, 2025

[](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685bbec5182784a6376582a1_%E0%A6%9C%E0%A6%A8%E0%A6%BE%E0%A6%AC%20%E0%A6%AE%E0%A7%8B%E0%A6%83%20%E0%A6%A8%E0%A6%BE%E0%A6%87%E0%A6%AE%20%E0%A6%B9%E0%A6%BE%E0%A6%B8%E0%A6%BE%E0%A6%A8%20%E0%A6%96%E0%A6%BE%E0%A6%A8%2C%20%E0%A6%AA%E0%A6%BF%E0%A6%A4%E0%A6%BE%E0%A6%83%20%E0%A6%B8%E0%A6%BF%E0%A6%B0%E0%A6%BE%E0%A6%9C%E0%A7%81%E0%A6%B2%20%E0%A6%87%E0%A6%B8%E0%A6%B2%E0%A6%BE%E0%A6%AE%20%E0%A6%96%E0%A6%BE%E0%A6%A8%20%E0%A6%8F%E0%A6%B0%20%E0%A6%AA%E0%A6%BE%E0%A6%B8%E0%A6%AA%E0%A7%8B%E0%A6%B0%E0%A7%8D%E0%A6%9F%20%E0%A6%95%E0%A6%B0%E0%A6%BE%E0%A6%B0%20%E0%A6%9C%E0%A6%A8%E0%A7%8D%E0%A6%AF%20%E0%A6%85%E0%A6%A8%E0%A6%BE%E0%A6%AA%E0%A6%A4%E0%A7%8D%E0%A6%A4%E0%A6%BF%20%E0%A6%AA%E0%A7%8D%E0%A6%B0%E0%A6%A6%E0%A6%BE%E0%A6%A8%E0%A5%A4.pdf)

-   বিডা'র উপপরিচালক (সিনিয়র সহকারী সচিব) জনাব নাশিদ কায়সার রিশাদ এর পাসপোর্ট অনাপত্তি সনদ।

February 9, 2025

[](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685bbed58941013b11904f07_%E0%A6%AC%E0%A6%BF%E0%A6%A1%E0%A6%BE_%E0%A6%B0%20%E0%A6%89%E0%A6%AA%E0%A6%AA%E0%A6%B0%E0%A6%BF%E0%A6%9A%E0%A6%BE%E0%A6%B2%E0%A6%95%20\(%E0%A6%B8%E0%A6%BF%E0%A6%A8%E0%A6%BF%E0%A7%9F%E0%A6%B0%20%E0%A6%B8%E0%A6%B9%E0%A6%95%E0%A6%BE%E0%A6%B0%E0%A7%80%20%E0%A6%B8%E0%A6%9A%E0%A6%BF%E0%A6%AC\)%20%E0%A6%9C%E0%A6%A8%E0%A6%BE%E0%A6%AC%20%E0%A6%A8%E0%A6%BE%E0%A6%B6%E0%A6%BF%E0%A6%A6%20%E0%A6%95%E0%A6%BE%E0%A7%9F%E0%A6%B8%E0%A6%BE%E0%A6%B0%20%E0%A6%B0%E0%A6%BF%E0%A6%B6%E0%A6%BE%E0%A6%A6%20%E0%A6%8F%E0%A6%B0%20%E0%A6%AA%E0%A6%BE%E0%A6%B8%E0%A6%AA%E0%A7%8B%E0%A6%B0%E0%A7%8D%E0%A6%9F%20%E0%A6%85%E0%A6%A8%E0%A6%BE%E0%A6%AA%E0%A6%A4%E0%A7%8D%E0%A6%A4%E0%A6%BF%20%E0%A6%B8%E0%A6%A8%E0%A6%A6%E0%A5%A4.pdf)

-   জনাব প্রণব কুমার রায়, পরিচালক (উপসচিব), বাংলাদেশ বিনিয়োগ উন্নয়ন কর্তৃপক্ষ, খুলনা এর পাসপোর্ট অনাপত্তি পত্র

January 27, 2025

[](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685d39452d6b35a5cb81c9eb_03%20%E0%A6%9C%E0%A6%A8%E0%A6%BE%E0%A6%AC%20%E0%A6%AA%E0%A7%8D%E0%A6%B0%E0%A6%A3%E0%A6%AC%20%E0%A6%95%E0%A7%81%E0%A6%AE%E0%A6%BE%E0%A6%B0%20%E0%A6%B0%E0%A6%BE%E0%A6%AF%E0%A6%BC%2C%20%E0%A6%AA%E0%A6%B0%E0%A6%BF%E0%A6%9A%E0%A6%BE%E0%A6%B2%E0%A6%95%20\(%E0%A6%89%E0%A6%AA%E0%A6%B8%E0%A6%9A%E0%A6%BF%E0%A6%AC\)%2C%20%E0%A6%AC%E0%A6%BE%E0%A6%82%E0%A6%B2%E0%A6%BE%E0%A6%A6%E0%A7%87%E0%A6%B6%20%E0%A6%AC%E0%A6%BF%E0%A6%A8%E0%A6%BF%E0%A6%AF%E0%A6%BC%E0%A7%8B%E0%A6%97%20%E0%A6%89%E0%A6%A8%E0%A7%8D%E0%A6%A8%E0%A6%AF%E0%A6%BC%E0%A6%A8%20%E0%A6%95%E0%A6%B0%E0%A7%8D%E0%A6%A4%E0%A7%83%E0%A6%AA%E0%A6%95%E0%A7%8D%E0%A6%B7.pdf)

[1](#)

...

[![arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6820149c00aa5aab285f0043_Vector%20\(14\).svg)](?28c48b5d_page=2)

1 / 29

NOC / GO

TITLE

DATE

ACTION

-   NOC of Mr. Md. Yousuf, Investment Assistant, Bangladesh Investment Development Authority (BIDA)

Feb 26, 2026

[Download](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69a00e42b5a07db0b942cebd_NOC%20Mr.%20Md.%20Yousuf%2C%20Investment%20Assistant%2C%20Bangladesh%20Investment%20Development%20Authority%20\(BIDA\).pdf)

-   উপপরিচালক নাশিদ কায়সার রিয়াদ, পাসপোর্ট এনওসি

Jan 25, 2026

[Download](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6975c652b527500334edf569_%E0%A6%89%E0%A6%AA%E0%A6%AA%E0%A6%B0%E0%A6%BF%E0%A6%9A%E0%A6%BE%E0%A6%B2%E0%A6%95%20%E0%A6%A8%E0%A6%BE%E0%A6%B6%E0%A6%BF%E0%A6%A6%20%E0%A6%95%E0%A6%BE%E0%A7%9F%E0%A6%B8%E0%A6%BE%E0%A6%B0%20%E0%A6%B0%E0%A6%BF%E0%A7%9F%E0%A6%BE%E0%A6%A6%2C%20%E0%A6%AA%E0%A6%BE%E0%A6%B8%E0%A6%AA%E0%A7%8B%E0%A6%B0%E0%A7%8D%E0%A6%9F%20%E0%A6%8F%E0%A6%A8%E0%A6%93%E0%A6%B8%E0%A6%BF.pdf)

-   জনাব মোঃ মনিবুর রহমান, ঊর্ধ্বতন বিনিয়োগ সহকারী, বাংলাদেশ বিনিয়োগ উন্নয়ন কর্তৃপক্ষ এর পাসপোর্ট অনাপত্তি সনদ

Jan 12, 2026

[Download](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6964953a516c536fe3e986e6_CamScanner%2001-12-2026%2012.25.pdf)

-   GO for Abdur Rahaman, Driver, Bangladesh Investment Development Authority

Dec 23, 2025

[Download](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/694b64e69bf23f25ee434740_Abdur%20Rahaman%20\(Leave\).pdf)

-   জনাব সুদীপ্ত ভৌমিক দীপ, নির্বাহী চেয়ারম্যানের সহকারী একান্ত সচিব বাংলাদেশ বিনিয়োগ উন্নয়ন কর্তৃপক্ষ এর পাসপোর্ট অনাপত্তি

Nov 24, 2025

[Download](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69243995b06e917f8b00f0e9_%E0%A6%9C%E0%A6%A8%E0%A6%BE%E0%A6%AC%20%E0%A6%B8%E0%A7%81%E0%A6%A6%E0%A7%80%E0%A6%AA%E0%A7%8D%E0%A6%A4%20%E0%A6%AD%E0%A7%8C%E0%A6%AE%E0%A6%BF%E0%A6%95%20%E0%A6%A6%E0%A7%80%E0%A6%AA%2C%20%E0%A6%A8%E0%A6%BF%E0%A6%B0%E0%A7%8D%E0%A6%AC%E0%A6%BE%E0%A6%B9%E0%A7%80%20%E0%A6%9A%E0%A7%87%E0%A7%9F%E0%A6%BE%E0%A6%B0%E0%A6%AE%E0%A7%8D%E0%A6%AF%E0%A6%BE%E0%A6%A8%E0%A7%87%E0%A6%B0%20%E0%A6%B8%E0%A6%B9%E0%A6%95%E0%A6%BE%E0%A6%B0%E0%A7%80%20%E0%A6%8F%E0%A6%95%E0%A6%BE%E0%A6%A8%E0%A7%8D%E0%A6%A4%20%E0%A6%B8%E0%A6%9A%E0%A6%BF%E0%A6%AC%20%E0%A6%AC%E0%A6%BE%E0%A6%82%E0%A6%B2%E0%A6%BE%E0%A6%A6%E0%A7%87%E0%A6%B6%20%E0%A6%AC%E0%A6%BF%E0%A6%A8%E0%A6%BF%E0%A7%9F%E0%A7%8B%E0%A6%97%20%E0%A6%89%E0%A6%A8%E0%A7%8D%E0%A6%A8%E0%A7%9F%E0%A6%A8%20%E0%A6%95%E0%A6%B0%E0%A7%8D%E0%A6%A4%E0%A7%83.pdf)

-   মোছাঃ শামীমা আক্তার পরিচালক (উপসচিব), বাংলাদেশ বিনিয়োগ উন্নয়ন কর্তৃপক্ষ এর পাসপোর্ট অনাপত্তি সনদ।

Nov 19, 2025

[Download](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/691d680bfa53351d48c38594_%E0%A6%AA%E0%A6%BE%E0%A6%B8%E0%A6%AA%E0%A7%8B%E0%A6%B0%E0%A7%8D%E0%A6%9F%20%E0%A6%85%E0%A6%A8%E0%A6%BE%E0%A6%AA%E0%A6%BF%E0%A6%93%20%E0%A6%B8%E0%A6%A8%E0%A6%A6%E0%A5%A4%20%E0%A6%AE%E0%A7%8B%E0%A6%9B%E0%A6%BE_%20%E0%A6%B8%E0%A6%AE%E0%A7%80%E0%A6%AE%E0%A6%BE%20%E0%A6%86%E0%A6%95%E0%A7%8D%E0%A6%A4%E0%A6%BE%E0%A6%B0.pdf)

-   জনাব ফাতেমা বেগম ও তার ২ (দুই) পুত্রের পাসপোর্ট করার জন্য অনাপত্তি প্রদান

Nov 2, 2025

[Download](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6906f6026c5b3049ddd9434e_DOC-20251029-WA0007.\(2\).pdf)

-   বিডার অফিস সহায়ক জনাব মজিবুর রহমান এর পাসপোর্ট করার জন্য NOC

Oct 28, 2025

[Download](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6902e18cd45f9dc6cbc6e659_Document%2039.pdf)

[1](#FAQ)

...

[![arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6820149c00aa5aab285f0043_Vector%20\(14\).svg)](?6b1f6838_page=2)

1 / 4

Meeting Notices

TITLE

DATE

ACTION

-   মহান বিজয় দিবস ২০২৪ যথাযোগ্য মর্যাদায় উদযাপনের লক্ষ্যে বাংলাদেশ বিনিয়োগ উন্নয়ন কর্তৃপক্ষ (বিডা) কর্তৃক গৃহীত কর্মসূচি

Dec 15, 2024

[Download](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685d5111aec7cf4c4a246c40_01%20%E0%A6%AE%E0%A6%B9%E0%A6%BE%E0%A6%A8%20%E0%A6%AC%E0%A6%BF%E0%A6%9C%E0%A6%AF%E0%A6%BC%20%E0%A6%A6%E0%A6%BF%E0%A6%AC%E0%A6%B8%20%E0%A7%A8%E0%A7%A6%E0%A7%A8%E0%A7%AA%20%E0%A6%AF%E0%A6%A5%E0%A6%BE%E0%A6%AF%E0%A7%8B%E0%A6%97%E0%A7%8D%E0%A6%AF%20%E0%A6%AE%E0%A6%B0%E0%A7%8D%E0%A6%AF%E0%A6%BE%E0%A6%A6%E0%A6%BE%E0%A6%AF%E0%A6%BC%20%E0%A6%89%E0%A6%A6%E0%A6%AF%E0%A6%BE%E0%A6%AA%E0%A6%A8%E0%A7%87%E0%A6%B0%20%E0%A6%B2%E0%A6%95%E0%A7%8D%E0%A6%B7%E0%A7%8D%E0%A6%AF%E0%A7%87%20%E0%A6%AC%E0%A6%BE%E0%A6%82%E0%A6%B2%E0%A6%BE%E0%A6%A6%E0%A7%87%E0%A6%B6%20%E0%A6%AC%E0%A6%BF%E0%A6%A8%E0%A6%BF%E0%A6%AF%E0%A6%BC%E0%A7%8B%E0%A6%97.pdf)

[1](#)

...

Other Notices

TITLE

DATE

ACTION

-   অফিস আদেশ (কর্মকর্তা পদায়নকৃত সংক্রান্ত)

Jul 2, 2026

[Download](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a46155671b7ed4bf4a34063_%E0%A6%85%E0%A6%AB%E0%A6%BF%E0%A6%B8%20%E0%A6%86%E0%A6%A6%E0%A7%87%E0%A6%B6%20\(%E0%A6%95%E0%A6%B0%E0%A7%8D%E0%A6%AE%E0%A6%95%E0%A6%B0%E0%A7%8D%E0%A6%A4%E0%A6%BE%20%E0%A6%AA%E0%A6%A6%E0%A6%BE%E0%A6%AF%E0%A6%BC%E0%A6%A8%E0%A6%95%E0%A7%83%E0%A6%A4%20%E0%A6%B8%E0%A6%82%E0%A6%95%E0%A7%8D%E0%A6%B0%E0%A6%BE%E0%A6%A8%E0%A7%8D%E0%A6%A4\).pdf)

-   Appointment letter of Md. Abdullah Al Noman

Jun 23, 2026

[Download](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3b4ff0b20cb4ab3caccc3a_WhatsApp%20Image%202026-06-23%20at%203.18.01%20PM.jpeg)

-   নির্বাহী চেয়ারম্যান মহোদয়ের সহকারী একান্ত সচিব এর যোগদানপত্র

Jun 21, 2026

[Download](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a378474a228486a7c7ca002_%E0%A6%A8%E0%A6%BF%E0%A6%B0%E0%A7%8D%E0%A6%AC%E0%A6%BE%E0%A6%B9%E0%A7%80%20%E0%A6%9A%E0%A7%87%E0%A7%9F%E0%A6%BE%E0%A6%B0%E0%A6%AE%E0%A7%8D%E0%A6%AF%E0%A6%BE%E0%A6%A8%20%E0%A6%AE%E0%A6%B9%E0%A7%8B%E0%A6%A6%E0%A7%9F%E0%A7%87%E0%A6%B0%20%E0%A6%B8%E0%A6%B9%E0%A6%95%E0%A6%BE%E0%A6%B0%E0%A7%80%20%E0%A6%8F%E0%A6%95%E0%A6%BE%E0%A6%A8%E0%A7%8D%E0%A6%A4%20%E0%A6%B8%E0%A6%9A%E0%A6%BF%E0%A6%AC%20%E0%A6%8F%E0%A6%B0%20%E0%A6%AF%E0%A7%8B%E0%A6%97%E0%A6%A6%E0%A6%BE%E0%A6%A8%E0%A6%AA%E0%A6%A4%E0%A7%8D%E0%A6%B0.pdf)

-   Notice To Formalise Work Visa or Work Permit

Jun 8, 2026

[Download](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a26ae686e6131eea8c72615_BIDA%20NOTICE-303.pdf)

-   সহকারী পরিচালক মিজ শ্রাবনী বসু এর অব্যাহতি পত্র

Jun 8, 2026

[Download](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a26457f1c846f2864a932b9_%E0%A6%B8%E0%A6%B9%E0%A6%95%E0%A6%BE%E0%A6%B0%E0%A7%80%20%E0%A6%AA%E0%A6%B0%E0%A6%BF%E0%A6%9A%E0%A6%BE%E0%A6%B2%E0%A6%95%20%E0%A6%AE%E0%A6%BF%E0%A6%9C%20%E0%A6%B6%E0%A7%8D%E0%A6%B0%E0%A6%BE%E0%A6%AC%E0%A6%A8%E0%A7%80%20%E0%A6%AC%E0%A6%B8%E0%A7%81%20%E0%A6%8F%E0%A6%B0%20%E0%A6%85%E0%A6%AC%E0%A7%8D%E0%A6%AF%E0%A6%BE%E0%A6%B9%E0%A6%A4%E0%A6%BF%20%E0%A6%AA%E0%A6%A4%E0%A7%8D%E0%A6%B0.pdf)

-   প্রস্তাবিত ইনভেস্ট বাংলাদেশ আইন, ২০২৬ এর প্রণীত খসড়ার বিষয়ে ই-মেইলঃ info@bida.gov.bd ঠিকানায় মতামত প্রদানের জন‍্য অনুরোধ করা হলো।

May 21, 2026

[Download](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a23d5ea08092d82f154a57b_Invest%20Bangladesh%20draft%20Act%20%20\(21%20May%202026\)%20v10.3.pdf)

-   Request for Expression of Interest (REOI) on “Hiring a National Consulting Firm to design and set up BIDA Overseas Office and to Recruit Consultants in Guangzhou, China”.

May 19, 2026

[Download](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a0c35db749f226928c8f325_Request%20for%20Expression%20of%20Interest%20\(REOI\).pdf)

-   Tender Notice (OTM)- Supply of Stationery Goods for BIDA

May 12, 2026

[Download](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a04271812699ebe7787b735_Tender%20Notice%20\(OTM\)-%20Supply%20of%20Stationery%20Goods%20for%20BIDA.pdf)

[1](#other-notices)

...

[![arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6820149c00aa5aab285f0043_Vector%20\(14\).svg)](?2626aa52_page=2)

1 / 8

Privacy Policy

TITLE

DATE

ACTION

-   Privacy Policy of Shuveccha / শুভেচ্ছা Shuveccha / শুভেচ্ছা Shuveccha / শুভেচ্ছা is an internet-based application designed especially for Non-Resident Bangladeshis (NRBs) — overseas citizens of the People's Republic of Bangladesh. The App offers secure access to services, communication supported, managed and governed by the Bangladesh Investment Development Authority (BIDA). The App is designed exclusively for NRBs and not accessible for Resident Bangladeshi nationals. 1. Information We Collect The app collects data strictly necessary to provide its services, ensure user safety, and optimize operational performance. The type of data collected includes: • Authentication and Profile Data o User ID and Password: For secure login with two-factor authentication. o Profile Data: Name, National ID/Passport Number, telephone and email contact addresses, resident country, and other details provided during registration to facilitate services and verify as an NRB. • Service and Communication Data o Service Requests: Metadata related to sent-in service requests, questions, and transactions (request type, timestamps, status changes). o Interaction Data: Metadata on interactions being performed over the App (sender/receiver ID, timestamp). Interaction data, if stored is encrypted and held on BIDA servers. o Support Interaction: Records of helpdesk data or support queries for quality control and troubleshooting purposes. • Location Data o Optional Location Tracking: Location data can be utilized when turned on by the user, e.g., for the purpose of authenticating eligibility for service or to provide location-based assistance. This is maintained only periodically to enable specific services. • Device Information o Device ID and Operating System: To ensure compatibility, security, and notification delivery. o Network Information: For enhanced connectivity and resolving technical issues. • Usage Data o App Use Data: Data on features utilized, usage frequency, and performance data are used for service optimization. These data are anonymized and aggregated where possible. 2. How We Use Information: Information collected by the application is used for the following purposes: • To enable secure services: Allow access to BIDA and NRB-related services like applications, support, and communication. • To authenticate and secure: Verify an individual as an NRB and protect the integrity of the platform. • To improve service efficiency: Enhance usage habits and performance statistics to improve service provision. • To facilitate NRB support: Ensure appropriate coordination with related agencies to fulfill NRB needs. • To comply with regulatory needs: Fulfill requirements as mandated by BIDA and applicable laws of Bangladesh. 3. Data Storage and Protection: • Encryption: Data in transit and stored data are encrypted. • Secure Servers: Data are maintained on secure servers owned by or under the control of BIDA in approved data centers within Bangladesh. • Access Control: Access is limited to authorized BIDA personnel or designated authorities with a legitimate need, on a role-based and permissioned basis. • Two-Factor Authentication: Login access can be secured with two-factor authentication means. • Security Audits: Regular audits and assessments are conducted to prevent unauthorized access. 4. Data Sharing and Disclosure • No Commercial Third-Party Sharing: Shuveccha / শুভেচ্ছা does not share personal data with external third parties for commercial or marketing reasons. • Internal Sharing (BIDA and Government Authorities): Data may be shared within BIDA and other concerned government departments strictly on a need-to-know basis for service facilitation, compliance with the law, or enforcement of policy. • Legal Compliance: Data can be disclosed if required by Bangladeshi law or legitimate legal processes. 5. Data Retention and Deletion • Retention: Data will be retained as long as necessary to fulfill service demands, comply with legal demands, and preserve the integrity of the application system. Retention durations are determined by BIDA policies. • Deletion: Deletion of an account or data can be submitted by users through official application support interfaces. These requests shall be processed in accordance with the policies of BIDA and applicable legislation. 6. User Rights Considering the distinctive purpose of Shuveccha / শুভেচ্ছা application as an online platform for Non-Resident Bangladeshis, user rights regarding access, correction, or removal of personal information are regulated by the governing laws and existing policies. These matters are not directly handled through the App. For requests or complaints regarding data, users are requested to use the official support channels included in the App and follow proper procedures. 7. Changes to This Privacy Policy We may update this Privacy Policy from time to time to reflect changes in our practices or due to operational, legal, or regulatory requirements. Updates will be communicated through the App and/or BIDA’s official channels. Continued use of the App after modifications constitutes acknowledgment of the updated policy. 8. Contact Information For any questions or concerns regarding this Privacy Policy or the Shuveccha / শুভেচ্ছা App, please contact the designated IT or administrative department of Bangladesh Investment Development Authority (BIDA) through your official internal communication channels.

Sep 12, 2025

[Download](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/68cba6e2bb4c5a02f9330ba5_Privacy%20Policy%20of%20Shuveccha.pdf)

[1](#)

...

#### BOOK AN APPOINTMENT

##### SERVICE

New Business Opportunities

Registration & Approvals

Regulatory Facilitation

Visa & Work Permit Support

Aftercare

Policy & Sectoral Guidance

##### REQUESTED DATE

##### REQUESTED TIME

**Thank you!**  
Your appointment request has been submitted.  
If approved, a confirmation email will be sent to you.

Oops! Something went wrong while submitting the form.