---
source: "Bangladesh Investment Development Authority (BIDA)"
tier: 1
category: "Government / regulator"
url: "https://bida.gov.bd/foreign-joint-venture-projects"
title: "BIDA | Foreign & Joint Venture Investment in Bangladesh"
scraped_at: "2026-07-02"
---

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/686cf7286136ad1eee6ed377_Layer_1%20\(1\).svg)](/)

[中文](/china)[BIDA OSS](/services#one-stop-services)[

Matchmakin

](https://uat-irms.oss.net.bd/matchmaking)

![bida search icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678cd4d48720bb0edd6ad500_Group%2055.svg)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/68945f6c4818ae3dc291a664_Layer_1.svg)![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![search](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6788a1c48788ea23e00ed88c_Group%2055%20\(1\).webp)

![humbergur](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678896a2d5b4ac64ddac5e2a_Group%2096%20\(3\).webp)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

-   [home](/)

-   [OPPORTUNITIES](/opportunities)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [Services](/services)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [RESOURCES](/resources)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [ABOUT BIDA](/about-bida)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [NOTICE](/notices)

[BIDA OSS](https://www.investbangladesh.gov.bd/services#one-stop-service)[中文](/china)[

MATCHMAKING

](https://uat-irms.oss.net.bd/matchmaking)

# Foreign & Joint Venture Projects

Services for 100% Foreign & Joint Venture Projects at BIDA

## SERVICES

BIDA Registration

Industrial project registration (new)

Documents Needed

-   Certificate of Incorporation
-   Memorandum and Article of Association
-   Up-to-date Trade License
-   Up-to-date TIN Certificate
-   Land Purchase/Rental deed agreement (office and Factory) of Project
-   Encashment certificate
-   Form VI, XII approved by RJSC&F
-   According to the "National Industrial Policy, 2022" NOC from concern Ministry/Directorate/Department for the controlled sector to be submitted
-   Others necessary documents (please attach if any)
-   Attachment of Company's Comments as per BIDA Requirement

Mode

[BIDA One Stop Service  
(OSS)](https://www.investbangladesh.gov.bd/services#bida-one-stop-service)

Fee

Registration fee based on Project Investment: 

-   Up to 1 Tk. 10 Crore - Tk.5,000/-
-   10 Crore Tk. 25 Crore - Tk. 10,000/-
-   25 Crore Tk. 50 Crore - Tk. 25,000/-
-   50 Crore Tk. 100 Crore - Tk. 50,000/-
-   100 Crore Tk. Above - Tk. 1,00,000/-

\+ 15% VAT

Online payment through BIDA One Stop Service (OSS)

Time

1 day  
Subject to submission of necessary documents

Amendment

Documents Needed

-   BIDA Registration Certificate
-   Copy of Board Resolution amendment related documents
-   Certificate of Incorporation
-   Memorandum & article of Association
-   Up-to-date Trade License
-   Up-to-date TIN Certificate
-   Land Purchase/Rental deed agreement of Project
-   List of Directors with Nationality & Address
-   Encashment certificate
-   Project profile if project cost is 100 million above
-   According to the "National Industrial Policy, 2022" NOC from concern Ministry/Directorate/ Department for the controlled sector to be submitted
-   Previous all BIDA Registration Amendment Certificate
-   Attachment of Company's Comments as per BIDA Requirement
-   Others necessary documents (please attach if any)

Mode

[BIDA One Stop Service  
(OSS)](https://www.investbangladesh.gov.bd/services#bida-one-stop-service)

Fee

Amendment fee Tk. 1000/-

\+ 15% VAT

Online payment through BIDA One Stop Service (OSS)

Time

3 working  
days  
Subject to submission of necessary documents

Types of project registration amendment

Clause no

Clause no 1

Amendment Type

Name of the company

Documents needed

1 . Board resolution regarding the name of the company

2\. Up-to-date incorporation certificate for the proposed name

Clause no 2

Office Address

1 . Board resolution regarding the office address

2\. Up-to-date trade license

3\. Form VI approved by the RJSC&F (for Office address change)

4\. Land Deed/Lease agreement (mentioning Office & Factory address)

Clause no 3

Factory Address

1 . Board Resolution regarding Factory Address

2\. Up-to-date trade license

3\. Land Deed/Lease agreement (mentioning Office & Factory address)

Clause no 4

Type of Industry

1 . Board Resolution regarding type of industry

2\. Explanation letter regarding the change of industry type

3\. Up-to-date revised machinery list (if applicable)

Clause no 5

Nature of Investment (Joint venture or 100% foreign)

If (JV to Foreign) / (Foreign to JV)

1 . Board Resolution regarding nature of investment

2\. Schedule X approved by the RJSC&F

3\. Form 117, XV, XII approved by the RJSC&F

Clause no 6

Investing Country (Joint venture or 100% foreign)

1 . Board Resolution regarding investing country

2\. Form 117 approved by the RJSC&F

Clause no 7

Date of Commercial Production of the Project

1 . Board Resolution regarding date of commercial production of the project

2\. Rational Explanation Letter

3\. NOC from concerned Ministry/Directorate/Department (Only applicable for controlled industry)

Clause no 8

Annual Production Capacity

1 . Board Resolution regarding annual production capacity

2\. Rational Explanation Letter regarding Annual Production Capacity

Clause no 9

List of Machineries

1 . Board Resolution regarding list of machineries

2\. Proforma invoice/ commercial invoice/any other relevant documents for verifying the value of the machinery

Clause no 10

Sales

1\. Board Resolution regarding sales

2\. Rational Explanation Letter

Clause no 11

Investment

1 . Board Resolution regarding investment

2\. Form 117 for share transfer, XV for new share allotment

Clause no 12

Equity

1 . Board Resolution regarding equity

2 . From 117 for changing paid of capital

Clause no 13

Number of Employees

1 . Board Resolution regarding Number of Employees

2\. Schedule II of the Labor Law 2015

3\. Rational Explanation Letter

Clause no 14

Name & address of the investors

1 . Board Resolution regarding name & address of the investors

2 . Form 117, XII, XV approved by the RJSC & F

3 . Schedule X approved by the RJSC & F

IRC recommendation

First Ad-Hoc

Documents Needed

-   BIDA Registration along with the last amendment
-   Copy of Trade License against factory address
-   Copy of TIN certificate
-   Copy of incorporation certificate and memorandum in case of company
-   Memorandum and Article of Association
-   Copy of Fire License
-   Copy of Bank Solvency certificate issued by concerned bank
-   Copy of Membership certificate of the concerned association
-   Copy of Environment/Site clearance certificate
-   LC copy against machineries imported and purchase voucher in case of locally procured machineries
-   Import criteria (List of the importable raw materials for producing per unit (Kg/Matric ton/ dozen/etc.) product finished goods
-   Attachment of Company's Comments as per BIDA Requirement
-   Others necessary documents (please attach if any)

Mode

[BIDA One Stop Service  
(OSS)](https://www.investbangladesh.gov.bd/services#bida-one-stop-service)

Fee

No fees

Time

10 working days  
Subject to submission of necessary documents

The Office of Chief Controller of Imports and Exports (CCI&E) will receive the recommendation through API & Email.

Second Ad-Hoc  
Note: If the company fails to import minimum 70% of total import capacity, 2nd adhoc is applicable

Documents Needed

-   BIDA Registration along with last amendment
-   Copy of Trade License against factory address
-   Copy of TIN certificate
-   Copy of Fire License
-   Copy of Environment/Site clearance certificate
-   Copy of incorporation certificate and memorandum / partnership deed
-   Sales statement (with monthly challan / Export statement Issued by Bank
-   Copy of Membership certificate of the concerned association
-   Import statement of Raw Materials / Spare parts issued by bank with LC
-   Attachment of Company's Comments as per BIDA Requirement
-   Others necessary documents (please attach if any)
-   Copy of 1st IRC approved Copy
-   Copy of 1st IRC approved Production Capacity and Entitlement paper

Mode

[BIDA One Stop Service  
(OSS)](https://www.investbangladesh.gov.bd/services#bida-one-stop-service)

Fee

No Fees

Time

10 working days  
Subject to submission of necessary documents

Third Ad-Hoc  
(If the company fails to import minimum 70% of total import capacity, 3rd adhoc is applicable)

Documents Needed

-   BIDA Registration along with last amendment
-   Copy of 1st & 2nd Adhoc IRC Recommendation letter issued by BIDA
-   Copy of Industrial IRC
-   Copy of Update TIN certificate
-   Copy of Update Trade License
-   Copy of Environment/Site clearance certificate
-   Copy of Update Fire License
-   Copy of Bank Import Statement issued by concerned bank
-   Copy of Bank Export Statement issued by concerned bank
-   Copy of installment Machinery List
-   Attachment of Company's Comments as per BIDA Requirement

Mode

[BIDA One Stop Service  
(OSS)](https://www.investbangladesh.gov.bd/services#bida-one-stop-service)

Fee

No fees

Time

10 working days  
Subject to submission of necessary documents

Regular

Documents Needed

-   Copy of BOI/BIDA registration (including all amendment)
-   Recommendation letter of 1st Adhoc, 2nd Adhoc/3rd Adhoc (with entitle paper)
-   Import statement of raw materials/spare parts from Lien Bank
-   Sales/Export statements (with report of Lien bank)
-   Copy of MUSHAK form-9.1 (VAT Challan)
-   Incorporation certificate
-   Copy of Trade License issued by concern authority of the factory location mentioning specific sector
-   TIN Certificate
-   Fire License (Up to Date)
-   Environment clearance Certificate/NOC (Up to Date)
-   Membership of concern association (Up to Date)
-   Machinery List Local /Imported (SL No, Name of Machine, Quantity and value (in million Tk./US$)
-   Attachment of Company's Comments as per BIDA Requirement
-   Others necessary documents (please attach if any)

Mode

[BIDA One Stop Service  
(OSS)](https://www.investbangladesh.gov.bd/services#bida-one-stop-service)

Fee

No fees

Time

10 working days  
Subject to submission of necessary documents

Import Permission (Capital machineries)

Documents Needed

-   Copy of BOI/BIDA registration (include all amendment)
-   Commercial Invoice
-   Bill of Lading/Air way bill/Consignment note
-   Packing List
-   Certificate of Origin
-   Survey report in case of used / running machinery
-   Attachment of Company's Comments as per BIDA Requirement
-   Others necessary documents (please attach if any)

Mode

[BIDA One Stop Service  
(OSS)](https://www.investbangladesh.gov.bd/services#bida-one-stop-service)

Fee

No fees

Time

3 working days  
Subject to submission of necessary documents

Amalgamation

Documents Needed

-   Forwarding letter submitted to Director General, Registration and Incentives Foreign Industry, Bangladesh Investment Development Authority, Dhaka by Chairman/Managing Director of the company/ Organization in official pad
-   Copy of BOI/BIDA registration
-   Board Resolution of the Company regarding amalgamation
-   List of machinery local/To be imported (Sl. No, Name of machinery, Quantity and value million Tk.)
-   Scheme of Amalgamation from in the Supreme Court of Bangladesh (High Court Division)

Mode

In-person submission

Fee

BDT 1000/- &  
15%  VAT is applicable against the said fee  
pay order in favor of “Bangladesh Investment Development Authority”

Time

15 days  
Subject to submission of necessary documents. & Subject to approval of Executive Committee meeting & submission of necessary documents

Agreement approval of remittances in relation to royalty fees, technical assistance fees, technical know-how/technical knowledge, Franchise fees

Documents Needed

-   Forwarding letter submitted to Director General, Registration and Incentives Foreign Industry, Bangladesh Investment Development Authority, Dhaka by Chairman/Managing Director of the company/Organization in official Letter head pad/Submission Online Application
-   A copy of Registration letter issued by the Bangladesh Investment Development Authority (BIDA)
-   Tow copies of Technology Transfer Agreement (Royalty/ Technical Know-how/Technical Assistance/Franchise Agreement)
-   Filled-in Prescribed Application Form supplied by BIDA signed by the Managing Director/Managing Partner/Proprietor;
-   Resolution of the Board of Directors of the company/Partners of the Firm regarding remittance of fees/showing amount, due year of remittance and name & address of the foreign service provider as per Agreement
-   A copy of Annual Report of the company/Firm comprising Audited Balance Sheet along with the Profit and Loss Accounts (in case of the project in operation) or Bill of Entry/Invoices of the Imported Machinery (in case of under implementation project)
-   Income Tax Return certified/authenticated/attested by Chartered Accountant Firm for the concerned Assessment Year along with Computation Sheet for taxable income for the same period and Tax Clearance Certificate issued by Deputy Commissioner of Taxes of the concerned Tax Circle
-   A copy of Memorandum & Articles of Association and Certificate of Incorporation of the company (if not submitted earlier)
-   Invoice(s) in support of fees to be remitted
-   Authenticated Banking documents showing Export Earning (if any)
-   Attested copy of Patent Right/Trade Mark/Brand Name Registration in Bangladesh (if any)

( All documents shall have to be attested by the Chairman/Managing Director/Director of  the company)

Mode

In-person submission

Fee

Annual fee (Partial year shall be counted as full year)- BDT .50,000/-  
& 15% VAT is applicable against the said fee

pay order in favor of “Bangladesh Investment Development Authority”

Time

28 days  
&  
Subject to approval of Executive Committee meeting & submission of necessary documents.

VISA RECOMMENDATION FOR FOREIGN & JV PROJECTS

E-Visa Recommendation

Documents Needed

Paper's/documents needed for recommendation of 'E' (Employment) type Visa in favor of the expatriate's:

-   Copy of the registration letter of the Bangladesh Investment Development Authority, if not submitted earlier
-   Copy of the memorandum and articles of the association
-   Certificate of incorporation in case of the locally incorporated company
-   Board Resolution for employment of the foreign nation(s) mentioning Expatriate Name, Nationality & Passport Number
-   Photograph of the Expatriate
-   Copy of passport (Full set) of the Expatriate (Whole of the used part)
-   Appointment Letter/Service Agreement/Transfer Letter of the expatriate
-   Certificate of all academic qualification & professional experience of the employee
-   Copy of the advertisement prior to the appointment of the expatriate with date of publishing and URL of the online advertisement
-   Specific activities of the company
-   Statement of manpower showing list of the local and expatriate personnel employed with designation, salary break-up, nationality and date of first appointment

NB:

-   (a) All documents shall have to be attested by the Chairman/CEO/Managing director/Country Manager/Chief executive of the Company/firms
-   (b) Document's must be submitted by an authorized person of the organization including the letter of authorization

Mode

[BIDA One Stop Service  
(OSS)](https://www.investbangladesh.gov.bd/services#bida-one-stop-service)

Fee

No fees

Time

24 Hrs.  
(1 day)

E1-Visa Recommendation

Documents Needed

Paper's/documents needed for recommendation of 'E' (Employment) type Visa in favor of the expatriate's:

-   Copy of the registration letter of the Bangladesh Investment Development Authority, if not submitted earlier
-   Copy of the memorandum and articles of the association
-   Certificate of incorporation in case of the locally incorporated company
-   Board Resolution for employment of the foreign nation(s) mentioning Expatriate Name, Nationality & Passport Number
-   Photograph of the Expatriate.
-   Copy of passport (Full set) of the Expatriate (Whole of the used part)
-   Appointment Letter/Service Agreement/Transfer Letter of the expatriate
-   Certificate of all academic qualification & professional experience of the employee
-   Copy of the advertisement prior to the appointment of the expatriate with date of publishing and URL of the online advertisement
-   Specific activities of the company
-   Statement of manpower showing list of the local and expatriate personnel employed with designation, salary break-up, nationality and date of first appointment

NB:

-   All documents shall have to be attested by the Chairman/ CEO / Managing director/ Country Manager/ Chief executive of the Company/ firms
-   Document's must be submitted by an authorized person of the organization including the letter of authorization

Mode

[BIDA One Stop Service  
(OSS)](https://www.investbangladesh.gov.bd/services#bida-one-stop-service)

Fee

No fees

Time

24 Hrs.  
(1 day)

P1-Visa Recommendation

Documents Needed

Paper's/ documents needed for recommendation of 'PI' (Private Investor) type Visa in favor of the expatriate's:

-   Copy of BOI/BIDA registration
-   Memorandum & article of Association. and certificate of incorporation of the company
-   Board Resolution for employment of foreign national’s mentioning private investor’s Name, Nationality & Passport Number
-   Photograph of the Investor
-   Copy of passport (Full set) of the Investor (Whole of the used part)
-   Specific activity of the company
-   Statement of manpower showing list of the local & expatriate personnel employed with designation, salary break-up, nationality and date of first appointment

NB:

-   All documents shall have to be attested by the Chairman/ CEO / Managing director/ Country Manager/ Chief executive of the Company/ firms
-   Document's must be submitted by an authorized person of the organization including the letter of authorization

Mode

[BIDA One Stop Service  
(OSS)](https://www.investbangladesh.gov.bd/services#bida-one-stop-service)

Fee

No fees

Time

24 Hrs.  
(1 day)

WORK PERMIT FOR FOREIGN & JV PROJECTS

New Work Permit

Documents Needed

Necessary documents for New Work Permit of employment of expatriate:

-   Copy of registration letter of the Bangladesh Investment Development Authority, if not submitted earlier
-   Board Resolution for employment of foreign nation(s) mentioning Expatriate Name, Nationality, Passport Number & Salary
-   Memorandum & Articles of Association of the company duly signed by shareholders along with Certificate of Incorporation (In case of limited company), if not submitted earlier
-   Copy of passport with E/PI VISA and arrival stamps for employees/Investors
-   Copy of service contract/ agreement/ appointment letter in case of the employee
-   Copy of buyer's nomination letter in case of employment of the buyer's representative
-   Academic qualification & experience certificates of the expatriate
-   Visa Recommendation Letter of the Expatriate/Investors

NB:

-   All documents shall have to be attested by the Chairman/ CEO / Managing director/ Country Manager/ Chief executive of the Company/ firms.
-   Document's must be submitted by an authorized person of the organization including the letter of authorization

Mode

[BIDA One Stop Service  
(OSS)](https://www.investbangladesh.gov.bd/services#bida-one-stop-service)

Fee

Per Person every year BDT 5,000/-  
& 15% of VAT is applicable against the said fee  
(Through OSS System)

Time

72 Hrs.  
(3 days)

Extension of Work Permit

Documents Needed

Necessary documents for New Work Permit of employment of expatriate:

-   Copy of registration letter of the Bangladesh Investment Development Authority, if not submitted earlier
-   Board Resolution for employment of foreign nation(s) mentioning Expatriate Name, Nationality, Passport Number & Salary
-   Memorandum & Articles of Association of the company duly signed by shareholders along with Certificate of Incorporation (In case of limited company), if not submitted earlier
-   Copy of passport with E/PI VISA and arrival stamps for employees/Investors
-   Copy of service contract/ agreement/ appointment letter in case of the employee
-   Copy of buyer's nomination letter in case of employment of the buyer's representative
-   Academic qualification & experience certificates of the expatriate
-   Visa Recommendation Letter of the Expatriate/Investors

NB:

-   All documents shall have to be attested by the Chairman/ CEO / Managing director/ Country Manager/ Chief executive of the Company/ firms
-   Document's must be submitted by an authorized person of the organization including the letter of authorization

Mode

[BIDA One Stop Service  
(OSS)](https://www.investbangladesh.gov.bd/services#bida-one-stop-service)

Fee

Per Person every year BDT 5,000/-  
& 15% of VAT is applicable against the said fee  
(Through OSS System)

Time

72 Hrs.  
(3 days)

Work Permit Cancellation

Documents Needed

Necessary documents for New Work Permit of employment of expatriate:

-   Copy of registration letter of the Bangladesh Investment Development Authority, if not submitted earlier
-   Board Resolution for employment of foreign nation(s) mentioning Expatriate Name, Nationality, Passport Number & Salary
-   Memorandum & Articles of Association of the company duly signed by shareholders along with Certificate of Incorporation (In case of limited company), if not submitted earlier
-   Copy of passport with E/PI VISA and arrival stamps for employees/Investors
-   Copy of service contract/ agreement/ appointment letter in case of the employee
-   Copy of buyer's nomination letter in case of employment of the buyer's representative
-   Academic qualification & experience certificates of the expatriate
-   Visa Recommendation Letter of the Expatriate/Investors

NB:

-   All documents shall have to be attested by the Chairman/ CEO / Managing director/ Country Manager/ Chief executive of the Company/ firms
-   Document's must be submitted by an authorized person of the organization including the letter of authorization

Mode

[BIDA One Stop Service  
(OSS)](https://www.investbangladesh.gov.bd/services#bida-one-stop-service)

Fee

Per Person every year BDT 5,000/-  
& 15% of VAT is applicable against the said fee  
(Through OSS System)

Time

72 Hrs.  
(3 days)

Amendment of Work Permit

Documents Needed

Documents required for amendment of work permit:

-   Re-appointment letter
-   Copy of last work permit
-   Board resolution regarding amendment of work permit
-   Others related documents regarding amendment of work permit

Mode

[BIDA One Stop Service  
(OSS)](https://www.investbangladesh.gov.bd/services#bida-one-stop-service)

Fee

Per Person BDT 1,000/-  
& 15% of VAT is applicable against the said fee  
(Through OSS System)

Time

48 Hrs.  
(2 days)

Foreign Loan Approval

Documents Needed

The following checklist is required for foreign loan approval by The Scrutiny Committee:

-   Forwarding Letter (Director General, Foreign Investment Promotion, BIDA) with justification of the proposal
-   Certificate of Incorporation and Certificate of Commencements from RJSC, Bangladesh
-   Memorandum & Articles of Association (Certified copy)
-   Form-X, Form-XII and Form-XV from RJSC as a proof of authorized capital, paid up capital, shareholding structure, etc
-   Latest registration (including all previous) from Bangladesh Investment Development Authority (BIDA) &/or Department of Textiles (DOT) with the inclusion of proposed loan/deferred payment maintaining debt-equity ratio of at least 70:30
-   Signed Term Sheet/Loan Agreement/Supply Agreement between the parties
-   Board's Resolution related to the proposed loan/deferred payment
-   Up-to-date feasibility report in details
-   Up-to-date financial analysis in details which includes Internal Rate of Return (IRR), Break-Even Analysis, Payback Period, Debt-Equity ratio of the project, Debt Service Coverage Ratio (DSCR) analysis for both Base case and Sensitivity cases (5% increase in cost of production, 5% decrease in sales, etc.) with all others
-   Latest Audited Balance Sheet. Please be informed that existing debt-equity ratio based on Audited Balance Sheet (including proposed amount) should be at least 70:30
-   Up-to-date Credit Rating Report of the company
-   No Objection Certificate from Commercial Bank regarding the willingness to act as a nominated bank
-   The utilization certificate from nominated bank containing the justification of the estimated price/quotation of the capital machineries, spare parts, etc. (Summary of the capital machineries (imported or to be imported) for the purpose of the proposed loan/deferred payment) submitted by the borrower in comparison with the latest market price with supporting documents (for example: Proforma Invoice, Bill of Lading, L/C copy, etc.)
-   Track record of the past foreign loans/deferred payments (if any) with approval letter and bank certificate of all transactions, utilizations and outstanding
-   CIB certificate of the company and its Sponsors/Directors from the nominated bank. The CIB certificate will clearly specify the recent date of searching CIB online and the status in general
-   Relevant CIB enquiry forms (Enquiry Form-1& 2) and under taking from Sponsors/Directors duly filled in for collection of up-to-date CIB report from Bangladesh Bank
-   17) Credential of the Sponsors/Directors
-   Clearance Certificate/NOC from Department of Environment
-   Agreement/s with The Government of The People's Republic of Bangladesh (GOB) associated with the implementation of the project (if any)

Mode

In-person submission

Fee

Loan Processing Fee

•Up to 1 Crore TK- Tk. 5,000/-

•1 Crore Tk. to 5 Crore - Tk. 10,000/-

•5 Crore Tk. to 10 Crore - Tk. 20,000/-

•10 Crore Tk. to 25 Crore - Tk. 50,000/-

•25 Crore Tk. & Above - Tk. 1,00,000/-

& 15% of VAT is applicable against the said fee   

If the foreign loan is approved in the scrutiny committee, you will have to pay processing fee by pay order in favor of “Bangladesh Investment Development Authority”

Time

At least 15 days but dependon The Scrutiny Committee’s Meeting

#### BOOK AN APPOINTMENT

##### SERVICE

New Business Opportunities

Registration & Approvals

Regulatory Facilitation

Visa & Work Permit Support

Aftercare

Policy & Sectoral Guidance

##### REQUESTED DATE

##### REQUESTED TIME

**Thank you!**  
Your appointment request has been submitted.  
If approved, a confirmation email will be sent to you.

Oops! Something went wrong while submitting the form.