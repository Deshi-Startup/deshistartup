---
source: "Bangladesh Investment Development Authority (BIDA)"
tier: 1
category: "Government / regulator"
url: "https://bida.gov.bd/bida-officers"
title: "BIDA Officers – Leadership Team | Bangladesh Investment Authority"
scraped_at: "2026-07-02"
---

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/686cf7286136ad1eee6ed377_Layer_1%20\(1\).svg)](/)

[中文](/china)[BIDA OSS](/services#one-stop-services)[

Matchmakin

](https://uat-irms.oss.net.bd/matchmaking)

![bida search icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678cd4d48720bb0edd6ad500_Group%2055.svg)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/68945f6c4818ae3dc291a664_Layer_1.svg)![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![search](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6788a1c48788ea23e00ed88c_Group%2055%20\(1\).webp)

![humbergur](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678896a2d5b4ac64ddac5e2a_Group%2096%20\(3\).webp)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

-   [home](/)

-   [OPPORTUNITIES](/opportunities)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [Services](/services)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [RESOURCES](/resources)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [ABOUT BIDA](/about-bida)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [NOTICE](/notices)

[BIDA OSS](https://www.investbangladesh.gov.bd/services#one-stop-service)[中文](/china)[

MATCHMAKING

](https://uat-irms.oss.net.bd/matchmaking)

# ABOUT BIDA

## BIDA OFFICERS

### Executive Chairman's Office

![Chowdhury Ashik Mahmud Bin Harun](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69b0e1b40c513514c88c1e27_686e50dbed8738847857300e_Chowdhury%20Ashik%20Mahmud%20Bin%20Harun.jpeg)

Chowdhury Ashik Mahmud Bin Harun

Executive Chairman

[

View Profile

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69b0e1b40c513514c88c1e27_686e50dbed8738847857300e_Chowdhury%20Ashik%20Mahmud%20Bin%20Harun.jpeg)](/officers/chowdhury-ashik-mahmud-bin-harun)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69af9f383a00d10e6a4c80c5_acqngcz1txw9stmrnsdi_Md.%20Anwar%20Uj%20Jaman.webp)

Md. Anwar Uj Jaman

Private Secretary (Senior Assistant Secretary) to the Hon'ble Executive Chairman (Additional Charge)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69af9f383a00d10e6a4c80c5_acqngcz1txw9stmrnsdi_Md.%20Anwar%20Uj%20Jaman.webp)](/officers/md-anwar-uj-jaman-35vbw)

![Samin Sababa Parin](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6a44cb39f2da10705abdbab8_68664b874e60df8817021594_Samin%20Sababa%20Parin-p-1600.jpg)

Samin Sababa Parin

Investment Communications & Engagement Specialist

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6a44cb39f2da10705abdbab8_68664b874e60df8817021594_Samin%20Sababa%20Parin-p-1600.jpg)](/officers/samin-sababa-parin)

![Samin Sababa Parin](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67c6aec82a16fea2bd22b87e_Testimonial-01%20\(44\).webp)

![Close Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685ce0ccc707148ee0d3dedf_Group%20296.svg)

Samin Sababa Parin

Samin Sababa Parin

Mobile

:

+880 XXXXXXXX

Phone (Office)

:

+880 XXXXXXXX

Fax

:

+880 XXXXXXXX

Email

:

+880 XXXXXXXX

#### Admin WING

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afa21a6c364f97b9100bdd_sotyilb8gur8y0spvmyj_Md.%20Humayun%20Kabir.webp)

Md. Humayun Kabir

Executive Member

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afa21a6c364f97b9100bdd_sotyilb8gur8y0spvmyj_Md.%20Humayun%20Kabir.webp)](/officers/name-2)

![Md. Muzib-Ul-Ferdous](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afa344f7d4394175193d92_8f59560e-6412-4e79-a5f4-3a76ef0a957c_Md.%20Muzib-Ul-Ferdous.jpg)

Md. Muzib-Ul-Ferdous

Director General (Joint Secretary), Admin and Finance

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afa344f7d4394175193d92_8f59560e-6412-4e79-a5f4-3a76ef0a957c_Md.%20Muzib-Ul-Ferdous.jpg)](/officers/md-muzib-ul-ferdous)

![Muhammad Abdul Halim Tolstoy](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afa56fc7a4ec5aa50cb2dc_68664d63ead59070378e25ad_Muhammad%20Abdul%20Halim%20Tolstoy.jpg)

Muhammad Abdul Halim Tolstoy

Director (Deputy Secretary), Finance, Budget and Audit

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afa56fc7a4ec5aa50cb2dc_68664d63ead59070378e25ad_Muhammad%20Abdul%20Halim%20Tolstoy.jpg)](/officers/muhammad-abdul-halim-tolstoy)

![Md. Maruful Alam](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afa293e72003e4a92427ec_686658e56f67f6dcb57a534a_Md.%20Maruful%20Alam.webp)

Md. Maruful Alam

Director (Deputy Secretary), Facilities Management, and Director, Human Resource Development and Director Registration Local Industry-1

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afa293e72003e4a92427ec_686658e56f67f6dcb57a534a_Md.%20Maruful%20Alam.webp)](/officers/md-maruful-alam)

![Abu Zer Gifary Tamal](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6a44cc3d19d9d585728d7782_68664d9605e55a5fd1b8218a_Abu%20Zer%20Gifary%20Tamal.jpg)

Abu Zer Gifary Tamal

Deputy Director (Admin)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6a44cc3d19d9d585728d7782_68664d9605e55a5fd1b8218a_Abu%20Zer%20Gifary%20Tamal.jpg)](/officers/abu-zer-gifary-tamal)

![Md. Abu Sayed Mahmud](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afac572edf6f94677b37f1_msrd9n198bhtwfnyi9tu_Md.%20Abu%20Sayed%20Mahmud.webp)

Md. Abu Sayed Mahmud

Deputy Director, Human Resources Development

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afac572edf6f94677b37f1_msrd9n198bhtwfnyi9tu_Md.%20Abu%20Sayed%20Mahmud.webp)](/officers/md-abu-sayed-mahmud)

![Md. Sayful Islam](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afa5d142bdbca54a5b8257_686657d4727d1b71895c3fc5_Md.%20Sayful%20Islam.jpg)

Md. Sayful Islam

Deputy Director (On Study Leave)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afa5d142bdbca54a5b8257_686657d4727d1b71895c3fc5_Md.%20Sayful%20Islam.jpg)](/officers/md-sayful-islam)

![Sheikh Ashikur Rahman](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6a44cd656bb969dc466228c0_68664dd98bdb0fd18048f716_Sheikh%20Ashikur%20Rahman.jpg)

Sheikh Ashikur Rahman

Deputy Director, Finance & Budget and Deputy Director, Audit (Additional Charge)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6a44cd656bb969dc466228c0_68664dd98bdb0fd18048f716_Sheikh%20Ashikur%20Rahman.jpg)](/officers/sheikh-ashikur-rahman)

![Md. Monirul Islam](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6a44cbc2114de77a61ae6b02_68664e4361c083dc82133256_Md.%20Monirul%20Islam.jpg)

Md. Monirul Islam

Assistant Director (Human Resources Development-1)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6a44cbc2114de77a61ae6b02_68664e4361c083dc82133256_Md.%20Monirul%20Islam.jpg)](/officers/md-monirul-islam-2)

![Md. Rabiul Islam](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6a44cdd1f3a3f3a02dae1223_68664e79c524dfe80bde208c_Md.%20Rabiul%20Islam.jpg)

Md. Rabiul Islam

Assistant Director (Common Services-1)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6a44cdd1f3a3f3a02dae1223_68664e79c524dfe80bde208c_Md.%20Rabiul%20Islam.jpg)](/officers/md-rabiul-islam)

![Md. Abu Sayem](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afa89df6f83f46f846da33_68664eb1883f66a59c8d5729_Md.%20Abu%20Sayem.jpg)

Md. Abu Sayem

Assistant Director (Common Services)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afa89df6f83f46f846da33_68664eb1883f66a59c8d5729_Md.%20Abu%20Sayem.jpg)](/officers/md-abu-sayem)

![Md. Alamgir Hussain](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afa4d8f9d88bfa558e0584_68664e95bd0be6936a7fd454_Md.%20Alamgir%20Hussain.webp)

Md. Alamgir Hussain

Assistant Director (Audit)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afa4d8f9d88bfa558e0584_68664e95bd0be6936a7fd454_Md.%20Alamgir%20Hussain.webp)](/officers/md-alamgir-hussain)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dc75f87f588cc446ddb568_A%20F%20M%20Al%20Mukit.webp)

AFM Al Mukit

Assistant Director (Human Resource Development-2)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dc75f87f588cc446ddb568_A%20F%20M%20Al%20Mukit.webp)](/officers/a-f-m-al-mukit)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dcae1da9307a1886f28847_Ashraful%20Islam.webp)

Ashraful Islam

Accounting Officer (Finance & Budget)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dcae1da9307a1886f28847_Ashraful%20Islam.webp)](/officers/ashraful-islam)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dcaec3fc10902014cb7c61_Abdullah%20Al%20Mahmud.webp)

Abdullah Al Mahmud

Foreman (Automobile)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dcaec3fc10902014cb7c61_Abdullah%20Al%20Mahmud.webp)](/officers/abdullah-al-mahmud)

#### Investment Promotion (Sector) Wing

![Nahian Rahman Rochi](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69b1009c0197aaea8041e51b_68664bbb72efcb7d114e2d09_Nahian%20Rahman%20Rochi.jpg)

Nahian Rahman Rochi

Executive Member

[

View Profile

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69b1009c0197aaea8041e51b_68664bbb72efcb7d114e2d09_Nahian%20Rahman%20Rochi.jpg)](/officers/nahian-rahman-rochi-2)

![Jibon Krishna Saha Roy](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6a44d538a097df1f1a457476_6863881b38660bc805d6f6e5_Jibon%20Krishna%20Saha%20Roy.jpg)

Jibon Krishna Saha Roy

Director General, Investment Promotion (Sector)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6a44d538a097df1f1a457476_6863881b38660bc805d6f6e5_Jibon%20Krishna%20Saha%20Roy.jpg)](/officers/jibon-krishna-saha-roy)

![Abdur Rahim](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6a02f0b823539891acb3afa4_23.png)

Abdur Rahim

Director (Deputy Secretary), Communication

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6a02f0b823539891acb3afa4_23.png)](/officers/abdur-rahim)

![Tajmahal Begum](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afa993c30eeed2f62aa7d3_68665b0fbe9cdf1285d54e83_Tajmahal%20Begum.webp)

Tajmahal Begum

Director (Deputy Secretary), Logistics, Light Engineering, FMCG, Renewables, Textile, Leather, Automotives, Electronics, IT-ITeS

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afa993c30eeed2f62aa7d3_68665b0fbe9cdf1285d54e83_Tajmahal%20Begum.webp)](/officers/tajmahal-begum)

![Muhammad Munirul Hasan](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6a02f0dcc778d9efbe3d9fb9_25.png)

Muhammad Munirul Hasan

Deputy Director, Legal Advisor, Senior Event Coordinator, Asset Management (Additional Charge)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6a02f0dcc778d9efbe3d9fb9_25.png)](/officers/muhammad-munirul-hasan)

![Md. Atik Sarker](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6a44d5d229ac5adfaedf5ac4_6866591061c083dc821e39b9_Md.%20Atik%20Sarker.jpg)

Md. Atik Sarker

Deputy Director, Electronics, IT & ITeS

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6a44d5d229ac5adfaedf5ac4_6866591061c083dc821e39b9_Md.%20Atik%20Sarker.jpg)](/officers/md-atik-sarker-2)

![Shaikh Rasibul Islam](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6a02f274153b2c27be3321e2_bida%20Officer%20image%2029%20medium%20quality.png)

Sheikh Rasibul Islam

Deputy Director, Logistics, Light Engineering, Service, Pharma, Healthcare, FMCG, Renewables & Agro-processing

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6a02f274153b2c27be3321e2_bida%20Officer%20image%2029%20medium%20quality.png)](/officers/shaikh-rasibul-islam)

![Ifteara Ferdosi](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6a02f0f3ee984d082471e076_28.png)

Ifteara Ferdosi

Deputy Director, Registration - Foreign Industry and Senior Transaction Advisor (Additional Charge)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6a02f0f3ee984d082471e076_28.png)](/officers/ifteara-ferdosi-1)

![Faizur Rabbee](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afaa4c693bcf4d94ae8aa9_6866579df4ea5efc2aae45c5_Faizur%20Rabbee-p-1600.webp)

Faizur Rabbee

Deputy Director, Textile & Leather (Additional Charge)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afaa4c693bcf4d94ae8aa9_6866579df4ea5efc2aae45c5_Faizur%20Rabbee-p-1600.webp)](/officers/faizur-rabbee)

![Proshanta Kumar Mandal](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69f9c50a27e58de1dd32a3a6_photo%201.jpg%20\(1\).jpeg)

Md. Abu Hanif

Public Relations Officer

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69f9c50a27e58de1dd32a3a6_photo%201.jpg%20\(1\).jpeg)](/officers/md-abu-hanif)

![Tasnim Sikder](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69f9c56dcd6614969db4ed63_WhatsApp%20Image%202026-05-03%20at%204.01.56%20PM.jpeg)

Tasnim Sikder

Public Relations Officer

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69f9c56dcd6614969db4ed63_WhatsApp%20Image%202026-05-03%20at%204.01.56%20PM.jpeg)](/officers/tasnim-sikder)

![Muhammad Zahid Hossain](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afaac691d4921190f88074_68665845d5bd058982f64a68_Muhammad%20Zahid%20Hossain.webp)

Muhammad Zahid Hossain

Assistant Director (Event Coordinator), Communication Wing and Analyst - Investment Research and Economic Observatory (Additional Charge)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afaac691d4921190f88074_68665845d5bd058982f64a68_Muhammad%20Zahid%20Hossain.webp)](/officers/muhammad-zahid-hossain)

![Jannatul Ferdousy](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6a02f1772b978b757e744ab6_33.png)

Jannatul Ferdousy

 Assistant Director, Automotives & EV

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6a02f1772b978b757e744ab6_33.png)](/officers/jannatul-ferdousy-2)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dc807dad3b42064d79b8a0_Md.%20Mahfuzul%20Islam.webp)

Md. Mahfuzul Islam

Assistant Director, Logistics, Heavy Industries & Light Engineering; Electronics, IT & ITeS

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dc807dad3b42064d79b8a0_Md.%20Mahfuzul%20Islam.webp)](/officers/md-mahfuzul-islam)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dc93bce33087b23e699e27_Hridi%20Rahaman.webp)

Hridi Rahman

Assistant Director, Pharma, Healthcare & Service

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dc93bce33087b23e699e27_Hridi%20Rahaman.webp)](/officers/hridi-rahman)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dc961ba209566c180b8fa3_Md.%20Rashedur%20Rahman.webp)

Md. Rashedur Rahman

Assistant Director, Pharma & Healthcare

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dc961ba209566c180b8fa3_Md.%20Rashedur%20Rahman.webp)](/officers/md-rashedur-rahman)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dc94b4c1b2cd7227950777_Md.%20Ashraful%20Alam%20Lincon.webp)

Md. Ashraful Alam Lincon

Assistant Director, Agriculture & Food Processing

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dc94b4c1b2cd7227950777_Md.%20Ashraful%20Alam%20Lincon.webp)](/officers/md-ashraful-alam-lincon)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dc9569aae47eac19530465_S.%20M.%20Rafio%20Morshed.webp)

SM Rafio Morshed

Assistant Director, Textile & Leather

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dc9569aae47eac19530465_S.%20M.%20Rafio%20Morshed.webp)](/officers/s-m-rafio-morshed)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dc70bc94722b8bbe68e807_Mobarok%20Hossain.webp)

Mobarok Hossain

Assistant Director, FMCG & Renewables

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dc70bc94722b8bbe68e807_Mobarok%20Hossain.webp)](/officers/mobarok-hossain-2)

#### Investment Promotion (Country) Wing  

![Nahian Rahman Rochi](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69b1009c0197aaea8041e51b_68664bbb72efcb7d114e2d09_Nahian%20Rahman%20Rochi.jpg)

Nahian Rahman Rochi

Executive Member

[

View Profile

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69b1009c0197aaea8041e51b_68664bbb72efcb7d114e2d09_Nahian%20Rahman%20Rochi.jpg)](/officers/nahian-rahman-rochi-2)

![Quazi Mohammad Hasan](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afadcdacf6c7952c1b5ae6_689476a6e28afaa836bbdc57_Quazi%20Mohammad%20Hasan.jpg)

Quazi Mohammad Hasan

Director General (Joint Secretary), Investment Promotion (Country)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afadcdacf6c7952c1b5ae6_689476a6e28afaa836bbdc57_Quazi%20Mohammad%20Hasan.jpg)](/officers/quazi-mohammad-hasan)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6a44d6436582f08c12328cfd_2Y6A4535.jpg)

Shah Nusrat Jahan

Director (Deputy Secretary), Country Liaison-2 and Director, Country Liaison-4 (Additional Charge)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6a44d6436582f08c12328cfd_2Y6A4535.jpg)](/officers/shah-nusrat-jahan)

![Abu Mohammad Nurul Hayat Totul](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afb328c4f9efa52402b29a_6863883a48ee3f1ee646c6f8_Abu%20Mohammad%20Nurul%20Hayat%20Totul.webp)

Abu Mohammad Nurul Hayat Totul

Deputy Director, Country Liaison-3 and Deputy Director, Country Liaison-5 (Additional Charge)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afb328c4f9efa52402b29a_6863883a48ee3f1ee646c6f8_Abu%20Mohammad%20Nurul%20Hayat%20Totul.webp)](/officers/abu-mohammad-nurul-hayat-totul)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69af9f383a00d10e6a4c80c5_acqngcz1txw9stmrnsdi_Md.%20Anwar%20Uj%20Jaman.webp)

Md. Anwar Uj Jaman

Deputy Director (Senior Assistant Secretary) Country Liaison-1

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69af9f383a00d10e6a4c80c5_acqngcz1txw9stmrnsdi_Md.%20Anwar%20Uj%20Jaman.webp)](/officers/md-anwar-uj-jaman-5rfy9)

![Sikdar Didarul](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afae6fd03888336c02cb83_686657f3f1b39ca5dd84420d_Sikdar%20Didarul.jpg)

Sikdar Didarul

Assistant Director Country Liaison-2 and Assistant Director, Country Liaison-4 (Additional Charge)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afae6fd03888336c02cb83_686657f3f1b39ca5dd84420d_Sikdar%20Didarul.jpg)](/officers/sikdar-didarul)

![Johary Bin Akhter](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afadea0ed587445f1f3b20_68908e7f855e60bec2f50b34_Johary%20Bin.jpg)

Johary Bin Akhter

Associate Relationship Manager

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afadea0ed587445f1f3b20_68908e7f855e60bec2f50b34_Johary%20Bin.jpg)](/officers/johary-bin-akhter)

![Nafisa Zaman](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afadb42d7c473abbda551f_68908e3385a3b7f93f5321c9_Nafisa.jpg)

Nafisa Zaman

Business Development Manager

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afadb42d7c473abbda551f_68908e3385a3b7f93f5321c9_Nafisa.jpg)](/officers/nafisa-zaman)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dc70bc94722b8bbe68e807_Mobarok%20Hossain.webp)

Mobarok Hossain

Assistant Director (Country Liaison-4)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dc70bc94722b8bbe68e807_Mobarok%20Hossain.webp)](/officers/mobarok-hossain)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dc807dad3b42064d79b8a0_Md.%20Mahfuzul%20Islam.webp)

Md. Mahfuzul Islam

Assistant Director, Country Liaison-3

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dc807dad3b42064d79b8a0_Md.%20Mahfuzul%20Islam.webp)](/officers/md-mahfuzul-islam-2)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dc961ba209566c180b8fa3_Md.%20Rashedur%20Rahman.webp)

Md. Rashedur Rahman

Assistant Director, Country Liaison-6 & 8 (Additional Charge)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dc961ba209566c180b8fa3_Md.%20Rashedur%20Rahman.webp)](/officers/md-rashedur-rahman-2)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dc9569aae47eac19530465_S.%20M.%20Rafio%20Morshed.webp)

SM Rafio Morshed

Assistant Director, Country Liaison-6

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dc9569aae47eac19530465_S.%20M.%20Rafio%20Morshed.webp)](/officers/sm-rafio-morshed)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dc94b4c1b2cd7227950777_Md.%20Ashraful%20Alam%20Lincon.webp)

Md. Ashraful Alam Lincon

Assistant Director, Country Liason-5

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dc94b4c1b2cd7227950777_Md.%20Ashraful%20Alam%20Lincon.webp)](/officers/md-ashraful-alam-lincon-2)

#### Operation-1 Wing

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afaf3194dc7cf7f8ffcb98_i078ltxhgrghqmwyragz_Md.%20Shaharul%20Huda.webp)

Md. Shaharul Huda

Executive Member

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afaf3194dc7cf7f8ffcb98_i078ltxhgrghqmwyragz_Md.%20Shaharul%20Huda.webp)](/officers/air-commodore-retired-md-shaharul-huda-2)

![Mst. Shamima Akter](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afaf73f18a6c0498b6ea95_686658c921629c9dc8fd1212_MST.%20SHAMIMA%20AKTER.webp)

Mst. Shamima Akter

Director (Deputy Secretary), Registration - Foreign Industry and Director, Visa & Work Permit - Industrial (Additional Charge), Director, Foreign Commercial (Additional Charge)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afaf73f18a6c0498b6ea95_686658c921629c9dc8fd1212_MST.%20SHAMIMA%20AKTER.webp)](/officers/mst-shamima-akter)

![Ifteara Ferdosi](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6a02f0f3ee984d082471e076_28.png)

Ifteara Ferdosi

Deputy Director, Registration - Foreign Industry and Senior Transaction Advisor (Additional Charge)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6a02f0f3ee984d082471e076_28.png)](/officers/ifteara-ferdosi)

![Faizur Rabbee](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afaa4c693bcf4d94ae8aa9_6866579df4ea5efc2aae45c5_Faizur%20Rabbee-p-1600.webp)

Faizur Rabbee

Deputy Director, Visa and Work Permit – Industrial

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afaa4c693bcf4d94ae8aa9_6866579df4ea5efc2aae45c5_Faizur%20Rabbee-p-1600.webp)](/officers/faizur-rabbee-2)

![Syed Mohammad Shorfuddin](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afafce87154fab5a2cafc2_6866592d794a916bfa83ed17_Syed%20Mohammad%20Shorfuddin.webp)

Syed Mohammad Shorfuddin

Deputy Director (Commercial Offices) & Deputy Director (Facilitation) (Additional Charge)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afafce87154fab5a2cafc2_6866592d794a916bfa83ed17_Syed%20Mohammad%20Shorfuddin.webp)](/officers/syed-mohammad-shorfuddin)

![Md. Suman Sheikh](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afb2b810ab61da80f14512_68665b4e1a3a011d4b194d56_Md.%20Suman%20Sheikh.jpg)

Md. Suman Sheikh

Assistant Director (Registration - Foreign Industry)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afb2b810ab61da80f14512_68665b4e1a3a011d4b194d56_Md.%20Suman%20Sheikh.jpg)](/officers/md-suman-sheikh)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dc6a9faae47eac194eb553_Nirjons%20photography%20%20\(20\).webp)

Tamzid Alam Raian

Assistant Director (Facilitation - Visa)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dc6a9faae47eac194eb553_Nirjons%20photography%20%20\(20\).webp)](/officers/tamzid-alam-raian)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dc891b579e1acd4f9d4c34_K.%20M.%20Shahidul%20Islam%20Raju.webp)

KM Shahidul Islam Raju

Assistant Director, Visa- Industrial and Work Permit – Industrial (Additional Charge)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dc891b579e1acd4f9d4c34_K.%20M.%20Shahidul%20Islam%20Raju.webp)](/officers/k-m-shahidul-islam-raju)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dc735e710ae5ba7abb2443_Md.%20Shahe-%20Din%20Moshaid.webp)

Md. Shahe-Din Moshaid

Assistant Director (Commercial Offices)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dc735e710ae5ba7abb2443_Md.%20Shahe-%20Din%20Moshaid.webp)](/officers/md-shahe-din-moshaid)

#### Operation-2 Wing

![Md. Muzib-Ul-Ferdous](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afa344f7d4394175193d92_8f59560e-6412-4e79-a5f4-3a76ef0a957c_Md.%20Muzib-Ul-Ferdous.jpg)

Md. Muzib-Ul-Ferdous

Director General (Joint Secretary), Admin and Finance

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afa344f7d4394175193d92_8f59560e-6412-4e79-a5f4-3a76ef0a957c_Md.%20Muzib-Ul-Ferdous.jpg)](/officers/md-muzib-ul-ferdous)

![Md. Sirajul Islam Khan](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afb0eb03b8b46eea1ca43a_68665823ebace192930c5bbe_MD.%20SIRAJUL%20ISLAM%20KHAN.webp)

Md. Sirajul Islam Khan

Director (Deputy Secretary), Registration - Local Industry-2 & Entrepreneurship Development

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afb0eb03b8b46eea1ca43a_68665823ebace192930c5bbe_MD.%20SIRAJUL%20ISLAM%20KHAN.webp)](/officers/md-sirajul-islam-khan)

![Md. Maruful Alam](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afa293e72003e4a92427ec_686658e56f67f6dcb57a534a_Md.%20Maruful%20Alam.webp)

Md. Maruful Alam

Director (Deputy Secretary), Facilities Management, and Director, Human Resource Development and Director Registration Local Industry-1

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afa293e72003e4a92427ec_686658e56f67f6dcb57a534a_Md.%20Maruful%20Alam.webp)](/officers/md-maruful-alam-2)

![Md. Atik Sarker](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6a44d5d229ac5adfaedf5ac4_6866591061c083dc821e39b9_Md.%20Atik%20Sarker.jpg)

Md. Atik Sarker

Deputy Director, Entrepreneurship Development and Asset Management (Additional Charge)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6a44d5d229ac5adfaedf5ac4_6866591061c083dc821e39b9_Md.%20Atik%20Sarker.jpg)](/officers/md-atik-sarker-3)

![Nashid Kaisher Riyadh](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6a02f13ab79cc046fb8e6f34_51.png)

Nashid Kaisher Riyadh

Deputy Director (Senior Assistant Secretary), Registration - Local Industry 1 & Deputy Director, Divisional Office Coordination (Additional Charge)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6a02f13ab79cc046fb8e6f34_51.png)](/officers/nashid-kaisher-riyadh)

![Fatema Begum](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afb14f758ba6bc9b735a42_68614eb151e34a94846e8661_Fatema%20Begum-min-p-1600.webp)

Fatema Begum

Assistant Director (Registration - Local Industry-1)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afb14f758ba6bc9b735a42_68614eb151e34a94846e8661_Fatema%20Begum-min-p-1600.webp)](/officers/fatema-begum)

![Ferdousi Akhter](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afb16b17c8b587c8ea2ff3_68665a39e6731c65730349ea_Ferdousi%20Akhter.webp)

Ferdousi Akhter

Assistant Director (Entrepreneur Development) & Assistant Director, Registration - Local Industry-2 (Additional Charge)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afb16b17c8b587c8ea2ff3_68665a39e6731c65730349ea_Ferdousi%20Akhter.webp)](/officers/ferdousi-akhter)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dc77ac2ddb544ca0be20f3_Tanzim%20Ferdous%20Amio.webp)

Tanzim Ferdous Amio

Assistant Director (Registration - Local Industry -2)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dc77ac2ddb544ca0be20f3_Tanzim%20Ferdous%20Amio.webp)](/officers/tanzim-ferdous-amio)

#### Research and Policy Wing

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afa21a6c364f97b9100bdd_sotyilb8gur8y0spvmyj_Md.%20Humayun%20Kabir.webp)

Md. Humayun Kabir

Executive Member

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afa21a6c364f97b9100bdd_sotyilb8gur8y0spvmyj_Md.%20Humayun%20Kabir.webp)](/officers/name-2)

![Gazi AKM Fazlul Haque](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afb2d9be4a2181d08f852b_689475cff893b543d1c27ae4_Gazi%20AKM%20Fazlul%20Haque.jpg)

Gazi AKM Fazlul Haque

Director General, Research and Policy

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afb2d9be4a2181d08f852b_689475cff893b543d1c27ae4_Gazi%20AKM%20Fazlul%20Haque.jpg)](/officers/gazi-akm-fazlul-haque)

![Dr. Md. Houmyoun Kabir Khan](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afb1d221c0f1b6b5da001d_686656c80481d5aae4f1ddf8_Dr.%20Md.%20Houmyoun%20Kabir%20Khan.webp)

Dr. Md. Houmyoun Kabir Khan

Director (Deputy Secretary), Investment Research and Economics Observatory & Policy Advocacy and Planning (Additional Charge)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afb1d221c0f1b6b5da001d_686656c80481d5aae4f1ddf8_Dr.%20Md.%20Houmyoun%20Kabir%20Khan.webp)](/officers/dr-md-houmyoun-kabir-khan)

![Dipankar Das Gupta](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afa798c30eeed2f62a7a97_68664db8275859af7bc13e92_Dipankar%20Das%20Gupta.jpg)

Dipankar Das Gupta

Deputy Director, Policy Advocacy, Planning (Additional Charge) and Procurement (Additional Charge)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afa798c30eeed2f62a7a97_68664db8275859af7bc13e92_Dipankar%20Das%20Gupta.jpg)](/officers/dipankar-das-gupta)

![Md. Shohel Rana](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afb048d04cb2540deddab7_686659576f67f6dcb57ac8c4_Md.%20Shohel%20Rana.jpg)

Md. Shohel Rana

Assistant Director (Assistant Secretary), Policy Advocacy

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afb048d04cb2540deddab7_686659576f67f6dcb57ac8c4_Md.%20Shohel%20Rana.jpg)](/officers/md-shohel-rana)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dc7547ba1412845b4e138a_Md.%20Shariotullah.webp)

Md. Shariotullah

Assistant Director (Planning)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dc7547ba1412845b4e138a_Md.%20Shariotullah.webp)](/officers/md-shariotullah)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dc966374bc51cb1c303e7d_Amit%20Roy%20Shaim.webp)

Amit Roy Shaim

Assistant Director (Asset Management)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dc966374bc51cb1c303e7d_Amit%20Roy%20Shaim.webp)](/officers/amit-roy-shaim)

#### One Stop Service and Digital Development Wing

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afaf3194dc7cf7f8ffcb98_i078ltxhgrghqmwyragz_Md.%20Shaharul%20Huda.webp)

Md. Shaharul Huda

Executive Member

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afaf3194dc7cf7f8ffcb98_i078ltxhgrghqmwyragz_Md.%20Shaharul%20Huda.webp)](/officers/air-commodore-retired-md-shaharul-huda-2)

![Sunil Kumar Adhikary](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69b11c5c7d29e1d52f920221_69423997a95e6319af7e19cf_IMG_5390-Sunil-p-1600.jpg)

Sunil Kumar Adhikary

Director (Deputy Secretary), One Stop Service & Data Analytics and Director, Digital Service Management Unit (Additional Charge)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69b11c5c7d29e1d52f920221_69423997a95e6319af7e19cf_IMG_5390-Sunil-p-1600.jpg)](/officers/sunil-kumar-adhikary)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afaa06f9d88bfa558e79a0_bc10ff18-c2c2-458a-bfe7-a6069d98425b_Kazi%20Md.%20Mohsin%20Uzzal.webp)

Kazi Md. Mohsin Uzzal

Deputy Director (Senior Assistant Secretary), One Stop Service, Data Analytics (Additional Charge)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afaa06f9d88bfa558e79a0_bc10ff18-c2c2-458a-bfe7-a6069d98425b_Kazi%20Md.%20Mohsin%20Uzzal.webp)](/officers/kazi-md-mohsin-uzzal-2)

![Dipu Sarkar](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69b0ebbba2d9fa478b8c6e7c_68664df624c5be2ba04dfbea_Dipu%20Sarkar.jpg)

Dipu Sarkar

Assistant Programmer, Digital Service Management

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69b0ebbba2d9fa478b8c6e7c_68664df624c5be2ba04dfbea_Dipu%20Sarkar.jpg)](/officers/dipu-sarkar)

![Md. Tajmilur Rahman](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afb3566c364f97b911db89_68664e16e6731c6573f5f656_Md.%20Tajmilur%20Rahman.webp)

Md. Tajmilur Rahman

Maintenance Engineer (Computer), Digital Service Management

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69afb3566c364f97b911db89_68664e16e6731c6573f5f656_Md.%20Tajmilur%20Rahman.webp)](/officers/md-tajmilur-rahman-2)

![Jannatul Ferdousy](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6a02f1772b978b757e744ab6_33.png)

Jannatul Ferdousy

 Assistant Director (Data Analytics) & Assistant Director (One Stop Service) (Additional Charge)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6a02f1772b978b757e744ab6_33.png)](/officers/jannatul-ferdousy)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dc71df7416e9ed4adf6d27_Syduzzaman%20Sifat.webp)

Syduzzaman Sifat

Assistant Director (One Stop Service)

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69dc71df7416e9ed4adf6d27_Syduzzaman%20Sifat.webp)](/officers/syduzzaman-sifat)

#### BOOK AN APPOINTMENT

##### SERVICE

New Business Opportunities

Registration & Approvals

Regulatory Facilitation

Visa & Work Permit Support

Aftercare

Policy & Sectoral Guidance

##### REQUESTED DATE

##### REQUESTED TIME

**Thank you!**  
Your appointment request has been submitted.  
If approved, a confirmation email will be sent to you.

Oops! Something went wrong while submitting the form.