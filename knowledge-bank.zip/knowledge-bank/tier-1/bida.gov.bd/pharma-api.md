---
source: "Bangladesh Investment Development Authority (BIDA)"
tier: 1
category: "Government / regulator"
url: "https://bida.gov.bd/investment-sector/pharma-api"
title: "Bangladesh Pharmaceutical & API Industry"
scraped_at: "2026-07-02"
---

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/686cf7286136ad1eee6ed377_Layer_1%20\(1\).svg)](/)

[中文](/china)[BIDA OSS](/services#one-stop-services)[

Matchmakin

](https://uat-irms.oss.net.bd/matchmaking)

![bida search icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678cd4d48720bb0edd6ad500_Group%2055.svg)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/68945f6c4818ae3dc291a664_Layer_1.svg)![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![search](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6788a1c48788ea23e00ed88c_Group%2055%20\(1\).webp)

![humbergur](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678896a2d5b4ac64ddac5e2a_Group%2096%20\(3\).webp)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

-   [home](/)

-   [OPPORTUNITIES](/opportunities)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [Services](/services)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [RESOURCES](/resources)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [ABOUT BIDA](/about-bida)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [NOTICE](/notices)

[BIDA OSS](https://www.investbangladesh.gov.bd/services#one-stop-service)[中文](/china)[

MATCHMAKING

](https://uat-irms.oss.net.bd/matchmaking)

# Pharmaceuticals & API 

Delivering Affordable, High-Quality Medicines to Global Markets

![Pharmaceuticals & API](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6833090a9fe12a683746bedf_Mask%20group%20\(38\).webp)

98%

domestic medicinal demand met

$6B

pharma market size

1.3B

annual API import

150+

export destinations 

## OVERVIEW

Bangladesh’s pharmaceutical industry is one of its most advanced sectors, meeting 98% of domestic medicinal demand and expanding rapidly into global markets. With a projected CAGR of over 12%, the sector is expected to surpass USD 6 billion by 2025, positioning Bangladesh as a regional hub for generic and specialized formulations. Pharmaceuticals are exported to over 150 countries, including highly regulated markets such as the USA, UK, EU, Canada, and Australia. In the first ten months of FY2024–25, pharmaceutical exports rose by 3.46% YoY, reaching USD 177.42 million.

Home to 213 active companies, the industry is a major white-collar employer backed by a skilled manufacturing base and strong regulatory compliance. With the TRIPS waiver extended to 2033, Bangladeshi firms enjoy the advantage to produce and export patented drugs. Strategic investments in R&D, production capacity, and entry into regulated markets are driving the sector’s shift from import substitution to high-value export orientation.

Bangladesh imports over 85% of its API needs at an annual cost of USD 1.3 billion. To build a self-reliant API ecosystem, the government is actively promoting API manufacturing as a prioritized export diversification sector along with pharmaceuticals. As Asia’s API market is projected to grow at 9% CAGR until 2027, Bangladesh is well-positioned to integrate into regional supply chains with its competitive cost base, policy support, and expanding production ecosystem.

## Growth Drivers

![Product diversity](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330a6e92b6ed77ecb90042_Group%20295.svg)

### Product diversity

Strong capabilities across key therapeutic areas, including anti-infectives, cardiovascular, metabolic, respiratory, and nervous system drugs.

![Specialized Capabilities and Demand for Advanced Treatments](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6854733ef9f7d3f4be1da855_SEPZ%20Icon-03.png)

### Specialized Capabilities and Demand for Advanced Treatments

The industry is advancing into complex formulations including insulin, hormones, anti-cancer drugs, MDIs, DPIs, and lyophilized injectables. Pharmaceutical imports rose significantly in early FY2025, reflecting rising demand for treatments targeting cancer, cardiac, renal, and diabetic conditions.

![Global Regulatory Approvals](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330ac8248e9bc100146958_Group%20294.svg)

### Global Regulatory Approvals

Leading companies are certified by global regulators including USFDA, UK MHRA, EU GMP, Health Canada, TGA Australia, ANVISA Brazil, and GCC.

![Cost-Effective Labor and Production](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330af2e88b12bfc30e6e90_Health%20Icon-05%20\(2\).svg)

### Cost-Effective Labor and Production

With monthly labor costs as low as USD 68.99, Bangladesh offers a 15% cost advantage over regional peers.

![TRIPS Waiver Advantage](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c51d814d4da2279365798_Agro%20Icon-01.svg)

### TRIPS Waiver Advantage

Bangladesh, as the only LDC with a mature pharma sector, benefits from the WTO TRIPS waiver until 2033.

![Infrastructure Development & API Acceleration](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330b4be0bc0c286a0dc6aa_Group%20296.svg)

### Infrastructure Development & API Acceleration

The 200-acre API Park established by BSCIC in Munshiganj is catalyzing domestic API production.

## KEY PLAYERS

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678c7258337ee533c78e5fe9_Rectangle%2041.svg)![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678c7258e1f212fceb08d288_Rectangle%2024.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330cfe5b8a3c54fea0017b_01.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330d448929fba40f9419b6_02.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330d6837cebb7393298b7e_03.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330d8ec430f8f88d84101e_04.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330de775ee0747e9e2f057_231.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330dfecf0a6a7db42a6224_232.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330e17c0b29cfacfea2d03_233.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330e576efccb98fe873060_234.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330e8cc430f8f88d84ae40_235.svg)

## KEY PLAYERS

![Novartis](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330cfe5b8a3c54fea0017b_01.svg)

![ACI (Pharmaceuticals)](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330d448929fba40f9419b6_02.svg)

![SK+F](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330d6837cebb7393298b7e_03.svg)

![Renata Limited](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330d8ec430f8f88d84101e_04.svg)

![Incepta](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330de775ee0747e9e2f057_231.svg)

![Roche](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330dfecf0a6a7db42a6224_232.svg)

![Novo Nordisk](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330e17c0b29cfacfea2d03_233.svg)

![Square (Pharmacuticales)](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330e576efccb98fe873060_234.svg)

![Active Fine Chemicals Ltd](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330e8cc430f8f88d84ae40_235.svg)

![Novartis](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330cfe5b8a3c54fea0017b_01.svg)

![ACI (Pharmaceuticals)](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330d448929fba40f9419b6_02.svg)

![SK+F](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330d6837cebb7393298b7e_03.svg)

![Renata Limited](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330d8ec430f8f88d84101e_04.svg)

![Incepta](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330de775ee0747e9e2f057_231.svg)

![Roche](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330dfecf0a6a7db42a6224_232.svg)

![Novo Nordisk](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330e17c0b29cfacfea2d03_233.svg)

![Square (Pharmacuticales)](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330e576efccb98fe873060_234.svg)

![Active Fine Chemicals Ltd](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330e8cc430f8f88d84ae40_235.svg)

![Novartis](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330cfe5b8a3c54fea0017b_01.svg)

![ACI (Pharmaceuticals)](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330d448929fba40f9419b6_02.svg)

![SK+F](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330d6837cebb7393298b7e_03.svg)

![Renata Limited](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330d8ec430f8f88d84101e_04.svg)

![Incepta](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330de775ee0747e9e2f057_231.svg)

![Roche](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330dfecf0a6a7db42a6224_232.svg)

![Novo Nordisk](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330e17c0b29cfacfea2d03_233.svg)

![Square (Pharmacuticales)](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330e576efccb98fe873060_234.svg)

![Active Fine Chemicals Ltd](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330e8cc430f8f88d84ae40_235.svg)

### Incentives and Policy Support

-   100% tax holiday for producers of 5 specific API molecules extended from 2022 to 2032.
-   7.5% tax holiday for producers of 3 specific API molecules extended from 2023 to 2032.
-   5% export subsidy on exporting Active Pharmaceutical Ingredients from Bangladesh (Applicable until 31 December 2025; [FEPD Circular No. 28](https://www.bb.org.bd/mediaroom/circulars/fepd/jul102025fepd28.pdf)).
-   6% export subsidy on exporting pharmaceutical products (Applicable until 31 December 2025; [FEPD Circular No. 28](https://www.bb.org.bd/mediaroom/circulars/fepd/jul102025fepd28.pdf)).
-   Customs duty exemption on APIs’ raw materials ([S.R.O. No. 127-AIN/2020/78/Customs](https://nbr.gov.bd/uploads/sros/19.SRO-177-2024-API-Del-New_.pdf)).

#### RELEVANT BODIES

-   Ministry of Health and Family Welfare (MOHFW)
-   Directorate General of Drug Administration (DGDA)
-   Bangladesh Export Processing Zones Authority (BEPZA)
-   Bangladesh Small and Cottage Industries Corporation (BSCIC)
-   Bangladesh Pharmaceutical Society (BPS)
-   Bangladesh Association of Pharmaceutical Industries (BAPI)

## **BIDA Sector Focal**

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69f98aa73cf19f0cbbaaccb2_Untitled%20design%20\(4\).png)

### Sheikh Rasibul Islam

Deputy Director

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)](https://wa.me/8801711952685)

[

+8801712595962

](https://wa.me/8801712595962)

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)](mailto:research@bida.gov.bd)

[

rasibul20@gmail.com

](https://rasibul20@gmail.com)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69f98aa73cf19f0cbbaaccb2_Untitled%20design%20\(4\).png)

### Hridi Rahman

Assistant Director

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)](https://wa.me/8801711952685)

[

+8801621132528

](https://wa.me/8801621132528)

[EXPLORE OUR SECTOR DESKS](/sector-desks)

Sheikh Rasibul Islam

Deputy Director

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)](https://wa.me/8801711952685)

+8801712595962

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)](mailto:research@bida.gov.bd)

rasibul20@gmail.com

Hridi Rahman

Assistant Director

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)](https://wa.me/8801711952685)

+8801621132528

![](https://cdn.prod.website-files.com/62434fa732124a0fb112aab4/62434fa732124a0e4912aadb_Chevron%20right-1.svg)

![](https://cdn.prod.website-files.com/62434fa732124a0fb112aab4/62434fa732124a7ce212aacc_Chevron%20right.svg)

## RESOURCES

Pharmaceuticals INDUSTRY & API

JUNE 2024

[

DOWNLOAD

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68bd46256ef8ad72600abdd0_Pharmaceuticles%20%26%20API%20Industries.pdf)

#### BOOK AN APPOINTMENT

##### SERVICE

New Business Opportunities

Registration & Approvals

Regulatory Facilitation

Visa & Work Permit Support

Aftercare

Policy & Sectoral Guidance

##### REQUESTED DATE

##### REQUESTED TIME

**Thank you!**  
Your appointment request has been submitted.  
If approved, a confirmation email will be sent to you.

Oops! Something went wrong while submitting the form.