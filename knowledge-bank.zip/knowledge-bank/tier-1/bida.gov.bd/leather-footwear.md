---
source: "Bangladesh Investment Development Authority (BIDA)"
tier: 1
category: "Government / regulator"
url: "https://bida.gov.bd/investment-sector/leather-footwear"
title: "Bangladesh: A Global Leather Leader"
scraped_at: "2026-07-02"
---

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/686cf7286136ad1eee6ed377_Layer_1%20\(1\).svg)](/)

[中文](/china)[BIDA OSS](/services#one-stop-services)[

Matchmakin

](https://uat-irms.oss.net.bd/matchmaking)

![bida search icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678cd4d48720bb0edd6ad500_Group%2055.svg)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/68945f6c4818ae3dc291a664_Layer_1.svg)![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![search](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6788a1c48788ea23e00ed88c_Group%2055%20\(1\).webp)

![humbergur](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678896a2d5b4ac64ddac5e2a_Group%2096%20\(3\).webp)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

-   [home](/)

-   [OPPORTUNITIES](/opportunities)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [Services](/services)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [RESOURCES](/resources)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [ABOUT BIDA](/about-bida)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [NOTICE](/notices)

[BIDA OSS](https://www.investbangladesh.gov.bd/services#one-stop-service)[中文](/china)[

MATCHMAKING

](https://uat-irms.oss.net.bd/matchmaking)

# Leather & Footwear

2nd Largest Export Earner Driving Sustainable and Scalable Growth

![Leather & Footwear](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6822c17858e8894975f910d1_Mask%20group%20\(29\).webp)

#8

largest global footwear producer

3,600+

footwear making units

10%

of global leather demand met

45%

YoY export growth in CY 24

## OVERVIEW

The leather and footwear industry is Bangladesh’s second-largest export sector after ready-made garments, contributing to approximately 3% of the global leather goods market and meeting nearly 10% of global leather demand. Designated as a priority sector for export diversification under the Industry Policy 2022, the industry is positioning itself as a global sourcing hub, backed by a cost-competitive workforce, abundant raw materials, and targeted policy incentives.

In 2024, exports from the sector reached USD 1.5 billion, registering an impressive 45% year-on-year growth. The government and industry are aligned in their ambition to scale this figure to USD 5 billion in annual exports within the next five years. Bangladesh’s footwear exports are well-diversified across key global markets including the USA, UK, Germany, France, Italy, Japan, China, South Korea, and Canada. The non-leather segment is speedily gaining ground, with exports to Spain, France, the Netherlands, South Korea, India, and China, meeting rising demand for sustainable alternatives. With up to 90% value addition potential and a flexible cost structure, Bangladesh is increasingly attracting the relocation of production from China, particularly in footwear and leather goods manufacturing.

Spanning the entire value chain—from tanning and finishing to leather accessories and finished goods—the sector employs around 850,000 people, with women making up 60% of the workforce. Bangladesh is also advancing in environmentally responsible leather processing, supported by a growing base of skilled and semi-skilled workers, including qualified leather technologists. With strong fundamentals and policy push, the leather sector is set to mirror the success of garments to become Bangladesh’s next global manufacturing powerhouse.

## Growth Drivers

![Green Manufacturing & Infrastructure Development](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c51f96c3973877a0a5313_SEPZ%20Icon-07.svg)

### Green Manufacturing & Infrastructure Development

Three specialized leather industrial zones are under development in Savar, Rajshahi, and Chattogram, enabling ESG-compliant production. The Savar Tannery Estate, now home to 205 eco-certified tanneries, is leading the sector’s green transition.

![Expanding Export Base](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c519c18ef09dcee2541b1_Group%20174.svg)

### Expanding Export Base

-   24% YoY growth in leather footwear exports in FY24 
-   23% CAGR in non-leather footwear exports over the past decade 
-   The United States is the primary destination for Bangladeshi leather footwear

![Abundant Raw Material Supply](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c67489a86eb99baec473d_Group%20167.svg)

### Abundant Raw Material Supply

With over 200 tanneries and 2.4% of the global livestock population, Bangladesh processes 35 million square feet of leather annually. Its bovine and ovine hides are internationally acclaimed for quality, and the country contributes 1.13% of global leather output—largely from domestic raw material sources.

![Robust Domestic Market & Production Capacity](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c60bc8613be5cf3ba5050_Group%20178%20\(1\).svg)

### Robust Domestic Market & Production Capacity

The footwear industry comprises over 3,500 MSMEs and 90 large-scale firms, collectively producing around 378 million pairs annually—with 53% to 66% consumed locally, underscoring strong domestic demand.

## KEY PLAYERS

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678c7258337ee533c78e5fe9_Rectangle%2041.svg)![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678c7258e1f212fceb08d288_Rectangle%2024.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c728028c46e014876f7fb_Telenor-Logo%20\(2\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c729d47739367b2d1ef8d_SCB-Logo%20\(2\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c72b34796f0608b45bb4a_HSBC-Logo%20\(2\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c72d99708c6a4e7692312_Citi-Bank-Logo%20\(15\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7313831cb3f78a8f7c28_Citi-Bank-Logo%20\(16\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c732f863aff64d4f1d099_Citi-Bank-Logo%20\(17\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c73ef474f93ad6e0b774f_Citi-Bank-Logo%20\(18\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c740aaace9489bc5042d6_Citi-Bank-Logo%20\(19\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7423a31397ba10d217d6_Citi-Bank-Logo%20\(20\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c744cda87e1899c6f188c_Telenor-Logo%20\(3\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c746d750e0f9f6342db1a_SCB-Logo%20\(3\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7489e7b77cd048760c21_HSBC-Logo%20\(3\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c74ad3f6ca499f7b4e461_Citi-Bank-Logo%20\(21\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c74d3012af90265c4e412_Citi-Bank-Logo%20\(22\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c74f711654cc6d1a5e9db_Citi-Bank-Logo%20\(23\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7594542f8db0503e8bda_Citi-Bank-Logo%20\(24\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c75b3bf753247778e69c3_Citi-Bank-Logo%20\(25\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c75cdc9aafee42d7d06e9_Citi-Bank-Logo%20\(26\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c75e591a017e233ee9884_Citi-Bank-Logo%20\(27\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c760499243844a7e676a2_Citi-Bank-Logo%20\(28\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c761c7b79a58e4085c83b_Citi-Bank-Logo%20\(29\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c764b321f40f85cbcb1b4_Citi-Bank-Logo%20\(31\).svg)

## KEY PLAYERS

![boss](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c728028c46e014876f7fb_Telenor-Logo%20\(2\).svg)

![adidas](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c729d47739367b2d1ef8d_SCB-Logo%20\(2\).svg)

![nike](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c72b34796f0608b45bb4a_HSBC-Logo%20\(2\).svg)

![puma](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c72d99708c6a4e7692312_Citi-Bank-Logo%20\(15\).svg)

![aldo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7313831cb3f78a8f7c28_Citi-Bank-Logo%20\(16\).svg)

![hm](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c732f863aff64d4f1d099_Citi-Bank-Logo%20\(17\).svg)

![marks & spencer](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c73ef474f93ad6e0b774f_Citi-Bank-Logo%20\(18\).svg)

![picard](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c740aaace9489bc5042d6_Citi-Bank-Logo%20\(19\).svg)

![timberland](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7423a31397ba10d217d6_Citi-Bank-Logo%20\(20\).svg)

![Hush Puppies](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c744cda87e1899c6f188c_Telenor-Logo%20\(3\).svg)

![Esprit](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c746d750e0f9f6342db1a_SCB-Logo%20\(3\).svg)

![Reebok](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7489e7b77cd048760c21_HSBC-Logo%20\(3\).svg)

![Decathlon](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c74ad3f6ca499f7b4e461_Citi-Bank-Logo%20\(21\).svg)

![Deichmann](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c74d3012af90265c4e412_Citi-Bank-Logo%20\(22\).svg)

![Fila](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c74f711654cc6d1a5e9db_Citi-Bank-Logo%20\(23\).svg)

![Bata](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7594542f8db0503e8bda_Citi-Bank-Logo%20\(24\).svg)

![Lotto](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c75b3bf753247778e69c3_Citi-Bank-Logo%20\(25\).svg)

![Apex](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c75cdc9aafee42d7d06e9_Citi-Bank-Logo%20\(26\).svg)

![Bay](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c75e591a017e233ee9884_Citi-Bank-Logo%20\(27\).svg)

![Fortuna](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c760499243844a7e676a2_Citi-Bank-Logo%20\(28\).svg)

![Step](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c761c7b79a58e4085c83b_Citi-Bank-Logo%20\(29\).svg)

![Simona Tanning](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c764b321f40f85cbcb1b4_Citi-Bank-Logo%20\(31\).svg)

![boss](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c728028c46e014876f7fb_Telenor-Logo%20\(2\).svg)

![adidas](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c729d47739367b2d1ef8d_SCB-Logo%20\(2\).svg)

![nike](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c72b34796f0608b45bb4a_HSBC-Logo%20\(2\).svg)

![puma](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c72d99708c6a4e7692312_Citi-Bank-Logo%20\(15\).svg)

![aldo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7313831cb3f78a8f7c28_Citi-Bank-Logo%20\(16\).svg)

![hm](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c732f863aff64d4f1d099_Citi-Bank-Logo%20\(17\).svg)

![marks & spencer](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c73ef474f93ad6e0b774f_Citi-Bank-Logo%20\(18\).svg)

![picard](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c740aaace9489bc5042d6_Citi-Bank-Logo%20\(19\).svg)

![timberland](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7423a31397ba10d217d6_Citi-Bank-Logo%20\(20\).svg)

![Hush Puppies](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c744cda87e1899c6f188c_Telenor-Logo%20\(3\).svg)

![Esprit](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c746d750e0f9f6342db1a_SCB-Logo%20\(3\).svg)

![Reebok](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7489e7b77cd048760c21_HSBC-Logo%20\(3\).svg)

![Decathlon](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c74ad3f6ca499f7b4e461_Citi-Bank-Logo%20\(21\).svg)

![Deichmann](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c74d3012af90265c4e412_Citi-Bank-Logo%20\(22\).svg)

![Fila](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c74f711654cc6d1a5e9db_Citi-Bank-Logo%20\(23\).svg)

![Bata](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7594542f8db0503e8bda_Citi-Bank-Logo%20\(24\).svg)

![Lotto](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c75b3bf753247778e69c3_Citi-Bank-Logo%20\(25\).svg)

![Apex](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c75cdc9aafee42d7d06e9_Citi-Bank-Logo%20\(26\).svg)

![Bay](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c75e591a017e233ee9884_Citi-Bank-Logo%20\(27\).svg)

![Fortuna](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c760499243844a7e676a2_Citi-Bank-Logo%20\(28\).svg)

![Step](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c761c7b79a58e4085c83b_Citi-Bank-Logo%20\(29\).svg)

![Simona Tanning](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c764b321f40f85cbcb1b4_Citi-Bank-Logo%20\(31\).svg)

![boss](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c728028c46e014876f7fb_Telenor-Logo%20\(2\).svg)

![adidas](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c729d47739367b2d1ef8d_SCB-Logo%20\(2\).svg)

![nike](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c72b34796f0608b45bb4a_HSBC-Logo%20\(2\).svg)

![puma](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c72d99708c6a4e7692312_Citi-Bank-Logo%20\(15\).svg)

![aldo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7313831cb3f78a8f7c28_Citi-Bank-Logo%20\(16\).svg)

![hm](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c732f863aff64d4f1d099_Citi-Bank-Logo%20\(17\).svg)

![marks & spencer](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c73ef474f93ad6e0b774f_Citi-Bank-Logo%20\(18\).svg)

![picard](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c740aaace9489bc5042d6_Citi-Bank-Logo%20\(19\).svg)

![timberland](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7423a31397ba10d217d6_Citi-Bank-Logo%20\(20\).svg)

![Hush Puppies](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c744cda87e1899c6f188c_Telenor-Logo%20\(3\).svg)

![Esprit](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c746d750e0f9f6342db1a_SCB-Logo%20\(3\).svg)

![Reebok](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7489e7b77cd048760c21_HSBC-Logo%20\(3\).svg)

![Decathlon](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c74ad3f6ca499f7b4e461_Citi-Bank-Logo%20\(21\).svg)

![Deichmann](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c74d3012af90265c4e412_Citi-Bank-Logo%20\(22\).svg)

![Fila](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c74f711654cc6d1a5e9db_Citi-Bank-Logo%20\(23\).svg)

![Bata](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7594542f8db0503e8bda_Citi-Bank-Logo%20\(24\).svg)

![Lotto](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c75b3bf753247778e69c3_Citi-Bank-Logo%20\(25\).svg)

![Apex](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c75cdc9aafee42d7d06e9_Citi-Bank-Logo%20\(26\).svg)

![Bay](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c75e591a017e233ee9884_Citi-Bank-Logo%20\(27\).svg)

![Fortuna](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c760499243844a7e676a2_Citi-Bank-Logo%20\(28\).svg)

![Step](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c761c7b79a58e4085c83b_Citi-Bank-Logo%20\(29\).svg)

![Simona Tanning](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c764b321f40f85cbcb1b4_Citi-Bank-Logo%20\(31\).svg)

### POLICIES & INCENTIVES

-   Reduced Corporate Income Tax (CIT) for 5–10 years based on location (Applicable until 30 June 2030; [S.R.O. No. 164-Law/Income Tax/2021](https://nbr.gov.bd/uploads/sros/SRO_on-164_Agro-based_Industry.pdf))
-   50% tax exemption on income from exports (Applicable until 30 June 2028; [SRO No 44/2024-4 Mar 2024)](https://nbr.gov.bd/uploads/sros/SRO_No-44_of_2024.pdf).
-   No VAT on export goods ([SRO No. 180 Ain/2025/308 dated 02 June 2025](https://nbr.gov.bd/uploads/sros/VATSRO-1802.pdf))
-   Import duty-free capital machinery ([118-AIN/2022/66/Customs](https://nbr.gov.bd/uploads/sros/3.SRO-75-2022-Cap-Mach-New_.pdf))
-   10% export subsidy on leather goods (Applicable until 31 December 2025; [FEPD Circular No. 28)](https://www.bb.org.bd/mediaroom/circulars/fepd/jul102025fepd28.pdf)
-   [Leather and Leather Products Development Policy 2019 has comprehensive incentives to boost exports](https://www.dpp.gov.bd/upload_file/gazettes/34813_68326.pdf)

#### RELEVANT BODIES

-   Ministry of Industries
-   Ministry of Commerce
-   Leather Goods & Footwear Manufacturers & Exporters Association of Bangladesh (LFMEAB)
-   Bangladesh Tanners Association (BTA)

## **BIDA Sector Focal**

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69f98aa73cf19f0cbbaaccb2_Untitled%20design%20\(4\).png)

### Faizur Rabbi

Deputy Director

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)](https://wa.me/8801711952685)

[

+8801711082417

](https://wa.me/8801711082417)

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)](mailto:research@bida.gov.bd)

[

rabbeefaizur@gmail.com

](https://rabbeefaizur@gmail.com)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69f98aa73cf19f0cbbaaccb2_Untitled%20design%20\(4\).png)

### SM Rafio Morshed

Assistant Director

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)](https://wa.me/8801711952685)

[

+8801671160070

](https://wa.me/8801671160070)

[EXPLORE OUR SECTOR DESKS](/sector-desks)

Faizur Rabbi

Deputy Director

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)](https://wa.me/8801711952685)

+8801711082417

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)](mailto:research@bida.gov.bd)

rabbeefaizur@gmail.com

SM Rafio Morshed

Assistant Director

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)](https://wa.me/8801711952685)

+8801671160070

![](https://cdn.prod.website-files.com/62434fa732124a0fb112aab4/62434fa732124a0e4912aadb_Chevron%20right-1.svg)

![](https://cdn.prod.website-files.com/62434fa732124a0fb112aab4/62434fa732124a7ce212aacc_Chevron%20right.svg)

## RESOURCES

INVEST IN BANGLADESH

OCT-DEC 2024

[

DOWNLOAD

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68bd42e0a6383274efd68436_INVEST%20IN%20BANGLADESH.pdf)

LEATHER & LEATHER GOODS INDUSTRIES

[

DOWNLOAD

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682ebf06a6e42db5a25deab3_Leather%20%26%20leather%20Goods%20Industries.pdf)

#### BOOK AN APPOINTMENT

##### SERVICE

New Business Opportunities

Registration & Approvals

Regulatory Facilitation

Visa & Work Permit Support

Aftercare

Policy & Sectoral Guidance

##### REQUESTED DATE

##### REQUESTED TIME

**Thank you!**  
Your appointment request has been submitted.  
If approved, a confirmation email will be sent to you.

Oops! Something went wrong while submitting the form.