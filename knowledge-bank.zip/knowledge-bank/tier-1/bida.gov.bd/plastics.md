---
source: "Bangladesh Investment Development Authority (BIDA)"
tier: 1
category: "Government / regulator"
url: "https://bida.gov.bd/investment-sector/plastics"
title: "Untapped Opportunities in Bangladesh’s Plastic Manufacturing Industry"
scraped_at: "2026-07-02"
---

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/686cf7286136ad1eee6ed377_Layer_1%20\(1\).svg)](/)

[中文](/china)[BIDA OSS](/services#one-stop-services)[

Matchmakin

](https://uat-irms.oss.net.bd/matchmaking)

![bida search icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678cd4d48720bb0edd6ad500_Group%2055.svg)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/68945f6c4818ae3dc291a664_Layer_1.svg)![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![search](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6788a1c48788ea23e00ed88c_Group%2055%20\(1\).webp)

![humbergur](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678896a2d5b4ac64ddac5e2a_Group%2096%20\(3\).webp)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

-   [home](/)

-   [OPPORTUNITIES](/opportunities)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [Services](/services)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [RESOURCES](/resources)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [ABOUT BIDA](/about-bida)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [NOTICE](/notices)

[BIDA OSS](https://www.investbangladesh.gov.bd/services#one-stop-service)[中文](/china)[

MATCHMAKING

](https://uat-irms.oss.net.bd/matchmaking)

# Plastics

Emerging Export Diversification Engine

![Plastics](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c8ec7f4b5403f723108aa_Mask%20group%20\(35\).webp)

6000+

factories

$3B

domestic market

20%

annual market growth

21%

export growth in FY25

## OVERVIEW

Bangladesh’s plastics industry is a fast-growing, employment-intensive sector supporting both domestic demand and global trade. The country is home to over 6,000 plastic manufacturing units, with 80% small and medium enterprises (SMEs) and 450 export-oriented firms. The industry employs approximately 1.5 million workers, meets over 80% of domestic demand (valued at USD 3 billion), and is growing at an estimated 20% annually.

Bangladesh produces more than 2,500 types of plastic products across sectors including packaging, construction, textiles, consumer goods, pharmaceuticals, automotive, and electronics. Around 17% of the sector’s output is exported, reflecting growing global competitiveness.

Recognized as a priority sector for export diversification under the National Industry Policy 2022, plastics exports recorded a 21.25% year-on-year growth in the July–February period of FY2024–25, reaching USD 203.63 million. While exports were historically concentrated in Europe, the sector is now expanding into North America, Australia, and emerging African markets.

Globally, the plastics market was valued at USD 712 billion in 2023 and is projected to reach USD 1.05 trillion by 2033 (CAGR: 4%), driven by demand across food & beverage, consumer goods, automotive, and electronics. Bangladesh currently holds only 0.5% of the global market, with clear ambitions to increase its share to 3%, backed by rising capacity, strong price competitiveness, and improving product standards.

## Growth Drivers

![Expanding Export Base](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c519c18ef09dcee2541b1_Group%20174.svg)

### Expanding Export Base

Plastic exports include USD 220M in direct shipments and USD 900M indirectly through the garment sector.

![High Domestic Coverage](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c60ad0d44bda929df1e3e_Group%20173.svg)

### High Domestic Coverage

The sector meets approximately 83.4% of Bangladesh’s domestic demand, significantly reducing reliance on imported plastic products.

![Diverse Product Range](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c67489a86eb99baec473d_Group%20167.svg)

### Diverse Product Range

The industry produces over 2,500 product types, including household items, packaging materials, toys, plastic moulds, melamine, furniture, PP woven bags, garment accessories, and components for electrical and automotive applications.

![Foreign Supplier Interest](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c51d814d4da2279365798_Agro%20Icon-01.svg)

### Foreign Supplier Interest

Growing demand for advanced technology including plastic injection moulding machines, PP woven bag machines, flexographic printing units, PET blow moulding machines, and plastic bag-making equipment.

![Job Creation & Cost Advantage](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c52424b6c0302704a3c16_Health%20Icon-05.svg)

### Job Creation & Cost Advantage

With a workforce of 1.5 million and a competitive average monthly wage of USD 66, the industry offers a compelling cost advantage for both local and international investors.

## KEY PLAYERS

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678c7258337ee533c78e5fe9_Rectangle%2041.svg)![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678c7258e1f212fceb08d288_Rectangle%2024.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7890683d3bb635e3c18a_Axiata-Logo%20\(5\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c78ca41d8916da3584c8b_Telenor-Logo%20\(5\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c78f589a2bb929f5b620d_SCB-Logo%20\(5\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7916843a89d811260508_HSBC-Logo%20\(5\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c793570d77823f5ebc2b7_Citi-Bank-Logo%20\(38\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c79521fce3b9df4e69946_Citi-Bank-Logo%20\(39\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c79710eb1d87251a57c1a_Citi-Bank-Logo%20\(40\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c799f773e5cce5274af35_Citi-Bank-Logo%20\(41\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7a0d5f4b1f6fc51805df_Citi-Bank-Logo%20\(43\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7a2684ae2966ca5a9206_Citi-Bank-Logo%20\(44\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7a41122d85a15d3f4b27_Citi-Bank-Logo%20\(45\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7a656dfcb24e530eacc3_Citi-Bank-Logo%20\(47\).svg)

## KEY PLAYERS

![RFL Plastics](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7890683d3bb635e3c18a_Axiata-Logo%20\(5\).svg)

![Bengal](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c78ca41d8916da3584c8b_Telenor-Logo%20\(5\).svg)

![Akij Group](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c78f589a2bb929f5b620d_SCB-Logo%20\(5\).svg)

![Aziz Pipes Limited](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7916843a89d811260508_HSBC-Logo%20\(5\).svg)

![Gazi](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c793570d77823f5ebc2b7_Citi-Bank-Logo%20\(38\).svg)

![Matador](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c79521fce3b9df4e69946_Citi-Bank-Logo%20\(39\).svg)

![Partex Plastics](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c79710eb1d87251a57c1a_Citi-Bank-Logo%20\(40\).svg)

![Aman Plastic Toys Industries](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c799f773e5cce5274af35_Citi-Bank-Logo%20\(41\).svg)

![GQ](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7a0d5f4b1f6fc51805df_Citi-Bank-Logo%20\(43\).svg)

![Kader](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7a2684ae2966ca5a9206_Citi-Bank-Logo%20\(44\).svg)

![NPOLY](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7a41122d85a15d3f4b27_Citi-Bank-Logo%20\(45\).svg)

![Premiafles](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7a656dfcb24e530eacc3_Citi-Bank-Logo%20\(47\).svg)

![RFL Plastics](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7890683d3bb635e3c18a_Axiata-Logo%20\(5\).svg)

![Bengal](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c78ca41d8916da3584c8b_Telenor-Logo%20\(5\).svg)

![Akij Group](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c78f589a2bb929f5b620d_SCB-Logo%20\(5\).svg)

![Aziz Pipes Limited](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7916843a89d811260508_HSBC-Logo%20\(5\).svg)

![Gazi](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c793570d77823f5ebc2b7_Citi-Bank-Logo%20\(38\).svg)

![Matador](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c79521fce3b9df4e69946_Citi-Bank-Logo%20\(39\).svg)

![Partex Plastics](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c79710eb1d87251a57c1a_Citi-Bank-Logo%20\(40\).svg)

![Aman Plastic Toys Industries](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c799f773e5cce5274af35_Citi-Bank-Logo%20\(41\).svg)

![GQ](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7a0d5f4b1f6fc51805df_Citi-Bank-Logo%20\(43\).svg)

![Kader](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7a2684ae2966ca5a9206_Citi-Bank-Logo%20\(44\).svg)

![NPOLY](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7a41122d85a15d3f4b27_Citi-Bank-Logo%20\(45\).svg)

![Premiafles](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7a656dfcb24e530eacc3_Citi-Bank-Logo%20\(47\).svg)

![RFL Plastics](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7890683d3bb635e3c18a_Axiata-Logo%20\(5\).svg)

![Bengal](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c78ca41d8916da3584c8b_Telenor-Logo%20\(5\).svg)

![Akij Group](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c78f589a2bb929f5b620d_SCB-Logo%20\(5\).svg)

![Aziz Pipes Limited](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7916843a89d811260508_HSBC-Logo%20\(5\).svg)

![Gazi](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c793570d77823f5ebc2b7_Citi-Bank-Logo%20\(38\).svg)

![Matador](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c79521fce3b9df4e69946_Citi-Bank-Logo%20\(39\).svg)

![Partex Plastics](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c79710eb1d87251a57c1a_Citi-Bank-Logo%20\(40\).svg)

![Aman Plastic Toys Industries](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c799f773e5cce5274af35_Citi-Bank-Logo%20\(41\).svg)

![GQ](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7a0d5f4b1f6fc51805df_Citi-Bank-Logo%20\(43\).svg)

![Kader](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7a2684ae2966ca5a9206_Citi-Bank-Logo%20\(44\).svg)

![NPOLY](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7a41122d85a15d3f4b27_Citi-Bank-Logo%20\(45\).svg)

![Premiafles](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7a656dfcb24e530eacc3_Citi-Bank-Logo%20\(47\).svg)

### POLICIES & INCENTIVES

-   Reduced Corporate Income Tax for 5–10 years for new plastic recycling businesses (Applicable until 30 June 2030; [S.R.O. No. 164-Law/Income Tax/2021](https://nbr.gov.bd/uploads/sros/SRO_on-164_Agro-based_Industry.pdf))
-   3% import duty on capital machinery/spares for other industries ([S.R.O. No. 121-AIN/2020/72/Customs](https://nbr.gov.bd/uploads/sros/2.SRO-121-2020-Capital-Mach-New_.pdf); [S.R.O. No. 122-AIN/2020/73/Customs](https://nbr.gov.bd/uploads/sros/3.SRO-122-2020-Indus-Raw-Mat-New.pdf))
-   Reduced import duty on raw materials & capital machinery ([S.R.O. No. 121-AIN/2020/72/Customs](https://nbr.gov.bd/uploads/sros/2.SRO-121-2020-Capital-Mach-New_.pdf); [S.R.O. No. 122-AIN/2020/73/Customs](https://nbr.gov.bd/uploads/sros/3.SRO-122-2020-Indus-Raw-Mat-New.pdf))
-   50% tax exemption on export income (Applicable until 30 June 2028; [SRO No. 170-Law/Income Tax/2023](https://nbr.gov.bd/uploads/sros/IT-SRO-170.pdf))
-   No VAT on export goods ([SRO No. 180 Ain/2025/308 dated 02 June 2025](https://nbr.gov.bd/uploads/sros/VATSRO-1802.pdf))
-   6% cash incentive on export of plastic products, including PET bottles (Applicable until 31 December 2025; [FEPD Circular No. 28](https://www.bb.org.bd/mediaroom/circulars/fepd/jul102025fepd28.pdf)).
-   6% export subsidy on polyester staple fiber plastic made from PET bottle flex (Applicable until 31 December 2025; [FEPD Circular No. 28](https://www.bb.org.bd/mediaroom/circulars/fepd/jul102025fepd28.pdf)).
-   6% export subsidy for PET bottles used in potato flakes exports (Applicable until 31 December 2025; [FEPD Circular No. 28](https://www.bb.org.bd/mediaroom/circulars/fepd/jul102025fepd28.pdf)).
-   [Towards A Multisectoral Action Plan For Sustainable Plastic Management In Bangladesh](https://doe.portal.gov.bd/sites/default/files/files/doe.portal.gov.bd/publications/25a7382d_11cc_4a55_b9d1_b575e843f401/2022-10-18-13-40-3c4c8bb9b9ed8d477a0eac9c653c6d69.pdf)

#### RELEVANT BODIES

-   Ministry of Industries
-   Ministry of Commerce
-   Bangladesh Plastic Goods Manufacturers & Exporters Association (BPGMEA)
-   Bangladesh Plastic Flakes Manufacturers and Export Association (BPFMEA)
-   Bangladesh Institute of Plastic Engineering & Technology (BIPET)

## **BIDA Sector Focal**

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69f98aa73cf19f0cbbaaccb2_Untitled%20design%20\(4\).png)

### Faizur Rabbi

Deputy Director

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)](https://wa.me/8801711952685)

[

+8801711082417

](https://wa.me/8801711082417)

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)](mailto:research@bida.gov.bd)

[

rabbeefaizur@gmail.com

](https://rabbeefaizur@gmail.com)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69f98aa73cf19f0cbbaaccb2_Untitled%20design%20\(4\).png)

### SM Rafio Morshed

Assistant Director

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)](https://wa.me/8801711952685)

[

+8801671160070

](https://wa.me/8801671160070)

[EXPLORE OUR SECTOR DESKS](/sector-desks)

Faizur Rabbi

Deputy Director

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)](https://wa.me/8801711952685)

+8801711082417

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)](mailto:research@bida.gov.bd)

rabbeefaizur@gmail.com

SM Rafio Morshed

Assistant Director

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)](https://wa.me/8801711952685)

+8801671160070

![](https://cdn.prod.website-files.com/62434fa732124a0fb112aab4/62434fa732124a0e4912aadb_Chevron%20right-1.svg)

![](https://cdn.prod.website-files.com/62434fa732124a0fb112aab4/62434fa732124a7ce212aacc_Chevron%20right.svg)

## RESOURCES

PLASTIC INDUSTRY

JUNE 2023

[

DOWNLOAD

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682ec19ac85cfde3f7b32f6d_Plastic%20Industry.pdf)

#### BOOK AN APPOINTMENT

##### SERVICE

New Business Opportunities

Registration & Approvals

Regulatory Facilitation

Visa & Work Permit Support

Aftercare

Policy & Sectoral Guidance

##### REQUESTED DATE

##### REQUESTED TIME

**Thank you!**  
Your appointment request has been submitted.  
If approved, a confirmation email will be sent to you.

Oops! Something went wrong while submitting the form.