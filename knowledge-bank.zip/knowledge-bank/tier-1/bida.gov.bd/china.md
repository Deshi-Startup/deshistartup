---
source: "Bangladesh Investment Development Authority (BIDA)"
tier: 1
category: "Government / regulator"
url: "https://bida.gov.bd/china"
title: "China Investment Gateway｜中国投资"
scraped_at: "2026-07-02"
---

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/686cf7286136ad1eee6ed377_Layer_1%20\(1\).svg)](/china)

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/686cf7286136ad1eee6ed377_Layer_1%20\(1\).svg)](/china)

[首页](/china)[投资机遇](#china-sector)[资源中心](https://investbangladesh.gov.bd/resources)[关于BIDA](/china-page-about-bida) [联系我们](/china-page-contact)

[English](/)[B2B商务对接](https://irms.bida.gov.bd/matchmaking)

# China  
Investment Gateway

# **中国投资者入口**

连接中国投资者与孟加拉国重点投资机遇

半万亿美元经济体  

3400万中产及富裕消费人口

人口年龄中位数26岁

半万亿美元经济体

3400万中产及富裕消费人口

人口年龄中位数26岁

[

联系我们

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a2f8b66f789986bf2eec25b_Icon%20\(1\).png)](/china-page-contact)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3a27910b04373ac8ad792a_flag%20china-bangladesh.png)

数据看点

## 中国在孟投资概览

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a375f266a55fb730e15d554_111.png)

### 1000+

#### 家中国企业在孟加拉国运营

在制造业、科技和服务业形成成熟布局

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a375f271051ca4400ea9c4e_112.png)

### 55万+

#### 中国投资创造的就业岗位

支持本地就业与技能提升

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a375f25077774be0379f496_113.png)

### 32亿美元

#### 中国对孟加拉国投资存量

截至2025年12月，累计FDI包括中国香港特别行政区

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a375f28f092e143fba70f7f_114.png)

### 12.3亿美元

#### 中国在电力与能源领域的FDI

随着中国对孟投资组合多元化，该领域成为领先领域

竞争优势

## 中国企业为何选择孟加拉国

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a351b9ee22db33d6ed05388_1.png)

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a2f8b66f789986bf2eec25b_Icon%20\(1\).png)

### 通往南亚和东南亚的门户



](/invest-in-bangladesh/gateway-to-south-and-southeast-asia)

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a2f8b66f789986bf2eec25b_Icon%20\(1\).png)

### 全球第八大劳动力市场



](/invest-in-bangladesh/worlds-8th-largest-workforce)

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a2f8b66f789986bf2eec25b_Icon%20\(1\).png)

### 到2030年成为全球第九大消费市场



](/invest-in-bangladesh/9th-largest-consumer-market-by-2030)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a351b9ee22db33d6ed05388_1.png)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a2f8b66f789986bf2eec25b_Icon%20\(1\).png)[通往南亚和东南亚的门户](/invest-in-bangladesh/gateway-to-south-and-southeast-asia)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a2f8b66f789986bf2eec25b_Icon%20\(1\).png)[全球第八大劳动力市场](/invest-in-bangladesh/worlds-8th-largest-workforce)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a2f8b66f789986bf2eec25b_Icon%20\(1\).png)[到2030年成为全球第九大消费市场](/invest-in-bangladesh/9th-largest-consumer-market-by-2030)

**企业故事**

## 在孟中国企业分享投资与成  
长经验

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a2fa38d11337841f0ddf576_Huawei_Standard_logo%201.png)

助力孟加拉国数字化发展、人力资本建设、绿色能源转型和本地经济生态发展

[

查看详情

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a2f8b66f789986bf2eec25b_Icon%20\(1\).png)

](/leading-chinese-enterprises/story-huawei)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a34cc67e16a19b5fb72d0c7_zte%20main.png)

通过战略性技术投资和基础设施建设推进孟加拉国数字化转型

[

查看详情

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a2f8b66f789986bf2eec25b_Icon%20\(1\).png)

](/leading-chinese-enterprises/zte)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a34cd1c5b5b48200279f72a_307565775_405707668394986_6281712374396245666_n.jpg)

通过战略性能源投资助力孟加拉国可持续增长

[

查看详情

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a2f8b66f789986bf2eec25b_Icon%20\(1\).png)

](/leading-chinese-enterprises/bepc)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3674abca0e46e56c01bee9_KMK_logo.png)

在孟加拉国建立高端航空用品包出口制造基地  

[

查看详情

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a2f8b66f789986bf2eec25b_Icon%20\(1\).png)

](/leading-chinese-enterprises/kmk)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a367428f139279efd798112_ldc.png)

业务涵盖成衣垂直产业链、鞋类、包装、建筑、渔业及海产品加工  

[

查看详情

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a2f8b66f789986bf2eec25b_Icon%20\(1\).png)

](/leading-chinese-enterprises/ldc-group)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3ce649247090ca895e66fc_2.png)

孟加拉国最大的轻型商用电动车锂电池换电网络  

[

查看详情

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a2f8b66f789986bf2eec25b_Icon%20\(1\).png)

](/leading-chinese-enterprises/tiger-new-energy)

竞争优势

## **优先行业**

纺织与服装

农产品加工

电子产品与信息技术

制药与医疗保健

电动汽车与汽车产业

可再生能源

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3269984d2cda93cd6fa6af_clothing_image_807x607.webp)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a38e2e61cc38736b1153544_textile.png)

#### 纺织与服装

全球第二大成衣出口国，引领绿色制造，  
并持续扩大国际市场覆盖

### #2

全球第二大成衣出口国

### 230+

LEED认证工厂

### 52

免税出口市场

### 10%

绿色税收激励

[

探索机遇

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a2f8b66f789986bf2eec25b_Icon%20\(1\).png)

](/china-sector/textile---apparel)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a38e2e61cc38736b1153544_textile.png)

#### **纺织与服装**

全球第二大成衣出口国，引领绿色制造，并持续扩大国际市场覆盖

### **#2**

全球第二大成衣出口国

### **230+**

 LEED认证工厂

### **52**

免税出口市场

### **10%**

 绿色税收激励

[

探索机遇

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a2f8b66f789986bf2eec25b_Icon%20\(1\).png)

](/china-sector/textile---apparel)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3269984d2cda93cd6fa6af_clothing_image_807x607.webp)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a38df314f514b060d88128d_agro.png)

#### 农产品加工

农业投资机遇三角洲

### 70M+

年农业产量超过7000万吨

### 13%

农业部门表现年复合增长率

### 7.3B

 包装食品市场规模达73亿美元

### 700

出口产品种类，销往140多个国家

[

探索机遇

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a2f8b66f789986bf2eec25b_Icon%20\(1\).png)](/china-sector/agribusiness)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3625a1187ee727427aed0c_ChatGPT%20Image%20Jun%2020%2C%202026%2C%2011_30_05%20AM.png)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3625a1187ee727427aed0c_ChatGPT%20Image%20Jun%2020%2C%202026%2C%2011_30_05%20AM.png)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a38f6ae7328f22b3925fe79_trac.png)

#### 农产品加工

农业投资机遇三角洲

### 70M+

年农业产量超过7000万吨

### 13%

农业部门表现年复合增长率

### 7.3B

包装食品市场规模达73亿美元

### 700

出口产品种类，销往140多个国家

[

探索机遇

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a2f8b66f789986bf2eec25b_Icon%20\(1\).png)

](/china-sector/agribusiness)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3a149e76be3e47eb2657d6_20b281a2-5f21-4093-a3f1-9d5e273d345f.jpg)

#### 电子产品与信息技术

青春、连接与代码交汇之地

### **全球第9位**

移动连接总量全球排名

### 21亿美元

2025年IT服务市场规模

### **65万+**

 注册自由职业者

### **4500+**

IT与软件公司

[

探索机遇

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a2f8b66f789986bf2eec25b_Icon%20\(1\).png)](/china-sector/electronics-and-it)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3b7ccbf2f30a0b3818ca78_WhatsApp%20Image%202026-06-24%20at%2012.42.47%20PM.jpeg)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3b7ccbf2f30a0b3818ca78_WhatsApp%20Image%202026-06-24%20at%2012.42.47%20PM.jpeg)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a38f54add42e1f84e0152b7_its.png)

#### 电子产品与信息技术

青春、连接与代码交汇之地

### 全球第9位

移动连接总量全球排名

### 21亿美元

到2025年，IT服务市场将如何发展

### 65万+

注册自由职业者

### 4500+

IT与软件公司

[

探索机遇

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a2f8b66f789986bf2eec25b_Icon%20\(1\).png)

](/china-sector/electronics-and-it)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a38f012bd92adc14b2028b8_pharma.png)

#### 制药与医疗保健

扩大医疗可及性，提升医疗能力

### 140亿美元

当前医疗保健市场规模

### 230亿美元

2030年市场机遇

### 98%

 药品需求由本地生产满足

### 8.2亿美元+

医疗科技市场，并受到私立医院4倍增长和诊断中心6倍增长支撑

[

探索机遇

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a2f8b66f789986bf2eec25b_Icon%20\(1\).png)

](/china-sector/pharma-healthcare)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3b7ccacaf62338e8e2d634_WhatsApp%20Image%202026-06-24%20at%2012.42.10%20PM.jpeg)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3b7ccacaf62338e8e2d634_WhatsApp%20Image%202026-06-24%20at%2012.42.10%20PM.jpeg)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a38f012bd92adc14b2028b8_pharma.png)

#### 制药与医疗保健

扩大医疗可及性，提升医疗能力

### 140亿美元

当前医疗保健市场规模

### 230亿美元

2030年市场机遇

### 98%

药品需求由本地生产满足

### 8.2亿美元+

医疗科技市场，并受到私立医院4倍增长和诊断中心6倍增长支撑

[

探索机遇

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a2f8b66f789986bf2eec25b_Icon%20\(1\).png)

](/china-sector/pharma-healthcare)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a38e58160934d8960b86de7_automotives.png)

#### 电动汽车与汽车产业

驱动下一代出行转型

### 600万+

全国注册车辆

### 5%

乘用车市场年增长率

### 20亿美元+

2030年市场机遇

### 零关税

电动汽车充电器、充电站、电池组件及原材料进口关税为零

[

探索机遇

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a2f8b66f789986bf2eec25b_Icon%20\(1\).png)](/china-sector/automotives)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3b7c5ab20cb4ab3cbc2b5b_ChatGPT%20Image%20Jun%2024%2C%202026%2C%2010_52_48%20AM.png)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3b7c5ab20cb4ab3cbc2b5b_ChatGPT%20Image%20Jun%2024%2C%202026%2C%2010_52_48%20AM.png)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a38e58160934d8960b86de7_automotives.png)

#### 电动汽车与汽车产业

驱动下一代出行转型

### 600万+

全国注册车辆

### 5%

乘用车市场年增长率

### 20亿美元+

2030年市场机遇

### 零关税

电动汽车充电器、充电站、电池组件及原材料进口关税为零

[

探索机遇

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a2f8b66f789986bf2eec25b_Icon%20\(1\).png)

](/china-sector/automotives)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a2fc595ad0c9875074ed4ef_Container%20\(2\).png)

#### 可再生能源

为增长型经济加速能源供给

### 600万+

 已安装太阳能家庭系统

### 7%

年度电力需求增长

### 20%

 2030年可再生能源目标

### 10

 清洁能源项目税收假期

[

探索机遇

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a2f8b66f789986bf2eec25b_Icon%20\(1\).png)

](/china-sector/renewable-energy)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a2fc380e6de79e22b78339f_Container.png)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a2fc380e6de79e22b78339f_Container.png)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a2fc595ad0c9875074ed4ef_Container%20\(2\).png)

#### 可再生能源

为增长型经济加速能源供给

### 600万+

已安装太阳能家庭系统

### 7%

年度电力需求增长

### 20%

 2030年可再生能源目标

### 10年

 清洁能源项目税收假期

[

探索机遇

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a2f8b66f789986bf2eec25b_Icon%20\(1\).png)](/china-sector/renewable-energy)

**在孟加拉国的主要中国投资者**

![Company logo](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3ce6a6139a885be3fb44ae_23.png)

![Company logo](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3ce6a2764a1bbe1df3243b_21.png)

![Company logo](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3ce6a2bca3b9dc98ba7b42_19.png)

![Company logo](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3ce6a2c2744ead38480868_22.png)

![Company logo](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3ce6a1ab2b0f0cacf99537_713f0d11128043a66bde6124c534620d_24.png)

![Company logo](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3ce6a1bca3b9dc98ba7a86_281ecbd5a88b1c31954ca9de53c0435c_20.png)

![Company logo](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3ce69d7fc921a5f9e086b4_15.png)

![Company logo](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3ce69dab2b0f0cacf991e2_9e9d7aa966d59e6ae656a393fb397a8e_16.png)

![Company logo](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3ce69dc1587a40785f658d_14.png)

![Company logo](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3ce69d247090ca895eb091_13.png)

![Company logo](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3ce69d29531c78fc2b64cf_18.png)

![Company logo](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3ce69d35326e3668dead9e_17.png)

![Company logo](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3ce69a60cddb5bc21d42ae_12.png)

![Company logo](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3ce69977a58b0fef243dbf_9.png)

![Company logo](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3ce69977a58b0fef243dba_7.png)

![Company logo](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3ce699764a1bbe1df31ff1_8.png)

![Company logo](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3ce699764a1bbe1df31fee_11.png)

![Company logo](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3ce6998102868f5c60ae36_10.png)

![Company logo](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3ce6964126f672bd99b168_043bb4676ba54ffffe412f9ba7a3f543_1.png)

![Company logo](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3ce6953a9bc06d2007d92d_4.png)

![Company logo](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3ce695ab2b0f0cacf98d7f_3.png)

![Company logo](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3ce694a7d30df8b5e0b52d_6.png)

![Company logo](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3ce69460cddb5bc21d3b4f_7748ec8b85d6d960507a3eac37003f83_5.png)

![Company logo](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3ce649247090ca895e66fc_2.png)

工业用地

## 中国经济和工业区

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a310e455de561172c81dc34_Containerz.png)

### **位置** **—** **安瓦拉，吉大港**

**位于安瓦拉，距吉大港市约15公里，靠近孟加拉国主要海港。**

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a310e451624af4eb7a0382e_Containerz1.png)

### **土地面积 —** **781英亩**

**全政府所有土地，规划用于大规模经济区开发。**

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a310e45160682d6afeb548e_Containerz2.png)

### **互联互通 —** **港口 + 公路 + 水路 + 铁路 + 机场**

**连接吉大港港口、国家公路、水路、铁路以及沙阿阿马纳特国际机场。**

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a310e45becaf8090fc71335_Containerz3.png)

###  **产业 —** **多行业 / 出口导向型产业**

 **适合化工、汽车组装、服装、制药、造船等出口导向型产业。**

[

查看详情

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a2f8b66f789986bf2eec25b_Icon%20\(1\).png)](/china-economic-zone)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a310e455de561172c81dc34_Containerz.png)

### 位置 — 安瓦拉，吉大港

位于安瓦拉，距吉大港市约15公里，靠近孟加拉国主要海港。

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a310e451624af4eb7a0382e_Containerz1.png)

### 土地面积 — 781英亩

全政府所有土地，规划用于大规模经济区开发。

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a310e45160682d6afeb548e_Containerz2.png)

### 互联互通 — 港口 + 公路 + 水路 + 铁路 + 机场

连接吉大港港口、国家公路、水路、铁路以及沙阿阿马纳特国际机场。

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a310e45becaf8090fc71335_Containerz3.png)

###  产业 — 多行业 / 出口导向型产业

 适合化工、汽车组装、服装、制药、造船等出口导向型产业。

[

查看详情

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a2f8b66f789986bf2eec25b_Icon%20\(1\).png)](/china-economic-zone)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a3662a4b3793215d696ab50_Banglabiz-removebg-preview.png)

## 开始您的孟加拉国投资之旅

**BanglaBiz是孟加拉国所有投资和商业相关服务的统一入口。  
通过一个统一平台，启动、跟踪并管理关键商业审批。**

[

BanglaBiz

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a30c41b7584432accd0b5c8_Icon8.png)](https://banglabiz.gov.bd/)

投资者支持

## 常见问题解答

与其他区域投资目的地相比，孟加拉国为投资者提供哪些竞争优势？

劳动力成本竞争力  
· 成衣行业最低工资为每月12,500塔卡（约113美元），明显低于越南（135至152美元）、印度尼西亚（170至204美元）和柬埔寨（204美元）  
· 对于劳动密集型出口制造商而言，这一差异可直接转化为更低的单位成本和更强的利润率  
  
劳动力规模与质量  
· 孟加拉国人口达1.736亿，其中超过65%处于劳动年龄，人口年龄中位数为26岁  
· 当前正处于人口红利的高峰阶段；人口学家预计，这一窗口期将持续至2040年前后  
· 年劳动生产率增长率为5.8%，高于越南的5.1%  
  
出口市场准入  
‍· 目前，欧洲市场销售的服装中，近四分之一产自孟加拉国  
· 孟加拉国是全球两大消费市场中第二大服装供应国  
· 截至2025年，孟加拉国在欧盟市场的份额为21.57%，在美国市场的份额为10.53%  
‍  
战略地理位置  
‍· 孟加拉国连接南亚和东南亚，是通往南亚次大陆和东盟市场的重要门户  
· 4小时飞行半径内可覆盖25亿消费者  
  
成熟的制造业基础设施  
‍· 孟加拉国是全球第二大成衣出口国，2024—25财年成衣出口额达482.8亿美元  
· 四十年的出口导向型生产经验，形成了深厚的产业生态，包括配套产业、合规工厂、熟练员工和物流能力· 正在向技术纺织品、鞋类、轻工工程和电子产品组装等领域扩展  
‍  
宏观经济表现  
‍· 预计到2030年，孟加拉国将成为全球第九大消费市场  
· 2013年至2023年期间，年均GDP增长率为6.4%  
· 2025年外国直接投资流入回升至17.7亿美元，较2024年增长39.36%

目前哪些行业是外国直接投资的重点优先领域？

行业

纺织与服装

农产品加工

电子产品与信息技术

制药与医疗保健

汽车

可再生能源

亮点

利用孟加拉国在ESG合规方面的全球领先地位，以及270家LEED认证绿色工厂和成熟供应链，支持行业向高价值、先进和技术纺织品转型。

依托自然资源优势，以及孟加拉国作为全球主要农业和淡水鱼生产国的地位，释放增长潜力；包括通过虾类经济区等专项举措开发蓝色经济机遇。

面向高投资回报资本的重点行业，聚焦电子产品、家用电器和组装制造，深化本地价值增加，承接不断增长的国内和区域消费需求，并推动出口竞争力从服装以外进一步多元化。

具备较高成熟度和即时进入潜力，特别是在原料药（API）和医疗器械领域，可依托现有强大的本地企业和基础设施发展高价值制造。

为进入亚洲最具潜力但尚未充分开发的汽车市场提供重要机会。依托10年制造业税收假期和长期电动汽车材料激励措施，承接不断增长的国内需求，并加速到2030年的绿色出行转型。

聚焦缓解公用事业约束并支持可持续生态系统建设。相关举措包括基于PPP的试点模式，例如130兆瓦Sonagazi太阳能发电项目，以动员私人资本投向公用事业规模的清洁能源。

在孟加拉国，中国投资的当前格局和规模如何？

关键数据：中国对孟加拉国FDI截至2025年12月，中国对孟加拉国FDI存量，包括香港在内，达到31.8亿美元。这一大规模资本投入使中国成为孟加拉国第二大FDI来源地。目前，近1000家中国企业在孟加拉国运营。这些企业累计创造了超过55万个就业岗位。电力仍是中国投资的最大行业，孟加拉国电力领域FDI存量达到34.3亿美元。中国是孟加拉国最大的国防供应方，2018年至2022年期间占孟加拉国武器进口的74%。2024年7月至2025年3月期间，出口加工区和经济区新签署的48项企业协议中，29项来自中国企业。2025年，仅三家旗舰中国企业的拟议投资额就达到3.22亿美元  
  
近期高关注度中国投资承诺  
· Handa Industries，总部位于香港：承诺投资2.5亿美元，用于针织、染整等纺织产业链一体化。  
· Kaixi Group：投资4000万美元，用于高端内衣制造，在Mirsharai的BEPZA经济区雇佣约3700名工人。  
· China Lesso Group：投资3277万美元，用于塑料制造。  
• BEPZA经济区，Mirsharai：2025年1月至9月期间签署23项投资协议，总额3.3372亿美元，其中中国企业占多数。  
‍  
‍

孟加拉国可为制造业投资者提供哪些基础设施、经济区和互联互通条件？

产业导向型园区  
投资者可进入多个专业化园区，并享受特别激励措施和税收假期：  
  
即将建设的中国经济区  
· 将在政府间（G2G）安排下，开发781英亩土地  
· 目标是创造约10万个就业岗位· 旨在吸引约5亿美元投资  
· 将配备专用公用事业线路、道路网络和一座1200米长码头  
  
10个经济区（EZ）  
· 覆盖全国多个关键战略地点，包括Kurigram、Jamalpur、Moulvibazar、Narayanganj、Chandpur、 Chattogram、Cox’s Bazar和Kushtia  
· 独立园区，向各类产业开放  
· 提供长期或短期土地租赁/出租  
· 配备专用公用事业服务  
  
1个出口加工区（EPZ）  
· 分布在全国各地、专门面向出口的工业园区，包括Chattogram EPZ、Dhaka EPZ、Mongla EPZ、Ishwardi EPZ、Cumilla EPZ、Uttara EPZ、Adamjee EPZ、Karnaphuli EPZ、BEPZA EZ、Patuakhali EPZ和Jashore EPZ  
· 提供真正意义上的“即插即用”投资地块高科技园区（HTP）  
· 在战略地点设有4个高科技园区  
· 在主要商业区设有3个软件技术园区  
· 在高校和区域枢纽设有4个运营中的孵化中心  
· 为高科技和IT相关项目提供专门工业园区  
· 提供长期或短期土地租赁/出租  
  
公私合作伙伴关系（PPP）  
· 促进PPP项目，并受理非邀约提案  
· 提供专门的单一管理入口  
· 提供可协商的条款和条件  
  
港口基础设施  
孟加拉国正在建设一体化互联互通网络，重点推进大规模港口扩建，港口处理能力预计将实现6倍增长。全国主要港口和码头的预计总处理能力将达到723万TEU。  
‍  
其中，Laldia集装箱码头于2025年10月签署特许经营协议，取得重要里程碑进展。目前建设已启动，目标处理能力为130万TEU。  
‍  
预计2026年将进一步取得进展，届时Bay Terminal和New Mooring Container Terminal（NCT）的国际招标任命工作将完成，标志着孟加拉国港口发展计划进入下一关键阶段。

外国投资者可享受哪些财政激励和税收优惠？

经济区内  
包括经济区、出口加工区和高科技园区  
· 企业所得可享受所得税减免：前3年100%免税，之后逐步递减至第10年  
· 股息收入和股份转让资本收益可享受10年免税  
· 资本机械和建筑材料进口关税降至1%  
· 与生产相关的公用事业服务可享受增值税免税  
· 土地开发税100%免除  
· 租赁登记印花税减免50%  
  
经济区外  
· 2025年7月1日至2030年6月30日期间开始商业运营的项目，最长可享受15年所得税减免：前10年100%免税，之后3年减免50%，最后2年减免25%  
· 符合条件的进口货物最高适用5%关税，优惠有效期至2028年6月30日  
· 符合条件的进口货物免征监管税和其他相关税费，优惠有效期至2028年6月30日  
· 发电业务可享受增值税免税，优惠有效期至2028年6月30日  
· 本地生产的电动自行车适用5%增值税，并可享受原材料关税减免，优惠有效期至2030年6月30日

孟加拉国的法律框架如何保护和保障外国私人投资？

孟加拉国外国投资保护的法律框架建立在四个支柱之上：国内立法、双边条约义务、多边保险机制，以及机构便利化支持。  
  
\### 《外国私人投资（促进与保护）法，1980年》  
该法案，即1980年第11号法案，是规范外国资本保护的基础性法律。其核心条款保障：· 防止国有化和征收：除非依据适用法律并支付充分补偿，外国投资不得被国有化或征收  
· 在非歧视基础上，给予外国投资者与本国投资者公平和公正待遇  
· 保障资本、本金、利润、股息和收益汇回的权利· 合同权利具有法律可执行性  
  
\### 《BIDA法，2016年》  
《BIDA法，2016年》确立孟加拉国投资发展局（Bangladesh Investment Development Authority, BIDA）作为最高投资促进机构和一站式服务提供方的地位，为投资注册、便利化和后续服务提供机构框架。  
  
\### 双边投资协定（BIT）  
孟加拉国已与33个国家签署双边投资协定（Bilateral Investment Treaties, BITs），将投资者权利置于国际法框架之下，而不仅仅依赖国内政策。《孟中双边投资协定》（Bangladesh-China Bilateral Investment Treaty）为中国投资者提供最惠国待遇，并允许通过国际仲裁进行投资者—国家争端解决。  
  
\### 多边担保  
孟加拉国是世界银行集团（World Bank Group）旗下多边投资担保机构（Multilateral Investment Guarantee Agency, MIGA）成员，投资者可获得政治风险保险，覆盖货币不可兑换、征收、政府违约，以及战争和内乱造成的损失。  
‍  
\### 《公司法，1994年》和《外汇管理法，1947年》  
企业设立和运营受《公司法，1994年》规范。外国汇兑交易，包括资本流入、利润汇出和资本汇回，由孟加拉国银行（Bangladesh Bank）根据《外汇管理法，1947年》进行监管，并通过定期发布的通函逐步放宽相关操作。  
  
\### 争端解决  
投资者—国家争端可根据适用的双边投资协定提交国内法院或国际仲裁。孟加拉国是《纽约公约》（New York Convention）缔约国，为国际仲裁裁决的执行提供框架。  
  
\### 避免双重征税协定避免双重征税协定（Double Taxation Treaties, DTTs）是保护外国投资者收入不在两个不同国家被重复征税的双边协议。孟加拉国目前已与36个国家签署并实施避免双重征税协定，其中包括中国。企业如需享受相关协定待遇，必须获得国家税务局（National Board of Revenue, NBR）批准，且该批准需每年续期。

在孟加拉国设立并注册外国商业实体的分步骤流程是什么？

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a376795f7734eba5cbc03b6_faq%20graph.png)

本概览详细说明了设立并启动各类商业实体所需的监管、合规和许可程序。内容列出了个人独资企业与合伙企业、本地有限公司以及外资有限公司的具体设立路径。流程涵盖从初始名称核准、公司设立，到取得必要的营业执照、税务登记、建筑/结构审批和环境许可，并最终完成开始运营所需的进口相关审批。  
  
‍

开始商业运营需要哪些监管审批、许可证和认证？

公司设立（运营前）  
· 向联合股份公司与企业注册处（Registrar of Joint Stock Companies and Firms, RJSC&F）申请名称核准（Name Clearance）  
· 向联合股份公司与企业注册处（Registrar of Joint Stock Companies and Firms, RJSC&F）办理公司设立登记  
· 对于外国公司：在向联合股份公司与企业注册处（Registrar of Joint Stock Companies and Firms, RJSC&F）提交申请前，需开立临时非居民塔卡银行账户（NRT Bank Account）  
  
核心商业登记  
‍· 向国家税务局（National Board of Revenue, NBR）申请纳税人识别号证书（TIN Certificate）· 申请营业执照（Trade License）  
· 向国家税务局（National Board of Revenue, NBR）办理增值税登记（VAT Registration）  
  
投资与选址登记  
‍· 如项目位于孟加拉国经济区管理局（Bangladesh Economic Zones Authority, BEZA）、孟加拉国出口加工区管理局（Bangladesh Export Processing Zones Authority, BEPZA）、孟加拉国高科技园区管理局（Bangladesh Hi-Tech Park Authority, BHTPA）或孟加拉国小型和家庭工业公司（Bangladesh Small and Cottage Industries Corporation, BSCIC）园区之外，需办理孟加拉国投资发展局（Bangladesh Investment Development Authority, BIDA）登记  
‍  
· 如项目位于孟加拉国经济区管理局（Bangladesh Economic Zones Authority, BEZA）、孟加拉国出口加工区管理局（Bangladesh Export Processing Zones Authority, BEPZA）、孟加拉国高科技园区管理局（Bangladesh Hi-Tech Park Authority, BHTPA）或孟加拉国小型和家庭工业公司（Bangladesh Small and Cottage Industries Corporation, BSCIC）园区之内，则需遵循相应园区管理机构的程序  
  
场地与基础设施  
‍· 向工厂与机构检查局（Department of Inspection for Factories and Establishments, DIFE）申请布局图审批（Approval of Layout Plan）  
· 向首都发展局（Rajdhani Unnayan Kartripakkha, RAJUK）、吉大港发展局（Chittagong Development Authority, CDA）或拉杰沙希发展局（Rajshahi Development Authority, RDA）申请建筑/厂房建设审批  
  
安全与环境许可  
‍· 向消防与民防局（Fire Service and Civil Defence, FSCD）申请消防许可证（Fire License）  
· 向环境局（Department of Environment, DOE）申请环境许可（Environmental Clearance）  
  
‍行业与商贸会员资格  
‍· 加入相关商业/贸易组织  
· 对于受管制行业，需获得相关部委/司局出具的无异议证明（NOC）  
  
进口相关审批  
‍· 申请孟加拉国投资发展局（Bangladesh Investment Development Authority, BIDA）出具临时进口登记证（Ad Hoc IRC）推荐函  
· 向进出口首席管制官办公室（Office of the Chief Controller of Imports and Exports, CCI&E）申请临时进口登记证（Ad Hoc IRC），用于进口资本机械和/或原材料  
  
注  
‍根据企业性质和所属行业，可能还需要额外的行业特定许可证和审批。  
‍  
  
‍

孟加拉国投资发展局（Bangladesh Investment Development Authority, BIDA）  
如何促进并简化外国投资全生命周期？

A. 覆盖投资全生命周期的端到端支持  
· 探索阶段： 孟加拉国投资发展局（Bangladesh Investment Development Authority, BIDA）推广投资机遇，提供市场信息，并将投资者与相关行业、园区管理机构和本地合作伙伴进行对接。· 咨询阶段： 孟加拉国投资发展局（Bangladesh Investment Development Authority, BIDA）提供定制化咨询、监管指导，以及与可信本地企业开展合资合作和B2B商务对接。  
‍  
· 执行与设立阶段： 孟加拉国投资发展局（Bangladesh Investment Development Authority, BIDA）协助办理审批、许可、土地获取、公用事业接入，并与孟加拉国银行（Bangladesh Bank）、国家税务委员会（National Board of Revenue, NBR）、相关部委、孟加拉国经济区管理局（Bangladesh Economic Zones Authority, BEZA）以及孟加拉国出口加工区管理局（Bangladesh Export Processing Zones Authority, BEPZA）协调完成相关许可。  
· 后续服务与扩展阶段： 孟加拉国投资发展局（Bangladesh Investment Development Authority, BIDA）提供投资后支持，协助解决运营问题，促进再投资，并通过专门的后续服务机制处理投资者诉求。  
· B2B商务对接： 孟加拉国投资发展局（Bangladesh Investment Development Authority, BIDA）通过便捷的数字平台，促进投资者与被投资方之间的对接。  
  
B. 咨询与政策支持  
· 政策诊断与倡导： 孟加拉国投资发展局（Bangladesh Investment Development Authority, BIDA）通过投资者反馈识别监管、财政和程序性障碍，并与相关部委和监管机构共同制定改革建议。  
· 投资激励与保护咨询： 孟加拉国投资发展局（Bangladesh Investment Development Authority, BIDA）为投资者提供关于激励措施、税收优惠、投资保护和合规框架的指导。  
· 市场与行业信息： 孟加拉国投资发展局（Bangladesh Investment Development Authority, BIDA）编制行业概况、机会图谱、监管指南和投资展望。  
· 竞争力与对标分析： 孟加拉国投资发展局（Bangladesh Investment Development Authority, BIDA）通过国际对标和绩效监测，支持相关机构改善投资环境。  
  
C. 运营便利化· 单一窗口服务：  
孟加拉国投资发展局（Bangladesh Investment Development Authority, BIDA）通过BanglaBiz一站式服务平台（BanglaBiz One Stop Service Platform）提供综合投资者服务。  
· FDI登记与审批： 孟加拉国投资发展局（Bangladesh Investment Development Authority, BIDA）办理外国直接投资（Foreign Direct Investment, FDI）和合资投资登记、工业许可及监管审批。  
· 跨机构协调： 孟加拉国投资发展局（Bangladesh Investment Development Authority, BIDA）与相关部委、监管机构和服务提供方协调工作流程。  
· 流程效率提升： 孟加拉国投资发展局（Bangladesh Investment Development Authority, BIDA）通过数字化、自动化和流程简化，减少时间、成本和合规负担，提升服务交付效率。  
  

问题8：外国企业人员如何申请签证推荐？

第一步：选择正确的签证类别  
首先需要确定申请人适用的签证类型：  
· E签证： 适用于在符合条件的机构就业的外国人员  
· E-1签证： 适用于服务、安装、维护、培训、监督或项目相关派遣任务  
· PI签证： 适用于在孟加拉国本人投资企业工作的外国投资者‍‍  
  
第二步：确认是否符合通过BIDA申请的条件  
‍符合条件的机构包括私营工业企业、商业办公室、分公司、联络/代表处、项目办公室、银行、医院、教育/文化机构、发展项目和合资企业协会。但由孟加拉国经济区管理局（Bangladesh Economic Zones Authority, BEZA）、孟加拉国出口加工区管理局（Bangladesh Export Processing Zones Authority, BEPZA）、孟加拉国高科技园区管理局（Bangladesh Hi-Tech Park Authority, BHTPA）或非政府组织事务局（NGO Affairs Bureau）主管/推荐的机构，不适用通过孟加拉国投资发展局（Bangladesh Investment Development Authority, BIDA）申请的程序。  
‍  
第三步：准备所需证明材料  
所需文件因签证类型而异：  
· E签证： 招聘流程记录、招聘广告、评估报告，以及候选人的学历和工作经验证明文件  
· E-1签证： 合同/服务文件，以及相关贸易或装运文件  
· PI签证： 符合要求门槛的投资证明。申请人所在机构须至少拥有10万美元外国股权投资，其中申请投资者本人须直接出资至少4万美元  
  
第四步：通过BIDA OSS提交申请  
申请人需通过孟加拉国投资发展局一站式服务平台（Bangladesh Investment Development Authority One-Stop Service, BIDA OSS）在线提交申请，并上传所有所需文件。孟加拉国投资发展局（Bangladesh Investment Development Authority, BIDA）将对申请进行审核。申请获批后，BIDA将出具签证推荐函，外国人员随后可向相关孟加拉国驻外使领馆提交该推荐函，以申请正式签证。‍‍  
  

外国员工申请工作许可需要满足哪些要求？

所有在孟加拉国就业的外国公民，以及在孟加拉国停留并工作的外国投资者，均必须取得工作许可。

申请时限

雇主必须在外国员工抵达孟加拉国后15天内，通过孟加拉国投资发展局一站式服务平台（Bangladesh Investment Development Authority One-Stop Service, BIDA OSS）提交申请，并附上相应签证、护照和支持文件。

核心资格条件

· 外国员工不得受雇于个人独资企业  
· 应优先雇用孟加拉国公民；只有在确实需要专业技能、经验或技术专长的情况下，才可聘用外国员工

本地员工与外国员工比例

机构类型

工业企业

商业/非工业/教育机构

比例（运营前/项目阶段）

10:1（项目实施阶段）

5:1（运营前）

比例（运营/生产阶段）

20:1（正常生产阶段）

10:1（运营期间）

注：投资者不计入上述比例计算

申请内容要求

申请材料必须明确说明外国员工的工资、津贴和福利。雇主还必须确保税务合规，并提交一项本地员工知识转移计划，该计划应在5年内完成。

许可期限和续期

· 初始工作许可通常签发1年  
· 在符合现有许可条件并通过安全审查的前提下，每次可续期最长2年  
· 续期申请必须至少在许可到期前2个月提交  
· 对于工业企业中的外国投资者，如需申请工作许可续期，总投资额通常须至少达到20万美元

外国员工申请工作许可需要满足哪些要求？

资本汇回  
‍资本汇回事项受孟加拉国银行外汇投资部（Bangladesh Bank Foreign Exchange Investment Department, FEID）于2026年3月8日发布的FEID Circular No. 01规范。  
‍可汇出内容  
‍· 股份出售所得的公允价值可全额汇出境外  
· 或者，出售所得在扣除适用税费后，可存入授权交易银行（Authorized Dealer Bank, AD Bank）的外币账户（Foreign Currency Account, FCY Account），随后汇出境外，或在孟加拉国再投资于股权或上市证券  
  
事先批准要求  
‍· 对于大多数交易，无需事先获得孟加拉国银行（Bangladesh Bank）批准。授权交易银行（Authorized Dealer Bank, AD Bank）可在以下情况下直接办理资本汇回：  
o 交易价值不超过公司净资产价值（Net Asset Value, NAV），金额无上限  
o 交易价值不超过1000万塔卡，无需独立估值  
o 交易价值不超过10亿塔卡，但需提交独立估值报告  
· 超过10亿塔卡的交易，需事先获得孟加拉国银行（Bangladesh Bank）批准；授权交易银行（Authorized Dealer Bank, AD Bank）须在3个工作日内将申请转交孟加拉国银行外汇投资部（Bangladesh Bank Foreign Exchange Investment Department, FEID）  
  
流程与时间表  
‍· 买方和卖方须首先签署谅解备忘录（Memorandum of Understanding, MoU）  
· 用于估值的经审计财务报表，其日期距谅解备忘录签署日不得超过6个月  
· 股份转让须在谅解备忘录签署或孟加拉国银行（Bangladesh Bank）批准后的45天内完成，以较晚日期为准  
· 授权交易银行（Authorized Dealer Bank, AD Bank）须在收到完整申请后的5个工作日内完成汇回办理  
  
估值要求  
‍· 出售所得须反映股份的公允价值，并使用以下三种认可方法中的一种或多种进行确定：  
o 净资产价值法（Net Asset Value Approach），即资产基础法  
o 市场法（Market Approach），即可比公司/交易法  
o 折现现金流法（Discounted Cash Flow Approach），即收益基础法  
· 估值报告须由持牌商业银行家（Licensed Merchant Bankers）或在孟加拉国银行（Bangladesh Bank）或孟加拉国证券交易委员会（Bangladesh Securities and Exchange Commission, BSEC）注册的特许会计师（Chartered Accountants）编制  
  
税务义务  
‍· 外国投资者须在汇出前结清所有适用的资本利得税和印花税  
· 税款须使用通过银行渠道从境外汇入的资金支付  
· 目标公司不得承担相关费用  
· 授权交易银行（Authorized Dealer Bank, AD Bank）将在办理汇回前核实税务合规情况  
  
分公司利润汇回  
‍在孟加拉国注册成立的外国银行和保险公司分公司，可通过授权交易银行（Authorized Dealer Bank, AD Bank）将税后利润汇回总部，无需事先批准。其他行业的分公司在汇出利润前，须获得孟加拉国投资发展局（Bangladesh Investment Development Authority, BIDA）和孟加拉国银行（Bangladesh Bank）批准。\[来源\]  
  
服务费汇出：特许权使用费和技术援助费  
‍工业企业汇出特许权使用费、技术诀窍费和技术援助费时，如费用总额不超过上一年度相关销售额的6%，或实缴资本的6%，以较高者为准，则无需事先获得孟加拉国投资发展局（Bangladesh Investment Development Authority, BIDA）批准。\[来源\]  
子公司的服务付款  
FE Circular No. 12（2025年2月19日）引入了一项重要便利化措施：外国公司在孟加拉国的本地子公司，如母公司持股超过50%，可在无需事先获得孟加拉国银行（Bangladesh Bank）批准的情况下，向母公司或集团公司汇出本地无法获得服务的相关服务费用，额度最高为一个会计年度净利润的10%（扣除源泉税前）。超过该上限的汇款，需提交支持文件并获得批准。  
  
外国员工薪资汇出  
‍· 在孟加拉国就业的外国公民，可通过授权交易银行（Authorized Dealer Bank, AD Bank）汇出其月度净工资的最高75%  
· 根据服务合同，在获批休假期间应支付的净工资也可汇出  
\[来源\]  
  
  
术语表（Glossary）  
‍  

缩写

BIDA

BEZA

BEPZA

NBR

FDI

Bangladesh Bank

BanglaBiz

英文全称

Bangladesh Investment Development Authority

Bangladesh Economic Zones Authority

Bangladesh Export Processing Zones Authority

National Board of Revenue

Foreign Direct Investment

Bangladesh Bank

BanglaBiz One Stop Service Platform

中文名称

孟加拉国投资发展局

孟加拉国经济区管理局

孟加拉国出口加工区管理局

国家税务委员会

外国直接投资

孟加拉国银行

BanglaBiz一站式服务平台

联系我们

## 中国投资服务台

联系专门的投资支持代表，获取中国企业进入孟加拉国所需的投资便利化支持。

[

联系中国投资服务台

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a30c41b7584432accd0b5c8_Icon8.png)](/china-country-desk)

![close icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685ce0ccc707148ee0d3dedf_Group%20296.svg)

![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/68c81c4cb7a2ebaf99b8ed48_warning.svg)

Scheduled Domain Migration  

[](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6a27e2042c4231522f9b91a5_Invest-Bangladesh-Newsletter-May-2026-Vol-1-Issue-1.pdf)