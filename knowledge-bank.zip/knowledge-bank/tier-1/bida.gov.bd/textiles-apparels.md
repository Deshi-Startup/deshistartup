---
source: "Bangladesh Investment Development Authority (BIDA)"
tier: 1
category: "Government / regulator"
url: "https://bida.gov.bd/investment-sector/textiles-apparels"
title: "Textiles and apparel"
scraped_at: "2026-07-02"
---

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/686cf7286136ad1eee6ed377_Layer_1%20\(1\).svg)](/)

[中文](/china)[BIDA OSS](/services#one-stop-services)[

Matchmakin

](https://uat-irms.oss.net.bd/matchmaking)

![bida search icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678cd4d48720bb0edd6ad500_Group%2055.svg)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/68945f6c4818ae3dc291a664_Layer_1.svg)![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![search](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6788a1c48788ea23e00ed88c_Group%2055%20\(1\).webp)

![humbergur](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678896a2d5b4ac64ddac5e2a_Group%2096%20\(3\).webp)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

-   [home](/)

-   [OPPORTUNITIES](/opportunities)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [Services](/services)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [RESOURCES](/resources)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [ABOUT BIDA](/about-bida)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [NOTICE](/notices)

[BIDA OSS](https://www.investbangladesh.gov.bd/services#one-stop-service)[中文](/china)[

MATCHMAKING

](https://uat-irms.oss.net.bd/matchmaking)

# Textiles and apparel

World’s Second-Largest RMG Exporter with Green Leadership and Expanding Global Reach

![Textiles and apparel](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682ec533ed37552c6b8ba7b9_Mask%20group%20\(36\).webp)

#2

largest RMG export globally

230+

LEED-certified factories

52

Duty-Free Export Markets

10%

Green Tax Incentives

## OVERVIEW

Bangladesh is a global hub for textiles and apparel manufacturing and is currently the second-largest exporter of ready-made garments (RMG) worldwide. In 2024, the sector recorded USD 38.48 billion in export earnings, with knitwear contributing USD 20.52 billion and woven garments USD 17.95 billion. The industry is backed by the highest number of green garment factories globally, with over 230 LEED-certified units, supported by government initiatives promoting sustainable manufacturing and environmental compliance.

The sector’s long-term growth is underpinned by diversification into advanced and value-added textiles, including smart fabrics, eco-friendly innovations, and technical textiles catering to the automotive, medical, and construction sectors. A backward linkage ecosystem, encompassing local production of yarn, fabrics, and accessories, strengthens supply chain resilience and reduces dependence on imports. Increasing investment in man-made fiber (MMF) and high-value apparel segments is helping the sector align with global demand shifts.

Bangladesh continues to expand its trade footprint through active pursuit of Free Trade Agreements (FTAs) and Preferential Trade Agreements (PTAs), including engagement with ASEAN countries and efforts to secure EU GSP+ status, enhancing market access and global competitiveness. Bangladeshi garments maintain a strong presence in traditional markets, led by the European Union, with key export destinations such as Germany, Spain, France, the Netherlands, Poland, Italy, and Denmark. The United States remains the largest single-country export market, followed by the United Kingdom and Canada. Simultaneously, Bangladesh is gaining momentum in non-traditional and high-potential markets, including Japan, Australia, India, South Korea, Turkey, Mexico, the UAE, and China. Additional growth is being seen in Malaysia, Brazil, Russia, Singapore, and Hong Kong (SAR of China).

The sector’s commitment to ethical production, environmental sustainability, and innovation—reinforced by partnerships such as the European Union Sustainability Compact covering 85% of Bangladesh’s RMG exports—continues to position the country as a trusted sourcing destination for global brands and investors.

## Growth Drivers

![Leading Exporter Position](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c519c18ef09dcee2541b1_Group%20174.svg)

### Leading Exporter Position

Second-largest clothing exporter globally, with 7% of global market share.

![Competitive Labor Costs](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c51bd32da7095abca16d6_SEPZ%20Icon-04.svg)

### Competitive Labor Costs

Monthly wage of USD 113, making it one of the most cost-effective labor forces.

![Policy Support](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c51d814d4da2279365798_Agro%20Icon-01.svg)

### Policy Support

RMG and man-made fiber are prioritized as top export diversification sectors under the National Industry Policy 2022, with incentives for green manufacturing and export growth.

![Sustainability Focus](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c51f96c3973877a0a5313_SEPZ%20Icon-07.svg)

### Sustainability Focus

230 LEED-certified factories, including 92 platinum and 124 gold.

![Diversification into High-Value Products](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c520b078a25e4f1a2c6d1_Group%20172.svg)

### Diversification into High-Value Products

Expanding into denim, sportswear, and technical textiles, adding value to its product range and meeting global demand for premium textiles.

![Skilled Workforce](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c52424b6c0302704a3c16_Health%20Icon-05.svg)

### Skilled Workforce

Employing 4.4 million workers, the sector benefits from increasing investments in skill development and technical training to support modern production needs.

## KEY PLAYERS

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678c7258337ee533c78e5fe9_Rectangle%2041.svg)![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678c7258e1f212fceb08d288_Rectangle%2024.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c6f8565c91ee0cfdf1e49_Axiata-Logo.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c6fbd2bcffeb5b6fc38ab_Telenor-Logo.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682ec653606b40a321419a04_SCB-Logo%20\(6\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7010012af90265c14ee6_HSBC-Logo.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c70406adc4233b16bbd69_Citi-Bank-Logo.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7060daa5b02bd7899ab8_Citi-Bank-Logo%20\(1\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c707c7e1e5c7edbcb1511_Citi-Bank-Logo%20\(2\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c70950025286f83971f1c_Citi-Bank-Logo%20\(3\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c70ac063bc49cb67e945e_Citi-Bank-Logo%20\(4\).svg)

## KEY PLAYERS

![dbl](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c6f8565c91ee0cfdf1e49_Axiata-Logo.svg)

![Square](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c6fbd2bcffeb5b6fc38ab_Telenor-Logo.svg)

![Grameen Knitwear Limited](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682ec653606b40a321419a04_SCB-Logo%20\(6\).svg)

![Noman](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7010012af90265c14ee6_HSBC-Logo.svg)

![Epyllion](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c70406adc4233b16bbd69_Citi-Bank-Logo.svg)

![Ha-meem](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7060daa5b02bd7899ab8_Citi-Bank-Logo%20\(1\).svg)

![viyellates](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c707c7e1e5c7edbcb1511_Citi-Bank-Logo%20\(2\).svg)

![youngone](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c70950025286f83971f1c_Citi-Bank-Logo%20\(3\).svg)

![mg](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c70ac063bc49cb67e945e_Citi-Bank-Logo%20\(4\).svg)

![dbl](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c6f8565c91ee0cfdf1e49_Axiata-Logo.svg)

![Square](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c6fbd2bcffeb5b6fc38ab_Telenor-Logo.svg)

![Grameen Knitwear Limited](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682ec653606b40a321419a04_SCB-Logo%20\(6\).svg)

![Noman](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7010012af90265c14ee6_HSBC-Logo.svg)

![Epyllion](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c70406adc4233b16bbd69_Citi-Bank-Logo.svg)

![Ha-meem](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7060daa5b02bd7899ab8_Citi-Bank-Logo%20\(1\).svg)

![viyellates](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c707c7e1e5c7edbcb1511_Citi-Bank-Logo%20\(2\).svg)

![youngone](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c70950025286f83971f1c_Citi-Bank-Logo%20\(3\).svg)

![mg](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c70ac063bc49cb67e945e_Citi-Bank-Logo%20\(4\).svg)

![dbl](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c6f8565c91ee0cfdf1e49_Axiata-Logo.svg)

![Square](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c6fbd2bcffeb5b6fc38ab_Telenor-Logo.svg)

![Grameen Knitwear Limited](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682ec653606b40a321419a04_SCB-Logo%20\(6\).svg)

![Noman](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7010012af90265c14ee6_HSBC-Logo.svg)

![Epyllion](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c70406adc4233b16bbd69_Citi-Bank-Logo.svg)

![Ha-meem](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7060daa5b02bd7899ab8_Citi-Bank-Logo%20\(1\).svg)

![viyellates](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c707c7e1e5c7edbcb1511_Citi-Bank-Logo%20\(2\).svg)

![youngone](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c70950025286f83971f1c_Citi-Bank-Logo%20\(3\).svg)

![mg](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c70ac063bc49cb67e945e_Citi-Bank-Logo%20\(4\).svg)

### POLICIES & INCENTIVES

-   Duty exemptions for importing capital machinery and raw materials for the textile sector. [(S.R.O. No. 230-Law/2024/72/Customs](https://nbr.gov.bd/uploads/sros/SRO_No._-_230-2024_.pdf); [S.R.O. No. 169-Law/2024/21/Customs](https://nbr.gov.bd/uploads/sros/08._SRO-169-Ain-2024-21-Customs_Textile-Equipment-New_.pdf))
-   Up to 0.3% to 3% cash incentives on textile exports, depending on the product type and market (Applicable until 31 Dec 2026, [FEPD Circular No. 28](https://www.bb.org.bd/mediaroom/circulars/fepd/jul102025fepd28.pdf))
-   Incentives for sustainable practices, including tax exemptions and duty-free imports for green factories; 10% corporate tax rate for export-oriented green industries (Applicable until 30 June 2028; [SRO No 44/2024 (4 Mar 2024)](https://nbr.gov.bd/uploads/sros/SRO_No-44_of_2024.pdf)
-   State-sponsored programs and grants for supporting investment in the training of the workforce, especially in advanced textile techniques

#### RELEVANT BODIES

-   Ministry of Textiles and Jute
-   Export Promotion Bureau (EPB)
-   Bangladesh Garment Manufacturers and Exporters Association (BGMEA)
-   Bangladesh Knitwear Manufacturers and Exporters Association (BKMEA)
-   Bangladesh Textile Mills Association (BTMA)

## **BIDA Sector Focal**

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69f98aa73cf19f0cbbaaccb2_Untitled%20design%20\(4\).png)

### Faizur Rabbi

Deputy Director

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)](https://wa.me/8801711952685)

[

+8801711082417

](https://wa.me/8801711082417)

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)](mailto:research@bida.gov.bd)

[

rabbeefaizur@gmail.com

](https://rabbeefaizur@gmail.com)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69f98aa73cf19f0cbbaaccb2_Untitled%20design%20\(4\).png)

### SM Rafio Morshed

Assistant Director

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)](https://wa.me/8801711952685)

[

+8801671160070

](https://wa.me/8801671160070)

[EXPLORE OUR SECTOR DESKS](/sector-desks)

Faizur Rabbi

Deputy Director

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)](https://wa.me/8801711952685)

+8801711082417

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)](mailto:research@bida.gov.bd)

rabbeefaizur@gmail.com

SM Rafio Morshed

Assistant Director

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)](https://wa.me/8801711952685)

+8801671160070

![](https://cdn.prod.website-files.com/62434fa732124a0fb112aab4/62434fa732124a0e4912aadb_Chevron%20right-1.svg)

![](https://cdn.prod.website-files.com/62434fa732124a0fb112aab4/62434fa732124a7ce212aacc_Chevron%20right.svg)

## RESOURCES

No items found.

#### BOOK AN APPOINTMENT

##### SERVICE

New Business Opportunities

Registration & Approvals

Regulatory Facilitation

Visa & Work Permit Support

Aftercare

Policy & Sectoral Guidance

##### REQUESTED DATE

##### REQUESTED TIME

**Thank you!**  
Your appointment request has been submitted.  
If approved, a confirmation email will be sent to you.

Oops! Something went wrong while submitting the form.