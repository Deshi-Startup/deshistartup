---
source: "Bangladesh Investment Development Authority (BIDA)"
tier: 1
category: "Government / regulator"
url: "https://bida.gov.bd/publications/sector-profiles"
title: "SECTOR PROFILES"
scraped_at: "2026-07-02"
---

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/686cf7286136ad1eee6ed377_Layer_1%20\(1\).svg)](/)

[中文](/china)[BIDA OSS](/services#one-stop-services)[

Matchmakin

](https://uat-irms.oss.net.bd/matchmaking)

![bida search icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678cd4d48720bb0edd6ad500_Group%2055.svg)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/68945f6c4818ae3dc291a664_Layer_1.svg)![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![search](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6788a1c48788ea23e00ed88c_Group%2055%20\(1\).webp)

![humbergur](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678896a2d5b4ac64ddac5e2a_Group%2096%20\(3\).webp)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

-   [home](/)

-   [OPPORTUNITIES](/opportunities)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [Services](/services)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [RESOURCES](/resources)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [ABOUT BIDA](/about-bida)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [NOTICE](/notices)

[BIDA OSS](https://www.investbangladesh.gov.bd/services#one-stop-service)[中文](/china)[

MATCHMAKING

](https://uat-irms.oss.net.bd/matchmaking)

# SECTOR PROFILES

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6853bd5943619d0dd42874b7_Sector-Resource-1%202%20\(2\).png)

## Healthcare industry

june 2024

[

DOWNLOAD

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68bd464f4e207f61a28f19ac_Healthcare%20%26%20Medical%20Device%20Industries.pdf)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6853bd79521e43772177e939_Pharmaceuticals-%26-API%201%20\(1\).png)

## Pharmaceuticals INDUSTRY & API

JUNE 2024

[

DOWNLOAD

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68bd46256ef8ad72600abdd0_Pharmaceuticles%20%26%20API%20Industries.pdf)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6853bdb4a4b5ba857d274741_Sector-Resource-1%201%20\(13\).png)

## Healthcare & Medical Device Industries

March 2022

[

DOWNLOAD

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68bd45fa4488ce668302faf9_Medical%20Equipment%20%26%20Devices%20Industry%20in%20Bangladesh.pdf)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6853be08b02b942a843b3f1f_Sector-Resource-1%201%20\(1\)%20\(1\).png)

## LIGHT ENGINEERING INDUSTRY

JUNE 2024

[

DOWNLOAD

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682ec0bbe4a9f3c5506fdb84_Light%20Engineering%20Industry.pdf)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6853be494c04541622b8613c_Sector-Resource-1%201%20\(2\)%20\(1\).png)

## PLASTIC INDUSTRY

JUNE 2023

[

DOWNLOAD

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682ec19ac85cfde3f7b32f6d_Plastic%20Industry.pdf)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6853be7296a153b0e2bb1b63_Sector-Resource-1%202%20\(1\)%20\(1\).png)

## LEATHER & LEATHER GOODS INDUSTRIES

June 2023

[

DOWNLOAD

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682ebf06a6e42db5a25deab3_Leather%20%26%20leather%20Goods%20Industries.pdf)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6853beb18e10e3728c682b46_Sector-Resource-1%201%20\(4\)%20\(1\).png)

## INFRASTRUCTURE SECTOR

APRIL 2021

[

DOWNLOAD

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68bd4504c4bd64cabae6a443_Infrastructure.pdf)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6853beb18e10e3728c682b46_Sector-Resource-1%201%20\(4\)%20\(1\).png)

## TELECOMMUNICATION & NETWORKING SECTOR

April 2021

[

DOWNLOAD

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68bd44d70853112c11a98ddb_Telecommunication%20and%20Networking%20Sector.pdf)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6853bf1d26234153c001ff6b_Sector-Resource-1%201%20\(5\)%20\(1\).png)

## CERAMICS INDUSTRY

JUNE 2023

[

DOWNLOAD

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68bd4499230628e6996275ae_Ceramics%20Industry.pdf)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6853bf4f36691f10a54b7fc4_Sector-Resource-1%201%20\(6\)%20\(1\).png)

## Diversified Jute Products

JUNE 2023

[

DOWNLOAD

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68bd445ae3de2ad6ceeaf831_Diversified%20Jute%20Products.pdf)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6853bf7e0d3515c51fcc2270_Sector-Resource-1%201%20\(7\)%20\(1\).png)

## Agro & Food Processing

June 2023

[

DOWNLOAD

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68bd441363998c4a6a0ca0cb_Agro%20%26%20Food%20Processing.pdf)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6853bfb7a4428782f00b45ae_Sector-Resource-1%201%20\(8\)%20\(1\).png)

## Shipbuilding Industry

June 2024

[

DOWNLOAD

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68bd43de05de00e06b408b0f_Shipbuilding%20Industry.pdf)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6853bfdd8867f44704941f7b_Sector-Resource-1%201%20\(9\)%20\(1\).png)

## Motorcycle & Parts Industry

July 2019

[

DOWNLOAD

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68bd43b1e601d5d98113adf5_Motorcycle%20%26%20Parts%20Industry_.pdf)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6853c01e2fbc4229ad8fbbe7_Sector-Resource-1%201%20\(10\)%20\(1\).png)

## Construction Material Industry

July 2019

[

DOWNLOAD

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68bd4387d95f81619ae72b7a_Construction%20Material%20Industry.pdf)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6853c0440d3515c51fccb816_Sector-Resource-1%201%20\(11\)%20\(1\).png)

## Infomation Technology Industry

July 2019

[

DOWNLOAD

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68bd43583f5b8f91434841ba_Infomation%20Technology%20Industry.pdf)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/6853c0723a705c66df03731a_Sector-Resource-1%201%20\(12\)%20\(1\).png)

## TOURISM SECTOR

APRIL 2021

[

DOWNLOAD

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68bd4330bdd33abdc397cce1_Tourism.pdf)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68eded96a38abd530576f9c2_2025-10-14%20.png)

## BIDA Brochure (Korean Version)

10 July 2025

[

DOWNLOAD

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/68ee032d3d514f93faf6c0f3_BIDA%20_%20Tri%20Fold%20Brochure%20_%2013-07-25%20Final%20without%20_251014_120135.pdf)

## Annual Reports

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69491a90ba889049414e57b4_Screenshot%202025-12-22%20161636.png)

21 Decemer 2025

BIDA Annual Report 2023-24 & 2024-25

[Read More >](https://drive.google.com/file/d/1f5DRUIzvVpsAQMoGrgUNi55at4e6fgxe/view?usp=sharing)

#### BOOK AN APPOINTMENT

##### SERVICE

New Business Opportunities

Registration & Approvals

Regulatory Facilitation

Visa & Work Permit Support

Aftercare

Policy & Sectoral Guidance

##### REQUESTED DATE

##### REQUESTED TIME

**Thank you!**  
Your appointment request has been submitted.  
If approved, a confirmation email will be sent to you.

Oops! Something went wrong while submitting the form.