---
source: "Bangladesh Investment Development Authority (BIDA)"
tier: 1
category: "Government / regulator"
url: "https://bida.gov.bd/domestic-projects"
title: "BIDA | Domestic Investment Opportunities in Bangladesh"
scraped_at: "2026-07-02"
---

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/686cf7286136ad1eee6ed377_Layer_1%20\(1\).svg)](/)

[中文](/china)[BIDA OSS](/services#one-stop-services)[

Matchmakin

](https://uat-irms.oss.net.bd/matchmaking)

![bida search icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678cd4d48720bb0edd6ad500_Group%2055.svg)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/68945f6c4818ae3dc291a664_Layer_1.svg)![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![search](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6788a1c48788ea23e00ed88c_Group%2055%20\(1\).webp)

![humbergur](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678896a2d5b4ac64ddac5e2a_Group%2096%20\(3\).webp)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

-   [home](/)

-   [OPPORTUNITIES](/opportunities)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [Services](/services)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [RESOURCES](/resources)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [ABOUT BIDA](/about-bida)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [NOTICE](/notices)

[BIDA OSS](https://www.investbangladesh.gov.bd/services#one-stop-service)[中文](/china)[

MATCHMAKING

](https://uat-irms.oss.net.bd/matchmaking)

# Domestic Projects

Services for Local Investment Projects at BIDA

## SERVICES

BIDA Registration

Industrial project registration (new)

Documents Needed

-   Certificate of Incorporation
-   Memorandum and Article of Association
-   Attachment of the Company's Comments as per BIDA Requirement
-   Other necessary documents (please attach if any)
-   According to the industrial policy, the 2016 NOC from the concerned Ministry/Directorate/Department for the controlled sector is to be submitted
-   Project profile if project cost is 100 million above
-   Land Purchase/Rental Deed Agreement of Project
-   List of Directors with Nationality & Address
-   Up-to-date TIN Certificate
-   Up-to-date Trade License

Mode

[BIDA One Stop Service  
(OSS)](https://www.investbangladesh.gov.bd/services#bida-one-stop-service)

Fee

Registration fee based on Project Investment:  

-   Up to 1 Tk. 10 Crore - Tk. 5,000/-
-   10 Crore Tk. 25 Crore - Tk. 10,000/-
-   25 Crore Tk. 50 Crore - Tk. 25,000/-
-   50 Crore Tk. 100 Crore - Tk. 50,000/-
-   100 Crore Tk. Above - Tk. 1,00,000/-

\+ 15% VAT Online payment through

BIDA One Stop Service (OSS)

Time

1 day  
Subject to submission of necessary documents

Amendment (For Machinery Inclusion Amendment)

Documents Needed

-   Previous all BIDA Registration Amendment Certificate
-   Copy of Board Resolution amendment-related documents (if it is a Limited Company)
-   Certificate of Incorporation
-   Memorandum & Article of Association
-   Up-to-date Trade License
-   Up-to-date TIN Certificate
-   Land Purchase/Rental deed agreement of Project
-   List of Directors with Nationality & Address
-   List of Machineries Local & Imported to be submitted in the official pad of the company (Authorized Copy)
-   Project profile if project cost is 100 million above
-   According to the industrial policy, 2016 NOC from concerned Ministry/Directorate/ Department for the controlled sector to be submitted
-   Other necessary documents (please attach if any)
-   Attachment of Company's Comments as per BIDA Requirement

Mode

[BIDA One Stop Service  
(OSS)](https://www.investbangladesh.gov.bd/services#bida-one-stop-service)

Fee

BDT 1000/- + 15% VAT

Online payment through BIDA One Stop Service (OSS)

Time

3 working days  
Subject to submission of necessary documents

Amendment (For Ownership Change)

Documents Needed

-   All previous BIDA Registration Amendment Certificate
-   Copy of Board Resolution amendment-related documents (if it is a Limited Company)
-   For private limited companies: Approval from the Registrar of Joint Stock Companies & Firms (RJSC) /Form-XII copy
-   Certificate of Incorporation
-   Memorandum & Article of Association
-   Up-to-date Trade License
-   Up-to-date TIN Certificate
-   Land Purchase/Rental Deed Agreement of Project
-   List of Directors with Nationality & Address
-   List of Machineries Local & Imported to be submitted in the official pad of the company (Authorized Copy)
-   Project profile if project cost is 100 million above
-   According to the industrial policy, 2016 NOC from concerned Ministry/Directorate/Department for the controlled sector to be submitted
-   Other necessary documents (please attach if any)
-   Attachment of Company's Comments as per BIDA Requirement

Mode

[BIDA One Stop Service  
(OSS)](https://www.investbangladesh.gov.bd/services#bida-one-stop-service)

Fee

BDT 1000/- + 15% VAT

Online payment through BIDA One Stop Service (OSS)

Time

3 working days  
Subject to submission of necessary documents

Amendment (Address Change Amendment)

Documents Needed

-   1. Previous all BIDA Registration Amendment Certificate
-   Copy of Board Resolution amendment-related documents (if it is a Limited Company)
-   For private limited companies: Approval from the Registrar of Joint Stock Companies & Firms (RJSC) /Form- VI copy
-   Certificate of Incorporation
-   Memorandum & Article of Association
-   Up-to-date Trade License
-   Up-to-date TIN Certificate
-   Land Purchase/Rental deed agreement of Project
-   List of Directors with Nationality & Address
-   List of Machineries Local & Imported to be submitted in the official pad of the company (Authorized Copy)
-   Project profile if project cost is 100 million above
-   According to the industrial policy, 2016 NOC from concerned Ministry/Directorate/Department for the controlled sector to be submitted
-   Other necessary documents (please attach if any)
-   Attachment of Company's Comments as per BIDA Requirement

Mode

[BIDA One Stop Service  
(OSS)](https://www.investbangladesh.gov.bd/services#bida-one-stop-service)

Fee

BDT 1000/- + 15% VAT

Online payment through BIDA One Stop Service (OSS)

Time

3 working days  
Subject to submission of necessary documents

Amendment (Issuance of Clearance Certificate for Imported/To-Be-Imported Machinery of Locally Registered Industries)

Documents Needed

-   Copy of the registration certificate and post-registration amendment (if applicable)
-   Copies of the Letter of Credit (LC), Invoice, and Bill of Lading (BL)

Mode

[BIDA One Stop Service  
(OSS)](https://www.investbangladesh.gov.bd/services#bida-one-stop-service)

Fee

No Fees

Time

3 working days  
Subject to submission of necessary documents

IRC recommendation

First Ad-Hoc

Documents Needed

-   BIDA Registration along with the last amendment
-   Copy of Trade License against factory address
-   Copy of TIN certificate
-   Copy of Fire License
-   Copy of Environment/Site clearance certificate
-   Copy of Bank Solvency certificate issued by concerned bank
-   Copy of incorporation certificate and memorandum in case of company
-   Copy of partnership deed in case of partnership
-   Copy of Membership certificate of the concerned association

Mode

[BIDA One Stop Service  
(OSS)](https://www.investbangladesh.gov.bd/services#bida-one-stop-service)

Fee

BDT 250 

Online payment through BIDA One Stop Service (OSS)

Time

10 working days  
Subject to submission of necessary documents

Second Ad-Hoc

Documents Needed

-   BIDA Registration along with the last amendment
-   Copy of Trade License against factory address
-   Copy of TIN certificate
-   Copy of Fire License
-   Copy of Environment/Site clearance certificate
-   Copy of Bank Certificate issued by the concerned bank
-   Copy of incorporation certificate and memorandum in case of the company
-   Copy of partnership deed in case of partnership
-   Copy of Membership certificate of the concerned association
-   LC Copy against the 1st Ad Hoc IRC Spare parts/Raw Materials Imported or Purchase
-   Attachment of Company's Comments as per BIDA Requirement No file found
-   Other necessary documents (please attach if any) No file found
-   Copy of 1st IRC approved Copy.
-   Copy of 1st IRC approved Production Capacity
-   Copy of 1st IRC approved Existing Machinery
-   Copy of 1st IRC approved Entitlement paper

Mode

[BIDA One Stop Service  
(OSS)](https://www.investbangladesh.gov.bd/services#bida-one-stop-service)

Fee

No Fees

Time

10 working days  
Subject to submission of necessary documents

Third Ad-Hoc

Documents Needed

-   BIDA Registration along with the last amendment
-   Copy of Trade License against factory address
-   Copy of TIN certificate
-   Copy of Fire License
-   Copy of Environment/Site clearance certificate
-   Copy of Bank Certificate issued by the concerned bank
-   Copy of incorporation certificate and memorandum in case of the company
-   Copy of partnership deed in case of partnership
-   Copy of Membership certificate of the concerned association
-   LC Copy against the 1st Ad Hoc IRC Spare parts/Raw Materials Imported or Purchase
-   Attachment of Company's Comments as per BIDA Requirement No file found
-   Other necessary documents (please attach if any) No file found
-   Copy of 1st IRC approved Copy
-   Copy of 1st IRC approved Production Capacity
-   Copy of 1st IRC approved Existing Machinery
-   Copy of 1st IRC approved Entitlement paper

Mode

[BIDA One Stop Service  
(OSS)](https://www.investbangladesh.gov.bd/services#bida-one-stop-service)

Fee

No fees

Time

10 working days  
Subject to submission of necessary documents

Regular

Documents Needed

-   Application on the company’s letterhead
-   Registration certificate and subsequent amendment
-   Ad-Hoc Industry IRC and 2nd Ad-Hoc Industry IRC recommendation
-   Ad-Hoc certificate of IRC
-   TIN certificate (in the name of the organization)
-   Updated trade license in the name of the factory address
-   Updated fire license
-   Updated environmental clearance certificate
-   Certification from the lien bank regarding raw material imports for Ad-Hoc IRC and export details for export-oriented industries
-   Certification from the lien bank regarding raw material imports for local marketing industries and production and VAT details on the company’s letterhead
-   List of installed machinery (serial number, name of equipment, quantity, and price)

Mode

[BIDA One Stop Service  
(OSS)](https://www.investbangladesh.gov.bd/services#bida-one-stop-service)

Fee

No fees

Time

10 working days  
Subject to submission of necessary documents

#### BOOK AN APPOINTMENT

##### SERVICE

New Business Opportunities

Registration & Approvals

Regulatory Facilitation

Visa & Work Permit Support

Aftercare

Policy & Sectoral Guidance

##### REQUESTED DATE

##### REQUESTED TIME

**Thank you!**  
Your appointment request has been submitted.  
If approved, a confirmation email will be sent to you.

Oops! Something went wrong while submitting the form.