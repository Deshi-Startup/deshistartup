---
source: "Bangladesh Investment Development Authority (BIDA)"
tier: 1
category: "Government / regulator"
url: "https://bida.gov.bd/investment-sector/medical-device"
title: "Bangladesh: A Hub for Medical Equipment Investment"
scraped_at: "2026-07-02"
---

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/686cf7286136ad1eee6ed377_Layer_1%20\(1\).svg)](/)

[中文](/china)[BIDA OSS](/services#one-stop-services)[

Matchmakin

](https://uat-irms.oss.net.bd/matchmaking)

![bida search icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678cd4d48720bb0edd6ad500_Group%2055.svg)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/68945f6c4818ae3dc291a664_Layer_1.svg)![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![search](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6788a1c48788ea23e00ed88c_Group%2055%20\(1\).webp)

![humbergur](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678896a2d5b4ac64ddac5e2a_Group%2096%20\(3\).webp)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

-   [home](/)

-   [OPPORTUNITIES](/opportunities)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [Services](/services)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [RESOURCES](/resources)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [ABOUT BIDA](/about-bida)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [NOTICE](/notices)

[BIDA OSS](https://www.investbangladesh.gov.bd/services#one-stop-service)[中文](/china)[

MATCHMAKING

](https://uat-irms.oss.net.bd/matchmaking)

# Medical Device

Building a Future-Ready Medtech Industry

![Medical Device](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68345872be9c7ac14168e776_Mask%20group%20\(40\).webp)

$925M+

annual market demand, growing at 20% per year

~$60M

local market for syringes, gloves, catheters

$3B

projected medical device market size by 2030

10.3%

cagr in healthcare spending since 2010

## OVERVIEW

Bangladesh’s medical device sector is poised for sustained growth, with the market projected to nearly double from USD 442 million in 2020 to USD 820 million by 2025. This momentum is underpinned by demographic trends—particularly an aging population and the rising prevalence of non-communicable diseases—as well as an expanding network of healthcare facilities.

While over 85% of medical equipment is currently imported, the policy landscape is evolving. Bangladesh is taking deliberate steps to strengthen domestic manufacturing capabilities, offering fiscal incentives and leveraging cost advantages in labor and precision assembly. With transferable expertise from the ready-made garments (RMG) sector and a maturing healthcare ecosystem, the country is increasingly positioned to serve as a competitive base for regional medical device production. Priority segments include diagnostic imaging, home healthcare solutions, wearable devices, and low-cost innovations tailored to rural markets.

## Growth Drivers

![Medtech and Digital Health Surge](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68344221bc67d521de7b7eaf_Group%20233.svg)

### Medtech and Digital Health Surge

The medtech and digital health segment is poised for strong growth by 2025, driven by rising demand for telemedicine, wearable technologies, and point-of-care diagnostics.

![Expanding Healthcare Ecosystem](https://cdn.prod.website-files.com/6820331d027084bef793fadb/683442507028b75d063e566f_Group%20198.svg)

### Expanding Healthcare Ecosystem

Bangladesh has over 5,000 public and private hospitals, with healthcare spending expected to reach USD 14 billion by 2025. Infrastructure upgrades and rural healthcare expansion are driving device adoption.

![Manufacturing Advantage from RMG](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68344281be9749d427597dd9_Group%20197.svg)

### Manufacturing Advantage from RMG

Bangladesh’s RMG sector provides a transferable skill base for cleanroom and precision manufacturing—paving the way for scalable, cost-effective device assembly.

![Rising Demand for Devices](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c60ad0d44bda929df1e3e_Group%20173.svg)

### Rising Demand for Devices

The growing burden of non-communicable diseases (NCDs)—diabetes, cardiovascular issues, and cancer—is fueling strong demand for diagnostic tools and medical equipment. Diabetes cases alone are projected to reach 43 million by 2030.

## KEY PLAYERS

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678c7258337ee533c78e5fe9_Rectangle%2041.svg)![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678c7258e1f212fceb08d288_Rectangle%2024.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68344e7bdc3283e9caf468d4_JMI%20Syringes%20Medical%20Devices%20Limited.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68344f02f3bda52ace56e8cc_Nipro%20JMI%20Company%20Ltd.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68344f25640328cef5e4353e_Getwell.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68344f4eaf5aa77344cdc938_opso_saline_ltd%201.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68344f7703bf1bfbb4272dfb_Techno%20Drugs%20Ltd.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330de775ee0747e9e2f057_231.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68344fc9be1a64769af06919_Bi-beat.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68345001af5aa77344ce2bc3_Group%20201.svg)

## KEY PLAYERS

![JMI Group](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68344e7bdc3283e9caf468d4_JMI%20Syringes%20Medical%20Devices%20Limited.svg)

![NIPRO](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68344f02f3bda52ace56e8cc_Nipro%20JMI%20Company%20Ltd.svg)

![Getwell](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68344f25640328cef5e4353e_Getwell.svg)

![Opso Saline LTD](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68344f4eaf5aa77344cdc938_opso_saline_ltd%201.svg)

![Techno Drugs Ltd](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68344f7703bf1bfbb4272dfb_Techno%20Drugs%20Ltd.svg)

![Incepta](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330de775ee0747e9e2f057_231.svg)

![Bi-Beat](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68344fc9be1a64769af06919_Bi-beat.svg)

![Promixco Limited](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68345001af5aa77344ce2bc3_Group%20201.svg)

![JMI Group](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68344e7bdc3283e9caf468d4_JMI%20Syringes%20Medical%20Devices%20Limited.svg)

![NIPRO](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68344f02f3bda52ace56e8cc_Nipro%20JMI%20Company%20Ltd.svg)

![Getwell](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68344f25640328cef5e4353e_Getwell.svg)

![Opso Saline LTD](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68344f4eaf5aa77344cdc938_opso_saline_ltd%201.svg)

![Techno Drugs Ltd](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68344f7703bf1bfbb4272dfb_Techno%20Drugs%20Ltd.svg)

![Incepta](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330de775ee0747e9e2f057_231.svg)

![Bi-Beat](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68344fc9be1a64769af06919_Bi-beat.svg)

![Promixco Limited](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68345001af5aa77344ce2bc3_Group%20201.svg)

![JMI Group](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68344e7bdc3283e9caf468d4_JMI%20Syringes%20Medical%20Devices%20Limited.svg)

![NIPRO](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68344f02f3bda52ace56e8cc_Nipro%20JMI%20Company%20Ltd.svg)

![Getwell](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68344f25640328cef5e4353e_Getwell.svg)

![Opso Saline LTD](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68344f4eaf5aa77344cdc938_opso_saline_ltd%201.svg)

![Techno Drugs Ltd](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68344f7703bf1bfbb4272dfb_Techno%20Drugs%20Ltd.svg)

![Incepta](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68330de775ee0747e9e2f057_231.svg)

![Bi-Beat](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68344fc9be1a64769af06919_Bi-beat.svg)

![Promixco Limited](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68345001af5aa77344ce2bc3_Group%20201.svg)

### POLICIES & INCENTIVES

-   10-year corporate tax exemption for healthcare training institutes (e.g., nursing, pharmacy). Applicable until 30 June 2030 (as per [SRO](https://nbr.gov.bd/uploads/sros/SRO_on-169_Hospitals.pdf)).
-   CD, VAT, AT, AIT Exemption on importation on dengue kits ([SRO No. 234-AIN/2024/76/Customs-26 June 2024)](https://www.taxvatpoint.com/wp-content/uploads/2024/12/SRO-No.-234-Law_2024_76-Customs_Amendment-of-SRO-No.-178-of-2024_Duty-benefit-at-the-time-of-Import-of-Dengue-Kit.pdf).
-   50% tax exemption on export income (Applicable until 30 June 2028; [SRO No 44/2024-4 Mar 2024)](https://nbr.gov.bd/uploads/sros/SRO_No-44_of_2024.pdf)
-   6% export subsidy on exporting of medical/surgical instruments and appliance (Applicable until 31 December 2025; [FEPD Circular No. 28).](https://www.bb.org.bd/mediaroom/circulars/fepd/jul102025fepd28.pdf)
-   Reduced import duties on raw materials for medical equipment ([SRO No. 180-AIN/2024/32/customs](https://nbr.gov.bd/uploads/sros/19._SRO-180-Ain-2024-32-Customs_Reffaral-Hospital-New_.pdf)).
-   VAT exemption on locally manufactured medical bed and AT & SD exemption on imported and local raw materials & spare parts (Applicable until 30 June 2030; [S.R.O No. 173-Act/2025/301-VAT](https://nbr.gov.bd/uploads/sros/VATSRO-1732.pdf)).
-   [Bangladesh Digital Health Strategy 2023–2027](https://dghs.portal.gov.bd/sites/default/files/files/dghs.portal.gov.bd/page/4124d18a_ab99_40e2_8fef_ff4052948739/2024-12-10-09-05-7d1979bca8a5e70363b9047b62fd143b.pdf)
-   [National Health Policy 2011](https://bangladesh.gov.bd/sites/default/files/files/bangladesh.gov.bd/policy/b58fb9a0_1984_4491_a980_0c23bd476b21/66.%20Health%20Policy%202011.pdf)
-   [Health Care Financing Strategy (HCFC)](https://heu.portal.gov.bd/sites/default/files/files/heu.portal.gov.bd/page/c1d65061_f61c_4df2_bd96_cd2e06a4d7f9/2024-04-22-09-54-6a997da367a434169e7da35af5dc7d4b.pdf)

#### RELEVANT BODIES

-   Directorate General of Drug Administration (DGDA)
-   Bangladesh Standards and Testing Institution (BSTI)

## **BIDA Sector Focal**

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69f98aa73cf19f0cbbaaccb2_Untitled%20design%20\(4\).png)

### Sheikh Rasibul Islam

Deputy Director

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)](https://wa.me/8801711952685)

[

+8801712595962

](https://wa.me/880171259596)

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)](mailto:research@bida.gov.bd)

[

rasibul20@gmail.com

](#)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69f98aa73cf19f0cbbaaccb2_Untitled%20design%20\(4\).png)

### Hridi Rahman

Assistant Director

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)](https://wa.me/8801711952685)

[

+8801621132528

](https://wa.me/8801621132528)

[EXPLORE OUR SECTOR DESKS](/sector-desks)

Sheikh Rasibul Islam

Deputy Director

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)](https://wa.me/8801711952685)

+8801712595962

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)](mailto:research@bida.gov.bd)

rasibul20@gmail.com

Hridi Rahman

Assistant Director

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)](https://wa.me/8801711952685)

+8801621132528

![](https://cdn.prod.website-files.com/62434fa732124a0fb112aab4/62434fa732124a0e4912aadb_Chevron%20right-1.svg)

![](https://cdn.prod.website-files.com/62434fa732124a0fb112aab4/62434fa732124a7ce212aacc_Chevron%20right.svg)

## RESOURCES

medical equipment & devices industry IN BD

[

DOWNLOAD

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68bd45fa4488ce668302faf9_Medical%20Equipment%20%26%20Devices%20Industry%20in%20Bangladesh.pdf)

Healthcare industry

june 2024

[

DOWNLOAD

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://cdn.prod.website-files.com/6820331d027084bef793fadb/68bd464f4e207f61a28f19ac_Healthcare%20%26%20Medical%20Device%20Industries.pdf)

#### BOOK AN APPOINTMENT

##### SERVICE

New Business Opportunities

Registration & Approvals

Regulatory Facilitation

Visa & Work Permit Support

Aftercare

Policy & Sectoral Guidance

##### REQUESTED DATE

##### REQUESTED TIME

**Thank you!**  
Your appointment request has been submitted.  
If approved, a confirmation email will be sent to you.

Oops! Something went wrong while submitting the form.