---
source: "Bangladesh Investment Development Authority (BIDA)"
tier: 1
category: "Government / regulator"
url: "https://bida.gov.bd/about-bida"
title: "About BIDA – Bangladesh Investment Development Authority"
scraped_at: "2026-07-02"
---

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/686cf7286136ad1eee6ed377_Layer_1%20\(1\).svg)](/)

[中文](/china)[BIDA OSS](/services#one-stop-services)[

Matchmakin

](https://uat-irms.oss.net.bd/matchmaking)

![bida search icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678cd4d48720bb0edd6ad500_Group%2055.svg)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/68945f6c4818ae3dc291a664_Layer_1.svg)![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![search](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6788a1c48788ea23e00ed88c_Group%2055%20\(1\).webp)

![humbergur](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678896a2d5b4ac64ddac5e2a_Group%2096%20\(3\).webp)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

-   [home](/)

-   [OPPORTUNITIES](/opportunities)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [Services](/services)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [RESOURCES](/resources)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [ABOUT BIDA](/about-bida)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [NOTICE](/notices)

[BIDA OSS](https://www.investbangladesh.gov.bd/services#one-stop-service)[中文](/china)[

MATCHMAKING

](https://uat-irms.oss.net.bd/matchmaking)

# ABOUT BIDA

The Bangladesh Investment Development Authority (BIDA) is the apex investment promotion agency of the Government of Bangladesh under the Prime Minister's Office. BIDA is mandated to promote private sector investment, streamline regulatory processes and support investors from entry to expansion.  
  
BIDA serves both domestic and foreign investors, offering strategic policy advocacy, project facilitation, and aftercare services. With a strong focus on investment competitiveness and ease of doing business, BIDA is at the forefront of Bangladesh’s transformation into a dynamic regional investment hub.

## VISION

To become a world class investment promotion agency for achieving economic progress.

## MISSION

Attracting domestic and foreign investment in the private sector, providing improved services, effective coordination and creating an investment-friendly environment.

## BIDA LEADERSHIP

![Chowdhury Ashik Mahmud Bin Harun](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69b0e1b40c513514c88c1e27_686e50dbed8738847857300e_Chowdhury%20Ashik%20Mahmud%20Bin%20Harun.jpeg)

Chowdhury Ashik Mahmud Bin Harun

Executive Chairman

[

View Profile

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](/officers/chowdhury-ashik-mahmud-bin-harun)

![Nahian Rahman Rochi](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69b103a48cb4875fbd98bbbd_68664bbb72efcb7d114e2d09_Nahian%20Rahman%20Rochi.jpg)

Nahian Rahman Rochi

Executive Member

[

View Profile

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](/officers/nahian-rahman-rochi)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69b0ff1ccc0cbcc7515fa725_i078ltxhgrghqmwyragz_Md.%20Shaharul%20Huda.jpg)

Md. Shaharul Huda

Executive Member

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](/officers/air-commodore-retired-md-shaharul-huda)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69b0ff504e8a7a9accfd9760_sotyilb8gur8y0spvmyj_Md.%20Humayun%20Kabir.jpg)

Md. Humayun Kabir

Executive Member

[

View details

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](/officers/name-2-copy)

[

## ALL BIDA OFFICERS

](/bida-officers)

#### BOOK AN APPOINTMENT

##### SERVICE

New Business Opportunities

Registration & Approvals

Regulatory Facilitation

Visa & Work Permit Support

Aftercare

Policy & Sectoral Guidance

##### REQUESTED DATE

##### REQUESTED TIME

**Thank you!**  
Your appointment request has been submitted.  
If approved, a confirmation email will be sent to you.

Oops! Something went wrong while submitting the form.