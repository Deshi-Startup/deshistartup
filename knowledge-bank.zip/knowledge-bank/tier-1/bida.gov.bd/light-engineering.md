---
source: "Bangladesh Investment Development Authority (BIDA)"
tier: 1
category: "Government / regulator"
url: "https://bida.gov.bd/investment-sector/light-engineering"
title: "Export Excellence Starts Here: Bangladesh’s Light Engineering Boom"
scraped_at: "2026-07-02"
---

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/686cf7286136ad1eee6ed377_Layer_1%20\(1\).svg)](/)

[中文](/china)[BIDA OSS](/services#one-stop-services)[

Matchmakin

](https://uat-irms.oss.net.bd/matchmaking)

![bida search icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678cd4d48720bb0edd6ad500_Group%2055.svg)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/68945f6c4818ae3dc291a664_Layer_1.svg)![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![search](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/6788a1c48788ea23e00ed88c_Group%2055%20\(1\).webp)

![humbergur](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678896a2d5b4ac64ddac5e2a_Group%2096%20\(3\).webp)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

[![BANGLADESH INVESTMENT DEVELOPMENT AUTHORITY](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/689460a0c8d47c4646e0f8fa_Layer_1%20\(1\).svg)](/)

![bida close](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678958eade2075429d28794f_Cross-04%201%20\(1\).webp)

-   [home](/)

-   [OPPORTUNITIES](/opportunities)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [Services](/services)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [RESOURCES](/resources)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [ABOUT BIDA](/about-bida)
    
    ![Right Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/685e2ce421d604369e9fba74_Vector%20\(15\).svg)
    

-   [NOTICE](/notices)

[BIDA OSS](https://www.investbangladesh.gov.bd/services#one-stop-service)[中文](/china)[

MATCHMAKING

](https://uat-irms.oss.net.bd/matchmaking)

# Light Engineering

Powering Industrial Growth with Precision and Scale

![Light Engineering](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c8de82988ff421a005452_Mask%20group%20\(34\).webp)

80K

Light Engineering Enterprises 

$8.2B

domestic demand

28.3%

CAGR from 2017 to 2022

$20B

sectoral investment

## OVERVIEW

The light engineering sector in Bangladesh is a vital enabler of growth and innovation across industries such as automobiles, agriculture, construction, and consumer goods, contributing approximately 3% to the national GDP. With a robust ecosystem of over 80,000 SMEs and a skilled workforce exceeding 1 million, the sector manufactures more than 3,800 types of machinery, spares, and accessories, supplying nearly half of Bangladesh’s USD 8.2 billion domestic demand. Product range spans automobile and railway spares, agricultural machinery, marine components, electrical goods, and industrial equipment for sectors such as textiles, plastics, food processing, and chemicals. Recognized as a priority sector for export diversification, light engineering has witnessed rapid growth – expanding at a 22.27% CAGR between 2017 and 2022, with industry estimates suggesting it could be as high as 28.3%, driven by rising demand across sub-segments.

Bangladesh’s light engineering exports are reaching key international markets including Japan, the Netherlands, South Korea, Taiwan, the United Kingdom, Thailand, and India. With competitive advantages such as low production costs, duty-free access to major economies, and a supportive policy regime offering cash incentives, tax holidays, and infrastructure support, the sector is well-positioned to become a major export powerhouse. The industry targets USD 12.56 billion in export revenues by 2030, propelled by a rapidly expanding domestic base and increasing global demand.

## Growth Drivers

![Domestic Market Self-Sufficiency](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c51d814d4da2279365798_Agro%20Icon-01.svg)

### Domestic Market Self-Sufficiency

Meeting 48–52% of national demand, reducing import dependency and strengthening industrial resilience.

![High Export Potential](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c519c18ef09dcee2541b1_Group%20174.svg)

### High Export Potential

Tapping into a USD 8 trillion global market, Bangladesh’s light engineering is primed for sustained export-led growth.

![Skilled Workforce](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c52424b6c0302704a3c16_Health%20Icon-05.svg)

### Skilled Workforce

A dedicated talent pool of 1 million skilled workers, representing 7% of the national workforce.

![Diverse Product Portfolio](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c67489a86eb99baec473d_Group%20167.svg)

### Diverse Product Portfolio

Leading export segments include:

-   Electrical goods – USD 149.5M (10.29% YoY growth)
-   Bicycles – USD 82.5M (38% YoY growth)
-   Iron & steel components – USD 66.96M (3.97% YoY)
-   Copper wire – USD 56.36M (48% YoY)
-   Engineering equipment – USD 55.81M

![Strong Industrial Base](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c60bc8613be5cf3ba5050_Group%20178%20\(1\).svg)

### Strong Industrial Base

Comprising 34 clusters across 18 districts, with key concentrations in Dhaka, Chattogram, Narayanganj, Bogura, Jessore, Gazipur, and Kishoreganj. A new 50-acre industrial city in Munshiganj and five more parks are planned to further expand capacity.

## KEY PLAYERS

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678c7258337ee533c78e5fe9_Rectangle%2041.svg)![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/678c7258e1f212fceb08d288_Rectangle%2024.svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c768d8867835e49e7f363_Telenor-Logo%20\(4\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c76ad0229e52c416a58d5_SCB-Logo%20\(4\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c76cba0514e0851a82f35_HSBC-Logo%20\(4\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7701843a89d811247b11_Citi-Bank-Logo%20\(32\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c771b5225fefdd32c157f_Citi-Bank-Logo%20\(33\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7158f0d9f2e02fc7f748_Axiata-Logo%20\(2\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c77476222034446d889ea_Citi-Bank-Logo%20\(34\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c77665225fefdd32c58f7_Citi-Bank-Logo%20\(35\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c77a39a5dcce54a9befd1_Citi-Bank-Logo%20\(36\).svg)

![Brand Logo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c77c3f10be5f400725e46_Citi-Bank-Logo%20\(37\).svg)

## KEY PLAYERS

![Walton](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c768d8867835e49e7f363_Telenor-Logo%20\(4\).svg)

![Meghna Corporation](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c76ad0229e52c416a58d5_SCB-Logo%20\(4\).svg)

![Aci Motors](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c76cba0514e0851a82f35_HSBC-Logo%20\(4\).svg)

![Rahimafrooz](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7701843a89d811247b11_Citi-Bank-Logo%20\(32\).svg)

![Samsung](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c771b5225fefdd32c157f_Citi-Bank-Logo%20\(33\).svg)

![Pran RFL](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7158f0d9f2e02fc7f748_Axiata-Logo%20\(2\).svg)

![Panna Group](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c77476222034446d889ea_Citi-Bank-Logo%20\(34\).svg)

![LG](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c77665225fefdd32c58f7_Citi-Bank-Logo%20\(35\).svg)

![Singer](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c77a39a5dcce54a9befd1_Citi-Bank-Logo%20\(36\).svg)

![Oppo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c77c3f10be5f400725e46_Citi-Bank-Logo%20\(37\).svg)

![Walton](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c768d8867835e49e7f363_Telenor-Logo%20\(4\).svg)

![Meghna Corporation](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c76ad0229e52c416a58d5_SCB-Logo%20\(4\).svg)

![Aci Motors](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c76cba0514e0851a82f35_HSBC-Logo%20\(4\).svg)

![Rahimafrooz](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7701843a89d811247b11_Citi-Bank-Logo%20\(32\).svg)

![Samsung](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c771b5225fefdd32c157f_Citi-Bank-Logo%20\(33\).svg)

![Pran RFL](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7158f0d9f2e02fc7f748_Axiata-Logo%20\(2\).svg)

![Panna Group](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c77476222034446d889ea_Citi-Bank-Logo%20\(34\).svg)

![LG](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c77665225fefdd32c58f7_Citi-Bank-Logo%20\(35\).svg)

![Singer](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c77a39a5dcce54a9befd1_Citi-Bank-Logo%20\(36\).svg)

![Oppo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c77c3f10be5f400725e46_Citi-Bank-Logo%20\(37\).svg)

![Walton](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c768d8867835e49e7f363_Telenor-Logo%20\(4\).svg)

![Meghna Corporation](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c76ad0229e52c416a58d5_SCB-Logo%20\(4\).svg)

![Aci Motors](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c76cba0514e0851a82f35_HSBC-Logo%20\(4\).svg)

![Rahimafrooz](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7701843a89d811247b11_Citi-Bank-Logo%20\(32\).svg)

![Samsung](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c771b5225fefdd32c157f_Citi-Bank-Logo%20\(33\).svg)

![Pran RFL](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c7158f0d9f2e02fc7f748_Axiata-Logo%20\(2\).svg)

![Panna Group](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c77476222034446d889ea_Citi-Bank-Logo%20\(34\).svg)

![LG](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c77665225fefdd32c58f7_Citi-Bank-Logo%20\(35\).svg)

![Singer](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c77a39a5dcce54a9befd1_Citi-Bank-Logo%20\(36\).svg)

![Oppo](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682c77c3f10be5f400725e46_Citi-Bank-Logo%20\(37\).svg)

### POLICIES & INCENTIVES

-   10-year tax holiday for new industries (Applicable until 30 June 2030; [SRO No. 166 Law/Income Tax/2021](https://nbr.gov.bd/uploads/sros/SRO_on-166_Light_Engineering.pdf))
-   Duty exemptions on capital machinery imports ([118-AIN/2022/66/Customs](https://nbr.gov.bd/uploads/sros/3.SRO-75-2022-Cap-Mach-New_.pdf))
-   10% Export Subsidy on export of light engineering products (Applicable until 31 December 2025; [FEPD Circular No. 28)](https://www.bb.org.bd/mediaroom/circulars/fepd/jul102025fepd28.pdf)
-   50% tax exemption on income from exports (Applicable until 30 June 2028; [SRO No. 170-Law/Income Tax/2023](https://nbr.gov.bd/uploads/sros/IT-SRO-170.pdf))
-   [Priority export diversification sector under Industry Policy 2022](https://file-rajshahi.portal.gov.bd/uploads/824150f3-d607-49dc-91c2-54b9162a6fa6/64a/bb1/c8d/64abb1c8d4b54611002017.pdf)

#### RELEVANT BODIES

-   Ministry of Industries
-   Ministry of Commerce
-   Light Engineering Product Business Promotion Council (LEPBPC)

## **BIDA Sector Focal**

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69f98aa73cf19f0cbbaaccb2_Untitled%20design%20\(4\).png)

### Sheikh Rasibul Islam

Deputy Director

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)](https://wa.me/8801711952685)

[

+8801712595962

](https://wa.me/8801712595962)

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)](mailto:research@bida.gov.bd)

[

rasibul20@gmail.com

](https://rasibul20@gmail.com)

![](https://cdn.prod.website-files.com/6820331d027084bef793fadb/69f98aa73cf19f0cbbaaccb2_Untitled%20design%20\(4\).png)

### Mahfuzul Islam

Assistant Director

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)](https://wa.me/8801711952685)

[

+8801521407944

](https://wa.me/8801521407944)

[EXPLORE OUR SECTOR DESKS](/sector-desks)

Sheikh Rasibul Islam

Deputy Director

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)](https://wa.me/8801711952685)

+8801712595962

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300accd2e953c1dfc97a_mail.png)](mailto:research@bida.gov.bd)

rasibul20@gmail.com

Mahfuzul Islam

Assistant Director

[![](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/69ef300a8d8eb33238088e52_call%20\(1\).png)](https://wa.me/8801711952685)

+8801521407944

![](https://cdn.prod.website-files.com/62434fa732124a0fb112aab4/62434fa732124a0e4912aadb_Chevron%20right-1.svg)

![](https://cdn.prod.website-files.com/62434fa732124a0fb112aab4/62434fa732124a7ce212aacc_Chevron%20right.svg)

## RESOURCES

LIGHT ENGINEERING INDUSTRY

JUNE 2024

[

DOWNLOAD

![Arrow Icon](https://cdn.prod.website-files.com/677b6bb4f4d7d19e2c0575a9/67b06e0a1aafb043ca5e7979_Vector%20\(82\).webp)](https://cdn.prod.website-files.com/6820331d027084bef793fadb/682ec0bbe4a9f3c5506fdb84_Light%20Engineering%20Industry.pdf)

#### BOOK AN APPOINTMENT

##### SERVICE

New Business Opportunities

Registration & Approvals

Regulatory Facilitation

Visa & Work Permit Support

Aftercare

Policy & Sectoral Guidance

##### REQUESTED DATE

##### REQUESTED TIME

**Thank you!**  
Your appointment request has been submitted.  
If approved, a confirmation email will be sent to you.

Oops! Something went wrong while submitting the form.