---
source: "Department of Patents, Designs and Trademarks"
tier: 1
category: "IP"
url: "https://dpdt.gov.bd/pages/officers"
title: "কর্মকর্তাবৃন্দ | পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর"
scraped_at: "2026-07-02"
---

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

## কর্মকর্তাবৃন্দ

ক্যাটাগরি ভিত্তিক কর্মকর্তাবৃন্দ

(সকল) মহাপরিচালকের দপ্তর প্রশাসন ও অর্থ শাখা পেটেন্ট ইউনিট শিল্প-নকশা ইউনিট ট্রেডমার্কস ইউনিট জি আই ইউনিট ডব্লিওটিও এবং আন্তর্জাতিক বিষয়ক আইটি ইউনিট

ক্রম অনুসারে ডিফল্ট শিরোনাম,পদবি / পোস্ট,ইমেইল,ফোন (অফিস),ইন্টারকম,ফ্যাক্স

পৃষ্ঠা আইটেম ১০ ২০ ৫০ ১০০ ২৫০

### মহাপরিচালকের দপ্তর

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/4bcc3adf19dd46909924bc2ad839884f.jpg)

নাম

মোঃ জাহাঙ্গীর হোসেন

পদবি

মহাপরিচালক

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

dg@dpdt.gov.bd

ফোন (অফিস)

+৮৮০২-২২৩৩৮০৬৯৬

ইন্টারকম

৬০১

কক্ষ নম্বর

মোবাইল

ফ্যাক্স

+৮৮-০২-৯৫৫৬৫৫৬

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-জাহাঙ্গীর-হোসেন-21eb73-6922d8eb933eb65569dfb3a2)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/86bc69d9610840d3a66bf18ac9379e09.jpg)

নাম

মোঃ ইসমাইল

পদবি

কম্পিউটার অপারেটর (পি এ টু মহাপরিচালক)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

md.ismailtk734@gmail.com

ফোন (অফিস)

০২-২২৩৩৮০৬৯৬

ইন্টারকম

৫২৫

কক্ষ নম্বর

মোবাইল

০১৯৬৫-৫১৬৯৩২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-ইসমাইল-46e5d2-6922dccb933eb65569e12167)

### প্রশাসন ও অর্থ শাখা

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/b234e68af3154183b393adb533350761.jpeg)

নাম

ড. কায়সার মুহাম্মদ মঈনুল হাসান

পদবি

পরিচালক (প্রশাসন ও অর্থ)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

dr.admin@dpdt.gov.bd

ফোন (অফিস)

২২৩৩৮৬৫৫৬

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭১২৬২০৮৯০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ড-কায়সার-মুহাম্মদ-মঈনুল-হাসান-87f10b-6922df42933eb65569e20e6d)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/7982d992b43640d1888a41cac6a51710.png)

নাম

কৌশিক উদ্দিন

পদবি

উপ-পরিচালক (প্রশাসন ও অর্থ)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

dd.koushik@dpdt.gov.bd

ফোন (অফিস)

+৮৮-০২-৯৫১২৭৪৩

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭১৬২৫৫২৩৫ (kaushik৮২iu@gmail.com)

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/কৌশিক-উদ্দিন-7e9e0a-6922d946933eb65569dfe00e)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2026/0/edb8bff2-68ab-4f0e-b585-cc7f7b003649.jpeg)

নাম

মুহাঃ আক্কাছ আলী ফকির

পদবি

প্রশাসনিক কর্মকর্তা

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

akkasdpdt500@gmail.com

ফোন (অফিস)

০২৯৫১১৪১৪

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭১২৫৬৫৩৩৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মুহাঃ-আক্কাছ-আলী-ফকির-ae73db-6922dbdc933eb65569e0d119)

### পেটেন্ট ইউনিট

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/45c3879901404f118d5005888be90404.png)

নাম

ড. অশোক কুমার রায়

পদবি

পরিচালক (পেটেন্ট ও শিল্প নকশা)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

dr.patent@dpdt.gov.bd

ফোন (অফিস)

+৮৮২২৩৩৫৭৮০২

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭২০৫১৬৮০৪ (ashoke১৯৭০@yahoo.com)

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ড-অশোক-কুমার-রায়-50268c-6922d914933eb65569dfc60f)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2026/4/6419ded8-92d2-46f2-805a-4e48085c2025.jpg)

নাম

মোঃ হাবিবুর রহমান

পদবি

উপ-পরিচালক (পেটেন্ট)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

dd.habib@dpdt.gov.bd

ফোন (অফিস)

+৮৮-০২-৯৫৮৮০৬০

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭১২২৫৫০৫৯(habib.dpdt@gmail.com)

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-হাবিবুর-রহমান-e2010b-6922e056933eb65569e2693d)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/8d88f51d628f4b26a42c2f708d16b85c.jpg)

নাম

মির্জা গোলাম সারোয়ার

পদবি

উপ-পরিচালক (পেটেন্ট)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

dd.sarwar@dpdt.gov.bd

ফোন (অফিস)

+৮৮-০২২২৩৩৫৮০৬১

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭১৬১৭৭৭৪৮

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মির্জা-গোলাম-সারোয়ার-b662e8-6922e17f933eb65569e2c60a)

৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/6d9ceca8ce954742bb2931f972990d07.png)

নাম

আমিন মোহাম্মদ তাজুল ইসলাম

পদবি

উপ-পরিচালক (পেটেন্ট)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

dd.tajul@dpdt.gov.bd

ফোন (অফিস)

০২২২৩৩৮৬৬০৫

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭১১১৬৭১৩২ (tushar\_bmb\_du@yahoo.com)

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/আমিন-মোহাম্মদ-তাজুল-ইসলাম-241bb5-6922d8ea933eb65569dfb2c9)

৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/af4e867e06474de6a5e7d4d204926794.jpg)

নাম

মিথুন কুমার দাস

পদবি

সহকারী পরিচালক, পেটেন্ট (টেক্সটাইল প্রকৌশল)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

ad.mithun@dpdt.gov.bd

ফোন (অফিস)

+৮৮০২-২২৩৩৫৭৩৩৩

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৯৪৫৬৫৯৮৩

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/প্রকৌশলী-মিথুন-কুমার-দাস-8eccbc-6922da53933eb65569e03b88)

৬

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/4bf050bb271a43a7b4c8d39a397f96a3.jpg)

নাম

মোঃ মজনু ভূঁইয়া

পদবি

সহকারী পরিচালক, পেটেন্ট (আইসিটি)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

ad.moznu@dpdt.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭২৯-১৮২৬৪০ (moznu৫৬১৩@gmail.com))

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-মজনু-ভূঁইয়া-523e9b-6922e19d933eb65569e2cd7f)

৭

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2026/3/0763b2c2-6586-4133-a0d5-1b77cf0cb1b4.jpeg)

নাম

নীহার রঞ্জন বর্মন

পদবি

সহকারী পরিচালক, পেটেন্ট (ফার্মেসি)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

ad.nihar@dpdt.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৯৪২১১৬৭২৭ (barman.niharranjan@yahoo.com)

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/নীহার-রঞ্জন-বর্মন-b2eb55-6922e1a2933eb65569e2cea2)

৮

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/481afe1a05e44dedb047b7a129e24d0c.png)

নাম

মোঃ রাশেদুল হাছান জীবন

পদবি

সহকারী পরিচালক, পেটেন্ট (যন্ত্র কৌশল)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

ad.jibon@dpdt.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭২২৬৫৭৯১৭

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-রাশেদুল-হাছান-জীবন-2f27ee-6922e212933eb65569e2e29d)

৯

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/bbdbc8a94f744d8a8c39c90fc223fffa.png)

নাম

মোঃ বায়েজীদ মামুন

পদবি

সহকারী পরিচালক, পেটেন্ট (কৃষি)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

ad.bayeazid@dpdt.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৭৪৮৭৯১৮৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-বায়েজীদ-মামুন-803597-6922d8e2933eb65569dfae9c)

১০

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/8785fb7cfb0f4f1996b9a7b3f05bc436.jpg)

নাম

সুমিত চন্দ্র সরকার

পদবি

সহকারী পরিচালক, পেটেন্ট (রসায়ন)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

ad.sumit@dpdt.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬৪০৫৩৯৬০৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/সুমিত-চন্দ্র-সরকার-277dc4-6922d8c8933eb65569df9e32)

১১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/bd02280bf2314c668d4bdb96a86ce495.png)

নাম

মোঃ সুজন ইসলাম

পদবি

সহকারী পরিচালক, পেটেন্ট (বায়োটেকনোলজি এন্ড জেনেটিক ইঞ্জিনিয়ারিং)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

ad.sujan@dpdt.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

৬২৮

মোবাইল

০১৭০৫৯৭৫৭১৮

ফ্যাক্স

sujan.dpdt@gmail.com

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-সুজন-ইসলাম-858a13-6922dad7933eb65569e06e6a)

১২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/6f097c382fc040b99a71d60ea43ff0c0.png)

নাম

সৈকত চন্দ্র কর

পদবি

সহকারী পরিচালক, পেটেন্ট (তড়িৎ প্রকৌশল )

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

ad.saikat@dpdt.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৫২১৪৮৫২২৯

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/সৈকত-চন্দ্র-কর-c62005-6922de8e933eb65569e1b8dd)

### শিল্প-নকশা ইউনিট

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/3b9410280f4b479d8b76c32612d8e743.png)

নাম

ড. অশোক কুমার রায়

পদবি

পরিচালক (শিল্প-নকশা)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

dr.patent@dpdt.gov.bd

ফোন (অফিস)

+৮৮২২৩৩৫৭৮০২

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭২০৫১৬৮০৪ (ashoke১৯৭০@yahoo.com)

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ড-অশোক-কুমার-রায়-0ecb4f-6922df99933eb65569e22f93)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/85ee128ed9284d4297c4956dff14cef1.jpg)

নাম

সাইদুজ্জামান

পদবি

উপ-পরিচালক (ইন্ডাষ্ট্রিয়াল ডিজাইন)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

dd.saiduzzaman@dpdt.gov.bd

ফোন (অফিস)

+৮৮-০২-৯৫৮৮০৬২

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭১১১৯৯৬৪২ (saiddpdt@gmail.com)

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/সাইদুজ্জামান-6c4031-6922e2df933eb65569e2feda)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2026/5/6cd7dcf2-0d53-4e79-a283-9d0af4aab1ad.jpeg)

নাম

মুহাম্মদ রকিবুল হাসান

পদবি

সহকারী পরিচালক (ইন্ডাষ্ট্রিয়াল ডিজাইন)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

ad.rakibul@dpdt.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬৭৫৩৯২৩৩৩

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মুহাম্মদ-রকিবুল-হাসান-6ce028-6922dfbf933eb65569e23cae)

৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/82c4ae57876b4717ba071e9603d98168.jpg)

নাম

ফয়েজ মাহবুব চৌধুরী

পদবি

সহকারী পরিচালক (ইন্ডাষ্ট্রিয়াল ডিজাইন)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

ad.faez@dpdt.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৯৭৭৮৪৪৭৯০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ফয়েজ-মাহবুব-চৌধুরী-8cbc3d-6922e198933eb65569e2cc3e)

### ট্রেডমার্কস ইউনিট

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/f1a79d1f1baf43448c4a11b1bd5f8ece.jpg)

নাম

মোঃ জিল্লুর রহমান

পদবি

পরিচালক (ট্রেডমার্কস)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

dr.tm@dpdt.gov.bd

ফোন (অফিস)

+৮৮২২৩৩৫৪৯০১

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭১৬৫৮৪৪৮৮

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-জিল্লুর-রহমান-d6ede6-6922e1df933eb65569e2db02)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/1bdeb423f9964c3d80a278c7ba7d2e4d.jpg)

নাম

মির্জা গোলাম সারোয়ার

পদবি

উপ-পরিচালক (ট্রেডমার্কস) (অঃ দাঃ)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

dd.sarwar@dpdt.gov.bd

ফোন (অফিস)

+৮৮-০২২২৩৩৫৮০৬১

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭১৬১৭৭৭৪৮

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মির্জা-গোলাম-সারোয়ার-9cca33-6922e073933eb65569e271dc)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/9f1c33a6cbff4206a843eaed1f2fd2a9.jpg)

নাম

মোঃ শফিকুল ইসলাম

পদবি

উপ-পরিচালক (ট্রেডমার্কস)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

dd.shafiq@dpdt.gov.bd

ফোন (অফিস)

+৮৮-০২-৯৫৮৮০৬৫

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৯১২২৭৬৬১২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-শফিকুল-ইসলাম-449f62-6922ddcd933eb65569e1656b)

৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2026/3/85e13cb8-39ba-4fe2-8323-c362294dcac0.png)

নাম

আনজুমান আরা আক্তার খানম

পদবি

উপ-পরিচালক (ট্রেডমার্কস)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

dd.anjuman@dpdt.gov.bd

ফোন (অফিস)

০২২২৩৩৮৯৬৬৩

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৮৪৩৫৩১০০০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/আনজুমান-আরা-আক্তার-খানম-128b57-6922dad3933eb65569e06d19)

৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/c11c5afa822a415fbb9bb566a8faa982.jpg)

নাম

মুহাম্মদ ফেরদৌস হাসান

পদবি

উপ-পরিচালক (ট্রেডমার্কস)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

dd.ferdoush@dpdt.gov.bd

ফোন (অফিস)

০২২২২৩৩৫৮০৬৩

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭৩৬৮৭২৭৪৭(f.shohan@yahoo.com)

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মুহাম্মদ-ফেরদৌস-হাসান-badb41-6922e29d933eb65569e2f34f)

৬

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/ad845f3fad0a46f08c7a204ceb66b1f0.jpg)

নাম

মোঃ মেহেদী হাসান

পদবি

উপ-পরিচালক (ট্রেডমার্কস)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

dd.mehedi@dpdt.gov.bd

ফোন (অফিস)

০২-২২৩৩৫৮০৭৩

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭৩৯৪৯১৩৮৫(mehedi৬৫৯@gmail.com)

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-মেহেদী-হাসান-7e777a-6922e26a933eb65569e2eda2)

৭

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/c9231b013f5e41c6b7b0fcd06a07d482.png)

নাম

কৌশিক উদ্দিন

পদবি

উপ-পরিচালক (ট্রেডমার্কস) (অঃ দাঃ)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

dd.koushik@dpdt.gov.bd

ফোন (অফিস)

+৮৮-০২-৯৫১২৭৪৩

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭১৬২৫৫২৩৫ (kaushik৮২iu@gmail.com)

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/কৌশিক-উদ্দিন-6c8e0a-6922dfc1933eb65569e23d39)

৮

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/e2142f6bf1184da28a172380014aa553.png)

নাম

মোঃ বেলাল হোসেন

পদবি

সহকারী পরিচালক (ট্রেডমার্কস)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

ad.belal@dpdt.gov.bd

ফোন (অফিস)

+৮৮০২২২৩৩৮৯৬৭৪

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭১০৫৩৫৪২৮(belal৭১lawdu@gmail.com)

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-বেলাল-হোসেন-fd70de-6922d8db933eb65569dfaa48)

৯

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/ffd2a358b39b4a4da93b57ddfef025ce.jpg)

নাম

অজয় কুমার রায়

পদবি

সহকারী পরিচালক (ট্রেডমার্কস)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

ad.azoy@dpdt.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭৪৪৭৬২৯৭৪

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/অজয়-কুমার-রায়-58702f-6922e165933eb65569e2be77)

১০

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/5623eaafab4846c59e1c94766a3cb636.jpg)

নাম

মোঃ মজনু ভূঁইয়া

পদবি

সহকারী পরিচালক (ট্রেডমার্কস) (অঃ দাঃ)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

ad.moznu@dpdt.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭২৯-১৮২৬৪০ (moznu৫৬১৩@gmail.com))

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-মজনু-ভূঁইয়া-3e93a4-6922e160933eb65569e2bcb9)

১১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/02e7ef14a34a418ca93fd550caa451a4.jpg)

নাম

মোঃ আজহারুল ইসলাম

পদবি

সহকারী পরিচালক (ট্রেডমার্কস)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

ad.azharul@dpdt.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬৭৬৪০১১৭৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-আজহারুল-ইসলাম-b0fd42-6922de78933eb65569e1ad7a)

১২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/8c3e7d37553548cbb74ee09bc7ce12c5.jpeg)

নাম

শামীমা নাসরিন

পদবি

সহকারী পরিচালক (ট্রেডমার্কস)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

ad.shamima@dpdt.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৮৪০২২৮৭৫৭

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/শামীমা-নাসরিন-7717f0-6922dc0d933eb65569e0e2ba)

১৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/6322b94f22514e77bbee87ac121498d7.png)

নাম

রাবেয়া আক্তার

পদবি

সহকারী পরিচালক (ট্রেডমার্কস)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

ad.rabeya@dpdt.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬৮৩৮২২২৫০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/রাবেয়া-আক্তার-5735c0-6922db89933eb65569e0ab69)

১৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/05daf7076def4aa98f456ab7f98b66ef.png)

নাম

মোঃ খোরশেদুল আলম

পদবি

সহকারী পরিচালক (ট্রেডমার্কস)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

ad.khorshedul@dpdt.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮০১৮১৮-৮৩৬৫০৮

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-খোরশেদুল-আলম-011e43-6922df9b933eb65569e23009)

১৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/2a557696c36b4768834d833f2aefadf3.png)

নাম

রাফি জামিল

পদবি

সহকারী পরিচালক (ট্রেডমার্কস)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

ad.rafi@dpdt.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬০০০০০১৪৭

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/রাফি-জামিল-a2b1e8-6922d999933eb65569dff380)

১৬

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/b1e3ce85ad5c4c709298f5a04ef8b563.png)

নাম

রাফিয়াতুন নাঈম

পদবি

সহকারী পরিচালক (ট্রেডমার্কস)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

ad.rafiat@dpdt.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৫৪০৬০৮০৪৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/রাফিয়াতুন-নাঈম-262a1c-6922d8c9933eb65569df9ef9)

### জি আই ইউনিট

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2026/5/f713d3da-fe86-4fe3-8f6e-1c048dd9a809.png)

নাম

ড. অশোক কুমার রায়

পদবি

পরিচালক (জি আই) (অঃ দাঃ)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

dr.gi@dpdt.gov.bd

ফোন (অফিস)

+৮৮২২৩৩৫৭৮০২

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭২০৫১৬৮০৪

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ড-কায়সার-মুহাম্মদ-মঈনুল-হাসান-1238e9-6922e05a933eb65569e26a6b)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/d24047472a7d4e41976a42a74fccc8fa.png)

নাম

আমিন মোহাম্মদ তাজুল ইসলাম

পদবি

উপ-পরিচালক (জি আই) (অঃ দাঃ)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

dd.gi@dpdt.gov.bd

ফোন (অফিস)

০২২২৩৩৮৬৬০৫

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭১১১৬৭১৩২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/আমিন-মোহাম্মদ-তাজুল-ইসলাম-09a03a-6922da75933eb65569e04ab2)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/2428a3f2c5ca467fb6e20607f3147578.jpg)

নাম

মোঃ মজনু ভূঁইয়া

পদবি

সহকারী পরিচালক (জি আই) (অঃ দাঃ)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

ad.moznu@dpdt.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭২৯-১৮২৬৪০ (moznu৫৬১৩@gmail.com))

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-মজনু-ভূঁইয়া-798ca4-6922df77933eb65569e222f6)

৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2026/3/9235f6b5-881e-46c2-a7be-7570b1c899e0.jpeg)

নাম

নীহার রঞ্জন বর্মন

পদবি

সহকারী পরিচালক (জি আই) (অঃ দাঃ)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

ad.nihar@dpdt.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৯৪২১১৬৭২৭ (barman.niharranjan@yahoo.com)

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/নীহার-রঞ্জন-বর্মন-0ad5ce-6922def4933eb65569e1eacd)

৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/0ca86ae90c1c4416b87592b102534b4c.png)

নাম

রাফি জামিল

পদবি

সহকারী পরিচালক (জি আই) (অঃ দাঃ)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

ad.rafi@dpdt.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৬০০০০০১৪৭

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/রাফি-জামিল-369ffc-695b9ac835ce18e1c05af05c)

### ডব্লিওটিও এবং আন্তর্জাতিক বিষয়ক

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2026/5/3e842cc0-0837-4688-b7ff-38a759fb3395.jpeg)

নাম

ড. কায়সার মুহাম্মদ মঈনুল হাসান

পদবি

পরিচালক (ডব্লিওটিও এবং আন্তর্জাতিক বিষয়ক) (অঃ দাঃ)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

dr.wto@dpdt.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭১২৬২০৮৯০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-গোলাম-কিবরিয়া-b7af3d-6922de4c933eb65569e19ae1)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2026/4/8bd822be-b48e-43e2-ab85-8a047a66fa8a.jpg)

নাম

মোঃ হাবিবুর রহমান

পদবি

উপ-পরিচালক (ডব্লিউটিও এবং আন্তর্জাতিক বিষয়ক) (অঃ দাঃ)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

dd.habib@dpdt.gov.bd

ফোন (অফিস)

+৮৮-০২-৯৫৮৮০৬০

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৭১২২৫৫০৫৯(habib.dpdt@gmail.com)

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-হাবিবুর-রহমান-c64809-6922db8c933eb65569e0ac89)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/1df5672b03684daabfb88937f0c65679.png)

নাম

মোঃ বেলাল হোসেন

পদবি

সহকারী পরিচালক (ডব্লিউটিও এবং আন্তর্জাতিক বিষয়ক) (অঃ দাঃ)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

ad.belal@dpdt.gov.bd

ফোন (অফিস)

+৮৮০২২২৩৩৮৯৬৭৪

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭১০৫৩৫৪২৮(belal৭১lawdu@gmail.com)

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-বেলাল-হোসেন-4a5b95-6922e072933eb65569e27183)

৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/718d4a7e112a43b0ad89589791026047.jpg)

নাম

ফয়েজ মাহবুব চৌধুরী

পদবি

সহকারী পরিচালক (ডব্লিউটিও এবং আন্তর্জাতিক বিষয়ক) (অঃ দাঃ)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

ad.faez@dpdt.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৯৭৭৮৪৪৭৯০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ফয়েজ-মাহবুব-চৌধুরী-325af8-6922ddf4933eb65569e174ab)

৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/4eaebb7216734d3892a2c1d832d652a4.png)

নাম

রাফিয়াতুন নাঈম

পদবি

সহকারী পরিচালক (ডব্লিউটিও এবং আন্তর্জাতিক বিষয়ক) (অঃ দাঃ)

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

ad.rafiat@dpdt.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৫৪০৬০৮০৪৫

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/রাফিয়াতুন-নাঈম-cdbef8-6922df37933eb65569e20a60)

### আইটি ইউনিট

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/0200161923f1439b8cc8587a183c0701.jpg)

নাম

মোঃ আসাদুজ্জামান সরকার

পদবি

সিস্টেমস্‌ এনালিস্ট

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

sa@dpdt.gov.bd

ফোন (অফিস)

+৮৮-০২-৪৭১১৬৮৯৯

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮-০১৮২৩২৭৩০৯৭(asad৫০@gmail.com)

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-আসাদুজ্জামান-সরকার-06a6ac-6922e193933eb65569e2cb04)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/c0e4456297984ada953fea7643f00785.png)

নাম

বিপুল বনিক

পদবি

প্রোগ্রামার

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

programmer@dpdt.gov.bd

ফোন (অফিস)

+৮৮০২৪৭১২০৬৩৫

ইন্টারকম

৬০৯

কক্ষ নম্বর

৬১৬

মোবাইল

০১৮১৭৭৫০৫৫৪(bipulcse@gmail.com)

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/বিপুল-বনিক-8ff381-6922e021933eb65569e25a04)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/ed05e95ea0e940fd9d351858f03b726a.png)

নাম

তন্ময় সাহা

পদবি

সহকারী প্রোগ্রামার

অফিস

পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর

ইমেইল

ap.tanmoy@dpdt.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৫৫৮১২৮১৪৪

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/তন্ময়-সাহা-0e8307-6922ded8933eb65569e1dcda)

-   ১
-   পৃষ্ঠায় যান 

আর্কাইভ দেখুন প্রকাশিত দেখুন দেখছেন ১ থেকে ৫০ পর্যন্ত, মোট ৫০ এন্ট্রি

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

### এক্সেসিবিলিটি

ফন্ট বৃদ্ধি ফন্ট হ্রাস

 মনোক্রোম

 ইনভার্ট

 বড় কার্সর

 লিঙ্ক হাইলাইট

 শিরোনাম হাইলাইট

 পড়ার গাইড

রিসেট

[স্ক্রিন রিডার ডাউনলোড করুন](https://www.nvaccess.org/files/nvda/releases/2020.4/nvda_2020.4.exe)

[কন্টেন্টে চলে যান](#main-content) [এক্সেসিবিলিটি মেনুতে যান](#accessibility-card-title)