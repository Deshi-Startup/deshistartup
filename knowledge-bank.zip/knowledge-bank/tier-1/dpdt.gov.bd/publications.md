---
source: "Department of Patents, Designs and Trademarks"
tier: 1
category: "IP"
url: "https://dpdt.gov.bd/pages/publications"
title: "প্রকাশনাসমূহ | পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর"
scraped_at: "2026-07-02"
---

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

## প্রকাশনাসমূহ

 এডভান্সড অপশনগুলো দেখান

গ্রুপ অনুসারে কিছুই না শিরোনাম,প্রকাশের তারিখ

পৃষ্ঠা আইটেম ১০ ২০ ৫০ ১০০

নং

শিরোনাম

কভার ছবি

সংযুক্তি ফাইল সমূহ

প্রকাশের তারিখ

কার্যকলাপ

 

   

   

 

১

বিশ্ব মেধাসম্পদ দিবস-২০২৪ স্মরণিকা

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/c650b2fbf6fa43f696792fc2eed44515.pdf "office-dpdt/2024/12/c650b2fbf6fa43f696792fc2eed44515.pdf")

২৬-০৪-২০২৪

[দেখুন](/pages/publications/বিশ্ব-মেধাসম্পদ-দিবস-২০২৪-স্মরণিকা-806527-6922da5a81fc96cef9eb608c)

২

স্বপ্রণোদিতভাবে প্রকাশযোগ্য তথ্য

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/906ecf58608d4f34ad2639e003e4a197.pdf "স্বপ্রণোদিতভাবে প্রকাশযোগ্য তথ্য")

২০-০৯-২০২০

[দেখুন](/pages/publications/স্বপ্রণোদিতভাবে-প্রকাশযোগ্য-তথ্য-1f50dd-6922dafc81fc96cef9eb8551)

৩

Geographical Indications

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/26bf69f588e44463a39e0d760ec3b722.pdf "Geographical Indications")

৩১-০১-২০১৭

[দেখুন](/pages/publications/geographical-indications-592efe-6922da0481fc96cef9eb4d4c)

৪

মেধা সম্পদ কী?

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/145b6e304acf4685b43d74dbc3e1f1b9.pdf "মেধা সম্পদ কী?")

১৫-০৯-২০১৫

[দেখুন](/pages/publications/মেধা-সম্পদ-কী-76ffc9-6922dac081fc96cef9eb7187)

৫

উদ্ভাবনের সঙ্গে বসবাস

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/d02bb6716a814d938468d070d10ca08c.pdf "উদ্ভাবনের সঙ্গে বসবাস")

১৫-০৯-২০১৫

[দেখুন](/pages/publications/উদ্ভাবনের-সঙ্গে-বসবাস-2ff571-6922da1481fc96cef9eb51d1)

৬

ক্ষুদ্র ও মাঝারি শিল্প প্রতিষ্ঠানের জন্য ইন্ডা.প্রোপার্টি সম্পর্কিত ধারণা

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/e195b605927b49e59d85f689e0b31f36.pdf "ক্ষুদ্র ও মাঝারি শিল্প প্রতিষ্ঠানের জন্য ইন্ডা.প্রোপার্টি সম্পর্কিত ধারণা")

১৫-০৯-২০১৫

[দেখুন](/pages/publications/ক্ষুদ্র-ও-মাঝারি-শিল্প-প্রতিষ্ঠানের-জন্য-ইন্ডা-প্রোপার্টি-b9d0b8-6922da8a81fc96cef9eb6851)

৭

ইনভেন্টিং দ্যা ফিউচার

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/ac33cb8cd5de41feb4bae99421e75787.pdf "ইনভেন্টিং দ্যা ফিউচার")

১৫-০৯-২০১৫

[দেখুন](/pages/publications/ইনভেন্টিং-দ্যা-ফিউচার-c240b2-6922dabf81fc96cef9eb7156)

৮

ইন্ডাস্ট্রিয়াল প্রোপার্টি সম্পর্কিত ধারণা

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/2d4aab3c8c6e4085b20279605e545b37.pdf "ইন্ডাস্ট্রিয়াল প্রোপার্টি সম্পর্কিত ধারণা")

১৫-০৯-২০১৫

[দেখুন](/pages/publications/ইন্ডাস্ট্রিয়াল-প্রোপার্টি-সম্পর্কিত-ধারণা-3e3ee8-6922d9ab81fc96cef9eb3396)

৯

ক্রিয়েটিভ এক্সপ্রেশন

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/9d42ae9aa6ff4e4f8522a1240336120b.pdf "ক্রিয়েটিভ এক্সপ্রেশন")

১৫-০৯-২০১৫

[দেখুন](/pages/publications/ক্রিয়েটিভ-এক্সপ্রেশন-9224c6-6922d9ad81fc96cef9eb3482)

১০

কপিরাইট সম্পর্কিত ধারণা

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/ca7b0bc76f60475495e98b3921db6aa2.pdf "কপিরাইট সম্পর্কিত ধারণা")

১৫-০৯-২০১৫

[দেখুন](/pages/publications/কপিরাইট-সম্পর্কিত-ধারণা-b5f46f-6922dad581fc96cef9eb74bd)

-   ১
-   ২
-   **পরবর্তী** 🡲
-   পৃষ্ঠায় যান 

আর্কাইভ দেখুন প্রকাশিত দেখুন দেখছেন ১ থেকে ১০ পর্যন্ত, মোট ১২ এন্ট্রি

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

### এক্সেসিবিলিটি

ফন্ট বৃদ্ধি ফন্ট হ্রাস

 মনোক্রোম

 ইনভার্ট

 বড় কার্সর

 লিঙ্ক হাইলাইট

 শিরোনাম হাইলাইট

 পড়ার গাইড

রিসেট

[স্ক্রিন রিডার ডাউনলোড করুন](https://www.nvaccess.org/files/nvda/releases/2020.4/nvda_2020.4.exe)

[কন্টেন্টে চলে যান](#main-content) [এক্সেসিবিলিটি মেনুতে যান](#accessibility-card-title)