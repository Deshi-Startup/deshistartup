---
source: "Department of Patents, Designs and Trademarks"
tier: 1
category: "IP"
url: "https://dpdt.gov.bd/pages/laws"
title: "আইন | পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর"
scraped_at: "2026-07-02"
---

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

## আইন

 এডভান্সড অপশনগুলো দেখান

গ্রুপ অনুসারে কিছুই না শিরোনাম,আইনের নং,গেজেট নং,ট্যাগ,স্মারক নম্বর,প্রকাশের তারিখ

পৃষ্ঠা আইটেম ১০ ২০ ৫০ ১০০

নং

শিরোনাম

আইনের নং

গেজেট নং

ট্যাগ

স্মারক নম্বর

ফাইল সমূহ

সংশোধন ফাইল সমূহ

প্রকাশের তারিখ

কার্যকলাপ

 

 

 

 

 

   

   

 

১

বাংলাদেশ পেটেন্ট আইন,২০২৩

 

 

 

 

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/1702e47d69c5445fb4a63d51b36c7631.pdf "office-dpdt/2024/12/1702e47d69c5445fb4a63d51b36c7631.pdf")

১৩-১১-২০২৩

[দেখুন](/pages/laws/বাংলাদেশ-পেটেন্ট-আইন-২০২৩-b76e52-6922d9f8933eb65569e016f1)

২

বাংলাদেশ শিল্প-নকশা আইন,২০২৩

 

 

 

 

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/7e319580d8bf48a9aaf30c861a912871.pdf "বাংলাদেশ শিল্প-নকশা আইন,২০২৩")

১১-০৭-২০২৩

[দেখুন](/pages/laws/বাংলাদেশ-শিল্প-নকশা-আইন-২০২৩-d3fa36-6922da07933eb65569e01f9c)

৩

বাংলাদেশ পেটেন্ট আইন, ২০২২

২০২২ সালের ০৫ নং আইন

 

 

 

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/c01344e700304513bd84a7e52a284ded.pdf "বাংলা ভার্সন")

১১-০৪-২০২২

[দেখুন](/pages/laws/বাংলাদেশ-পেটেন্ট-আইন-২০২২-5fd6ce-6922da01933eb65569e01c3f)

৪

ট্রেডমার্ক (সংশোধন) আইন, ২০১৫

ট্রেডমার্ক আইন, ২০০৯ (১৯ নং আইন)

 

 

 

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/c0169933106744a4abbfcc44b35c7ab9.pdf "বাংলা ভার্সন")

২১-১১-২০১৫

[দেখুন](/pages/laws/ট্রেডমার্ক-সংশোধন-আইন-২০১৫-169204-6922d9fd933eb65569e01a02)

৫

ভৌগোলিক নির্দেশক পণ্য (নিবন্ধন ও সুরক্ষা) আইন, ২০১৩

২০১৩ সনের ৫৪ নং আইন

 

 

 

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/b47ec54292174f0491f2d8bfe0e346a8.pdf "ইংরেজী ভার্সন")[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/b7e5ca3b0a824d5d869441213f35de26.pdf "বাংলা ভার্সন")

১০-১১-২০১৩

[দেখুন](/pages/laws/ভৌগোলিক-নির্দেশক-পণ্য-নিবন্ধন-ও-সুরক্ষা-আইন-২০১৩-6c1dd6-6922d9fe933eb65569e01ab3)

৬

ট্রেডমার্ক আইন, ২০০৯

২০০৯ সনের ১৯ নং আইন

 

 

 

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/fd84513d63a54d31b90bf5c0036aa310.pdf "ইংরেজী ভার্সন")[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/4bd0dc33b5ba4cf8b005b6687cd2b09e.pdf "বাংলা ভার্সন")

২৪-০৩-২০০৯

[দেখুন](/pages/laws/ট্রেডমার্ক-আইন-২০০৯-090dd2-6922d9ff933eb65569e01ade)

৭

ট্রেডমার্কস (সংশেধিত) আইন, ২০০৩

১৪

 

 

 

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/1ef97e4b8801428db1ca25a042241690.pdf "ট্রেডমার্কস আইন, ২০০৩")

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/437dfd41e1044f278c88ff7ef1d48a7d.pdf "ট্রেডমার্কস (সংশেধিত) আইন, ২০০৩")

১৩-০৫-২০০৩

[দেখুন](/pages/laws/ট্রেডমার্কস-সংশেধিত-আইন-২০০৩-433181-6922d9fb933eb65569e018b0)

৮

পেটেন্ট এবং ডিজাইন (সংশোধিত) আইন, ২০০৩

১৫

 

 

 

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/fa43a5e81d8444edae131b9a5095d31b.pdf "পেটেন্ট এবং ডিজাইন (সংশোধিত) আইন, ২০০৩")

১৩-০৫-২০০৩

[দেখুন](/pages/laws/পেটেন্ট-এবং-ডিজাইন-সংশোধিত-আইন-২০০৩-f78ab1-6922d9fc933eb65569e0196a)

৯

পেটেন্ট ও ডিজাইন আইন, ১৯১১

ACT NO. II OF 1911

 

 

 

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/e107f32bd9954c809e285b77cb9f8810.pdf "ইংরেজী ভার্সন")

[দেখুন](/pages/laws/পেটেন্ট-ও-ডিজাইন-আইন-১৯১১-aedb3e-6922d9f4933eb65569e0148f)

-   ১
-   পৃষ্ঠায় যান 

আর্কাইভ দেখুন প্রকাশিত দেখুন দেখছেন ১ থেকে ৯ পর্যন্ত, মোট ৯ এন্ট্রি

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

### এক্সেসিবিলিটি

ফন্ট বৃদ্ধি ফন্ট হ্রাস

 মনোক্রোম

 ইনভার্ট

 বড় কার্সর

 লিঙ্ক হাইলাইট

 শিরোনাম হাইলাইট

 পড়ার গাইড

রিসেট

[স্ক্রিন রিডার ডাউনলোড করুন](https://www.nvaccess.org/files/nvda/releases/2020.4/nvda_2020.4.exe)

[কন্টেন্টে চলে যান](#main-content) [এক্সেসিবিলিটি মেনুতে যান](#accessibility-card-title)