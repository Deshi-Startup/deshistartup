---
source: "Department of Patents, Designs and Trademarks"
tier: 1
category: "IP"
url: "https://dpdt.gov.bd/pages/photo-galleries"
title: "ফটোগ্যালারি | পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর"
scraped_at: "2026-07-02"
---

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

## ফটোগ্যালারি

ক্রম অনুসারে ডিফল্ট শিরোনাম,ফটো গ্যালারির ধরণ

পৃষ্ঠা আইটেম ১০ ২০ ৫০ ১০০

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2026/6/33f2ffb3-f226-413a-9980-ec0c4994f9d5.jpg)

শিল্প মন্ত্রণালয়ের নবনিযুক্ত মাননীয় মন্ত্রী জনাব খন্দকার আব্দুল মুক্তাদির-কে পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তরের পক্ষ থেকে মহাপরিচালক জনাব মোঃ জাহাঙ্গীর হোসেন এর ফুলেল শুভেচ্ছা।

[দেখুন](/pages/photo-galleries/শিল্প-মন্ত্রণালয়ের-নবনিযুক্ত-মাননীয়-মন্ত্রী-জনাব-খন্দকার-আব্দুল-মুক্তাদির-কে-পেটেন্ট-শিল্প-নকশা-ও-ট্রেডমার্কস-অধিদপ্তরের-পক্ষ-থেকে-মহাপরিচালক-জনাব-মোঃ-জাহাঙ্গীর-হোসেন-এর-ফুলেল-শুভেচ্ছা-xf26sv-6a462e1ba03fc4552dd433e7)

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2026/6/e1183e92-eb51-4415-b677-8b3c7b74ef61.jpg)

Unlocking the Commercial Potential of Registered Geographical Indications (GI) Goods in Bangladesh: Effective GI Tagging, Opportunities and Challenges" বিষয়ক কর্মশালা।

[দেখুন](/pages/photo-galleries/unlocking-the-commercial-potential-of-registered-geographical-indications-gi-goods-in-bangladesh-effective-gi-tagging-opportunities-and-challenges-বিষয়ক-কর্মশালা-f96cma-6a462ce4d46f6e66514921ad)

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2026/6/32e8a76a-80cb-4e9d-9b35-81c91693f20e.jpg)

Bangladesh’s Patent Landscape and LDC Graduation: Challenges, Strategic Plan, Role of Regulatory Bodies and Domestic Stakeholders" বিষয়ক কর্মশালা।

[দেখুন](/pages/photo-galleries/bangladeshs-patent-landscape-and-ldc-graduation-challenges-strategic-plan-role-of-regulatory-bodies-and-domestic-stakeholders-বিষয়ক-কর্মশালা-may3t4-6a462c51bfe9696467bbd92f)

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2026/6/9a455cc8-3deb-4a76-87f6-aea38fe21de2.jpeg)

বিশ্ব মেধাস্বত্ব দিবস - ২০২৬

[দেখুন](/pages/photo-galleries/বিশ্ব-মেধাস্বত্ব-দিবস-২০২৬-8fy47y-6a462b6fa21d610fe04c82e1)

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/0232c90b91a64fddb12a3da96d40cf0d.JPG)

“বাংলােদশ পেটেন্ট আইন,২০২৩; বাস্তবায়নের লক্ষ্যে করণীয় শীর্ষক সেমিনার\_৩১\_০৭\_২০২৪

[দেখুন](/pages/photo-galleries/বাংলােদশ-পেটেন্ট-আইন-২০২৩-বাস্তবায়নের-লক্ষ্যে-করণীয়-শীর্ষক-a1716b-6922d97681fc96cef9eb225b)

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/24a86e8c09af4acb8bf8d2f58e2f03b4.jpg)

WIPO এর সাথে অটোমেশন চুক্তি স্বাক্ষর ২০২৪

[দেখুন](/pages/photo-galleries/wipo-এর-সাথে-অটোমেশন-চুক্তি-স্বাক্ষর-২০২৪-ddac37-6922d94781fc96cef9eb1575)

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/8b2726d232954324b50942da0c7d6cb9.jpeg)

সুশাসন প্রতিষ্ঠার নিমিত্ত অংশীজনের (stakeholders) অংশগ্রহণে সভা

[দেখুন](/pages/photo-galleries/সুশাসন-প্রতিষ্ঠার-নিমিত্ত-অংশীজনের-stakeholders-অংশগ্রহণে-সভা-0a16cc-6922dc0e81fc96cef9ebc602)

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/7fa8aafd2eec47d3b66b7d79975bc6e7.jpg)

Representing Bangladessh in WIPO General Assembly. September 30 to October 9, 2019 (Geneva, Switzerland)

[দেখুন](/pages/photo-galleries/representing-bangladessh-in-wipo-general-assembly-september-30-to-october-9-2019-geneva-switzerland-2745f9-6922d90d81fc96cef9eb0c29)

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/99eeee01f2b9421ba27ca687808947f4.jpg)

WIPO High-Level Forum, 2018

[দেখুন](/pages/photo-galleries/wipo-high-level-forum-2018-8bd89c-6922dda881fc96cef9ec0f31)

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/76f5893a62a2488aa955d2cb859696f1.jpg)

SLA Signing Ceremony for TISCs between WIPO and DPDT

[দেখুন](/pages/photo-galleries/sla-signing-ceremony-for-tiscs-between-wipo-and-dpdt-f79403-6922dc5b81fc96cef9ebd50c)

-   ১
-   পৃষ্ঠায় যান 

আর্কাইভ দেখুন প্রকাশিত দেখুন দেখছেন ১ থেকে ১০ পর্যন্ত, মোট ১০ এন্ট্রি

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

### এক্সেসিবিলিটি

ফন্ট বৃদ্ধি ফন্ট হ্রাস

 মনোক্রোম

 ইনভার্ট

 বড় কার্সর

 লিঙ্ক হাইলাইট

 শিরোনাম হাইলাইট

 পড়ার গাইড

রিসেট

[স্ক্রিন রিডার ডাউনলোড করুন](https://www.nvaccess.org/files/nvda/releases/2020.4/nvda_2020.4.exe)

[কন্টেন্টে চলে যান](#main-content) [এক্সেসিবিলিটি মেনুতে যান](#accessibility-card-title)