---
source: "Department of Patents, Designs and Trademarks"
tier: 1
category: "IP"
url: "https://dpdt.gov.bd/"
title: "হোম | পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর"
scraped_at: "2026-07-02"
---

### স্বাগত বার্তা

গণপ্রজাতন্ত্রী বাংলাদেশ সরকারের শিল্প মন্ত্রণালয়ের নিয়ন্ত্রণাধীন **পেটেন্ট, শিল্প-নকশা ও ট্রেডমার্কস অধিদপ্তর** এর অফিসিয়াল ওয়েবসাইটে আপনাকে স্বাগত।

সাবেক ‘পেটেন্ট অফিস’ এবং ‘ট্রেডমার্কস রেজিস্ট্রি’ অফিস দুটি একীভূত করে ২০০৩ সালে পেটেন্ট, ডিজাইন ও ট্রেডমার্কস অধিদপ্তর হিসাবে এটি কার্যক্রম শুরু করে। এই অধিদপ্তরের মূল কার্যাবলীর মধ্যে রয়েছে মেধা সম্পদ সুরক্ষায় নতুন নতুন উদ্ভাবনের পেটেন্ট, ডিজাইন সত্ত্ব মঞ্জুর করা, পণ্য ও সেবার ট্রেডমার্ক ও ভৌগোলিক নির্দেশক পণ্য নিবন্ধন করা।

নোটিশ বোর্ড

-   [
    
    ৩৩৯ নং ট্রেডমার্ক জার্নালে প্রকাশিত ট্রেডমার্ক দরখাস্ত সমূহের বিরুদ্ধে দায়েরকৃত অপোজিশন মামলা সংক্রান্ত তথ্য।
    
    ২৪-০৬-২০২৬ **সাধারণ**
    
    ](/pages/notices/৩৩৯-নং-ট্রেডমার্ক-জার্নালে-প্রকাশিত-ট্রেডমার্ক-দরখাস্ত-সমূহের-বিরুদ্ধে-দায়েরকৃত-অপোজিশন-মামলা-সংক্রান্ত-তথ্য-4wcj98-6a3bb1ce96ede6d08b061305)
-   [
    
    ৩৩৮ নং ট্রেডমার্ক জার্নালে প্রকাশিত ট্রেডমার্ক দরখাস্ত সমূহের বিরুদ্ধে দায়েরকৃত অপোজিশন মামলা সংক্রান্ত তথ্য।
    
    ২৪-০৬-২০২৬ **সাধারণ**
    
    ](/pages/notices/৩৩৮-নং-ট্রেডমার্ক-জার্নালে-প্রকাশিত-ট্রেডমার্ক-দরখাস্ত-সমূহের-বিরুদ্ধে-দায়েরকৃত-অপোজিশন-মামলা-সংক্রান্ত-তথ্য-kequc2-6a3bb1a8ead8618d35d4d212)
-   [
    
    ৩৩৭ নং ট্রেডমার্ক জার্নালে প্রকাশিত ট্রেডমার্ক দরখাস্ত সমূহের বিরুদ্ধে দায়েরকৃত অপোজিশন মামলা সংক্রান্ত তথ্য।
    
    ২৩-০৫-২০২৬ **সাধারণ**
    
    ](/pages/notices/৩৩৭-নং-ট্রেডমার্ক-জার্নালে-প্রকাশিত-ট্রেডমার্ক-দরখাস্ত-সমূহের-বিরুদ্ধে-দায়েরকৃত-অপোজিশন-মামলা-সংক্রান্ত-তথ্য-kzipjs-6a126f8d7fa93b1e330f5d85)

[সকল নোটিশ দেখুন](/pages/notices)

খবর

[বাংলাদেশ পেটেন্ট আইন, ২০২৩ কার্যকর এর গেজেট](/pages/news/বাংলাদেশ-পেটেন্ট-আইন-২০২৩-কার্যকর-এর-গেজেট-db2212-6922d996933eb65569dff2d3)

[সকল](/pages/news/)

সেবা সমূহ

[সব দেখুন](/pages/service-boxes)

# আমাদের বিষয়

![আমাদের বিষয়](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/188eb002cdc14eb2a800a62b326c312c.png)

-   [কর্মকর্তাবৃন্দ](/pages/officers "কর্মকর্তাবৃন্দ")
-   [সাংগঠনিক কাঠামো](/pages/static-pages/6922e04a933eb65569e265a1 "সাংগঠনিক কাঠামো")
-   [অফিস আদেশ/পাসপোর্ট অনাপত্তিপত্র](/pages/office-orders "অফিস আদেশ/পাসপোর্ট অনাপত্তিপত্র")
-   [ফোকাল পয়েন্ট তালিকা](/pages/static-pages/6922dbc7933eb65569e0c790 "ফোকাল পয়েন্ট তালিকা")

# আইন/নীতিমালা/প্রজ্ঞাপন/পরিপত্র

![আইন/নীতিমালা/প্রজ্ঞাপন/পরিপত্র](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/9435596f2a2b485da1605748891888b3.png)

-   [আইন](/pages/laws "আইন")
-   [নীতিমালা](/pages/policies "নীতিমালা")
-   [বিধিবিধান](/pages/legislative-informations "বিধিবিধান")
-   [প্রজ্ঞাপন ও অন্যান্য](/pages/static-pages/6922dd2a933eb65569e13c11 "প্রজ্ঞাপন ও অন্যান্য")

# আমাদের সেবা সমূহ

![আমাদের সেবা সমূহ](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/bfd849994e494bbcae3ac24718bac3bc.png)

-   [মেধাস্বত্ব বিষয়ক নিবন্ধন](/pages/static-pages/6922df8b933eb65569e22aeb "মেধাস্বত্ব বিষয়ক নিবন্ধন")
-   [নিবন্ধিত মেধাস্বত্বের নবায়ণ](/pages/static-pages/6922dc6b933eb65569e1042a "নিবন্ধিত মেধাস্বত্বের নবায়ণ")
-   [নিবন্ধিত মেধাসম্পদের তথ্য প্রদান](/pages/static-pages/6922dccc933eb65569e121e0 "নিবন্ধিত মেধাসম্পদের তথ্য প্রদান")
-   [সকল সেবা](/pages/office-process-maps "সকল সেবা")

# ফরম

![ফরম](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/dd11b4a0f5444b66af81c3454764e0b0.png)

-   [পেটেন্ট](/pages/static-pages/6922dce0933eb65569e12878 "পেটেন্ট")
-   [ডিজাইন](/pages/static-pages/6922dfde933eb65569e24690 "ডিজাইন")
-   [ট্রেডমার্কস](/pages/static-pages/6922e08d933eb65569e278d3 "ট্রেডমার্কস")
-   [ভৌগোলিক নির্দেশক পণ্য](/pages/static-pages/6922dc71933eb65569e10685 "ভৌগোলিক নির্দেশক পণ্য")

# অনলাইন সেবা

![অনলাইন সেবা](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/ebab7bc3ed224ac3b6ad039efb0c6c78.png)

-   [পেটেন্ট](/pages/static-pages/6922e04d933eb65569e2666d "পেটেন্ট")
-   [ডিজাইন](/pages/static-pages/6922e04d933eb65569e2666d "ডিজাইন")
-   [ট্রেডমার্কস](/pages/static-pages/6922e04d933eb65569e2666d "ট্রেডমার্কস")
-   [জি আই](/pages/static-pages/6922e04d933eb65569e2666d "জি আই")

# সরকারি কর্মসম্পাদন পরিবীক্ষণ প্রতিবেদন

![সরকারি কর্মসম্পাদন পরিবীক্ষণ প্রতিবেদন](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/c0abde59bea8492fa8299ee048483158.png)

-   [নির্দেশিকা/পরিপত্র/জিপিএমএস টিম/ফোকাল পয়েন্ট](/pages/static-pages/6922e037933eb65569e26098 "নির্দেশিকা/পরিপত্র/জিপিএমএস টিম/ফোকাল পয়েন্ট")
-   [সরকারি কর্মসম্পাদন পরিবীক্ষণ প্রতিবেদন](/pages/static-pages/6922dfaa933eb65569e2353b "সরকারি কর্মসম্পাদন পরিবীক্ষণ প্রতিবেদন")
-   [জিপিএমএস সফটওয়্যার লিংক](https://gpms.cabinet.gov.bd/ "জিপিএমএস সফটওয়্যার লিংক")
-   [প্রশিক্ষণ কর্মশালা](/pages/static-pages/6922dc4c933eb65569e0f90a "প্রশিক্ষণ কর্মশালা")

# বাজেট ও উন্নয়ন

![বাজেট ও উন্নয়ন](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/de9bea1e7d6c4102b7b5c56c94c373f3.png)

-   [বাজেট](/pages/static-pages/6922de4d933eb65569e19b4b "বাজেট")
-   [ক্রয় পরিকল্পনা](/pages/static-pages/6922e157933eb65569e2b921 "ক্রয় পরিকল্পনা")
-   [প্রকল্প/কর্মসূচী](/pages/projects/6922d97fdbfbab28ce04d40c "প্রকল্প/কর্মসূচী")
-   [অন্যান্য](/pages/static-pages/6922df32933eb65569e2082e "অন্যান্য")

# অভিযোগ প্রতিকার ব্যবস্থাপনা

![অভিযোগ প্রতিকার ব্যবস্থাপনা](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/c31903b814834c30b76be13c66071bb0.png)

-   [অনিক/আপিল কর্তৃপক্ষ](/pages/static-pages/6922dc3a933eb65569e0f1a3 "অনিক/আপিল কর্তৃপক্ষ")
-   [GRS বার্ষিক/ত্রৈমাসিক প্রতিবেদন](/pages/static-pages/6922ddd4933eb65569e167fa "GRS বার্ষিক/ত্রৈমাসিক প্রতিবেদন")
-   [অভিযোগ প্রতিকার ব্যবস্থা সংক্রান্ত ইন বিধি নীতিমালা](https://cabinet.gov.bd/pages/static-pages/6940329d35ce18e1c055f637 "অভিযোগ প্রতিকার ব্যবস্থা সংক্রান্ত ইন বিধি নীতিমালা")
-   [অভিযোগ দাখিল (অনলাইন আবেদন)](https://www.grs.gov.bd/ "অভিযোগ দাখিল (অনলাইন আবেদন)")

# ইনোভেশন কার্যক্রম

![ইনোভেশন কার্যক্রম](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/6848e11859524fff9b2379f4d699f6e0.png)

-   [ইনোভেশন টিম](/pages/static-pages/6922dcc8933eb65569e1204e "ইনোভেশন টিম")
-   [উদ্ভাবনী উদ্যোগ সমুহ](/pages/static-pages/6922de84933eb65569e1b3b7 "উদ্ভাবনী উদ্যোগ সমুহ")
-   [ইনোভেশন টিমের বার্ষিক প্রতিবেদন](/pages/static-pages/6922dc50933eb65569e0fad4 "ইনোভেশন টিমের বার্ষিক প্রতিবেদন")
-   [সকল (ইনোভেশন টিম)](/pages/innovation-corners/6922d96981fc96cef9eb1e40 "সকল (ইনোভেশন টিম)")

# জাতীয় শুদ্ধাচার কৌশল

![জাতীয় শুদ্ধাচার কৌশল](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/7ea9c2ba94e2494292d3c625768f7cfd.png)

-   [ডিপিডিটি'র কার্যক্রম](/pages/static-pages/6922dd03933eb65569e132b5 "ডিপিডিটি'র কার্যক্রম")
-   [কমিটি/উপ-কমিটি](/pages/committees/6922db48dbfbab28ce059184 "কমিটি/উপ-কমিটি")
-   [কর্মপরিকল্পনা/প্রতিবেদন](/pages/static-pages/6922df5e933eb65569e21894 "কর্মপরিকল্পনা/প্রতিবেদন")
-   [জাতীয় শুদ্ধাচার ফোকাল পয়েন্ট](/pages/static-pages/6922dd78933eb65569e15270 "জাতীয় শুদ্ধাচার ফোকাল পয়েন্ট")

# সেবা প্রদান প্রতিশ্রুতি (সিটিজেন্‌স চার্টার)

![সেবা প্রদান প্রতিশ্রুতি (সিটিজেন্‌স চার্টার)](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/5e527b0d123c434987d870b137d73ea2.png)

-   [সেবা প্রদান প্রতিশ্রুতি](/pages/static-pages/6922df66933eb65569e21bc3 "সেবা প্রদান প্রতিশ্রুতি")
-   [ফোকাল পয়েন্ট কর্মকর্তা/পরিবীক্ষণ কমিটি](/pages/static-pages/6922de62933eb65569e1a484 "ফোকাল পয়েন্ট কর্মকর্তা/পরিবীক্ষণ কমিটি")
-   [ত্রৈমাসিক/বার্ষিক পরিবীক্ষণ/মূল্যায়ন প্রতিবেদন](/pages/static-pages/6922dca9933eb65569e117a4 "ত্রৈমাসিক/বার্ষিক পরিবীক্ষণ/মূল্যায়ন প্রতিবেদন")
-   [আইন/বিধি/নীতিমালা/পরিপত্র/](/pages/static-pages/6922de1d933eb65569e185ab "আইন/বিধি/নীতিমালা/পরিপত্র/")

# তথ্য অধিকার

![তথ্য অধিকার](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/d26f2dac9f894ec9b9c1ad34e21c54cf.png)

-   [তথ্য অধিকার আইন/বিধিবিধান](/pages/static-pages/6922db89933eb65569e0ab19 "তথ্য অধিকার আইন/বিধিবিধান")
-   [বার্ষিক কর্মপরিকল্পনা/প্রতিবেদন](/pages/static-pages/6922db65933eb65569e09e72 "বার্ষিক কর্মপরিকল্পনা/প্রতিবেদন")
-   [দায়িত্বপ্রাপ্ত কর্মকর্তা ও আপিল কর্তৃপক্ষ](/pages/static-pages/6922dd30933eb65569e13dc7 "দায়িত্বপ্রাপ্ত কর্মকর্তা ও আপিল কর্তৃপক্ষ")
-   [স্বপ্রণোদিতভাবে প্রকাশযোগ্য তথ্যসমূহ](/pages/static-pages/6922df25933eb65569e202b0 "স্বপ্রণোদিতভাবে প্রকাশযোগ্য তথ্যসমূহ")

# ডেজিগনেটেড/ফোকাল পয়েন্ট কর্মকর্তা

-   [NDA ফোকাল পয়েন্ট](/pages/static-pages/6922e092933eb65569e27a2f "NDA ফোকাল পয়েন্ট")
-   [ডেজিগনেটেড অফিসার](/pages/static-pages/6922e060933eb65569e26bf3 "ডেজিগনেটেড অফিসার")

# মঞ্জুরকৃত পেটেন্ট, শিল্প-নকশা, ট্রেডমার্ক, জিআই

![মঞ্জুরকৃত পেটেন্ট, শিল্প-নকশা, ট্রেডমার্ক, জিআই](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/d553715967c84fd998a728eb827420aa.png)

-   [পেটেন্ট](/pages/static-pages/6922e022933eb65569e25a5a "পেটেন্ট")
-   [শিল্প-নকশা](/pages/static-pages/6922dfc3933eb65569e23de4 "শিল্প-নকশা")
-   [ট্রেডমার্ক](/pages/static-pages/6922e0aa933eb65569e28164 "ট্রেডমার্ক")
-   [জিআই](/pages/static-pages/6922dff0933eb65569e24bcf "জিআই")

সকল সেবাসমূহ দেখুন সংক্ষিপ্ত

![IPAS 4 উদ্বোধনী অনুষ্ঠান](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/7a17f4d52aa744db8956d99e7b20921c.png)

IPAS 4 উদ্বোধনী অনুষ্ঠান

![মেধাসম্পদ দিবস – ২০২৬](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2026/3/c59c3dd0-75ee-4eda-b23c-8513144f509e.png)

মেধাসম্পদ দিবস – ২০২৬

![কর্মকর্তাদের দক্ষতা উন্নয়নে ইন-হাউজ প্রশিক্ষণ](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/747fa3777d1840018c55a305729db8b9.jpg)

কর্মকর্তাদের দক্ষতা উন্নয়নে ইন-হাউজ প্রশিক্ষণ

![আইপি ডে ২০২৬](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2026/3/c5d845b6-7d1d-469d-a432-23a433f3c823.jpeg)

আইপি ডে ২০২৬

❮ ❯

  

![IPAS 4 উদ্বোধনী অনুষ্ঠান](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/7a17f4d52aa744db8956d99e7b20921c.png) ![মেধাসম্পদ দিবস – ২০২৬](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2026/3/c59c3dd0-75ee-4eda-b23c-8513144f509e.png) ![কর্মকর্তাদের দক্ষতা উন্নয়নে ইন-হাউজ প্রশিক্ষণ](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/747fa3777d1840018c55a305729db8b9.jpg) ![আইপি ডে ২০২৬](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2026/3/c5d845b6-7d1d-469d-a432-23a433f3c823.jpeg)

🡸 🡺

### এক্সেসিবিলিটি

ফন্ট বৃদ্ধি ফন্ট হ্রাস

 মনোক্রোম

 ইনভার্ট

 বড় কার্সর

 লিঙ্ক হাইলাইট

 শিরোনাম হাইলাইট

 পড়ার গাইড

রিসেট

[স্ক্রিন রিডার ডাউনলোড করুন](https://www.nvaccess.org/files/nvda/releases/2020.4/nvda_2020.4.exe)

[কন্টেন্টে চলে যান](#main-content) [এক্সেসিবিলিটি মেনুতে যান](#accessibility-card-title)

### মাননীয় মন্ত্রী

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2026/1/1a244964-8dae-4953-a06c-20389c6e28bb.jpeg)

**জনাব খন্দকার আব্দুল মুক্তাদির**

মাননীয় মন্ত্রী, শিল্প মন্ত্রণালয়

### সচিব

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2026/5/ccf6d404-8dfc-44a9-b58e-7649507947da.jpeg)

**জনাব আব্দুন নাসের খান**

সচিব, শিল্প মন্ত্রণালয়

### মহাপরিচালক

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/9e540d656baf4426a003ea845c7f4a92.jpg)

**জনাব মোঃ জাহাঙ্গীর হোসেন**

মহাপরিচালক

### কেন্দ্রীয় ই-সেবা

-   [**ডি-নথি**](https://d.nothi.gov.bd/login)
-   [**ওয়েবমেইল**](https://mail.dpdt.gov.bd/)
-   [**মাইগভ**](https://www.mygov.bd/)
-   [**আইপাস ৪.০ (অনলাইন আবেদন)**](http://bd.wipo.net/efiling-dashboard)

[![](/site-assets/images/service_link_5.jpg)](https://www.mygov.bd/)

[![](/site-assets/images/service_link_3.gif)](#)

# গুরুত্বপূর্ণ লিঙ্ক

-   [নিয়োগ বিজ্ঞপ্তি-২০২৬](http://dpdt.teletalk.com.bd/)
-   [শিল্প মন্ত্রণালয়](http://www.moind.gov.bd/)
-   [বিশ্ব মেধাসম্পদ সংস্থা](http://www.wipo.int)
-   [বিশ্ব বানিজ্য সংস্থা](http://www.wto.org/)
-   [পার্সোনেল ম্যানেজমেন্ট সিস্টেম](http://pmis.mopa.gov.bd/)

[সকল](/pages/external-links)

### ভিডিও

### আবেদন প্রক্রিয়া - ভিডিও লিংক

**[পেটেন্ট](https://youtu.be/YckrfhPy9hM?si=DXHlC4y6H3eMcCYa)**

**[ট্রেডমার্কস](https://youtu.be/MfwPrUYO_Fg?si=qnI45-EF6ywP-lrQ)**

**[শিল্প-নকশা](https://youtu.be/UHXsu86SkkA?si=03Dj5iA528aCXYZc)**

### বিজ্ঞপ্তি

### নাগরিক সনদ

[![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-dpdt/2024/12/e07595e04c834836a6ceb92ef84f6b5c.JPG)](/pages/static-pages/6922df66933eb65569e21bc3)  

### সেবা গ্রহীতাদের মতামত ও পরামর্শ

[এখানে ক্লিক করুন](/pages/web-forms/6922d3c281fc96cef9e9bf46)

### সেবা সহজিকরণ

### বাংলাদেশ ই-ডিরেক্টরি

[![](/site-assets/images/service_link_1.jpg)](https://edirectory.portal.gov.bd/)

###### জাতীয় সঙ্গীত

[![](/site-assets/images/service_link_4.png)](https://bkkb.portal.gov.bd/)

# সামাজিক যোগাযোগ

[](https://www.facebook.com/dpdt.gov.bd "facebook")

# ইনোভেশন কর্নার

-   [ইনোভেশন টিম](/pages/innovation-corners?filters=%7B%22innovation_corner_type%22%3A%226922d29981fc96cef9e9947b%22%7D)
-   [ইনোভেশন অফিসার](/pages/innovation-corners?filters=%7B%22innovation_corner_type%22%3A%226922d29981fc96cef9e9947c%22%7D)
-   [উদ্ভাবনী উদ্যোগ](/pages/innovation-corners?filters=%7B%22innovation_corner_type%22%3A%226922d2c081fc96cef9e9a486%22%7D)
-   [ইনোভেশন কর্ম পরিকল্পনা](/pages/innovation-corners?filters=%7B%22innovation_corner_type%22%3A%226922d29981fc96cef9e9947d%22%7D)
-   [ইনোভেশন কর্মপরিকল্পনার বাস্তবায়ন অগ্রগতি প্রতিবেদন](/pages/innovation-corners?filters=%7B%22innovation_corner_type%22%3A%226922d29c81fc96cef9e99602%22%7D)

[সকল](/pages/innovation-corners)

# [সরকারি অফিসের নতুন ওয়েবসাইটের আবেদন](https://pms.portal.gov.bd/office/outauth_new_office)

### বিনিয়োগ শিক্ষা কার্যক্রম

-   [ওয়েবসাইট লিংক](http://finlitbd.com/ "নকলের জন্য আবেদন")
-   [ইউটিউব লিংক](https://www.youtube.com/@financialliteracyprogramba6178 "ই-সেবার আবেদন")

### জরুরি যোগাযোগ

[সরকারি তথ্য ও সেবা **৩৩৩**](https://bangladesh.gov.bd/site/page/aaebba14-f52a-4a3d-98fd-a3f8b911d3d9) [জরুরি সেবা **৯৯৯**](https://bangladesh.gov.bd/site/page/aaebba14-f52a-4a3d-98fd-a3f8b911d3d9) [ফায়ার সার্ভিস হটলাইন **১০২**](https://bangladesh.gov.bd/site/page/aaebba14-f52a-4a3d-98fd-a3f8b911d3d9)

সকল সেবা দেখুন সংক্ষিপ্ত