---
source: "Sylhet City Corporation"
tier: 1
category: "City corporation"
url: "https://scc.gov.bd/"
title: "হোম | সিলেট সিটি কর্পোরেশন"
scraped_at: "2026-07-02"
---

নোটিশ বোর্ড

-   [
    
    Mr. Md Moklisur Rahman, Office Support Staff, Tax Collection Section - Ex Bangladesh Leave
    
    ২৮-০৬-২০২৬ **নতুন** **সাধারণ**
    
    ](/pages/notices/mr-md-moklisur-rahman-office-support-staff-tax-collection-section-ex-bangladesh-leave-jcxwu8-6a439edd6a045855c09697c2)
-   [
    
    পুনঃ ইজারা দরপত্র বিজ্ঞপ্তি
    
    ২৮-০৬-২০২৬ **নতুন** **সাধারণ**
    
    ](/pages/notices/পুনঃ-ইজারা-দরপত্র-বিজ্ঞপ্তি-4ntxkl-6a414d86ead8618d35d5cccb)
-   [
    
    সিলেট সিটি কর্পোরেশনের সম্প্রসারিত এলাকার মহাপরিকল্পনা-মাস্টার প্ল্যান (২০২৫–২০৫০) প্রণয়ন কার্যক্রমের অংশ হিসেবে আগামী ২৪-০৬-২০২৬ হতে ১১-০৭-২০২৬ তারিখ পর্যন্ত সংশ্লিষ্ট ওয়ার্ডসমূহে ওয়ার্ডভিত্তিক স্টেকহোল্ডার কনসালটেশন ওয়ার্কশপ আয়োজন প্রসঙ্গে
    
    ২৪-০৬-২০২৬ **সাধারণ**
    
    ](/pages/notices/সিলেট-সিটি-কর্পোরেশনের-সম্প্রসারিত-এলাকার-মহাপরিকল্পনা-মাস্টার-প্ল্যান-২০২৫২০৫০-প্রণয়ন-কার্যক্রমের-অংশ-হিসেবে-আগামী-২৪-০৬-২০২৬-হতে-১১-০৭-২০২৬-তারিখ-পর্যন্ত-সংশ্লিষ্ট-ওয়ার্ডসমূহে-ওয়ার্ডভিত্তিক-স্টেকহোল্ডার-কনসালটেশন-ওয়ার্কশপ-অংশগ্রহণ-প্রসঙ্গে-en555l-6a3b812b5d1c1bb52cd50d3a)

[সকল নোটিশ দেখুন](/pages/notices)

খবর

[সিলেট আন্তর্জাতিক স্টেডিয়াম: জিম্বাবুয়ে ‘এ’ দলের সঙ্গে ড্র করল বাংলাদেশ](/pages/news/সিলেট-আন্তর্জাতিক-স্টেডিয়াম-জিম্বাবুয়ে-এ-দলের-সঙ্গে-ড্র-করল-বাংলাদেশ-0svd57-6a40d8dab196a5c26dbab997) [শাহজালাল (রহ.)-এর মাজারের আর্থিক ব্যবস্থাপনায় স্বচ্ছতা আনতে ১৩ সদস্যের কমিটি গঠন](/pages/news/শাহজালাল-রহ-এর-মাজারের-আর্থিক-ব্যবস্থাপনায়-স্বচ্ছতা-আনতে-১৩-সদস্যের-কমিটি-গঠন-aqup1o-6a40d87e57b461749303893c) [ইসলামপুর কেন্দ্রীয় জামে মসজিদ পরিদর্শনে সিসিক প্রশাসক: মসজিদ ও এলাকার উন্নয়নে প্রয়োজনীয় পদক্ষেপ নেওয়ার আশ্বাস](/pages/news/ইসলামপুর-কেন্দ্রীয়-জামে-মসজিদ-পরিদর্শনে-সিসিক-প্রশাসক-মসজিদ-ও-এলাকার-উন্নয়নে-প্রয়োজনীয়-পদক্ষেপ-নেওয়ার-আশ্বাস-rha5bw-6a3cbdc0c46c177d11057191) [জাতীয় ভিটামিন ‘এ’ প্লাস ক্যাম্পেইন সফলে সবাইকে এগিয়ে আসতে হবে: পরিকল্পনা সভায় সিসিক প্রশাসক](/pages/news/জাতীয়-ভিটামিন-এ-প্লাস-ক্যাম্পেইন-সফলে-সবাইকে-এগিয়ে-আসতে-হবে-পরিকল্পনা-সভায়-সিসিক-প্রশাসক-omk2ii-6a3cbcf357b461749302ecba) [মদন মোহন কলেজের নবীনবরণ অনুষ্ঠানে সিসিক প্রশাসক: মানসম্মত শিক্ষা ছাড়া প্রতিযোগিতামূলক বিশ্বে টিকে থাকা সম্ভব নয়](/pages/news/মদন-মোহন-কলেজের-নবীনবরণ-অনুষ্ঠানে-সিসিক-প্রশাসক-মানসম্মত-শিক্ষা-ছাড়া-প্রতিযোগিতামূলক-বিশ্বে-টিকে-থাকা-সম্ভব-নয়-gqf6b7-6a3cbd6eea1dba9cc6998806)

[সকল](/pages/news/)

সেবা সমূহ

[সব দেখুন](/pages/service-boxes)

# সিসিক সম্পর্কে

![সিসিক সম্পর্কে](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/577474b6bdfb4d4793960cb9d665a9a2.png)

-   [আমাদের নগরী - এক নজরে সিসিক](/pages/static-pages/6922df09933eb65569e1f5f4 "আমাদের নগরী - এক নজরে সিসিক")
-   [সিটিজেন চার্টার](/pages/office-citizen-charters/6922d8a1933eb65569df965f "সিটিজেন চার্টার")
-   [সিসিক ম্যাপ](/pages/static-pages/6922df43933eb65569e20ee1 "সিসিক ম্যাপ")
-   [সাংগঠনিক কাঠামো](/pages/common-documents/6922e19ddbfbab28ce07af38 "সাংগঠনিক কাঠামো")

# কর্মকর্তাবৃন্দ এবং জনপ্রতিনিধি

![কর্মকর্তাবৃন্দ এবং জনপ্রতিনিধি](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/ee74345c910f4bc69e246d7989df89f7.png)

-   [মাননীয় মেয়র](/pages/office-heads/6922d8a1dbfbab28ce045f9a "মাননীয় মেয়র")
-   [বিভাগ ভিত্তিক কর্মকর্তাবৃন্দ](/pages/officers "বিভাগ ভিত্তিক কর্মকর্তাবৃন্দ")
-   [কাউন্সিলরবৃন্দ (সাধারন আসন)](/pages/static-pages/6922dcfd933eb65569e1310d "কাউন্সিলরবৃন্দ (সাধারন আসন)")
-   [কাউন্সিলরবৃন্দ (সংরক্ষিত আসন)](/pages/static-pages/6922dcda933eb65569e1266e "কাউন্সিলরবৃন্দ (সংরক্ষিত আসন)")

# বিজ্ঞপ্তি/আদেশ/দরপত্র

![বিজ্ঞপ্তি/আদেশ/দরপত্র](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/7a11a8da11854f7ba0749b83b66f73e1.png)

-   [অফিস আদেশ](/pages/office-orders "অফিস আদেশ")
-   [বিজ্ঞপ্তি](/pages/notification-circulars "বিজ্ঞপ্তি")
-   [অনাপত্তি সনদ](/pages/go-ultimates "অনাপত্তি সনদ")
-   [বহিঃ বাংলাদেশ ছুটি](/pages/go-ultimates "বহিঃ বাংলাদেশ ছুটি")

# উদ্ভাবনী কার্যক্রম

![উদ্ভাবনী কার্যক্রম](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/f00b310f2449407487bcf460900a993b.png)

-   [বার্ষিক উদ্ভাবন কর্মপরিকল্পনা](/pages/static-pages/6922ddf4933eb65569e17487 "বার্ষিক উদ্ভাবন কর্মপরিকল্পনা")
-   [উদ্ভাবনী কর্মকর্তা](/pages/static-pages/6922ddaf933eb65569e15dea "উদ্ভাবনী কর্মকর্তা")
-   [উদ্ভাবনী উদ্যোগ সমূহ](/pages/reports/6922df2adbfbab28ce06ded5 "উদ্ভাবনী উদ্যোগ সমূহ")
-   [উদ্ভাবন কর্মপরিকল্পনা বাস্তবায়ন ও মূল্যায়ন নির্দেশিকা](/pages/reports/6922debcdbfbab28ce06b301 "উদ্ভাবন কর্মপরিকল্পনা বাস্তবায়ন ও মূল্যায়ন নির্দেশিকা")

# বাজেট ও প্রকল্প

![বাজেট ও প্রকল্প](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/65919465c780423f9e664f6a0afb3824.png)

-   [বাজেট](/pages/reports/6922dc33dbfbab28ce05d954 "বাজেট")
-   [বার্ষিক প্রতিবেদন](/pages/static-pages/6922e130933eb65569e2ac49 "বার্ষিক প্রতিবেদন")
-   [উল্লেখযোগ্য উন্নয়নমূলক প্রকল্প](/pages/common-documents/6922e05edbfbab28ce07458d "উল্লেখযোগ্য উন্নয়নমূলক প্রকল্প")
-   [ক্রয় পরিকল্পনা](/pages/common-documents/6922e444dbfbab28ce08a4a1 "ক্রয় পরিকল্পনা")

# দরপত্র

![দরপত্র](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/8d958a92319344e0ba6b73e99bac1453.png)

-   [টেন্ডার বিজ্ঞপ্তি](/pages/tenders "টেন্ডার বিজ্ঞপ্তি")
-   [ইজিপি তথ্য বাতায়ন](https://www.eprocure.gov.bd/ "ইজিপি তথ্য বাতায়ন")
-   [পিই নির্দেশিকা](/pages/common-documents/6922e15cdbfbab28ce0798cf "পিই নির্দেশিকা")
-   [সিপিটিইউ তথ্য বাতায়ন](http://www.cptu.gov.bd/ "সিপিটিইউ তথ্য বাতায়ন")

# জাতীয় শুদ্ধাচার কৌশল

![জাতীয় শুদ্ধাচার কৌশল](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/99398d6a71b243a886a860f16fcf0a87.png)

-   [জাতীয় শুদ্ধাচার কৌশল](/pages/reports/6922db82dbfbab28ce05a7a3 "জাতীয় শুদ্ধাচার কৌশল ")
-   [কর্ম-পরিকল্পনা ও উত্তম চর্চা](/pages/static-pages/6922dea3933eb65569e1c37e "কর্ম-পরিকল্পনা ও উত্তম চর্চা")
-   [নৈতিকতা কমিটি](/pages/static-pages/6922de40933eb65569e1955a "নৈতিকতা কমিটি")
-   [প্রজ্ঞাপন/নীতিমালা/পরিপত্র](/pages/static-pages/6922dd81933eb65569e15483 " প্রজ্ঞাপন/নীতিমালা/পরিপত্র")

# সেবা প্রদান প্রতিশ্রুতি (সিটিজেন্‌স চার্টার)

![সেবা প্রদান প্রতিশ্রুতি (সিটিজেন্‌স চার্টার)](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/15d5bf9f17f2499c8081182d9e7d937a.png)

-   [সেবা প্রদান প্রতিশ্রুতি](/pages/office-citizen-charters/6922d8a1933eb65569df965f "সেবা প্রদান প্রতিশ্রুতি")
-   [ফোকাল পয়েন্ট /পরিবীক্ষণ কমিটি](/pages/static-pages/6922e0ac933eb65569e281f6 "ফোকাল পয়েন্ট /পরিবীক্ষণ কমিটি")
-   [বার্ষিক পরিবীক্ষণ প্রতিবেদন](/pages/reports/6922df27dbfbab28ce06ddf3 "বার্ষিক পরিবীক্ষণ প্রতিবেদন")
-   [আইন/বিধি/নীতিমালা/পরিপত্র/নির্দেশিকা/প্রজ্ঞাপন](/pages/static-pages/6922df8f933eb65569e22c3b "আইন/বিধি/নীতিমালা/পরিপত্র/নির্দেশিকা/প্রজ্ঞাপন")

# সরকারি কর্মসম্পাদন পরিবীক্ষণ পদ্ধতি

![সরকারি কর্মসম্পাদন পরিবীক্ষণ পদ্ধতি](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/0854d59873284d36a6c50c166d2d91dd.png)

-   [ত্রৈমাসিক অর্জন প্রতিবেদন](/pages/reports/6922ded7dbfbab28ce06be9a "ত্রৈমাসিক অর্জন প্রতিবেদন")
-   [সরকারি কর্মসম্পাদন পরিবীক্ষণ পদ্ধতি ও বার্ষিক কর্মসম্পাদন চুক্তি সমূহ](/pages/static-pages/6922dfec933eb65569e24ad7 "সরকারি কর্মসম্পাদন পরিবীক্ষণ পদ্ধতি ও বার্ষিক কর্মসম্পাদন চুক্তি সমূহ")
-   [জিপিএমএস টিম](/pages/static-pages/6922df82933eb65569e22740 "জিপিএমএস টিম")
-   [জিপিএমএস সফটওয়্যার লিংক](https://gpms.cabinet.gov.bd/ "জিপিএমএস সফটওয়্যার লিংক")

# অভিযোগ প্রতিকার ব্যবস্থাপনা

![অভিযোগ প্রতিকার ব্যবস্থাপনা](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/818bc1da735d4dd2a35b4bc83f5b1cf0.png)

-   [অভিযোগ নিস্পত্তি ও আপিল কর্মকর্তা](/pages/static-pages/6922dfd6933eb65569e243f3 "অভিযোগ নিস্পত্তি ও আপিল কর্মকর্তা")
-   [মাসিক/ত্রৈমাসিক/বার্ষিক পরিবীক্ষণ/মূল্যায়ন প্রতিবেদন](/pages/reports/6922dbafdbfbab28ce05b77b "মাসিক/ত্রৈমাসিক/বার্ষিক পরিবীক্ষণ/মূল্যায়ন প্রতিবেদন")
-   [অনলাইনে অভিযোগ দাখিল](http://www.grs.gov.bd/ "অনলাইনে অভিযোগ দাখিল")
-   [আইন/বিধি/নীতিমালা/পরিপত্র/নির্দেশিকা/প্রজ্ঞাপন](/pages/static-pages/6922df68933eb65569e21c8c "আইন/বিধি/নীতিমালা/পরিপত্র/নির্দেশিকা/প্রজ্ঞাপন")

# তথ্য অধিকার

![তথ্য অধিকার](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/5cef6ccae39a42a4b4423c4ff6a58977.png)

-   [আইন বিধি ও নির্দেশিকা](/pages/static-pages/6922dd69933eb65569e14f13 "আইন বিধি ও নির্দেশিকা")
-   [তথ্য প্রদানকারী কর্মকর্তা](/views/info-officers "তথ্য প্রদানকারী কর্মকর্তা")
-   [তথ্য প্রাপ্তির আবেদন ও আপিল ফরম](/pages/static-pages/6922dceb933eb65569e12bfe "তথ্য প্রাপ্তির আবেদন ও আপিল ফরম")
-   [স্বপ্রণোদিত তথ্য প্রকাশ নির্দেশিকা](/pages/static-pages/6922e0ba933eb65569e2859e "স্বপ্রণোদিত তথ্য প্রকাশ নির্দেশিকা")

# আইন ও প্রতিবেদন

![আইন ও প্রতিবেদন](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/00e976206a3342f58924d452d778be24.png)

-   [আইন সমূহ](/pages/reports/6922dc2bdbfbab28ce05d6dc "আইন সমূহ")
-   [তথ্য বাতায়ন হালনাগাদ - ত্রৈমাসিক প্রতিবেদন](/pages/reports/6922deecdbfbab28ce06c731 "তথ্য বাতায়ন হালনাগাদ - ত্রৈমাসিক প্রতিবেদন")
-   [স্থাবর-অস্থাবর সম্পত্তির তথ্য](/pages/reports/6922dee2dbfbab28ce06c3b5 "স্থাবর-অস্থাবর সম্পত্তির তথ্য")
-   [ই-নথি বাস্তবায়ন প্রতিবেদন](/pages/reports/6922dbf0dbfbab28ce05c99f "ই-নথি বাস্তবায়ন প্রতিবেদন")

# সিটি কর্পোরেশন পরিচালন ব্যবস্থা উন্নয়ন কৌশলপত্র ২০২০-২০৩০

![সিটি কর্পোরেশন পরিচালন ব্যবস্থা উন্নয়ন কৌশলপত্র ২০২০-২০৩০](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/af012ade6a214ac9b2f01f5395f6c572.png)

-   [কৌশলপত্র, কর্মপরিকল্পনা ও অগ্রগতি প্রতিবেদনসমূহ](/pages/static-pages/6922e0c8933eb65569e2892f "কৌশলপত্র, কর্মপরিকল্পনা ও অগ্রগতি প্রতিবেদনসমূহ")
-   [বার্ষিক বাজেট ও প্রতিবেদনসমূহ](/pages/static-pages/6922e0cf933eb65569e28ab2 "বার্ষিক বাজেট ও প্রতিবেদনসমূহ")
-   [সাধারণ সভা, স্থায়ী কমিটি, সিটি কর্পোরেশন প্রবিধান এবং উপ-আইনসমূহ](/pages/static-pages/6922dee8933eb65569e1e4de "সাধারণ সভা, স্থায়ী কমিটি, সিটি কর্পোরেশন প্রবিধান এবং উপ-আইনসমূহ")
-   [নাগরিক সম্পৃক্তকরণ](/pages/static-pages/6922dc47933eb65569e0f749 "নাগরিক সম্পৃক্তকরণ")

সকল সেবাসমূহ দেখুন সংক্ষিপ্ত

![1](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/9cb8e28edd31408188f16191c2507910.jpg)

1

❮ ❯

  

![1](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/9cb8e28edd31408188f16191c2507910.jpg)

🡸 🡺

### এক্সেসিবিলিটি

ফন্ট বৃদ্ধি ফন্ট হ্রাস

 মনোক্রোম

 ইনভার্ট

 বড় কার্সর

 লিঙ্ক হাইলাইট

 শিরোনাম হাইলাইট

 পড়ার গাইড

রিসেট

[স্ক্রিন রিডার ডাউনলোড করুন](https://www.nvaccess.org/files/nvda/releases/2020.4/nvda_2020.4.exe)

[কন্টেন্টে চলে যান](#main-content) [এক্সেসিবিলিটি মেনুতে যান](#accessibility-card-title)

# 

প্রশাসক

![minister](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2026/1/3200669e-19b5-4f90-b637-da9e13abed70.jpeg)

**

**আব্দুল কাইয়ুম চৌধুরী**

**পদবিঃ প্রশাসক**

**ফোন : +৮৮০২৯৯৬৬৩৩০৪৫**

**ইমেইল : [\[email protected\]](/cdn-cgi/l/email-protection)**

**যোগদানের তারিখ : ২৫ ফেব্রুয়ারি ২০২৬**

[📎 জীবন বৃত্তান্ত.pdf](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2026/2/adaebc8c-48e2-4027-a384-50b3e9a403ed.pdf)

**[বিস্তারিত](/pages/office-heads/খান-মোঃ-রেজা-উন-নবী-a7c07e-6922d8a1dbfbab28ce045f9a)

# 

**প্রধান নির্বাহী কর্মকর্তা (যুগ্মসচিব)**

![minister](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/7188cf1d43ee44a1b2490ae55845edf5.jpg)

**

**মোহাম্মদ রেজাই রাফিন সরকার**

**পদবিঃ প্রধান নির্বাহী কর্মকর্তা (যুগ্মসচিব)**  
**কার্যকালঃ ২৭ অক্টোবর ২০২৪ - বর্তমান**  
**টেলিফোনঃ +৮৮০-২৯৯৬৬৩৩৩৮১**  
**মোবাইলঃ +৮৮ ০১৭৭৭ ২৫৮ ১৮০**

**হোয়াটসঅ্যাপঃ +৮৮ ০১৭৭৭ ২৫৮ ১৮০**

**ইমেইলঃ [\[email protected\]](/cdn-cgi/l/email-protection)**

**[বিস্তারিত](/pages/office-heads/মোহাম্মদ-রেজাই-রাফিন-সরকার-5a8508-6922d8a7dbfbab28ce0463b6)

#### **জরুরী যোগাযোগঃ**

-   #### পানি সমস্যা ০১৭১১১৮৪৮১১
    
-   রাস্তাঘাট, নর্দমা, ফুটপাত ও জলাবদ্ধতা সংক্রান্ত ০১৭১১৯০৬৬৪৭
-   মশক নিধন ও জন্ম নিবন্ধন ০১৭৪৫৩৭৮৪৫৬
-   সড়কবাতি সংক্রান্ত ০২৯৯৬৬৩৫০৪৫
-   ট্রেড লাইসেন্স/নিবন্ধন সংক্রান্ত ০১৯৫৮২৮৪৮২০
-   বর্জ্য ব্যবস্থাপনা ০১৭৬৯০০৫৮৫৬
-   ট্যাক্স নির্ধারন এবং নাম সংশোধন ০১৭১১৮১২২৬৭
-   ট্যাক্স/হোল্ডিং পরিশোধ সংক্রান্ত ০১৭১১০৩০১৫০
-   আইন এবং প্রশাসনিক ০১৭২৪০৬৫২৮২
-   ভবন নির্মাণ অনুমোদন ০১৭১১৯০৬৬৪৭
-   রাজস্ব সংক্রান্ত ০১৭২২৩৮২১১৮
-   সম্পত্তি বিষয়ক ০১৭২২৩৮২১১৮
-   রোড রোলার, এক্সেভেটর বা যান্ত্রিক সংক্রান্ত ০১৭২২০১১৭২৭
-   হিসাব এবং বিল সংক্রান্ত ০১৭১১৪৬১৭১২
-   তথ্য প্রদান ০১৯৫৮২৮৪৮০০
-   বস্তি বিষয়ক ০১৭১১২৮০৬৪৮
-   জনসংযোগ ০১৭১২১৭৭১৩
-   শিক্ষা, সংস্কৃতি, পাঠাগার ও সমাজকল্যাণ ০১৭১২১৭৭৭১৩
-   সিটি মার্কেট/হকার মার্কেট ভাড়া/বরাদ্দ সংক্রান্ত ০১৯৫৮২৮৪৮১৫

![minister](#)

[বিস্তারিত](/pages/office-heads/জরুরী-যোগাযোগঃ-a74a99-6922d8a3dbfbab28ce046161)

### সিসিক হটলাইন

সিসিক হটলাইন [**০১৭০৪১০০০০১**](tel:০১৯৬৯৯২২৭২২)

দুদক [**১০৬**](tel:106)

জরুরি সেবা [**৯৯৯**](tel:999)

নাগরিক সেবা [**৩৩৩**](tel:333)

শিশু সহায়তা [**১০৯৮**](tel:1098)

নারী ও শিশু নির্যাতন প্রতিরোধে [**১০৯**](tel:1098)

স্বাস্থ্য বাতায়ন [**১৬২৬৩**](tel:১৬২৬৩)

দুর্যোগের আগাম বার্তা [**১০৯০**](tel:1090)

ভূমি সেবা পেতে অভিযোগ [**১৬১২২**](tel:16122)

জরুরী হটলাইন [**১৬৫৭৫**](tel:16575)

# অভ্যন্তরীণ ই-সেবাসমূহ

-   [অনলাইন ট্রেড লাইসেন্স](https://tradelicence.scc.gov.bd/)
-   [অনলাইন সনদের আবেদন](https://sonod.scc.gov.bd/)
-   [অনলাইন হোল্ডিং ট্যাক্স এন্ড এসেসমেন্ট](https://revenue.scc.gov.bd/)
-   [অযান্ত্রিক যান চালকের ড্রাইভিং লাইসেন্স](https://citizen.scc.gov.bd/services/nm-vehicle?subMenu=dashboardv)
-   [স্থাপনা/ইমারত নির্মাণ নকশা অনুমোদনের আবেদন](https://citizen.scc.gov.bd/)
-   [নগর মোবাইল অ্যাপ (ওয়েব ভার্সন)](https://nogorapp.scc.gov.bd/)

[সকল](/pages/internal-eservices)

 [![](/site-assets/images/service_link_1.jpg)](https://edirectory.portal.gov.bd/)[![](/site-assets/images/service_link_2.gif) ](https://www.mygov.bd/)[![](/site-assets/images/service_link_3.gif)](#)

[কেন্দ্রীয় ই-সেবাসমূহ](https://bangladesh.gov.bd/site/view/all_eservices_in_bangladesh/)

[![](/site-assets/images/service_link_5.jpg)](https://www.mygov.bd/)

[![](/site-assets/images/service_link_3.gif)](#)

# গুরুত্বপূর্ণ লিঙ্ক

-   [জন্ম ও মৃত্যু নিবন্ধন](http://bdris.gov.bd/br/application)
-   [ই-জিপি](https://www.eprocure.gov.bd/)
-   [স্থানীয় সরকার মন্ত্রণালয়](https://lgd.gov.bd/)

[সকল](/pages/external-links)

### সেবা সহজিকরণ

### বাংলাদেশ ই-ডিরেক্টরি

[![](/site-assets/images/service_link_1.jpg)](https://edirectory.portal.gov.bd/)

###### জাতীয় সঙ্গীত

[![](/site-assets/images/service_link_4.png)](https://bkkb.portal.gov.bd/)

# সামাজিক যোগাযোগ

[](https://www.facebook.com/sccsylhet/ "facebook")[](https://www.youtube.com/@sylhetcitycorporation3218 "youtube")

# [সরকারি অফিসের নতুন ওয়েবসাইটের আবেদন](https://pms.portal.gov.bd/office/outauth_new_office)

### বিনিয়োগ শিক্ষা কার্যক্রম

-   [ওয়েবসাইট লিংক](http://finlitbd.com/ "নকলের জন্য আবেদন")
-   [ইউটিউব লিংক](https://www.youtube.com/@financialliteracyprogramba6178 "ই-সেবার আবেদন")

### জরুরি যোগাযোগ

[সরকারি তথ্য ও সেবা **৩৩৩**](https://bangladesh.gov.bd/site/page/aaebba14-f52a-4a3d-98fd-a3f8b911d3d9) [জরুরি সেবা **৯৯৯**](https://bangladesh.gov.bd/site/page/aaebba14-f52a-4a3d-98fd-a3f8b911d3d9) [ফায়ার সার্ভিস হটলাইন **১০২**](https://bangladesh.gov.bd/site/page/aaebba14-f52a-4a3d-98fd-a3f8b911d3d9)

সকল সেবা দেখুন সংক্ষিপ্ত