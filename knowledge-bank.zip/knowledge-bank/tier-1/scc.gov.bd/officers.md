---
source: "Sylhet City Corporation"
tier: 1
category: "City corporation"
url: "https://scc.gov.bd/pages/officers"
title: "কর্মকর্তাবৃন্দ | সিলেট সিটি কর্পোরেশন"
scraped_at: "2026-07-02"
---

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

## কর্মকর্তাবৃন্দ

ক্রম অনুসারে ডিফল্ট শিরোনাম,পদবি / পোস্ট,ইমেইল,ফোন (অফিস),ইন্টারকম,ফ্যাক্স

পৃষ্ঠা আইটেম ১০ ২০ ৫০ ১০০ ২৫০

### (অফিসার ক্যাটাগরি উল্লেখিত নয়)

১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2026/1/6578f6e2-0868-43e4-aabf-48540fde61c6.jpeg)

নাম

আব্দুল কাইয়ুম চৌধুরী

পদবি

প্রশাসক

অফিস

সিলেট সিটি কর্পোরেশন

ইমেইল

mayor@scc.gov.bd

ফোন (অফিস)

০২৯৯৬৬৪৩২৬৬

ইন্টারকম

কক্ষ নম্বর

মোবাইল

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [জীবন বৃত্তান্ত](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2026/2/615e2373-e2a0-495a-a95c-864cf876dded.pdf)   •   [দেখুন](/pages/officers/খান-মোঃ-রেজা-উন-নবী-4158b1-6922e1ed933eb65569e2dd47)

২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/e059ea2466664d648f7c53bd390a2093.jpg)

নাম

মোহাম্মদ রেজাই রাফিন সরকার

পদবি

প্রধান নির্বাহী কর্মকর্তা (যুগ্মসচিব)

অফিস

সিলেট সিটি কর্পোরেশন

ইমেইল

ceo@scc.gov.bd

ফোন (অফিস)

+৮৮০-২৯৯৬৬৩৩৩৮১

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮ ০১৭৭৭ ২৫৮ ১৮০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোহাম্মদ-রেজাই-রাফিন-সরকার-041ad8-6922e2da933eb65569e2fd98)

৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2026/2/fb51b283-c9d8-4065-872b-2f9f0c2b2f0c.jpg)

নাম

মোঃ আশিক নূর

পদবি

সচিব

অফিস

সিলেট সিটি কর্পোরেশন

ইমেইল

secretary@scc.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮০ ১৭২৪-০৬৫২৮২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/বিশ্বজিত-দেব-e96aab-6922dd21933eb65569e139e5)

৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/91cb22a8e59b48b9a28b18527f2e6d45.jpg)

নাম

মোঃ আলী আকবর

পদবি

প্রধান প্রকৌশলী (ভারপ্রাপ্ত)

অফিস

সিলেট সিটি কর্পোরেশন

ইমেইল

ce@scc.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮০১৭১১৯০৬৬৪৭

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-আলী-আকবর-bb4967-6922e063933eb65569e26cd6)

৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/485f7bafcde74f439ddb79d998902b77.jpeg)

নাম

বিশ্বজিত দেব

পদবি

প্রধান রাজস্ব কর্মকর্তা

অফিস

সিলেট সিটি কর্পোরেশন

ইমেইল

cro@scc.gov.bd

ফোন (অফিস)

+৮৮০২৯৯৬৬ ৩১০৮

ইন্টারকম

১৪৯

কক্ষ নম্বর

৫১৩

মোবাইল

+৮৮০১৭২২৩৮২১১৮

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/বিশ্বজিত-দেব-608566-6922dfc1933eb65569e23d1f)

৬

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/e52f68a71fc941b989d525881985960f.jpg)

নাম

ডাঃ মোঃ জাহিদুল ইসলাম

পদবি

প্রধান স্বাস্থ্য কর্মকর্তা

অফিস

সিলেট সিটি কর্পোরেশন

ইমেইল

cho@scc.gov.bd

ফোন (অফিস)

০২৯৯৬৬ ৪০৩০৮

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৪৫৩৭৮৪৫৬

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/ডাঃ-মোঃ-জাহিদুল-ইসলাম-9ee9de-6922de5a933eb65569e1a118)

৭

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2026/5/38033fca-1c6b-41f2-abd3-50e957ac04f4.jpeg)

নাম

বিশ্বজিত দেব

পদবি

প্রধান সম্পত্তি কর্মকর্তা (অতিরিক্ত দায়িত্ব)

অফিস

সিলেট সিটি কর্পোরেশন

ইমেইল

cro@scc.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

৫১৪

মোবাইল

+৮৮০১৭২২৩৮২১১৮

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/সুনন্দা-রায়-fa2619-6922d90e933eb65569dfc3bc)

৮

নাম

মোহাম্মদ শফিকুল ইসলাম

পদবি

এক্সিকিউটিভ ম্যাজিস্ট্রেট

অফিস

সিলেট সিটি কর্পোরেশন

ইমেইল

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭৮৪-৬৪৮২৬৪

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোহাম্মদ-শফিকুল-ইসলাম-72cc92-6922e1e0933eb65569e2db1d)

৯

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/6d94283e3e95484da6832eec178b203d.jpg)

নাম

মোহাম্মদ একলিম আবদীন

পদবি

প্রধান বর্জ্য ব্যবস্থাপনা কর্মকর্তা

অফিস

সিলেট সিটি কর্পোরেশন

ইমেইল

cwmo@scc.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮০১৭৬৯০০৫৮৫৬

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোহাম্মদ-একলিম-আবদীন-b83296-6922e222933eb65569e2e4b0)

১০

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/950c59feec8a488c8d52b330e52727a1.jpg)

নাম

রজি উদ্দিন খান

পদবি

নির্বাহী প্রকৌশলী (পূর্ত)

অফিস

সিলেট সিটি কর্পোরেশন

ইমেইল

razi\_uddin\_khan@yahoo.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭১৬-৬৯০১০১

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/রজি-উদ্দিন-খান-aa899f-6922dddf933eb65569e16d09)

১১

নাম

জয়দেব বিশ্বাস

পদবি

নির্বাহী প্রকৌশলী (বিদ্যুৎ)

অফিস

সিলেট সিটি কর্পোরেশন

ইমেইল

ফোন (অফিস)

০২৯৯৬৬ ৩৫০৪৫

ইন্টারকম

কক্ষ নম্বর

মোবাইল

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/জয়দেব-বিশ্বাস-45b054-6922e1a6933eb65569e2cfb6)

১২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/910e70376fe84aaca18697c564db9f53.jpg)

নাম

মোহাম্মদ উল্লাহ

পদবি

নির্বাহী প্রকৌশলী (যান্ত্রিক)

অফিস

সিলেট সিটি কর্পোরেশন

ইমেইল

sccheadofmechanical@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭২২০১১৭২৭

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোহাম্মদ-উল্লাহ-402540-6922d8d2933eb65569dfa3a6)

১৩

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/5d6ea467ce794ebc87225aec786df072.jpeg)

নাম

মোঃ আব্দুল বাছিত

পদবি

প্রধান এসেসর

অফিস

সিলেট সিটি কর্পোরেশন

ইমেইল

basitabdul812267@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭১১৮১২২৬৭

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-আব্দুল-বাছিত-bc3e7b-6922df5d933eb65569e217d5)

১৪

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/5db1affd4c4b482dafb9a3a276876d10.jpg)

নাম

আ ন ম মনছুফ

পদবি

হিসাবরক্ষণ কর্মকর্তা

অফিস

সিলেট সিটি কর্পোরেশন

ইমেইল

ফোন (অফিস)

০২৯৯৬৬ ৪০০৬১

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭১১৪৬১৭১২

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/আ-ন-ম-মনছুফ-ed44d0-6922e15f933eb65569e2bc85)

১৫

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/a8f3594efe07489a94adf6c9a818dd84.jpg)

নাম

হানিফুর রহমান

পদবি

প্রশাসনিক কর্মকর্তা

অফিস

সিলেট সিটি কর্পোরেশন

ইমেইল

hfbmbd.2021@yahoo.com

ফোন (অফিস)

০২৯৯৬৬ ৩৩০৪৫

ইন্টারকম

কক্ষ নম্বর

মোবাইল

+৮৮০১৭১১৫৭০৭২৭

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/হানিফুর-রহমান-a41ab2-6922e1b0933eb65569e2d1f4)

১৬

নাম

শাকিল আহমদ

পদবি

সহকারী তথ্য কর্মকর্তা

অফিস

সিলেট সিটি কর্পোরেশন

ইমেইল

io@scc.gov.bd

ফোন (অফিস)

০১৯৫৮২৮৪৮০০

ইন্টারকম

কক্ষ নম্বর

মোবাইল

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/শাকিল-আহমদ-b13c90-6922e1b6933eb65569e2d315)

১৭

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/3781881a313e48b4b1121c74a3b945c7.jpg)

নাম

মো: আবুল ফজল (খোকন)

পদবি

বস্তি উন্নয়ন কর্মকর্তা

অফিস

সিলেট সিটি কর্পোরেশন

ইমেইল

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭১১২৮০৬৪৮

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মো-আবুল-ফজল-খোকন-f73030-6922e272933eb65569e2ee9d)

১৮

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/99a3a291b7214aad88863ab2ea695ba0.jpg)

নাম

নেহার রঞ্জন পুরকায়স্থ

পদবি

জনসংযোগ কর্মকর্তা

অফিস

সিলেট সিটি কর্পোরেশন

ইমেইল

pro@scc.gov.bd

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭১২১৭৭৭১৩

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/নেহার-রঞ্জন-পুরকায়স্থ-9d3bed-6922e01d933eb65569e258bc)

১৯

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/72898338540e47159721e2f3eca40d41.jpeg)

নাম

মোঃ জামিলুর রহমান

পদবি

ট্যাক্সেশন অফিসার

অফিস

সিলেট সিটি কর্পোরেশন

ইমেইল

syl.jamil69@gmail.com

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭১১০৩০১৫০

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-জামিলুর-রহমান-9c68ac-6922e085933eb65569e2763f)

২০

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/f581f5085b77473b8076f8a0fdbdc8da.jpg)

নাম

রুবেল আহমদ

পদবি

লাইসেন্স কর্মকর্তা

অফিস

সিলেট সিটি কর্পোরেশন

ইমেইল

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭১৭৬৮২৫৬৮

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/রুবেল-আহমদ-2df27d-6922dcca933eb65569e12101)

২১

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/6b50cec330a94cb889c50e0ec190c6a2.jpg)

নাম

মোঃ আব্দুল আজিজ

পদবি

সহকারী সম্পত্তি কর্মকর্তা (চুক্তিভিত্তিক)

অফিস

সিলেট সিটি কর্পোরেশন

ইমেইল

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭১১৭০০২৬৬

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/মোঃ-আব্দুল-আজিজ-710fd2-6922dad0933eb65569e06c34)

২২

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/06f9a471ef724abaa3bd9c9866211307.jpg)

নাম

নেহার রঞ্জন পুরকায়স্থ

পদবি

শিক্ষা, সংস্কৃতি, পাঠাগার ও সমাজকল্যাণ কর্মকর্তা

অফিস

সিলেট সিটি কর্পোরেশন

ইমেইল

ফোন (অফিস)

ইন্টারকম

কক্ষ নম্বর

মোবাইল

০১৭১২১৭৭৭১৩

ফ্যাক্স

ভিকার্ড ডাউনলোড করুন   •   [দেখুন](/pages/officers/নেহার-রঞ্জন-পুরকায়স্থ-ba32b6-6922dc0f933eb65569e0e37d)

-   ১
-   পৃষ্ঠায় যান 

আর্কাইভ দেখুন প্রকাশিত দেখুন দেখছেন ১ থেকে ২২ পর্যন্ত, মোট ২২ এন্ট্রি

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

### এক্সেসিবিলিটি

ফন্ট বৃদ্ধি ফন্ট হ্রাস

 মনোক্রোম

 ইনভার্ট

 বড় কার্সর

 লিঙ্ক হাইলাইট

 শিরোনাম হাইলাইট

 পড়ার গাইড

রিসেট

[স্ক্রিন রিডার ডাউনলোড করুন](https://www.nvaccess.org/files/nvda/releases/2020.4/nvda_2020.4.exe)

[কন্টেন্টে চলে যান](#main-content) [এক্সেসিবিলিটি মেনুতে যান](#accessibility-card-title)