---
source: "Sylhet City Corporation"
tier: 1
category: "City corporation"
url: "https://scc.gov.bd/pages/photo-galleries"
title: "ফটোগ্যালারি | সিলেট সিটি কর্পোরেশন"
scraped_at: "2026-07-02"
---

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

## ফটোগ্যালারি

ক্রম অনুসারে ডিফল্ট শিরোনাম,ফটো গ্যালারির ধরণ

পৃষ্ঠা আইটেম ১০ ২০ ৫০ ১০০

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/4f72e8fd48264f1dbaa7ea96a7e3eca8.jpg)

বাজেট ঘোষনা

[দেখুন](/pages/photo-galleries/বাজেট-ঘোষনা-4542ff-6922db8d81fc96cef9ebaab1)

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/55553330fbf843c6936686bb4b7ce068.jpg)

সিসিক/ভূমিকম্প পরিস্থিতিতে জরুরী সভা

[দেখুন](/pages/photo-galleries/সিসিক-ভূমিকম্প-পরিস্থিতিতে-জরুরী-সভা-c07707-6922dabe81fc96cef9eb710b)

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/d836608d172b47caac6bdbaf34453af1.jpeg)

সিসিকের বিজয় দিবসের অনুষ্ঠানে মেয়র আরিফ মুক্তিযোদ্ধারা স্বাধীনতা দিয়েছেন, দেশ গড়ার দায়িত্ব আমাদের

[দেখুন](/pages/photo-galleries/সিসিকের-বিজয়-দিবসের-অনুষ্ঠানে-মেয়র-আরিফ-মুক্তিযোদ্ধারা-bf50f5-6922d8d281fc96cef9eaee6d)

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/62a767496858463dbe14e32a4eb02f73.jpg)

জাতীয় হাম-রুবেলা টিনাদান ক্যাম্পেইন ২০২০ শুরু ১ লাখ ৪ হাজার শিশুকে হাম-রুবেলা টিকা প্রদানের লক্ষমাত্রা সিসিকের

[দেখুন](/pages/photo-galleries/জাতীয়-হাম-রুবেলা-টিনাদান-ক্যাম্পেইন-২০২০-শুরু-১-লাখ-৪-হাজার-শিশুকে-b0fd0b-6922dc6581fc96cef9ebd6ec)

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/a3e40136971b4cd5952702f205d7c64e.jpg)

সিসিক-লাহিজান সিটি মেয়রের ভার্চ্যুয়াল সভা চায়ের জন্য বিখ্যাত দুই সিটিকে ‘সিস্টার সিটি’ করার প্রস্তাব

[দেখুন](/pages/photo-galleries/সিসিক-লাহিজান-সিটি-মেয়রের-ভার্চ্যুয়াল-সভা-চায়ের-জন্য-বিখ্যাত-দুই-3457b7-6922db6981fc96cef9eba4af)

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/4f7cf29d56fb4d07b5f7c07761c1ee34.jpg)

সিলেট মহানগরীর সামাজিক নিরাপত্তা টেকসইকরণে সভা

[দেখুন](/pages/photo-galleries/সিলেট-মহানগরীর-সামাজিক-নিরাপত্তা-টেকসইকরণে-সভা-3f5212-6922dc6f81fc96cef9ebd8df)

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/e0af08ca725e413caaf723aac3581184.jpg)

সিসিক ২০২০-২০২১ অর্থবছরের বাজেট ঘোষণা

[দেখুন](/pages/photo-galleries/সিসিক-২০২০-২০২১-অর্থবছরের-বাজেট-ঘোষণা-64501b-6922dd8681fc96cef9ec0a9f)

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/1e5d5f63a055438eac818833a147de0e.jpg)

সিলেটের উন্নয়ন কাজ দেখতে মেয়রের সাথে ভারতীয় হাই কমিশনার -৩১/১০/২১

[দেখুন](/pages/photo-galleries/সিলেটের-উন্নয়ন-কাজ-দেখতে-মেয়রের-সাথে-ভারতীয়-হাই-কমিশনার-৩১-১০-২১-caf463-6922db1681fc96cef9eb8ff6)

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/fe3ea06c806942ffa9829ca4a45afa27.jpeg)

পরিছন্নতা কার্যক্রমে স্বচ্ছতা আনয়নে সিলেট সিটি কর্পোরেশনের ১৯নং ওয়ার্ড কাউন্সিলর কার্যালয়ে প্রধান নিবার্হী কর্মকর্তা স্যারের সভাপতিত্বে অনুষ্ঠিত সভা।

[দেখুন](/pages/photo-galleries/পরিছন্নতা-কার্যক্রমে-স্বচ্ছতা-আনয়নে-সিলেট-সিটি-কর্পোরেশনের-da6e9a-6922d8ef81fc96cef9eaff56)

![](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/bb71eaf3fc8545e7b788039c26a84a01.jpg)

সিলেট সিটি কর্পোরেশনের সার্বিক কর্মকান্ড, জাতীয় শুদ্ধাচার কৌশল কর্ম পরিকল্পনা ২০২১-২২ যথাযথ বাস্তবায়নে অবদান রাখায় পুরস্কার প্রদান

[দেখুন](/pages/photo-galleries/সিলেট-সিটি-কর্পোরেশনের-সার্বিক-কর্মকান্ড-জাতীয়-শুদ্ধাচার-কৌশল-c34eb8-6922d8d581fc96cef9eaf07a)

-   ১
-   ২
-   **পরবর্তী** 🡲
-   পৃষ্ঠায় যান 

আর্কাইভ দেখুন প্রকাশিত দেখুন দেখছেন ১ থেকে ১০ পর্যন্ত, মোট ১৬ এন্ট্রি

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

### এক্সেসিবিলিটি

ফন্ট বৃদ্ধি ফন্ট হ্রাস

 মনোক্রোম

 ইনভার্ট

 বড় কার্সর

 লিঙ্ক হাইলাইট

 শিরোনাম হাইলাইট

 পড়ার গাইড

রিসেট

[স্ক্রিন রিডার ডাউনলোড করুন](https://www.nvaccess.org/files/nvda/releases/2020.4/nvda_2020.4.exe)

[কন্টেন্টে চলে যান](#main-content) [এক্সেসিবিলিটি মেনুতে যান](#accessibility-card-title)