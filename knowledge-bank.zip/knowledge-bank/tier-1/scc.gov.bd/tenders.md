---
source: "Sylhet City Corporation"
tier: 1
category: "City corporation"
url: "https://scc.gov.bd/pages/tenders"
title: "টেন্ডার (দরপত্র) | সিলেট সিটি কর্পোরেশন"
scraped_at: "2026-07-02"
---

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

## টেন্ডার (দরপত্র)

 এডভান্সড অপশনগুলো দেখান

গ্রুপ অনুসারে কিছুই না শিরোনাম,দরপত্র নং,দরপত্রের ধরণ,প্রকাশের তারিখ

পৃষ্ঠা আইটেম ১০ ২০ ৫০ ১০০

নং

শিরোনাম

দরপত্র নং

দরপত্রের ধরণ

ফাইল সমূহ

প্রকাশের তারিখ

কার্যকলাপ

 

 

 

   

 

১

e-Tender Notice - 27/2025-26

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2026/5/1748108a-df07-4874-af95-95720619d503.pdf "office-scc/2026/5/1748108a-df07-4874-af95-95720619d503.pdf")

২৩-০৬-২০২৬

[দেখুন](/pages/tenders/e-tender-notice-272025-26-u06zxl-6a3b6fe6a306397897d88576)

২

e-Tender Notice - 26/2025-26

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2026/5/c1971233-1b46-4e81-8e72-a89aea51bd90.pdf "office-scc/2026/5/c1971233-1b46-4e81-8e72-a89aea51bd90.pdf")

২১-০৬-২০২৬

[দেখুন](/pages/tenders/e-tender-notice-262025-26-rqhkjw-6a38bd7f66737705f7e51b47)

৩

ইজারা দরপত্র বিজ্ঞপ্তি

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2026/5/9952bac0-4656-4496-889a-9a406b7469e2.pdf "office-scc/2026/5/9952bac0-4656-4496-889a-9a406b7469e2.pdf")

১৮-০৬-২০২৬

[দেখুন](/pages/tenders/ইজারা-দরপত্র-বিজ্ঞপ্তি-j3oy8g-6a33acf996ede6d08b046e09)

৪

e-Tender Notice - 25/2025-26

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2026/5/556f60e8-5338-4238-8fc2-1d12d6f80d71.pdf "office-scc/2026/5/556f60e8-5338-4238-8fc2-1d12d6f80d71.pdf")

১৫-০৬-২০২৬

[দেখুন](/pages/tenders/e-tender-notice-252025-26-ijc5js-6a33a594305a00ac840e5f67)

-   ১
-   পৃষ্ঠায় যান 

আর্কাইভ দেখুন প্রকাশিত দেখুন দেখছেন ১ থেকে ৪ পর্যন্ত, মোট ৪ এন্ট্রি

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

### এক্সেসিবিলিটি

ফন্ট বৃদ্ধি ফন্ট হ্রাস

 মনোক্রোম

 ইনভার্ট

 বড় কার্সর

 লিঙ্ক হাইলাইট

 শিরোনাম হাইলাইট

 পড়ার গাইড

রিসেট

[স্ক্রিন রিডার ডাউনলোড করুন](https://www.nvaccess.org/files/nvda/releases/2020.4/nvda_2020.4.exe)

[কন্টেন্টে চলে যান](#main-content) [এক্সেসিবিলিটি মেনুতে যান](#accessibility-card-title)