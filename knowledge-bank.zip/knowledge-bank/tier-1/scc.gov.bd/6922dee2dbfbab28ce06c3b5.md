---
source: "Sylhet City Corporation"
tier: 1
category: "City corporation"
url: "https://scc.gov.bd/pages/reports/6922dee2dbfbab28ce06c3b5"
title: "সিলেট সিটি কর্পোরেশনের স্থাবর অস্থাবর সম্পত্তির হালনাগাদ তথ্য | বিভিন্ন প্রতিবেদন | সিলেট সিটি কর্পোরেশন"
scraped_at: "2026-07-02"
---

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

কনটেন্টটি শেষ হাল-নাগাদ করা হয়েছে: মঙ্গলবার, ১৩ মে, ২০২৫ এ ০৯:৩৭ PM

## সিলেট সিটি কর্পোরেশনের স্থাবর-অস্থাবর সম্পত্তির হালনাগাদ তথ্য

কন্টেন্ট: বিভিন্ন প্রতিবেদন প্রতিবেদনের ধরণ: অন্যান্য-প্রতিবেদন প্রকাশের তারিখ: ১৮-০৯-২০২১

সিলেট সিটি কর্পোরেশ...[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/43e5fb06bdb142d8aaaf87dda1e01c72.pdf "Click here to download")

### ফাইল প্রিভিউ ওয়েব ব্রাউজারে সমর্থিত নয়

সিলেট সিটি কর্পোরেশনের স্থাবর-অস্থাবর সম্পত্তির হালনাগাদ তথ্য

[ডাউনলোড করুন](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2024/12/43e5fb06bdb142d8aaaf87dda1e01c72.pdf "Click here to download")

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

### এক্সেসিবিলিটি

ফন্ট বৃদ্ধি ফন্ট হ্রাস

 মনোক্রোম

 ইনভার্ট

 বড় কার্সর

 লিঙ্ক হাইলাইট

 শিরোনাম হাইলাইট

 পড়ার গাইড

রিসেট

[স্ক্রিন রিডার ডাউনলোড করুন](https://www.nvaccess.org/files/nvda/releases/2020.4/nvda_2020.4.exe)

[কন্টেন্টে চলে যান](#main-content) [এক্সেসিবিলিটি মেনুতে যান](#accessibility-card-title)