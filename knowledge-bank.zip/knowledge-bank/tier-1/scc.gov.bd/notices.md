---
source: "Sylhet City Corporation"
tier: 1
category: "City corporation"
url: "https://scc.gov.bd/pages/notices"
title: "নোটিশ | সিলেট সিটি কর্পোরেশন"
scraped_at: "2026-07-02"
---

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

## নোটিশ

 এডভান্সড অপশনগুলো দেখান

গ্রুপ অনুসারে কিছুই না শিরোনাম,প্রকাশের তারিখ

পৃষ্ঠা আইটেম ১০ ২০ ৫০ ১০০

নং

শিরোনাম

ফাইল সমূহ

ইমেজ

প্রকাশের তারিখ

কার্যকলাপ

 

   

   

 

১

Mr. Md Moklisur Rahman, Office Support Staff, Tax Collection Section - Ex Bangladesh Leave

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2026/5/02cb7a88-b09c-49af-8b62-2610fb0b7660.pdf "office-scc/2026/5/02cb7a88-b09c-49af-8b62-2610fb0b7660.pdf")

২৮-০৬-২০২৬

[দেখুন](/pages/notices/mr-md-moklisur-rahman-office-support-staff-tax-collection-section-ex-bangladesh-leave-jcxwu8-6a439edd6a045855c09697c2)

২

পুনঃ ইজারা দরপত্র বিজ্ঞপ্তি

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2026/5/256e4f3d-4ff7-4f21-aad8-85c7d76618db.pdf "office-scc/2026/5/256e4f3d-4ff7-4f21-aad8-85c7d76618db.pdf")

২৮-০৬-২০২৬

[দেখুন](/pages/notices/পুনঃ-ইজারা-দরপত্র-বিজ্ঞপ্তি-4ntxkl-6a414d86ead8618d35d5cccb)

৩

সিলেট সিটি কর্পোরেশনের সম্প্রসারিত এলাকার মহাপরিকল্পনা-মাস্টার প্ল্যান (২০২৫–২০৫০) প্রণয়ন কার্যক্রমের অংশ হিসেবে আগামী ২৪-০৬-২০২৬ হতে ১১-০৭-২০২৬ তারিখ পর্যন্ত সংশ্লিষ্ট ওয়ার্ডসমূহে ওয়ার্ডভিত্তিক স্টেকহোল্ডার কনসালটেশন ওয়ার্কশপ আয়োজন প্রসঙ্গে

২৪-০৬-২০২৬

[দেখুন](/pages/notices/সিলেট-সিটি-কর্পোরেশনের-সম্প্রসারিত-এলাকার-মহাপরিকল্পনা-মাস্টার-প্ল্যান-২০২৫২০৫০-প্রণয়ন-কার্যক্রমের-অংশ-হিসেবে-আগামী-২৪-০৬-২০২৬-হতে-১১-০৭-২০২৬-তারিখ-পর্যন্ত-সংশ্লিষ্ট-ওয়ার্ডসমূহে-ওয়ার্ডভিত্তিক-স্টেকহোল্ডার-কনসালটেশন-ওয়ার্কশপ-অংশগ্রহণ-প্রসঙ্গে-en555l-6a3b812b5d1c1bb52cd50d3a)

৪

e-Tender Notice - 27/2025-26

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2026/5/73d3fcf1-55cc-41a5-b065-81e356de4ae5.pdf "office-scc/2026/5/73d3fcf1-55cc-41a5-b065-81e356de4ae5.pdf")

২৩-০৬-২০২৬

[দেখুন](/pages/notices/e-tender-notice-272025-26-mx0uu0-6a3b7011f606a85e9363bbda)

৫

যোগদান

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2026/5/74734510-c9e1-4b15-b123-84b1a40524fc.pdf "office-scc/2026/5/74734510-c9e1-4b15-b123-84b1a40524fc.pdf")

২১-০৬-২০২৬

[দেখুন](/pages/notices/যোগদান-br57y3-6a38e4f296ede6d08b0534d1)

৬

e-Tender Notice - 26/2025-26

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2026/5/05142422-d862-4ad2-a138-edf13e888357.pdf "office-scc/2026/5/05142422-d862-4ad2-a138-edf13e888357.pdf")

২১-০৬-২০২৬

[দেখুন](/pages/notices/e-tender-notice-262025-26-ba4whx-6a38bdb1f606a85e9362df88)

৭

অফিস আদেশ

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2026/5/da5300e3-af14-4b64-90f0-303c6621617c.pdf "office-scc/2026/5/da5300e3-af14-4b64-90f0-303c6621617c.pdf")

১৪-০৬-২০২৬

[দেখুন](/pages/notices/অফিস-আদেশ-my69ew-6a2f880a83e9ea4be20615d6)

৮

Mr. Chandan Das, Assessor (Officer in Special Duty), Assessment Section - Ex Bangladesh Leave

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2026/4/24a0e297-e7fb-4d87-b526-9364ff2dc87f.pdf "office-scc/2026/4/24a0e297-e7fb-4d87-b526-9364ff2dc87f.pdf")

১৯-০৫-২০২৬

[দেখুন](/pages/notices/mr-chandan-das-assessor-officer-in-special-duty-assessment-section-ex-bangladesh-leave-uqx3w8-6a0d4ce22a941ac3be734f61)

৯

যোগদান

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2026/5/0c99dd7d-fe62-40f3-a617-1aba2f10cfc0.pdf "office-scc/2026/5/0c99dd7d-fe62-40f3-a617-1aba2f10cfc0.pdf")

১৮-০৫-২০২৬

[দেখুন](/pages/notices/যোগদান-sxyzed-6a1e7400040d753b4f03d26b)

১০

কোম্পানিগঞ্জের জব্দকৃত বালুর পুনঃদরপত্র বিজ্ঞপ্তি

[](https://objectstorage.ap-dcc-gazipur-1.oraclecloud15.com/n/axvjbnqprylg/b/V2Ministry/o/office-scc/2026/4/45a7fae5-ebfb-4ab5-8564-dc9914b3a916.pdf "office-scc/2026/4/45a7fae5-ebfb-4ab5-8564-dc9914b3a916.pdf")

১৪-০৫-২০২৬

[দেখুন](/pages/notices/কোম্পানিগঞ্জের-জব্দকৃত-বালুর-পুনঃদরপত্র-বিজ্ঞপ্তি-6a060cc9fa5a21e711e4c723)

-   ১
-   ২
-   ৩
-   **পরবর্তী** 🡲
-   পৃষ্ঠায় যান 

আর্কাইভ দেখুন প্রকাশিত দেখুন দেখছেন ১ থেকে ১০ পর্যন্ত, মোট ২৫ এন্ট্রি

এই কনটেন্টটি শেয়ার করতে ক্লিক করুন

আপনার মতামত প্রদান করুন

### আপনার মতামত প্রদান করুন

আপনার নাম  নাম অবশ্যই দিতে হবে

আপনার ইমেইল  সঠিক ইমেইল দিন

আপনার যোগাযোগ নম্বর  সঠিক ফোন নম্বর দিন (যেমন 017XXXXXXXX)

আপনার মতামত মতামত কমপক্ষে ২০ অক্ষরের হতে হবে

Attachment (jpg, jpeg, png, pdf • max 2 MB)  Invalid file. Allowed: JPG, JPEG, PNG, PDF up to 2MB

জমা দিন

### এক্সেসিবিলিটি

ফন্ট বৃদ্ধি ফন্ট হ্রাস

 মনোক্রোম

 ইনভার্ট

 বড় কার্সর

 লিঙ্ক হাইলাইট

 শিরোনাম হাইলাইট

 পড়ার গাইড

রিসেট

[স্ক্রিন রিডার ডাউনলোড করুন](https://www.nvaccess.org/files/nvda/releases/2020.4/nvda_2020.4.exe)

[কন্টেন্টে চলে যান](#main-content) [এক্সেসিবিলিটি মেনুতে যান](#accessibility-card-title)