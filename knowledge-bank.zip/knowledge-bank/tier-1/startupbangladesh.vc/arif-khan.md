---
source: "Startup Bangladesh Limited"
tier: 1
category: "Government VC"
url: "https://www.startupbangladesh.vc/bods/arif-khan/"
title: "Startup Bangladesh Limited - ARIF KHANStartup Bangladesh Limited - ARIF KHAN"
scraped_at: "2026-07-02"
---

![](https://www.startupbangladesh.vc/wp-content/uploads/2021/07/Arif-Khan.jpg)

Independent Director, Board of Directors, Startup Bangladesh Limited and Vice Chairman of Shanta Asset Management

## ARIF KHAN

Mr. Arif Khan is at present the Vice Chairman of Shanta Asset Management. Mr. Khan has played a pivotal role in the field of finance both in public and private sector of Bangladesh and has over 30 years of experience in the financial sectors of Bangladesh.

Prior to joining Shanta Group, he was the Managing Director and Chief Executive of IDLC Finance, where he previously served for 15 years and held key positions, including the role of the deputy managing director. Before joining IDLC as the MD and CEO, Mr. Khan served Bangladesh Securities and Exchange Commission (BSEC) as a commissioner. During his stint with BSEC he pioneered several reforming initiatives as a capital market regulator under guidance of Honorable Chairman and Ministry of Finance including Stock Exchanges Demutualization, Corporate Governance Code for Publicly Listed Companies, Public Issue Rules, Listing Regulations, Equity Research Rules and many more.

Mr. Khan graduated in Finance and Banking from the University of Dhaka and later completed his MBA from the Institute of Business Administration (IBA). He was the president of Institute of Cost & Management Accountants of Bangladesh and is the founding President of Bangladesh Merchant Bankers’ Association (BMBA) and CFA society, Bangladesh.