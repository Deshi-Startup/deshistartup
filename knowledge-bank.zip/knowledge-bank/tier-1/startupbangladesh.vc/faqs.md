---
source: "Startup Bangladesh Limited"
tier: 1
category: "Government VC"
url: "https://www.startupbangladesh.vc/contact/faqs/"
title: "Startup Bangladesh Limited - FAQStartup Bangladesh Limited - FAQ"
scraped_at: "2026-07-02"
---

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/) 

[Apply Now](http://www.startupbangladesh.vc/contact/apply-for-investment/)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg) 

#### about

#### Fund of Funds

#### Portfolio

#### Partners

#### NRB Connect

#### media

#### career

#### contact

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/des-close.svg)

#### Bangladesh National Parliament House

Jatiya Sangsad Bhaban or National Parliament House, is the house of the Parliament of Bangladesh, located at Sher-e-Bangla Nagar in the Bangladeshi capital of Dhaka.

[Learn more](javascript:)

Photo by Unknown

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/)  

[Apply Now](https://www.startupbangladesh.vc/contact/apply-for-investment/)

-   -   [About](javascript:)
        
    -   [Fund of Funds](javascript:)
        
    -   [Portfolio](javascript:)
        
    -   [Partners](javascript:)
        
    -   [NRB Connect](javascript:)
        
    -   [media](javascript:)
        
    -   [career](javascript:)
        
    -   [contact](javascript:)
        

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

-   [](https://www.startupbangladesh.vc/contact/contact-enquiries/)
-   [](https://www.startupbangladesh.vc/contact/apply-for-investment/)

FAQ ![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/caret.svg) 

-   [Application for Investment](https://www.startupbangladesh.vc/contact/apply-for-investment/)
-   [Information](https://www.startupbangladesh.vc/contact/contact-info/)
-   [Enquiries](https://www.startupbangladesh.vc/contact/contact-enquiries/)
-   [FAQ](https://www.startupbangladesh.vc/contact/faqs/)

## FAQ

#### Q: What is Startup Bangladesh Limited?

Startup Bangladesh Limited, founded in March 2020, is a first of its kind venture capital company in Bangladesh under the ICT Division, Government of the People’s Republic of Bangladesh. The purpose of the company is to develop Bangladesh’s venture capital ecosystem by assisting startups and impact enterprises in the form of investment capital, governance structuring and operational support. Startup Bangladesh Limited will make equity/quasi-equity investments in seed, early and growth stage startups/select impact enterprises with the option to co-invest, support run as fund-of-funds, asset manager and provide ecosystem building support to local startups and stakeholders.

#### Q: Who is eligible for investment?

The company will aspire to invest in startups and enterprises registered in Bangladesh with high growth potential and/or significant social impact. The investees will be seed, early stage and growth stage startups and impact enterprises.

#### Q: What criteria do we look at while selecting enterprises to invest?

Industry focus –Sectors that Startup Bangladesh Limited will focus on includes (but not limited to):  
\- Fintech/Financial Services  
\- Health-tech/ Healthcare  
\- Enterprise Solutions/ Software  
\- Entertainment & Lifestyle  
\- E-commerce/Retail  
\- Frontier Technology  
\- Core Technologies/AI/Deep Tech  
\- EdTech/Education  
\- Food and Agri-tech/Agriculture  
\- IoT  
\- Logistics/Mobility  
\- Emerging Technology Related Services  
  
Alignment with National goals: Companies working on areas which would significantly contribute towards the nation’s SDG achievement, are aligned with National ICT Policy, country’s 8th 5-year plan, Vision of Digital Bangladesh, Vision 2041 and other relevant national goals.  
  
Impact: Additionally, Startup Bangladesh Limited will also take into account (besides the company’s growth potential) their impact on social good, citizen services, climate change, inclusion (gender, person with different abilities) etc.

#### Q: What is the investment process?

The investment team will be involved throughout the process, starting from initial screening, in-depth due diligence, deal structuring, investments, and active role in management of investee companies (where applicable).  
  
The process involves initial screening focusing on- a) Problem, b) Solution, c) Product-Market Fit, d) Market Fundamentals, e) Business Model, f) Team. Deals that pass the initial screening stage will be subject to further business, financial and legal due diligence and structuring. Once the due diligence process is satisfactorily completed, go ahead from the investment committee and approval from the Board are received, the Share Subscription Agreement (SSA) and other documentations are executed and the agreed upon disbursement/s will be made.

#### Q: What are the investment terms?

Each investment’s terms and agreements will be specific to the nature of the business model, company valuation, the industry and market it operates in and other attributes of the concerned proposal. Transaction value for each investment will be in the range of BDT 25 lac to BDT 5 crore (per round). There is no minimum limit for target ownership by the firm but with a maximum of 49% stake in each investee. Expected exit for investments is expected to be within 5-8 years of investment subject to market conditions.

#### Q: How do you reach out to us?

Interested companies and startups can reach out to Startup Bangladesh Limited via investment@startupbangladeshvc.gov.bd sharing at a minimum the following set of information:  
  
\- Investment Pitch Deck including Financial Projections, Business Model, Product Market Fit, Impact, Alignment with Government Vision and SDGs, Company Details such as Founder and Team Information.  
  
\- Additionally, the information package should also comprise of key regulatory documents such as Trade License of the company, e-TIN and VAT registration certificates, permission for tax holiday (if any), any other license or permission in relation to the company, Certificate of Incorporation (CoI) and Memorandum & Articles of Association (AoA) of the company to name a few.

#### Q: What happens next?

If initial screening and investigations are promising, Startup Bangladesh Limited will share an Indication of Interest (IoI) and propose a meeting with the key stakeholders to explore further details about the pitch, the type of investment syndicate which would appeal to both parties and do more in-depth research.

#### Q: What is the expected timeline?

The process of reaching terms for an investment (term sheet) can take from 1 month to 4 months or longer.  
  
If there's any further query, contact us through details on our website.

© 2025 Startup Bangladesh Limited