---
source: "Startup Bangladesh Limited"
tier: 1
category: "Government VC"
url: "http://startupbangladesh.vc/about-our-purpose/"
title: "Startup Bangladesh Limited - Our PurposeStartup Bangladesh Limited - Our Purpose"
scraped_at: "2026-07-02"
---

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/) 

[Apply Now](http://www.startupbangladesh.vc/contact/apply-for-investment/)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg) 

#### about

#### Fund of Funds

#### Portfolio

#### Partners

#### NRB Connect

#### media

#### career

#### contact

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/des-close.svg)

#### Bangladesh National Parliament House

Jatiya Sangsad Bhaban or National Parliament House, is the house of the Parliament of Bangladesh, located at Sher-e-Bangla Nagar in the Bangladeshi capital of Dhaka.

[Learn more](javascript:)

Photo by Unknown

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/)  

[Apply Now](https://www.startupbangladesh.vc/contact/apply-for-investment/)

-   -   [About](javascript:)
        
    -   [Fund of Funds](javascript:)
        
    -   [Portfolio](javascript:)
        
    -   [Partners](javascript:)
        
    -   [NRB Connect](javascript:)
        
    -   [media](javascript:)
        
    -   [career](javascript:)
        
    -   [contact](javascript:)
        

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

-   [](http://startupbangladesh.vc/about-who-we-are/)
-   [](http://startupbangladesh.vc/about-our-values/)

Our Purpose ![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/caret.svg) 

-   [Who We Are](https://www.startupbangladesh.vc/about/about-who-we-are/)
-   [Our Purpose](https://www.startupbangladesh.vc/about/about-our-purpose/)
-   [Our Values](https://www.startupbangladesh.vc/about/about-our-values/)
-   [What We Do](https://www.startupbangladesh.vc/about/about-what-we-do/)
-   [People](https://www.startupbangladesh.vc/about/people-board-of-director/)

## Our Purpose

**Our Vision:** "To position Bangladesh as a leading destination for global venture capital and entrepreneurship, building a sustainable and robust startup ecosystem."

**Our Mission:** "To drive sustainable socio-economic impact by strategically investing in innovative startups, building a strong startup pipeline, and supporting a dynamic investment ecosystem."

  
  

Startup Bangladesh Limited is committed to developing Bangladesh’s venture capital ecosystem by providing support to early-stage tech based companies in the form of capital, financial guidance, and operational guidance. The company also intends to provide superior returns over a medium to long term by investing in high growth and social impact companies, with good management and corporate governance through equality and equity linked instruments.

-   Support Technology-Based Innovation
-   Create New Employment Opportunities
-   Develop Technical Skills
-   Promote Under-Represented Tech Groups
-   Connect With Non-Resident Bangladeshis
-   Foster an entrepreneurship culture
-   Attract foreign investment and expertise

  
  
  
  
  
  

© 2025 Startup Bangladesh Limited