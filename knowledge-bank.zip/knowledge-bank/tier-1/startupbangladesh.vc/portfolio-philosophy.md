---
source: "Startup Bangladesh Limited"
tier: 1
category: "Government VC"
url: "https://www.startupbangladesh.vc/portfolio-2/portfolio-philosophy/"
title: "Startup Bangladesh Limited - Philosophy Startup Bangladesh PhilosophyStartup Bangladesh Limited - Philosophy Startup Bangladesh Philosophy"
scraped_at: "2026-07-02"
---

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/) 

[Apply Now](http://www.startupbangladesh.vc/contact/apply-for-investment/)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg) 

#### about

#### Fund of Funds

#### Portfolio

#### Partners

#### NRB Connect

#### media

#### career

#### contact

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/des-close.svg)

#### Bangladesh National Parliament House

Jatiya Sangsad Bhaban or National Parliament House, is the house of the Parliament of Bangladesh, located at Sher-e-Bangla Nagar in the Bangladeshi capital of Dhaka.

[Learn more](javascript:)

Photo by Unknown

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/)  

[Apply Now](https://www.startupbangladesh.vc/contact/apply-for-investment/)

-   -   [About](javascript:)
        
    -   [Fund of Funds](javascript:)
        
    -   [Portfolio](javascript:)
        
    -   [Partners](javascript:)
        
    -   [NRB Connect](javascript:)
        
    -   [media](javascript:)
        
    -   [career](javascript:)
        
    -   [contact](javascript:)
        

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

-   [](https://www.startupbangladesh.vc/portfolio-2/portfolio/)
-   [](https://www.startupbangladesh.vc/portfolio-2/portfolio/)

Philosophy ![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/caret.svg) 

-   [Philosophy](https://www.startupbangladesh.vc/portfolio-2/portfolio-philosophy/)
-   [Our Portfolio](https://www.startupbangladesh.vc/portfolio-2/portfolio/)

## Philosophy

The Startup Bangladesh Fund will provide financial support to high-tech startups and growth companies in the form of equity or convertible debt (the Investment). The Investment will provide the necessary capital to accelerate technological development and achieve commercial success. The Fund is committed to fostering technical innovation and sustainable development through a process that is transparent, accountable and provides equal opportunity for all. It will seek to invest in non-listed companies with high growth potential that are registered in Bangladesh. The investees will be early stage tech-based companies with high growth potential. Exit for investments is expected to be within 3-5 years of investment.

© 2025 Startup Bangladesh Limited