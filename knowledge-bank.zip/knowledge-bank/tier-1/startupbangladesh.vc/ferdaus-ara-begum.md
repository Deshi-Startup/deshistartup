---
source: "Startup Bangladesh Limited"
tier: 1
category: "Government VC"
url: "https://www.startupbangladesh.vc/bods/ferdaus-ara-begum/"
title: "Startup Bangladesh Limited - FERDAUS ARA BEGUMStartup Bangladesh Limited - FERDAUS ARA BEGUM"
scraped_at: "2026-07-02"
---

![](https://www.startupbangladesh.vc/wp-content/uploads/2025/02/FERDAUS-ARA-BEGUM-2.jpg)

Independent Director, Board of Directors, Startup Bangladesh Limited and Chief Executive Officer, Business Initiative Leading Development (BUILD)

## FERDAUS ARA BEGUM

Ferdaus Ara Begum has vast experience of working with the private sector since 1987. A master’s degree holder in economics from the University of Dhaka, she completed her Post-Graduate Diploma in International Economics and Institutions. She received training from AIT, Thailand, on Project Implementation and Management. She attended training on services and international trade law and development in Esami, Arusha and Tanzania. She has previously acted as the In-Charge of the DCCI Research Cell for several years, served as Secretary of the DCCI for some time, and worked as Executive Director of the SAARC Chamber of Commerce and Industry for several years.

She has managed numerous projects and coordinated many national and international programmes, contributing her extensive expertise to the areas of policy research and advocacy, SME development and promotion, research on Multilateral Training System (MTS), project management, women entrepreneurship development, and chamber management. She has also worked for CIPE, ITC, JETRO, GIZ in different capacities.