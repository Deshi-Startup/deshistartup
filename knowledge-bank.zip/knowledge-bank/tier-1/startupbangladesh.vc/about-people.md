---
source: "Startup Bangladesh Limited"
tier: 1
category: "Government VC"
url: "https://www.startupbangladesh.vc/about/about-people/"
title: "Startup Bangladesh Limited - TeamStartup Bangladesh Limited - Team"
scraped_at: "2026-07-02"
---

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/) 

[Apply Now](http://www.startupbangladesh.vc/contact/apply-for-investment/)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg) 

#### about

#### Fund of Funds

#### Portfolio

#### Partners

#### NRB Connect

#### media

#### career

#### contact

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/des-close.svg)

#### Bangladesh National Parliament House

Jatiya Sangsad Bhaban or National Parliament House, is the house of the Parliament of Bangladesh, located at Sher-e-Bangla Nagar in the Bangladeshi capital of Dhaka.

[Learn more](javascript:)

Photo by Unknown

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/)  

[Apply Now](https://www.startupbangladesh.vc/contact/apply-for-investment/)

-   -   [About](javascript:)
        
    -   [Fund of Funds](javascript:)
        
    -   [Portfolio](javascript:)
        
    -   [Partners](javascript:)
        
    -   [NRB Connect](javascript:)
        
    -   [media](javascript:)
        
    -   [career](javascript:)
        
    -   [contact](javascript:)
        

![](https://www.startupbangladesh.vc/wp-content/uploads/2025/01/SBL-CL.jpg)

## TOGETHER, WE HELP YOU INNOVATE FASTER.

-   [](https://startupbangladesh.vc/about/people-board-of-director/)
-   [](https://startupbangladesh.vc/about/people-board-of-director/)

Team ![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/caret.svg) 

-   [Board of Director](https://www.startupbangladesh.vc/about/people-board-of-director/)
-   [Team](https://www.startupbangladesh.vc/about/about-people/)

![Nurul Hai](https://www.startupbangladesh.vc/wp-content/uploads/2020/12/WhatsApp-Image-2026-02-17-at-1.27.27-PM.jpeg)

#### Nurul Hai

Managing Director and CEO

[Explore Profile](https://www.startupbangladesh.vc/members/nurul-hai/)

![A.B.M. MONIRUL ISLAM, PMP](https://www.startupbangladesh.vc/wp-content/uploads/2021/03/Monirul2.jpg)

#### A.B.M. MONIRUL ISLAM, PMP

Chief Strategy Officer and Company Secretary

[Explore Profile](https://www.startupbangladesh.vc/members/a-b-m-monirul-islam/)

### Investment

![Rashel Mia](https://www.startupbangladesh.vc/wp-content/uploads/2021/03/Rashel-new.jpg)

#### Rashel Mia

Assistant Vice President - Fund of Funds

[Explore Profile](https://www.startupbangladesh.vc/members/rashel-mia/)

![Md. Anowar Jahid](https://www.startupbangladesh.vc/wp-content/uploads/2021/12/Anowar-Jahid-1.jpg)

#### Md. Anowar Jahid

Assistant Vice President - Venture Capital

[Explore Profile](https://www.startupbangladesh.vc/members/md-anowar-jahid/)

![NAZIA TUBUSSUM](https://www.startupbangladesh.vc/wp-content/uploads/2021/03/Nazia-4.jpg)

#### NAZIA TUBUSSUM

Associate - Venture Capital

[Explore Profile](https://www.startupbangladesh.vc/members/nazia-tubussum/)

![Hridoi Saraff](https://www.startupbangladesh.vc/wp-content/uploads/2021/03/hridoi-1.jpg)

#### Hridoi Saraff

Executive - Fund of Funds (on study leave)

[Explore Profile](https://www.startupbangladesh.vc/members/hridoi-saraff/)

### Impact and Ecosystem

![Md Dewan Adnan](https://www.startupbangladesh.vc/wp-content/uploads/2021/03/Adnan-7.jpg)

#### Md Dewan Adnan

Assistant Vice President - Impact and Ecosystem

[Explore Profile](https://www.startupbangladesh.vc/members/md-dewan-adnan/)

![NAFIS ALAM](https://www.startupbangladesh.vc/wp-content/uploads/2021/03/Nafis-1.jpg)

#### NAFIS ALAM

Assistant Vice President - Impact and Ecosystem

[Explore Profile](https://www.startupbangladesh.vc/members/nafis-alam/)

### Compliance and HR

![NAZMUL HUDA](https://www.startupbangladesh.vc/wp-content/uploads/2021/03/Nazmul-2-2.jpg)

#### NAZMUL HUDA

Assistant Vice President - Compliance and HR

[Explore Profile](https://www.startupbangladesh.vc/members/nazmul-huda/)

![PUSPITA DAS](https://www.startupbangladesh.vc/wp-content/uploads/2021/03/Puspita-4.jpg)

#### PUSPITA DAS

Analyst - Compliance and HR

[Explore Profile](https://www.startupbangladesh.vc/members/puspita-das/)

![Mehedi Hasan](https://www.startupbangladesh.vc/wp-content/uploads/2021/03/mehedi24.jpg)

#### Mehedi Hasan

Executive - Compliance and HR

[Explore Profile](https://www.startupbangladesh.vc/members/mehedi-hasan/)

### Finance and Accounts

![Md. Mamun Miah](https://www.startupbangladesh.vc/wp-content/uploads/2021/03/Mamun-Mia2.jpg)

#### Md. Mamun Miah

Associate - Finance and Accounts

[Explore Profile](https://www.startupbangladesh.vc/members/md-mamun-miah/)

![Sadman Osman](https://www.startupbangladesh.vc/wp-content/uploads/2023/12/Sadman.jpg)

#### Sadman Osman

Executive - Finance and Accounts

[Explore Profile](https://www.startupbangladesh.vc/members/sadman-osman/)

### Information Technology

![SHIB NARAYAN DHAR](https://www.startupbangladesh.vc/wp-content/uploads/2021/03/Shib-1.jpg)

#### SHIB NARAYAN DHAR

Associate - Information Technology

[Explore Profile](https://www.startupbangladesh.vc/members/shib-dhar/)

© 2025 Startup Bangladesh Limited