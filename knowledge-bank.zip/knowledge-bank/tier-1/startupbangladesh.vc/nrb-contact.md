---
source: "Startup Bangladesh Limited"
tier: 1
category: "Government VC"
url: "https://www.startupbangladesh.vc/nrb-contact/"
title: "Startup Bangladesh Limited - NRB Program ContactStartup Bangladesh Limited - NRB Program Contact"
scraped_at: "2026-07-02"
---

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/) 

[Apply Now](http://www.startupbangladesh.vc/contact/apply-for-investment/)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg) 

#### about

#### Fund of Funds

#### Portfolio

#### Partners

#### NRB Connect

#### media

#### career

#### contact

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/des-close.svg)

#### Bangladesh National Parliament House

Jatiya Sangsad Bhaban or National Parliament House, is the house of the Parliament of Bangladesh, located at Sher-e-Bangla Nagar in the Bangladeshi capital of Dhaka.

[Learn more](javascript:)

Photo by Unknown

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/)  

[Apply Now](https://www.startupbangladesh.vc/contact/apply-for-investment/)

-   -   [About](javascript:)
        
    -   [Fund of Funds](javascript:)
        
    -   [Portfolio](javascript:)
        
    -   [Partners](javascript:)
        
    -   [NRB Connect](javascript:)
        
    -   [media](javascript:)
        
    -   [career](javascript:)
        
    -   [contact](javascript:)
        

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

-   [](https://www.startupbangladesh.vc/sbl-young-ambassadors/)
-   [](https://www.startupbangladesh.vc/sbl-nrb-connect/)

NRB Program Contact ![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/caret.svg) 

-   [SBL NRB Connect](https://www.startupbangladesh.vc/sbl-nrb-connect/)
-   [NRB–Startup Bridge](https://www.startupbangladesh.vc/nrb-reconnect-and-rebuild/)
-   [NRB Desk Services](https://www.startupbangladesh.vc/nrb-connect-services/)
-   [SBL Young Ambassador Program](https://www.startupbangladesh.vc/sbl-young-ambassador-program/)
-   [SBL Young Ambassadors](https://www.startupbangladesh.vc/sbl-young-ambassadors/)
-   [NRB Program Contact](https://www.startupbangladesh.vc/nrb-contact/)

## NRB Program Contact

#### **Join the Movement:**

This is more than a program—it’s an invitation to connect, contribute, and lead. Whether you're an investor, entrepreneur, professional, or researcher abroad, your knowledge can help shape the next chapter of Bangladesh.

#### **Contact:**

Name: Md Dewan Adnan Designation: Assistant Vice President - Impact and Ecosystem Cell/WhatsApp: [+8801723551057](tel:+8801723551057) Email: [adnan@startupbangladesh.gov.bd](mailto:adnan@startupbangladeshvc.gov.bd)

© 2025 Startup Bangladesh Limited

\-->