---
source: "Startup Bangladesh Limited"
tier: 1
category: "Government VC"
url: "https://www.startupbangladesh.vc/bods/quazi-anowar-hossain/"
title: "Startup Bangladesh Limited - Md. Mamunur Rashid BhuiyanStartup Bangladesh Limited - Md. Mamunur Rashid Bhuiyan"
scraped_at: "2026-07-02"
---

![](https://www.startupbangladesh.vc/wp-content/uploads/2020/12/Md.-Mamunur-Rashid-Bhuiyan-2.jpg)

Chairman, Board of Directors, Startup Bangladesh Limited and Acting Secretary, ICT Division

## Md. Mamunur Rashid Bhuiyan