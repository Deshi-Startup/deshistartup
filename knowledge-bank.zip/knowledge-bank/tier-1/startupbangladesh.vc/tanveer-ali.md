---
source: "Startup Bangladesh Limited"
tier: 1
category: "Government VC"
url: "https://www.startupbangladesh.vc/bods/tanveer-ali/"
title: "Startup Bangladesh Limited - Tanveer AliStartup Bangladesh Limited - Tanveer Ali"
scraped_at: "2026-07-02"
---

![](https://www.startupbangladesh.vc/wp-content/uploads/2025/02/Tanveer-Ali-2.jpg)

Independent Director, Board of Directors, Startup Bangladesh Limited and Chairman, Constellation Asset Management Company Limited

## Tanveer Ali

Mr. Tanveer Ali is Chairman of Constellation Asset Management. He is among the earliest angel investors and startup ecosystem advocates in Bangladesh. With a portfolio of over 15 investments in Bangladesh and more than 60 globally, he has invested in or supported a wide array of Bangladeshi startups, including Pathao, Chaldal, ShopUp, Barikoi, ShareTrip, and Ridmik.

Originally from Toronto, Canada, Mr. Ali has been based in Bangladesh since 2006. He was an Executive Director at Olympic Industries, the largest biscuit manufacturer in Bangladesh, where he oversaw revenue growth from $7 million in 2007 to $260 million in 2023. He also led the launch of the company’s sustainability program and the implementation of SAP ERP.

Mr. Ali holds a BA in Political Science from the University of Waterloo, Canada, and a joint MBA from IE Business School, Spain, and Brown University, USA. He has previously served on the Executive Council of VCPEAB (Venture Capital & Private Equity Association of Bangladesh), the Executive Committee of BAPLC (Bangladesh Association of Publicly Listed Companies), and the Investment Committee of BD Venture. Mr. Ali is also a trustee of the Mubarak Ali Foundation, a trust focused on impactful changes in art, architecture and education in Bangladesh and through the engagement of the Bangladeshi diaspora.