---
source: "Startup Bangladesh Limited"
tier: 1
category: "Government VC"
url: "https://www.startupbangladesh.vc/"
title: "Startup Bangladesh Limited - a Venture Capital CompanyStartup Bangladesh Limited - a Venture Capital Company"
scraped_at: "2026-07-02"
---

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/) 

[Apply Now](http://www.startupbangladesh.vc/contact/apply-for-investment/)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg) 

#### about

#### Fund of Funds

#### Portfolio

#### Partners

#### NRB Connect

#### media

#### career

#### contact

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/des-close.svg)

#### Bangladesh National Parliament House

Jatiya Sangsad Bhaban or National Parliament House, is the house of the Parliament of Bangladesh, located at Sher-e-Bangla Nagar in the Bangladeshi capital of Dhaka.

[Learn more](javascript:)

Photo by Unknown

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/)  

[Apply Now](https://www.startupbangladesh.vc/contact/apply-for-investment/)

-   -   [About](javascript:)
        
    -   [Fund of Funds](javascript:)
        
    -   [Portfolio](javascript:)
        
    -   [Partners](javascript:)
        
    -   [NRB Connect](javascript:)
        
    -   [media](javascript:)
        
    -   [career](javascript:)
        
    -   [contact](javascript:)
        

![banner image missing](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)   

![](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/Investing-in-Tomorrows-Leaders.svg)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/des-close.svg)

Learn more

![banner image missing](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)   

![](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/connecting-innovators.svg)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/des-close.svg)

Learn more

![banner image missing](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)   

![](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/empowering-bangladesh.svg)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/des-close.svg)

Learn more

![banner image missing](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)   

![](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/Driving-Sustainable.svg)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/des-close.svg)

Learn more

![banner image missing](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)   

![](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/Catalyzing-Global-Success.svg)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/des-close.svg)

Learn more

![banner image missing](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)   

![](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/championing.svg)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/des-close.svg)

Learn more

-   [](https://www.facebook.com/startupbdvc)
-   [](https://www.linkedin.com/company/startup-bangladesh-limited)
-   [](https://www.youtube.com/channel/UC-3D-qfASY1dN0iYzHMlInQ)
-   [](https://x.com/startupbdltdvc)

© 2025 Startup Bangladesh Limited