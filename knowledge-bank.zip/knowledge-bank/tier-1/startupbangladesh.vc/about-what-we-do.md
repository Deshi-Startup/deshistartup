---
source: "Startup Bangladesh Limited"
tier: 1
category: "Government VC"
url: "http://startupbangladesh.vc/about-what-we-do/"
title: "Startup Bangladesh Limited - What We DoStartup Bangladesh Limited - What We Do"
scraped_at: "2026-07-02"
---

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/) 

[Apply Now](http://www.startupbangladesh.vc/contact/apply-for-investment/)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg) 

#### about

#### Fund of Funds

#### Portfolio

#### Partners

#### NRB Connect

#### media

#### career

#### contact

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/des-close.svg)

#### Bangladesh National Parliament House

Jatiya Sangsad Bhaban or National Parliament House, is the house of the Parliament of Bangladesh, located at Sher-e-Bangla Nagar in the Bangladeshi capital of Dhaka.

[Learn more](javascript:)

Photo by Unknown

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/)  

[Apply Now](https://www.startupbangladesh.vc/contact/apply-for-investment/)

-   -   [About](javascript:)
        
    -   [Fund of Funds](javascript:)
        
    -   [Portfolio](javascript:)
        
    -   [Partners](javascript:)
        
    -   [NRB Connect](javascript:)
        
    -   [media](javascript:)
        
    -   [career](javascript:)
        
    -   [contact](javascript:)
        

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

-   [](http://startupbangladesh.vc/about-our-values/)
-   [](https://www.startupbangladesh.vc/about/people-board-of-director/)

What We Do ![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/caret.svg) 

-   [Who We Are](https://www.startupbangladesh.vc/about/about-who-we-are/)
-   [Our Purpose](https://www.startupbangladesh.vc/about/about-our-purpose/)
-   [Our Values](https://www.startupbangladesh.vc/about/about-our-values/)
-   [What We Do](https://www.startupbangladesh.vc/about/about-what-we-do/)
-   [People](https://www.startupbangladesh.vc/about/people-board-of-director/)

## What We Do

We provide investment in the form of equity, convertible debt and/or grants in seed and growth stage startups. We invest through co-investments, as a fund-of-funds, and asset manager and provide other in-kind support to startups and stakeholders.

© 2025 Startup Bangladesh Limited