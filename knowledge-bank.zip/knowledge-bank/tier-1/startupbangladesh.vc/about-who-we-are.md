---
source: "Startup Bangladesh Limited"
tier: 1
category: "Government VC"
url: "http://startupbangladesh.vc/about-who-we-are/"
title: "Startup Bangladesh Limited - Govt. Sponsored Venture Capital BangladeshStartup Bangladesh Limited - Govt. Sponsored Venture Capital Bangladesh"
scraped_at: "2026-07-02"
---

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/) 

[Apply Now](http://www.startupbangladesh.vc/contact/apply-for-investment/)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg) 

#### about

#### Fund of Funds

#### Portfolio

#### Partners

#### NRB Connect

#### media

#### career

#### contact

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/des-close.svg)

#### Bangladesh National Parliament House

Jatiya Sangsad Bhaban or National Parliament House, is the house of the Parliament of Bangladesh, located at Sher-e-Bangla Nagar in the Bangladeshi capital of Dhaka.

[Learn more](javascript:)

Photo by Unknown

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/)  

[Apply Now](https://www.startupbangladesh.vc/contact/apply-for-investment/)

-   -   [About](javascript:)
        
    -   [Fund of Funds](javascript:)
        
    -   [Portfolio](javascript:)
        
    -   [Partners](javascript:)
        
    -   [NRB Connect](javascript:)
        
    -   [media](javascript:)
        
    -   [career](javascript:)
        
    -   [contact](javascript:)
        

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

-   [](https://www.startupbangladesh.vc/about/visionarie/)
-   [](http://startupbangladesh.vc/about-our-purpose/)

Who We Are ![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/caret.svg) 

-   [Who We Are](https://www.startupbangladesh.vc/about/about-who-we-are/)
-   [Our Purpose](https://www.startupbangladesh.vc/about/about-our-purpose/)
-   [Our Values](https://www.startupbangladesh.vc/about/about-our-values/)
-   [What We Do](https://www.startupbangladesh.vc/about/about-what-we-do/)
-   [People](https://www.startupbangladesh.vc/about/people-board-of-director/)

## Who We Are

Startup Bangladesh Limited is the flagship venture capital fund of ICT Division. It's the first and only venture capital fund sponsored by the government of the people’s republic of Bangladesh started its journey on March 2020 with an allocated capital of BDT 500 crores.  
  
The Fund will provide investment in the form of equity, convertible debt and/or grants in pre-seed, seed and growth stage startups. It would invest thru co-investments, as a fund-of-funds and asset manager and provide other in-kind support to startups and stakeholders.  
  
The Fund will support technology-based innovations to create new employment opportunities, promote under-represented tech groups, foster entrepreneurship culture and Bring transformational changes to lives of millions.  
  
Bangladesh is one of the youngest countries in the world, with more than half of its population being under 25. Startups have complemented GoB efforts in building the Smart infrastructure in: transportation, logistics, essential goods and services, payments, food & agriculture, entertainment, health and education.  
  
As part of the ICT Division's innovative steps to address existing gaps and constraints towards implementing the ambitious global framework of the SDGs, it is taking numerous initiatives to develop the technology infrastructure of the country to create universal and affordable access to digital devices and the Internet in an effort to develop the digital literacy of the people. Startups can play a critical role in addressing the market needs and this will serve as the basis to have far-reaching consequences in developing and upgrading the education and health systems and making them accessible to all. The crucial and essential solutions provided by startups can play a significant role in the Nation’s achieving SDG Goal 2030 and beyond.  
  
Riding on solid fundamentals the startup ecosystem is coming of age – where 1.2 million jobs have been created, more than 500,000 micro entrepreneurs have been supported and USD 940 million+ of foreign direct investments have been invested in Startups over the last 13 years. Startups have played a pivotal role in driving innovation, propelling the journey towards better Bangladesh. We do believe that as a country we are entering the “high seas” with a rising sun lighting its Smart transformation.  
  
  
  

© 2025 Startup Bangladesh Limited