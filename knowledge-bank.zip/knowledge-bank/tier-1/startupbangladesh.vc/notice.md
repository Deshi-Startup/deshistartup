---
source: "Startup Bangladesh Limited"
tier: 1
category: "Government VC"
url: "https://www.startupbangladesh.vc/media/notice/"
title: "Startup Bangladesh Limited - NoticeStartup Bangladesh Limited - Notice"
scraped_at: "2026-07-02"
---

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/) 

[Apply Now](http://www.startupbangladesh.vc/contact/apply-for-investment/)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg) 

#### about

#### Fund of Funds

#### Portfolio

#### Partners

#### NRB Connect

#### media

#### career

#### contact

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/des-close.svg)

#### Bangladesh National Parliament House

Jatiya Sangsad Bhaban or National Parliament House, is the house of the Parliament of Bangladesh, located at Sher-e-Bangla Nagar in the Bangladeshi capital of Dhaka.

[Learn more](javascript:)

Photo by Unknown

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/)  

[Apply Now](https://www.startupbangladesh.vc/contact/apply-for-investment/)

-   -   [About](javascript:)
        
    -   [Fund of Funds](javascript:)
        
    -   [Portfolio](javascript:)
        
    -   [Partners](javascript:)
        
    -   [NRB Connect](javascript:)
        
    -   [media](javascript:)
        
    -   [career](javascript:)
        
    -   [contact](javascript:)
        

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

-   [](https://www.startupbangladesh.vc/media/media_events)
-   [](https://www.startupbangladesh.vc/media/media_resources)

Notice ![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/caret.svg) 

-   [Newsroom](https://www.startupbangladesh.vc/media/news/)
-   [Gallery](https://www.startupbangladesh.vc/media/gallery/)
-   [Events](https://www.startupbangladesh.vc/media/media_events/)
-   [Notice](https://www.startupbangladesh.vc/media/notice/)
-   [Newsletter](https://www.startupbangladesh.vc/media/media_resources/)
-   [Latest Reports](https://www.startupbangladesh.vc/media/latest-reports/)

## Notice

[](<       https://www.startupbangladesh.vc/notice/tor-pool-car-driver/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### ToR – Driver (Contractual)

[](<       https://www.startupbangladesh.vc/notice/noc-rashel-mia/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### NOC – Rashel Mia

[](<       https://www.startupbangladesh.vc/notice/analyst-impact-ecosystem/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Analyst – Impact & Ecosystem

[](<       https://www.startupbangladesh.vc/notice/chief-investment-officer-cio/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Chief Investment Officer (CIO)

[](<       https://www.startupbangladesh.vc/notice/head-of-portfolio-investment/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Head of Portfolio Investment Job Circular Startup Bangladesh Limited

[](<       https://www.startupbangladesh.vc/notice/managing-director-job-circular_startup-bangladesh-limited/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Managing Director Job Circular\_Startup Bangladesh Limited

[](<       https://www.startupbangladesh.vc/notice/tender_event-management-for-organizing-bangladesh-startup-connect/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Tender\_Event Management for Organizing Bangladesh Startup Connect

[](<       https://www.startupbangladesh.vc/notice/rfq_quotation_notice_website-design-and-development-for-startup-bangladesh-limited/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### RFQ\_Quotation\_Notice\_Website Design and Development for Startup Bangladesh Limited

[](<       https://www.startupbangladesh.vc/notice/annual-tax-return-services-for-startup-bangladesh-limited/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### RFQ\_Annual Tax return services for Startup Bangladesh Limited

[](<       https://www.startupbangladesh.vc/notice/rfq_financial-due-diligence-of-startup-company-for-investment-of-startup-bangladesh/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### RFQ\_Financial Due Diligence of startup company for investment of Startup Bangladesh

[](<       https://www.startupbangladesh.vc/notice/annual-tax-return-service-for-startup-bangladesh-limited/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Annual Tax return service for Startup Bangladesh Limited

[](<       https://www.startupbangladesh.vc/notice/startup-carnival_tender-corrigendum_sbl_24-dec-2024/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Startup Carnival\_Tender Corrigendum\_SBL\_24 Dec 2024

[](<       https://www.startupbangladesh.vc/notice/tender-event-management-for-organizing-startup-carnival/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Tender – Event Management for Organizing Startup Carnival

[](<       https://www.startupbangladesh.vc/notice/intern-application-deadline-15-10-2024/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Intern (Application Deadline: 15-10-2024)

[](<       https://www.startupbangladesh.vc/notice/law-firm-to-support-sbl-for-its-legal-activities-related-to-invest-in-startups/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### EOI: Law Firm to support SBL for its legal activities related to invest in startups

[](<       https://www.startupbangladesh.vc/notice/executive-assistant-to-md-application-deadline-25-05-2024/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Executive Assistant to MD – Application Deadline: 25-05-2024

[](<       https://www.startupbangladesh.vc/notice/investment-executive-application-deadline-09-05-2024/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Investment Executive – Application Deadline: 09-05-2024

[](<       https://www.startupbangladesh.vc/notice/admin-executive-application-deadline-09-05-2024/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### ADMIN EXECUTIVE – Application Deadline: 09-05-2024

[](<       https://www.startupbangladesh.vc/notice/noc-a-b-m-monirul-islam/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### NOC – A.B.M. Monirul Islam

[](<       https://www.startupbangladesh.vc/notice/position-specialist-accounts-audit-contractual-application-deadline-18-01-2024/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Position: Specialist – Accounts & Audit (Contractual), Application Deadline: 18-01-2024

[](<       https://www.startupbangladesh.vc/notice/rfq-tax-return-services-for-startup-bangladesh-limited/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### RFQ – Tax return services for Startup Bangladesh Limited

[](<       https://www.startupbangladesh.vc/notice/rfq-stationeries-and-printing-items-for-startup-bangladesh-limited/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### RFQ – Stationeries and Printing Items for Startup Bangladesh Limited

[](<       https://www.startupbangladesh.vc/notice/startup-bangladesh-limited-office-construction-tender/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Startup Bangladesh Limited Office Construction Tender

[](<       https://www.startupbangladesh.vc/notice/position-operations-accountant-contractual-application-deadline-24-09-2023/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Position: OPERATIONS ACCOUNTANT (CONTRACTUAL), Application Deadline: 24-09-2023

[](<       https://www.startupbangladesh.vc/notice/position-intern-investment-2-application-deadline-24-08-2023/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Position: Intern-Investment (2) (Application Deadline: 24-08-2023)

[](<       https://www.startupbangladesh.vc/notice/rfq-notice-it-and-electronics-equipment-for-startup-bangladesh-limited/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### RFQ Notice – IT and Electronics Equipment for Startup Bangladesh Limited

[](<       https://www.startupbangladesh.vc/notice/event-management-tender-notice-for-organising-bangladesh-startup-summit-for-startup-bangladesh-limited/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Event Management Tender notice for organising Bangladesh Startup Summit for Startup Bangladesh Limited

[](<       https://www.startupbangladesh.vc/notice/supply-tender-notice-for-organising-bangladesh-startup-summit-for-startup-bangladesh-limited/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Supply Tender notice for organising Bangladesh Startup Summit for Startup Bangladesh Limited

[](<       https://www.startupbangladesh.vc/notice/rfq-promo-video-production-for-bangladesh-startup-summit-2023/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### RFQ – Promo Video Production for Bangladesh Startup Summit 2023

[](<       https://www.startupbangladesh.vc/notice/rfq-notice-bangladesh-startup-summit-2023-event-support-and-vendor-coordination-for-startup-bangladesh-limited/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### RFQ Notice – Bangladesh Startup Summit 2023 Event Support and Vendor Coordination for Startup Bangladesh Limited

[](<       https://www.startupbangladesh.vc/notice/rfq-vat-tax-return-services-for-startup-bangladesh-limited/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### RFQ – VAT-Tax return services for Startup Bangladesh Limited

[](<       https://www.startupbangladesh.vc/notice/position-intern-finance-accounts-application-deadline-16-02-2023/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Position: INTERN-FINANCE & ACCOUNTS (Application Deadline: 16/02/2023)

[](<       https://www.startupbangladesh.vc/notice/rfq-quotation-notice-and-document-vat-tax-return-services-for-startup-bangladesh-limited/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### RFQ Quotation Notice and Document – VAT-Tax return services for Startup Bangladesh Limited

[](<       https://www.startupbangladesh.vc/notice/position-intern-marketing-01-application-deadline-31-07-2022/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Position: Intern – Marketing (01) (Application Deadline: 31/07/2022)

[](<       https://www.startupbangladesh.vc/notice/position-intern-investment-02-application-deadline-31-07-2022/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### POSITION: INTERN – INVESTMENT (02) (Application Deadline: 31/07/2022 )

[](<       https://www.startupbangladesh.vc/notice/investment-manager-application-deadline-13-07-2022/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Investment Manager (Application Deadline: 13-07-2022)

[](<       https://www.startupbangladesh.vc/notice/rfq-document-supply-and-implementation-of-accounting-software/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### RFQ Document – Supply and Implementation of Accounting Software

[](<       https://www.startupbangladesh.vc/notice/supply-and-implementation-of-accounting-software/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### RFQ – Supply and Implementation of Accounting Software

[](<       https://www.startupbangladesh.vc/notice/investment-analyst-application-deadline-15-03-2022/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### INVESTMENT ANALYST (Application Deadline: 15-03-2022)

[](<       https://www.startupbangladesh.vc/notice/rfq-shotoborshe-shoto-asha-2nd-investment-announcement-and-companys-2nd-year-celebration-event/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### RFQ-Shotoborshe Shoto Asha 2nd Investment Announcement and Company’s 2nd year Celebration Event

[](<       https://www.startupbangladesh.vc/notice/rfq-document-shotoborshe-shoto-asha-2nd-investment-announcement-and-companys-2nd-year-celebration-event/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### RFQ Document-Shotoborshe Shoto Asha 2nd Investment Announcement and Company’s 2nd year Celebration Event

[](<       https://www.startupbangladesh.vc/notice/procurement-of-it-equipment-for-startup-bangladesh-limited/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Tender – Procurement of IT Equipment for Startup Bangladesh Limited

[](<       https://www.startupbangladesh.vc/notice/network-equipment-rfq-notice/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Network Infrastructure RFQ Notice

[](<       https://www.startupbangladesh.vc/notice/network-infrastructure-rfq-document/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Network Infrastructure RFQ Document

[](<       https://www.startupbangladesh.vc/notice/legal-and-regulatory-due-diligence-tender/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Legal and Regulatory Due Diligence Tender

[](<       https://www.startupbangladesh.vc/notice/rfq-document_vat-tax-return-services-for-startup-bangladesh-limited/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### RFQ Document\_VAT-TAX Return Services for Startup Bangladesh Limited

[](<       https://www.startupbangladesh.vc/notice/quotation-notice-vat-tax-return-services-for-startup-bangladesh-limited/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Quotation Notice\_VAT-TAX Return Services for Startup Bangladesh Limited

[](<       https://www.startupbangladesh.vc/notice/managing-director-application-deadline-15-12-2021/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### MANAGING DIRECTOR (Application Deadline: 15-12-2021)

[](<       https://www.startupbangladesh.vc/notice/receptionist-application-deadline-27-08-2021/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Receptionist (Application Deadline: 27/08/2021)

[](<       https://www.startupbangladesh.vc/notice/executive-assistant-to-management-team-application-deadline-27-08-2021/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Executive Assistant to Management Team (Application Deadline: 27/08/2021)

[](<       https://www.startupbangladesh.vc/notice/head-of-governance-and-external-affairs-application-deadline-19-08-2021/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Head of Governance and External Affairs (Application Deadline: 19/08/2021)

[](<       https://www.startupbangladesh.vc/notice/rfq-document-network-infrastructure-of-startup-bangladesh-limited/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Network Infrastructure of Startup Bangladesh Limited – RFQ Document

[](<       https://www.startupbangladesh.vc/notice/quotation-notice-for-network-infrastructure-of-startup-bangladesh-limited/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Network Infrastructure of Startup Bangladesh Limited – Quotation Notice

[](<       https://www.startupbangladesh.vc/notice/recruitment-notice-executive-assistant-to-management-team-the-receptionist/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Recruitment Notice for “Executive Assistant to Management Team” & “Receptionist”

[](<       https://www.startupbangladesh.vc/notice/it-and-electronics-equipment-tender/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### IT and Electronics Equipment Tender

[](<       https://www.startupbangladesh.vc/notice/head-of-portfolio-investment-application-deadline-03-06-2021/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Head of Portfolio Investment (Application Deadline: 03/06/2021)

[](<       https://www.startupbangladesh.vc/notice/perspective-plan-of-bangladesh-2021-2041/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### PERSPECTIVE PLAN OF BANGLADESH 2021-2041

[](<       https://www.startupbangladesh.vc/notice/digital-associate-application-deadline-25-05-2021/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Digital Associate (Application Deadline: 25/05/2021)

[](<       https://www.startupbangladesh.vc/notice/statutory-audit-rfq-document/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Statutory Audit RFQ Document

[](<       https://www.startupbangladesh.vc/notice/rfq-notice-for-statutory-audit/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### RFQ Notice for Statutory Audit

© 2025 Startup Bangladesh Limited