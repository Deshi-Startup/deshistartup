---
source: "Startup Bangladesh Limited"
tier: 1
category: "Government VC"
url: "https://www.startupbangladesh.vc/bods/dilruba-shaheena/"
title: "Startup Bangladesh Limited - Dilruba ShaheenaStartup Bangladesh Limited - Dilruba Shaheena"
scraped_at: "2026-07-02"
---

![](https://www.startupbangladesh.vc/wp-content/uploads/2026/06/Dilruba-Shaheena-2.jpg)

Member, Board of Directors, Startup Bangladesh Limited and Additional Secretary, Finance Division, Ministry of Finance

## Dilruba Shaheena