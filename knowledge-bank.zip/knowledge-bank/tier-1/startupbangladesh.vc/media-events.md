---
source: "Startup Bangladesh Limited"
tier: 1
category: "Government VC"
url: "https://www.startupbangladesh.vc/media/media_events/"
title: "Startup Bangladesh Limited - EventsStartup Bangladesh Limited - Events"
scraped_at: "2026-07-02"
---

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/) 

[Apply Now](http://www.startupbangladesh.vc/contact/apply-for-investment/)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg) 

#### about

#### Fund of Funds

#### Portfolio

#### Partners

#### NRB Connect

#### media

#### career

#### contact

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/des-close.svg)

#### Bangladesh National Parliament House

Jatiya Sangsad Bhaban or National Parliament House, is the house of the Parliament of Bangladesh, located at Sher-e-Bangla Nagar in the Bangladeshi capital of Dhaka.

[Learn more](javascript:)

Photo by Unknown

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/)  

[Apply Now](https://www.startupbangladesh.vc/contact/apply-for-investment/)

-   -   [About](javascript:)
        
    -   [Fund of Funds](javascript:)
        
    -   [Portfolio](javascript:)
        
    -   [Partners](javascript:)
        
    -   [NRB Connect](javascript:)
        
    -   [media](javascript:)
        
    -   [career](javascript:)
        
    -   [contact](javascript:)
        

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

-   [](https://www.startupbangladesh.vc/media/media-photo)
-   [](https://www.startupbangladesh.vc/media/notice)

Events ![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/caret.svg) 

-   [Newsroom](https://www.startupbangladesh.vc/media/news/)
-   [Gallery](https://www.startupbangladesh.vc/media/gallery/)
-   [Events](https://www.startupbangladesh.vc/media/media_events/)
-   [Notice](https://www.startupbangladesh.vc/media/notice/)
-   [Newsletter](https://www.startupbangladesh.vc/media/media_resources/)
-   [Latest Reports](https://www.startupbangladesh.vc/media/latest-reports/)

## Events

[](<       https://www.startupbangladesh.vc/events/bangladeshs-startup-ecosystem-showcased-at-expand-north-star-2024-in-dubai/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Bangladesh’s startup ecosystem showcased at Expand North Star 2024 in Dubai

[](<       https://www.startupbangladesh.vc/events/bangladeshi-startups-joined-at-the-largest-tech-show-in-the-world-gitex-global-its-startup-focused-event-the-expand-north-star/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Bangladeshi Startups joined at The Largest Tech Show in the world, GITEX Global & it’s Startup Focused event The Expand North Star

[](<       https://www.startupbangladesh.vc/events/bringing-bangladeshi-tech-startups-to-the-public-market/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Bringing Bangladeshi Tech Startups to the Public Market

[](<       https://www.startupbangladesh.vc/events/startup-bangladesh-limited-sbl-has-entered-into-a-strategic-partnership-with-smart-bangladesh-accelerator-sba/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Startup Bangladesh Limited (SBL) has entered into a strategic partnership with Smart Bangladesh Accelerator (SBA)

[](<       https://www.startupbangladesh.vc/events/startup-bangladesh-organized-its-policy-workshop-on-national-startup-policy/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Startup Bangladesh organized its Policy workshop on National Startup Policy

[](<       https://www.startupbangladesh.vc/events/startup-bangladesh-limited-signs-mou-with-visa/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Startup Bangladesh Limited signs MoU with Visa

[](<       https://www.startupbangladesh.vc/events/startup-bangladesh-and-edge-project-join-hands-to-develop-sustainable-entrepreneurs-for-the-nation/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Startup Bangladesh and EDGE Project join hands to develop sustainable entrepreneurs for the nation.

[](<       https://www.startupbangladesh.vc/events/the-2nd-annual-general-meeting-of-startup-bangladesh-limited-successfully-closed-on-7th-december-2022/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### The 2nd Annual General Meeting of Startup Bangladesh Limited successfully closed on 7th December, 2022

[](<       https://www.startupbangladesh.vc/events/startup-bangladesh-limited-signs-mou-with-lightcastle-partners/>)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

#### Startup Bangladesh Limited signs MOU with LightCastle Partners

© 2025 Startup Bangladesh Limited