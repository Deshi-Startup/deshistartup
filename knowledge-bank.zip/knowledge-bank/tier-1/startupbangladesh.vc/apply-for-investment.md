---
source: "Startup Bangladesh Limited"
tier: 1
category: "Government VC"
url: "http://www.startupbangladesh.vc/contact/apply-for-investment/"
title: "Startup Bangladesh Limited - Application for InvestmentStartup Bangladesh Limited - Application for Investment"
scraped_at: "2026-07-02"
---

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/) 

[Apply Now](http://www.startupbangladesh.vc/contact/apply-for-investment/)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg) 

#### about

#### Fund of Funds

#### Portfolio

#### Partners

#### NRB Connect

#### media

#### career

#### contact

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/des-close.svg)

#### Bangladesh National Parliament House

Jatiya Sangsad Bhaban or National Parliament House, is the house of the Parliament of Bangladesh, located at Sher-e-Bangla Nagar in the Bangladeshi capital of Dhaka.

[Learn more](javascript:)

Photo by Unknown

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/)  

[Apply Now](https://www.startupbangladesh.vc/contact/apply-for-investment/)

-   -   [About](javascript:)
        
    -   [Fund of Funds](javascript:)
        
    -   [Portfolio](javascript:)
        
    -   [Partners](javascript:)
        
    -   [NRB Connect](javascript:)
        
    -   [media](javascript:)
        
    -   [career](javascript:)
        
    -   [contact](javascript:)
        

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

-   [](https://www.startupbangladesh.vc/contact/faqs/)
-   [](https://www.startupbangladesh.vc/contact/contact-info/)

Application for Investment ![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/caret.svg) 

-   [Application for Investment](https://www.startupbangladesh.vc/contact/apply-for-investment/)
-   [Information](https://www.startupbangladesh.vc/contact/contact-info/)
-   [Enquiries](https://www.startupbangladesh.vc/contact/contact-enquiries/)
-   [FAQ](https://www.startupbangladesh.vc/contact/faqs/)

## Application for Investment

Startup Bangladesh Limited, founded in March 2020, is a first of its kind venture capital company in Bangladesh under the ICT Division, Government of the People’s Republic of Bangladesh.

The company will aspire to invest in startups and enterprises registered in Bangladesh with high growth potential and/or significant social impact who has a Minimal Viable Product (MVP), Demonstrated Track Record of Growing Customer Base & Revenue etc. The investees will be seed and growth stage startups and impact enterprises.

For further queries regarding Investment please visit our FAQ section.

1\. COMPANY

Company Name:  
Describe the Company Products or Services (400 Characters):  
Company Address:

2\. FOUNDERS AND CONTACT

Founder Name:  
Founder Email:  
Founder Phone Number:

Co-Founder Name (if any):  
Co-Founder Email (if any):  
Co-Founder Phone Number (if any):  
Founder(s)/Co-founder(s) CV Link:  
Founder(s)/Co-founder(s) any other Business Involvement:—Please choose an option—YesNo

Please mention company name, designation etc.:

Any loans obtained by the Founder(s)/Co-founder(s) and the Business:—Please choose an option—YesNo

Please mention loan details (Provide Bank name, total loan amount, outstanding balance, and overdue amount):

Founder(s)/Co-founder(s) act as guarantors for any loans:—Please choose an option—YesNo

3\. TEAM

Number of Full Time Employees:  
Number of Part Time Employees:  
Tech Team Size:

4\. BUSINESS SECTOR AND STAGE

Category of the Business:  
—Please choose an option—FintechEdtechAgritechSAASArtificial Intelligence/Machine LearningLogistic & TravelFoodtechMobility/LogisticsHealthEntertainment and LifestyleOthers

Please describe the Category

Stage of the Business:  
—Please choose an option—Seed (Have a MVP, tested in the market, have a customer base)Growth (Have business in commercial operation with solid traction, existing customer and recurring revenue)  
Revenue (BDT):  
GMV (Gross Merchandise Value) (BDT):  
Number of B2C client(s) (if any):  
Number of B2B client(s) (if any):

5\. COMPANY STATUS

Formation of the Company:  
—Please choose an option—Private LimitedPartnershipSole ProprietorshipOthers

Please describe the Company Formation Type

Date of Incorporation:  
Number of Existing Investor(s) (if any):  
Amount of Previously Raised Investment (BDT) (if any):

6\. PITCH DECK LINK:  

7\. WEBSITE LINK:  

8\. SOCIAL MEDIA LINK (if any)

Facebook:  
Twitter:  
Youtube:

9\. STARTUP VIDEO LINK (if any):  

Confidentiality Note: All Information Provided to Startup Bangladesh Ltd. Will Remain Confidential

© 2025 Startup Bangladesh Limited