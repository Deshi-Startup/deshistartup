---
source: "Startup Bangladesh Limited"
tier: 1
category: "Government VC"
url: "https://www.startupbangladesh.vc/eligibility-criteria-for-fund-managers/"
title: "Startup Bangladesh Limited - Eligibility Criteria for Fund ManagersStartup Bangladesh Limited - Eligibility Criteria for Fund Managers"
scraped_at: "2026-07-02"
---

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/) 

[Apply Now](http://www.startupbangladesh.vc/contact/apply-for-investment/)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg) 

#### about

#### Fund of Funds

#### Portfolio

#### Partners

#### NRB Connect

#### media

#### career

#### contact

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/des-close.svg)

#### Bangladesh National Parliament House

Jatiya Sangsad Bhaban or National Parliament House, is the house of the Parliament of Bangladesh, located at Sher-e-Bangla Nagar in the Bangladeshi capital of Dhaka.

[Learn more](javascript:)

Photo by Unknown

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/)  

[Apply Now](https://www.startupbangladesh.vc/contact/apply-for-investment/)

-   -   [About](javascript:)
        
    -   [Fund of Funds](javascript:)
        
    -   [Portfolio](javascript:)
        
    -   [Partners](javascript:)
        
    -   [NRB Connect](javascript:)
        
    -   [media](javascript:)
        
    -   [career](javascript:)
        
    -   [contact](javascript:)
        

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

-   [](https://www.startupbangladesh.vc/fund-of-funds-overview/)
-   [](https://www.startupbangladesh.vc/apply-for-fund-of-funds/)

Eligibility Criteria for Fund Managers ![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/caret.svg) 

-   [Fund of Funds Overview](https://www.startupbangladesh.vc/fund-of-funds-overview/)
-   [Eligibility Criteria for Fund Managers](https://www.startupbangladesh.vc/eligibility-criteria-for-fund-managers/)
-   [Apply for Fund of Funds](https://www.startupbangladesh.vc/apply-for-fund-of-funds/)

## Eligibility Criteria for Fund Managers

To ensure a focus on high-quality VCs, assessment will only be conducted for those VCs that meet the following eligibility criteria:

### Size of Venture Capital Fund Managers

-   Local VCs must have a minimum AUM of BDT 50 Cr (AUM waiver applies for emerging fund managers).
-   Global VCs must have a minimum AUM of USD 50 Mn.

### Alignment of Fund Investment Strategy

-   The VC's investment strategy must align with our investment thesis, including focus sectors, geographies, and impact areas.

### Presence in Bangladesh/Developing Markets

-   The VC must have invested in startups in Bangladesh or other emerging economies.

### Fundraising Capability and Allocation Strategy

-   Our FoF’s investment must not exceed 49.99% of the partnership fund size.
-   The VC must earmark an additional amount at least equal to what is raised from our FoF (1:1 matching) towards BD.

### Reputation and Credibility

-   The VC must not have faced fraud, regulatory penalties, or unethical behavior (e.g., MAS notifications on enforcement actions in Singapore can be referred).
-   The VC must have a proven 3+ year fund management track record in any country, with an IRR of over 15% from previous funds.
-   An Emerging Fund Manager must have prior experience in Venture Capital, Private Equity, or related fields.

### Relevant Experience & Expertise of the Team

-   Key people (CEO, CIO, & Partners) must have a minimum of 7 years of relevant experience in fund management.
-   The VC must have a team with relevant experience in PE, VC, Entrepreneurship, Banking, M&A, or Capital Markets.

### Legal and Regulatory Compliance

-   The VC must be registered with a recognized regulatory body in its respective jurisdiction (e.g., BSEC in Bangladesh, MAS in Singapore).

  
  

**For More Information:**  
Email: rashel@startupbangladeshvc.gov.bd  

© 2025 Startup Bangladesh Limited

\-->