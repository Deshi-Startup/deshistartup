---
source: "Startup Bangladesh Limited"
tier: 1
category: "Government VC"
url: "https://www.startupbangladesh.vc/bods/nurul-hai/"
title: "Startup Bangladesh Limited - Nurul HaiStartup Bangladesh Limited - Nurul Hai"
scraped_at: "2026-07-02"
---

![](https://www.startupbangladesh.vc/wp-content/uploads/2021/03/Nurul-Hai-2.jpg)

Member, Board of Directors and Managing Director, Startup Bangladesh Limited

## Nurul Hai

Mr. Nurul Hai serves as the Managing Director overseeing all business aspects of Startup Bangladesh Limited (SBL). He brings over 16 years of experience in venture investing, impact fund management, company building, value creation, investment banking and impact research. His career spans South Asian markets with additional engagements in East Africa and the Caribbean, where he has helped founders turn resilient business models into scalable and profitable outcomes while protecting investor downside through strict monitoring, significant value addition, disciplined governance and appropriate exits. He believes that thriving startup ecosystems are built when public ambition effectively meets private execution, and he has made a practice of translating that belief into investable pipelines, clear decision frameworks and actionable results. Before joining SBL, he was the Vice President at SEAF, a global impact fund management firm based in Washington D.C., focusing on global impact investing and development impact work. In Bangladesh, he led SEAF’s Bangladesh Ventures Fund and completed several exits from portfolio companies as well as an Agri-ventures fund.

Mr. Hai’s earlier leadership track includes building the research and alternative asset management teams at LankaBangla AMC, where he formed teams and managed public-markets fund with a strong process discipline. As part of his earlier advisory roles, he steered US$2–40 million transactions across various verticals including consumer, agri-ventures, technology and industrials. Foundational roles at IL Capital, BD Capital, BRAC Bank, and Asian Tiger Capital Partners sharpened his end-to-end skill set from origination and valuation to documentation, monitoring, and exit execution.

Mr. Hai’s network spans DFIs, VCs, PEs, Financial Institutions, and other Institutional Investors, enabling fundraising and market entry for companies while maintaining strong standards on governance and ESG including gender-lens investing and climate actions. He has executed several types of exits including IPO, trade sale, settlement, self-liquidation, etc. He contributes to the ecosystem as a pitch judge at Unicorn Battles, an APAC Mentor & Strategic Advisor to 2X Ignite (part of 2X Global), and a Board Member of the Global Centre for Risk and Innovation – platforms he uses to coach operators and raise the bar for investment readiness. He holds an EMBA (Finance) from IBA and a BBA (Finance) from the University of Dhaka.

_His vision for Startup Bangladesh Limited is to pair speed with stewardship: disciplined pacing and concentration, transparent monitoring, and global partnerships that open new markets for Bangladesh’s founders and investors. The goal is a pipeline where outcomes are shared – founders grow with clarity, and investors are rewarded through clean governance and timely profitable exits._

Email: nhai@startupbangladesh.gov.bd