---
source: "Startup Bangladesh Limited"
tier: 1
category: "Government VC"
url: "https://www.startupbangladesh.vc/bods/hafiz-ahmed-chowdhury/"
title: "Startup Bangladesh Limited - Dr. Hafiz Ahmed ChowdhuryStartup Bangladesh Limited - Dr. Hafiz Ahmed Chowdhury"
scraped_at: "2026-07-02"
---

![](https://www.startupbangladesh.vc/wp-content/uploads/2023/05/Hafiz-Ahmed-Chowdhury.jpg)

Member, Board of Directors, Startup Bangladesh Limited and Secretary, Legislative and Parliamentary Affairs Division, Ministry of Law, Justice and Parliamentary Affairs

## Dr. Hafiz Ahmed Chowdhury

Mr. Hafiz Ahmed Chowdhury, at present, Secretary, Legislative and Parliamentary Affairs Division, Ministry of Law, Justice and Parliamentary Affairs

He passed SSC from Nawabpur Government High School, Dhaka; HSC from Dhaka College and LL.B (Honors) and LL.M from University of Dhaka successfully. He was also Awarded M.Phil.  from Islamic University, Kushtia and PhD from University of Dhaka. He was enrolled as an Advocate of the District Court and the High Court Division of the Supreme Court of Bangladesh on 16 August, 1994 and 07 March, 1996 respectively. He practiced as an Advocate from 16 August, 1994 to 19 January, 2000 in the District Courts of Bangladesh and the High Court Division of the Supreme Court of Bangladesh respectively.

Later on 20 January, 2000 he joined in the Ministry of Law, Justice and Parliamentary Affairs as an Assistant Secretary (Drafting) and started his career in the profession of Legislative Drafting. He was later promoted to Senior Assistant Secretary (Drafting), Deputy Secretary (Drafting) and Joint Secretary (Drafting) in the Legislative and Parliamentary Affairs Division of Ministry of Law, Justice & Parliamentary Affairs. He has been serving as an Additional Secretary (Drafting) (Current Charge) in the Legislative & Parliamentary Affairs Division of the same Ministry from June 27, 2021 till date.

While in service, he has received various short-term and long-term trainings at home and abroad. He has traveled to UK, Canada, Singapore, India, Nepal, Italy, Switzerland, Sweden, South Korea, Malaysia, Japan, France, Finland, Philippines, Thailand, China, Hong Kong, Qatar, United Arab Emirates, Saudi Arabia and Germany.

In his long service career Mr. Hafiz has participated actively in different meetings, workshops, seminars; regional, bi-lateral and multilateral meetings on different negotiations in the country and abroad.

He attended as a member of delegation of 70th Session of the Committee on the Child Rights held in Geneva, Switzerland on 15-16 September, 2015 for Consideration of CRC reports submitted by Bangladesh (5th Periodic reports).  He also attended as a member of delegation of 51st Session of the Committee on the Child Rights held in Geneva, Switzerland on June 3, 2009 for Consideration of CRC reports submitted by Bangladesh (3rd and 4th Periodic reports).

In his personal life he is married and blessed with two daughters. His vision is to serve the nation.  His favourite hobby is reading books and papers.