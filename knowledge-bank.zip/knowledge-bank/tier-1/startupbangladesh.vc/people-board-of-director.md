---
source: "Startup Bangladesh Limited"
tier: 1
category: "Government VC"
url: "https://www.startupbangladesh.vc/about/people-board-of-director/"
title: "Startup Bangladesh Limited - Board of DirectorStartup Bangladesh Limited - Board of Director"
scraped_at: "2026-07-02"
---

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/) 

[Apply Now](http://www.startupbangladesh.vc/contact/apply-for-investment/)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg) 

#### about

#### Fund of Funds

#### Portfolio

#### Partners

#### NRB Connect

#### media

#### career

#### contact

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/des-close.svg)

#### Bangladesh National Parliament House

Jatiya Sangsad Bhaban or National Parliament House, is the house of the Parliament of Bangladesh, located at Sher-e-Bangla Nagar in the Bangladeshi capital of Dhaka.

[Learn more](javascript:)

Photo by Unknown

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/)  

[Apply Now](https://www.startupbangladesh.vc/contact/apply-for-investment/)

-   -   [About](javascript:)
        
    -   [Fund of Funds](javascript:)
        
    -   [Portfolio](javascript:)
        
    -   [Partners](javascript:)
        
    -   [NRB Connect](javascript:)
        
    -   [media](javascript:)
        
    -   [career](javascript:)
        
    -   [contact](javascript:)
        

![](https://www.startupbangladesh.vc/wp-content/uploads/2025/01/SBL-CL.jpg)

## TOGETHER,  
WE HELP YOU  
INNOVATE FASTER.

-   [](https://www.startupbangladesh.vc/about/about-people/)
-   [](https://www.startupbangladesh.vc/about/about-people/)

Board of Director ![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/caret.svg) 

-   [Board of Director](https://www.startupbangladesh.vc/about/people-board-of-director/)
-   [Team](https://www.startupbangladesh.vc/about/about-people/)

![](https://www.startupbangladesh.vc/wp-content/uploads/2020/12/Md.-Mamunur-Rashid-Bhuiyan-1.jpg) 

#### Md. Mamunur Rashid Bhuiyan

Chairman, Board of Directors, Startup Bangladesh Limited and Acting Secretary, ICT Division

[Explore Profile](https://www.startupbangladesh.vc/bods/quazi-anowar-hossain/)

![](https://www.startupbangladesh.vc/wp-content/uploads/2023/05/Hafiz-Ahmed-chowdhury-1.jpg) 

#### Dr. Hafiz Ahmed Chowdhury

Member, Board of Directors, Startup Bangladesh Limited and Secretary, Legislative and Parliamentary Affairs Division, Ministry of Law, Justice and Parliamentary Affairs

[Explore Profile](https://www.startupbangladesh.vc/bods/hafiz-ahmed-chowdhury/)

![](https://www.startupbangladesh.vc/wp-content/uploads/2026/06/Mohammed-Humayun-Kabir-2.jpg) 

#### Mohammed Humayun Kabir

Member, Board of Directors, Startup Bangladesh Limited and Additional Secretary, Cabinet Division

[Explore Profile](https://www.startupbangladesh.vc/bods/mohammed-humayun-kabir/)

![](https://www.startupbangladesh.vc/wp-content/uploads/2026/06/Dilruba-Shaheena-1.jpg) 

#### Dilruba Shaheena

Member, Board of Directors, Startup Bangladesh Limited and Additional Secretary, Finance Division, Ministry of Finance

[Explore Profile](https://www.startupbangladesh.vc/bods/dilruba-shaheena/)

![](https://www.startupbangladesh.vc/wp-content/uploads/2021/07/Arif-Khan-1.jpg) 

#### ARIF KHAN

Independent Director, Board of Directors, Startup Bangladesh Limited and Vice Chairman of Shanta Asset Management

[Explore Profile](https://www.startupbangladesh.vc/bods/arif-khan/)

![](https://www.startupbangladesh.vc/wp-content/uploads/2025/02/FERDAUS-ARA-BEGUM-1.jpg) 

#### FERDAUS ARA BEGUM

Independent Director, Board of Directors, Startup Bangladesh Limited and Chief Executive Officer, Business Initiative Leading Development (BUILD)

[Explore Profile](https://www.startupbangladesh.vc/bods/ferdaus-ara-begum/)

![](https://www.startupbangladesh.vc/wp-content/uploads/2025/02/Tanveer-Ali-1.jpg) 

#### Tanveer Ali

Independent Director, Board of Directors, Startup Bangladesh Limited and Chairman, Constellation Asset Management Company Limited

[Explore Profile](https://www.startupbangladesh.vc/bods/tanveer-ali/)

![](https://www.startupbangladesh.vc/wp-content/uploads/2020/12/WhatsApp-Image-2026-02-17-at-1.27.27-PM.jpeg) 

#### Nurul Hai

Member, Board of Directors and Managing Director, Startup Bangladesh Limited

[Explore Profile](https://www.startupbangladesh.vc/bods/nurul-hai/)

© 2025 Startup Bangladesh Limited