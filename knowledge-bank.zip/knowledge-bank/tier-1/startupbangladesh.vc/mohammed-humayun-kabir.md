---
source: "Startup Bangladesh Limited"
tier: 1
category: "Government VC"
url: "https://www.startupbangladesh.vc/bods/mohammed-humayun-kabir/"
title: "Startup Bangladesh Limited - Mohammed Humayun KabirStartup Bangladesh Limited - Mohammed Humayun Kabir"
scraped_at: "2026-07-02"
---

![](https://www.startupbangladesh.vc/wp-content/uploads/2026/06/Mohammed-Humayun-Kabir.jpg)

Member, Board of Directors, Startup Bangladesh Limited and Additional Secretary, Cabinet Division

## Mohammed Humayun Kabir