---
source: "Startup Bangladesh Limited"
tier: 1
category: "Government VC"
url: "https://www.startupbangladesh.vc/apply-for-fund-of-funds/"
title: "Startup Bangladesh Limited - Apply for Fund of FundsStartup Bangladesh Limited - Apply for Fund of Funds"
scraped_at: "2026-07-02"
---

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/) 

[Apply Now](http://www.startupbangladesh.vc/contact/apply-for-investment/)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg) 

#### about

#### Fund of Funds

#### Portfolio

#### Partners

#### NRB Connect

#### media

#### career

#### contact

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/des-close.svg)

#### Bangladesh National Parliament House

Jatiya Sangsad Bhaban or National Parliament House, is the house of the Parliament of Bangladesh, located at Sher-e-Bangla Nagar in the Bangladeshi capital of Dhaka.

[Learn more](javascript:)

Photo by Unknown

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/)  

[Apply Now](https://www.startupbangladesh.vc/contact/apply-for-investment/)

-   -   [About](javascript:)
        
    -   [Fund of Funds](javascript:)
        
    -   [Portfolio](javascript:)
        
    -   [Partners](javascript:)
        
    -   [NRB Connect](javascript:)
        
    -   [media](javascript:)
        
    -   [career](javascript:)
        
    -   [contact](javascript:)
        

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

-   [](https://www.startupbangladesh.vc/eligibility-criteria-for-fund-managers)
-   [](https://www.startupbangladesh.vc/fund-of-funds-overview/)

Apply for Fund of Funds ![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/caret.svg) 

-   [Fund of Funds Overview](https://www.startupbangladesh.vc/fund-of-funds-overview/)
-   [Eligibility Criteria for Fund Managers](https://www.startupbangladesh.vc/eligibility-criteria-for-fund-managers/)
-   [Apply for Fund of Funds](https://www.startupbangladesh.vc/apply-for-fund-of-funds/)

## Apply for Fund of Funds

Fund Name:

Fund Manager Name:

Asset Under Management (In Millions USD):

Email:

Phone Number:

Website:

Type of Fund:—Please choose an option—Venture CapitalPrivate EquityVenture DebtPrivate Credit

Stage:—Please choose an option—Incubator/AcceleratorEarly StageLate StageGrowthBuyoutOthers

Sector Focus:  
AgnosticFintechEdtechAgritechSAASAILogistic & TravelFoodtechHealthEntertainment and LifestyleOthers (If chosen please define below)

Target Fund Size (In Millions USD):

Allocation for Bangladesh as a Percentage of The Target Fund Size:

GP Commitment as a Percentage of The Target Fund Size:

How much have you raised so far? (In Millions USD):

Who are your Biggest LPs?:

Discuss your Deal Sourcing Model and Capability in Bangladesh:

Provide Fund's pitch deck link (PDF Only):  

I confirm that the information above is accurate and that the application submission does not constitute an investment approval.

© 2025 Startup Bangladesh Limited