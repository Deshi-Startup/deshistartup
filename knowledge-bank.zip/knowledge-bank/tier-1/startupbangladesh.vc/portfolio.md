---
source: "Startup Bangladesh Limited"
tier: 1
category: "Government VC"
url: "https://www.startupbangladesh.vc/portfolio-2/portfolio/"
title: "Startup Bangladesh Limited - Our PortfolioStartup Bangladesh Limited - Our Portfolio"
scraped_at: "2026-07-02"
---

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/) 

[Apply Now](http://www.startupbangladesh.vc/contact/apply-for-investment/)

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg) 

#### about

#### Fund of Funds

#### Portfolio

#### Partners

#### NRB Connect

#### media

#### career

#### contact

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/des-close.svg)

#### Bangladesh National Parliament House

Jatiya Sangsad Bhaban or National Parliament House, is the house of the Parliament of Bangladesh, located at Sher-e-Bangla Nagar in the Bangladeshi capital of Dhaka.

[Learn more](javascript:)

Photo by Unknown

[![Startup Bangladesh Limited](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/SBL-Logo-svg.svg)](https://www.startupbangladesh.vc/)  

[Apply Now](https://www.startupbangladesh.vc/contact/apply-for-investment/)

-   -   [About](javascript:)
        
    -   [Fund of Funds](javascript:)
        
    -   [Portfolio](javascript:)
        
    -   [Partners](javascript:)
        
    -   [NRB Connect](javascript:)
        
    -   [media](javascript:)
        
    -   [career](javascript:)
        
    -   [contact](javascript:)
        

![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/blur.jpg)

-   [](https://www.startupbangladesh.vc/portfolio-2/portfolio-philosophy/)
-   [](https://www.startupbangladesh.vc/portfolio-2/portfolio-philosophy/)

Our Portfolio ![](https://www.startupbangladesh.vc/wp-content/themes/sbw/assets/images/static/caret.svg) 

-   [Philosophy](https://www.startupbangladesh.vc/portfolio-2/portfolio-philosophy/)
-   [Our Portfolio](https://www.startupbangladesh.vc/portfolio-2/portfolio/)

## Our Portfolio

All Sectors Fintech Education & Learning Healthcare & Life Science Media, Entertainment & Communication Retail, E-commerce & Consumer Agriculture & Food Software, SaaS & B2B Solution Mobility, Logistics & Transport Hospitality & Tourism Gaming & Sports AI, Deep-Tech & Frontier Tech

[](https://www.startupbangladesh.vc/portfolio/ifarmer/)![](https://www.startupbangladesh.vc/wp-content/uploads/2022/03/iFarmer-Logo-png-English.png)

iFarmer

[](https://www.startupbangladesh.vc/portfolio/10-minute-school/)![](https://www.startupbangladesh.vc/wp-content/uploads/2022/03/10MS-Logo.png)

10 Minute School

[](https://www.startupbangladesh.vc/portfolio/chaldal/)![](https://www.startupbangladesh.vc/wp-content/uploads/2021/07/Chaldal-BrandID-2021.png)

Chaldal

[](https://www.startupbangladesh.vc/portfolio/pickaboo/)![](https://www.startupbangladesh.vc/wp-content/uploads/2023/01/pickaboo-logo.png)

Pickaboo

[](https://www.startupbangladesh.vc/portfolio/sharetrip/)![](https://www.startupbangladesh.vc/wp-content/uploads/2022/11/sharetrip.png)

ShareTrip

[](https://www.startupbangladesh.vc/portfolio/sheba/)![](https://www.startupbangladesh.vc/wp-content/uploads/2021/07/SPL-Logo-Horizontal.png)

Sheba Platform Limited

[](https://www.startupbangladesh.vc/portfolio/markopolo/)![](https://www.startupbangladesh.vc/wp-content/uploads/2023/05/Markopolo-featured.jpg)

Markopolo

[](https://www.startupbangladesh.vc/portfolio/pulse-tech/)![](https://www.startupbangladesh.vc/wp-content/uploads/2024/06/pulsetech-1.png)

Pulse Tech

[](https://www.startupbangladesh.vc/portfolio/shikho/)![](https://www.startupbangladesh.vc/wp-content/uploads/2025/05/Shikho-Logo-jpg.jpg)

Shikho

[](https://www.startupbangladesh.vc/portfolio/pathao/)![](https://www.startupbangladesh.vc/wp-content/uploads/2021/04/Pathao_new2.png)

Pathao

[](https://www.startupbangladesh.vc/portfolio/truck-lagbe/)![](https://www.startupbangladesh.vc/wp-content/uploads/2022/03/Truck-Lagbe-Logo-03.png)

Truck Lagbe

[](https://www.startupbangladesh.vc/portfolio/hishab/)![](https://www.startupbangladesh.vc/wp-content/uploads/2024/01/Hishab-Logo.png)

Hishab

[](https://www.startupbangladesh.vc/portfolio/arogga/)![](https://www.startupbangladesh.vc/wp-content/uploads/2023/09/Arogga.jpg)

Arogga

[](https://www.startupbangladesh.vc/portfolio/frontier-nutrition/)![](https://www.startupbangladesh.vc/wp-content/uploads/2022/03/care-nutrition-logo.png)

Care Nutrition

[](https://www.startupbangladesh.vc/portfolio/medeasy/)![](https://www.startupbangladesh.vc/wp-content/uploads/2023/08/Medeasy.png)

MedEasy

[](https://www.startupbangladesh.vc/portfolio/amarlab/)![](https://www.startupbangladesh.vc/wp-content/uploads/2023/03/amarlab-logo.png)

AmarLab

[](https://www.startupbangladesh.vc/portfolio/bimafy/)![](https://www.startupbangladesh.vc/wp-content/uploads/2023/01/Bimafy-Logo.png)

Bimafy

[](https://www.startupbangladesh.vc/portfolio/bongo-bd/)![](https://www.startupbangladesh.vc/wp-content/uploads/2023/08/bongo-logo.png)

Bongo BD

[](https://www.startupbangladesh.vc/portfolio/moner-bondhu/)![](https://www.startupbangladesh.vc/wp-content/uploads/2021/04/Moner-Bondhu_logo-new.png)

Moner Bondhu

[](https://www.startupbangladesh.vc/portfolio/dhakacast/)![](https://www.startupbangladesh.vc/wp-content/uploads/2021/07/Dhaka_Cast_logo-01.png)

DhakaCast

[](https://www.startupbangladesh.vc/portfolio/open-refactory/)![](https://www.startupbangladesh.vc/wp-content/uploads/2023/03/open-refactory-logo.png)

Open Refactory

[](https://www.startupbangladesh.vc/portfolio/dubotech-digital/)![](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/Dubotech-Digital-Limited-logo.jpg)

Dubotech Digital

[](https://www.startupbangladesh.vc/portfolio/intelligent-machines/)![](https://www.startupbangladesh.vc/wp-content/uploads/2021/07/Intelligent-Machines-Logo-Full-Color.png)

Intelligent Machines

[](https://www.startupbangladesh.vc/portfolio/loop/)![](https://www.startupbangladesh.vc/wp-content/uploads/2022/03/Logo-1-01.png)

Loop

[](https://www.startupbangladesh.vc/portfolio/shuttle/)![](https://www.startupbangladesh.vc/wp-content/uploads/2022/03/Shuttle-logo-white-01.jpg)

Shuttle

[](https://www.startupbangladesh.vc/portfolio/swap/)![](https://www.startupbangladesh.vc/wp-content/uploads/2022/11/swap.png)

Swap

[](https://www.startupbangladesh.vc/portfolio/vroom/)![](https://www.startupbangladesh.vc/wp-content/uploads/2022/11/vroom2.png)

Vroom

[](https://www.startupbangladesh.vc/portfolio/zantrik/)![](https://www.startupbangladesh.vc/wp-content/uploads/2022/03/Zantrik_Logo.png)

Zantrik

[](https://www.startupbangladesh.vc/portfolio/pavilion/)![](https://www.startupbangladesh.vc/wp-content/uploads/2023/12/pavilion-logo.jpg)

Pavilion

[](https://www.startupbangladesh.vc/portfolio/myalice/)![](https://www.startupbangladesh.vc/wp-content/uploads/2023/12/myalice-logo.svg)

myalice

[](https://www.startupbangladesh.vc/portfolio/parents-care/)![](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/ParentsCare​-logo.jpg)

Parents Care​

[](https://www.startupbangladesh.vc/portfolio/english-champ/)![](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/English-Champ-Logo-Orange.png)

English Champ​

[](https://www.startupbangladesh.vc/portfolio/sokrio-technologies/)![](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/Sokrio-Technologies-Limited-logo.png)

Sokrio Technologies

[](https://www.startupbangladesh.vc/portfolio/booktionary/)![](https://www.startupbangladesh.vc/wp-content/uploads/2024/11/Booktionary-logo.png)

Booktionary​

[](https://www.startupbangladesh.vc/portfolio/hellotask/)![](https://www.startupbangladesh.vc/wp-content/uploads/2022/03/Hellotask-New-Logo.png)

HelloTask

© 2025 Startup Bangladesh Limited